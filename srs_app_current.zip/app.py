import streamlit as st
import ollama

from tab_upload   import render_upload_tab
from tab_generate import render_generate_tab
from tab_preview  import render_preview_tab

# ─── Page Config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="SRS Report Generator",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ─── Session State ────────────────────────────────────────────────────────────
def init_state():
    defaults = {
        "project_files":    {},
        "srs_sections":     {},
        "generation_order": [],
        "ollama_host":      "http://127.0.0.1:11434",
        "current_model":    "gpt-oss:20b",
        "active_tab":       "upload",
        "full_srs_doc":     "",
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()

# ─── Ollama client ────────────────────────────────────────────────────────────
try:
    client = ollama.Client(host=st.session_state.ollama_host)
except Exception as e:
    st.error(f"❌ Ollama connection failed: {e}")
    st.stop()

# ─── Header ───────────────────────────────────────────────────────────────────
st.markdown(""" <h1 style="text-align:center; font-size:90px;">SRS Document Generation</h1> """, unsafe_allow_html=True)

# ─── Tabs ─────────────────────────────────────────────────────────────────────
tab_upload, tab_generate, tab_preview = st.tabs([
    "📁  Upload Project",
    "⚡  Generate Sections",
    "📄  Preview & Export",
])

with tab_upload:
    render_upload_tab()

with tab_generate:
    render_generate_tab(client)

with tab_preview:
    render_preview_tab()
