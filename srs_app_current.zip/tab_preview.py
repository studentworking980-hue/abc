# tab_preview.py — Tab 3: Preview & Export

import streamlit as st
from constants import SRS_SECTIONS
from helpers import assemble_full_srs, download_full_srs, download_section


def render_preview_tab():
    done_count = len([k for k in SRS_SECTIONS if k in st.session_state.srs_sections
                      and st.session_state.srs_sections[k].strip()])

    if done_count == 0:
        st.warning("⚠️ No sections generated yet. Go to the **Generate Sections** tab to build your SRS.")
        return

    st.markdown(f"### 📄 SRS Document Preview — {done_count}/{len(SRS_SECTIONS)} Sections")

    col_dl1, col_dl2, col_dl3 = st.columns(3)
    with col_dl1:
        download_full_srs(st.session_state.srs_sections)
    with col_dl2:
        full_doc = assemble_full_srs(st.session_state.srs_sections)
        st.metric("Estimated Pages", f"~{max(1, len(full_doc) // 3000)} pages")
    with col_dl3:
        st.metric("Total Characters", f"{len(full_doc):,}")

    st.markdown("---")

    # Table of contents
    st.markdown("#### 📑 Table of Contents")
    for sec_key, sec_meta in SRS_SECTIONS.items():
        is_done = sec_key in st.session_state.srs_sections and st.session_state.srs_sections[sec_key].strip()
        status  = "✅" if is_done else "⬜"
        st.markdown(f"{status} {sec_meta['title']}")
        for sub_title in sec_meta.get("subsections", {}).values():
            st.markdown(f"&nbsp;&nbsp;&nbsp;&nbsp;— {sub_title}")

    st.markdown("---")
    st.markdown("#### 📖 Full Document")

    # Render each section
    for sec_key, sec_meta in SRS_SECTIONS.items():
        if sec_key in st.session_state.srs_sections and st.session_state.srs_sections[sec_key].strip():
            with st.expander(f"📝 {sec_meta['title']}", expanded=False):
                st.markdown(st.session_state.srs_sections[sec_key])
                col_a, col_b = st.columns(2)
                with col_a:
                    download_section(sec_key, st.session_state.srs_sections[sec_key])
                with col_b:
                    if st.button("📋 Raw Text", key=f"preview_raw_{sec_key}"):
                        st.code(st.session_state.srs_sections[sec_key])
