# tab_generate.py — Tab 2: Generate Sections

import streamlit as st
from constants import SRS_SECTIONS
from helpers import build_srs_prompt, call_ollama_stream, download_section


def render_generate_tab(client):
    if not st.session_state.project_files:
        st.warning("⚠️ Please upload your project archive first in the **Upload Project** tab.")
        return

    st.markdown("### ⚡ Generate SRS Sections")
    st.info(
        "Each section is generated independently so the AI can focus deeply on each part. "
        "Generate them in order, or pick any section to regenerate. "
        "All sections are saved automatically."
    )

    # ── Generate All / Clear buttons ─────────────────────────────────────────
    col_all1, col_all2 = st.columns([2, 1])
    with col_all1:
        gen_all = st.button(
            "🚀 Generate ALL Sections Sequentially",
            use_container_width=True,
            type="primary",
            key="gen_all_btn",
            disabled=not st.session_state.project_files,
        )
    with col_all2:
        if st.button("🗑️ Clear All Sections", use_container_width=True, key="clear_all"):
            st.session_state.srs_sections = {}
            st.rerun()

    st.markdown("---")

    # ── Generate ALL flow ─────────────────────────────────────────────────────
    if gen_all:
        for sec_key in SRS_SECTIONS:
            sec_meta = SRS_SECTIONS[sec_key]
            st.markdown(f"#### ⚙️ Generating: {sec_meta['title']}…")
            prompt = build_srs_prompt(sec_key, st.session_state.project_files)
            result = call_ollama_stream(client, prompt)
            if result:
                st.session_state.srs_sections[sec_key] = result
            st.success(f"✅ {sec_meta['title']} — Done")
            st.markdown("---")
        #st.balloons()
        st.success("🎉 All sections generated! Go to the **Preview & Export** tab.")
        return

    # ── Per-section cards ─────────────────────────────────────────────────────
    for sec_key, sec_meta in SRS_SECTIONS.items():
        is_done = sec_key in st.session_state.srs_sections and st.session_state.srs_sections[sec_key].strip()
        card_cls = "section-card section-done" if is_done else "section-card section-pending"
        badge    = '<span class="status-badge-done">✅ Generated</span>' if is_done else '<span class="status-badge-pending">⬜ Pending</span>'

        st.markdown(f'<div class="{card_cls}">', unsafe_allow_html=True)
        c1, c2, c3 = st.columns([3, 1, 1])
        with c1:
            st.markdown(f"**{sec_meta['title']}** &nbsp; {badge}", unsafe_allow_html=True)
            if sec_meta.get("subsections"):
                subs = " · ".join(sec_meta["subsections"].values())
                st.caption(subs)
        with c2:
            if st.button(
                "🔄 Regenerate" if is_done else "▶️ Generate",
                use_container_width=True,
                key=f"gen_{sec_key}",
            ):
                st.session_state[f"generating_{sec_key}"] = True
        with c3:
            if is_done:
                if st.button("👁️ View", use_container_width=True, key=f"view_{sec_key}"):
                    st.session_state[f"expand_{sec_key}"] = not st.session_state.get(f"expand_{sec_key}", False)

        st.markdown("</div>", unsafe_allow_html=True)

        # Handle generation
        if st.session_state.get(f"generating_{sec_key}"):
            st.session_state[f"generating_{sec_key}"] = False
            with st.container():
                st.markdown(f"#### ⚙️ Generating: {sec_meta['title']}…")
                prompt = build_srs_prompt(sec_key, st.session_state.project_files)
                result = call_ollama_stream(client, prompt)
                if result:
                    st.session_state.srs_sections[sec_key] = result
                    st.success(f"✅ {sec_meta['title']} saved!")
                    st.rerun()

        # Handle inline view toggle
        if st.session_state.get(f"expand_{sec_key}") and is_done:
            with st.expander(f"📖 {sec_meta['title']} — Preview", expanded=True):
                st.markdown(st.session_state.srs_sections[sec_key])
                col_dl, col_copy = st.columns(2)
                with col_dl:
                    download_section(sec_key, st.session_state.srs_sections[sec_key])
                with col_copy:
                    if st.button("📋 Show Raw", key=f"raw_{sec_key}"):
                        st.code(st.session_state.srs_sections[sec_key])
