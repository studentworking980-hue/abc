# tab_upload.py — Tab 1: Upload Project

import streamlit as st
from helpers import extract_zip, extract_tar, language_counts, total_size_kb


def render_upload_tab():
    st.markdown("### Upload Your Project Codebase")
    st.info(
        "Upload a **ZIP or TAR.GZ archive** of your project folder. "
        "All code files (Python, Java, JS, C++, HTML, SQL, etc.) will be extracted and analysed. "
        "The AI will read the entire codebase to generate a professional SRS document."
    )

    col_up, col_info = st.columns([1, 1], gap="large")

    with col_up:
        archive = st.file_uploader(
            "Project Archive (ZIP / TAR.GZ)",
            type=["zip", "tar", "gz", "tgz"],
            key="project_uploader",
        )

        if archive:
            with st.spinner("🔍 Extracting and indexing files…"):
                loaded = (
                    extract_zip(archive)
                    if archive.name.lower().endswith(".zip")
                    else extract_tar(archive)
                )
            if loaded:
                st.session_state.project_files = loaded
                st.session_state.srs_sections  = {}
                st.markdown(
                    f'<div class="strip-success">✅ Successfully loaded <strong>{len(loaded)}</strong> '
                    f'files from <strong>{archive.name}</strong> '
                    f'({total_size_kb(loaded):.1f} KB total)</div>',
                    unsafe_allow_html=True,
                )
            else:
                st.warning("⚠️ No supported code files found in the archive.")

    with col_info:
        if st.session_state.project_files:
            files = st.session_state.project_files
            st.markdown("### 📊 Project Analysis")
            st.metric("Total Files", len(files))
            st.metric("Total Size", f"{total_size_kb(files):.1f} KB")

            lang_data = language_counts(files)
            st.markdown("**Languages / File Types Detected:**")
            for lang, cnt in sorted(lang_data.items(), key=lambda x: -x[1]):
                bar_w = int(cnt / max(lang_data.values()) * 100)
                st.markdown(
                    f"`{lang}` — {cnt} file(s) "
                    f'<div style="background:#1a4fa3;height:6px;width:{bar_w}%;border-radius:4px;margin-bottom:4px"></div>',
                    unsafe_allow_html=True
                )
        else:
            st.markdown("### 💡 Tips")
            st.markdown("""
- Compress your entire project folder into a `.zip` or `.tar.gz`.
- Include all source files: backend, frontend, configs, SQL schemas, README, etc.
- The more code uploaded, the more accurate and detailed the SRS will be.
- Large projects (100+ files) will produce a more comprehensive document.
            """)

    if st.session_state.project_files:
        st.markdown("---")
        st.success("✅ Project loaded! Go to the **Generate Sections** tab to start building your SRS.")
