# Quality Assurance Plan Document of S-Band 2-Watt Transmitter for Project SAAW

![](images/d7a6a8df4be9c23b0f96890ae218822a3af3099ceb5c973800db85dc9c89aa3b.jpg)

<table><tr><td>Document No.</td><td>EIWAVE/TX222SAW/QAP</td></tr><tr><td>PO No</td><td>3220010735, Dated: 16thNov 2022</td></tr><tr><td>Model No./Part No.</td><td>EI-02-SB-2W-TX</td></tr><tr><td>Date of Issue</td><td>10thApril 2025</td></tr><tr><td>No. of Pages</td><td>54</td></tr></table>

# EI WAVE DIGITECH (I) PVT LTD

![](images/84f597cffa9a3cebbb21d5bcf8fcff6d3ec46c616b70ef60a4e70a11a8c1f3fa.jpg)

Website: www.eiwave.com

E-mail: sales@eiwave.com

8-2-693/2/29, Mithila Nagar, Banjara Hills Road No:12, Hyderabad -500 034, T.S., INDIA

Email - sales@eiwave.com PH No: 040 - 23376799

![](images/2c4579e4bcc0195471a29edf6ef2d7a5f73bb70e1d3ed7cea8de7317c0dbde82.jpg)

![](images/cac0341f401b8c7c24be6e9bd0bbdf575b840f8ce8a5f08518ff45480ab285e7.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td rowspan="4" colspan="2">RCI - DRDO</td><td>Document No.:</td><td colspan="3">EIWAVE/TX222SAW/QAP</td></tr><tr><td>Issue No.:</td><td>01</td><td>Issue Date:</td><td>10thApril 2025</td></tr><tr><td>Copy No.:</td><td>01</td><td>No. of Pages:</td><td>54</td></tr><tr><td colspan="2">Document Classification</td><td colspan="2">Restricted</td></tr><tr><td colspan="4">Title:</td><td colspan="2">Project/ System :</td></tr><tr><td rowspan="3" colspan="4">Quality Assurance Plan Document of S-Band 2-Watt Transmitter for Project SAAW</td><td colspan="2">SAAW</td></tr><tr><td colspan="2">Part No.</td></tr><tr><td colspan="2">EI-02-SB-2W-TX</td></tr><tr><td>Task</td><td colspan="2">Group</td><td colspan="2">Members</td><td>Signature</td></tr><tr><td rowspan="2">Prepared By</td><td colspan="2">EI WAVE DIGITECH</td><td colspan="2">Anand Kumar, Jr. Engr</td><td>Amit Kawai</td></tr><tr><td colspan="2">EI WAVE DIGITECH</td><td colspan="2">K.Ramesh Babu, Sr.Engr</td><td>K.Panish Babu</td></tr><tr><td rowspan="3">Verified By</td><td colspan="2">EI WAVE DIGITECH</td><td colspan="2">Arun Verma, COO</td><td>Arun</td></tr><tr><td colspan="2">DOFI, RCI</td><td colspan="2">Rohit Kumar Upadhyaya, Sc &#x27;B&#x27;</td><td>Rupadhyaya</td></tr><tr><td colspan="2">Project EO -SAAW</td><td colspan="2">Naresh Bhukya, Sc &#x27;E&#x27;</td><td>A. Reeth</td></tr><tr><td rowspan="3">Reviewed By</td><td colspan="2">DR&amp;QA,RCI (Elec)</td><td colspan="2">Anil Kumar Prajapati, Sc &#x27;B&#x27;</td><td>Vshil Kumar 18/02/2026</td></tr><tr><td colspan="2">RCMA (Missile)</td><td colspan="2">B.Sri latha, Sc &#x27;D&#x27;</td><td></td></tr><tr><td colspan="2">DOFI,RCI</td><td colspan="2">Dr. K. Sudarsana Reddy, Sc &#x27;G&#x27;</td><td></td></tr><tr><td rowspan="3">Approved By</td><td colspan="2">DR&amp;QA,RCI(TD-Elec)</td><td colspan="2">Dr.G.Mallikarjuna Rao, Sc &#x27;G&#x27;</td><td></td></tr><tr><td colspan="2">DOFI,RCI (TD)</td><td colspan="2">M.Atul Pawar, Sc &#x27;H&#x27;</td><td></td></tr><tr><td colspan="2">RCMA (Missile), RD</td><td colspan="2">Dr. Akhilesh Pathak, OS</td><td></td></tr><tr><td>Issue Authorized By</td><td colspan="2">PD, EO-SAAW</td><td colspan="2">Vinod Kumar Kabra, Sc &#x27;G&#x27;</td><td></td></tr><tr><td colspan="6">EI WAVE DIGITECH (I) PVT LTD
8-2-693/2/29, Mithila Nagar, Banjara Hills Road No:12,
Hyderabad -500 034, T.S., INDIA
Email - sales@eiwave.com PH No: 040 - 23376799</td></tr><tr><td colspan="6">Distribution List:
1) Project EO-SAAW
2) DOFI-RCI
3) RCMA (Missile)
4) DR&amp;QA</td></tr></table>

![](images/40956cb7cd9ae9b236bc6f6c444cb6225ec694d3502b82a78dc10b1b832d4fd1.jpg)

AMENDMENTS RECORD SHEET   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td rowspan="2">S.No</td><td colspan="2">Amendment</td><td rowspan="2">Amendment pertains to S.No/ Para No/ Column No</td><td rowspan="2">Authority</td><td rowspan="2">Amended by name
(Signature &amp; Date)</td></tr><tr><td>Number</td><td>Date</td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr></table>

NOTE:   
Entries to be made by holder of the document as and when amendment/addendum to the Document received, duly vetted by the stakeholders

![](images/50a28c4c99d7449381e66bbdde33d7125d9747ea585b61f98219b22ab3985609.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr><tr><td colspan="4">ABBREVIATION</td></tr><tr><td>PREET :</td><td colspan="3">Pre- Environmental Test</td></tr><tr><td>INSET :</td><td colspan="3">In SITU Environmental Test</td></tr><tr><td>POET :</td><td colspan="3">Post Environmental Test</td></tr><tr><td>AT :</td><td colspan="3">Acceptance Tests</td></tr><tr><td>QT :</td><td colspan="3">Qualification Tests</td></tr><tr><td>TS :</td><td colspan="3">Technical Specifications</td></tr><tr><td>VCO :</td><td colspan="3">Voltage Controlled Oscillator</td></tr><tr><td>TCXO :</td><td colspan="3">Temperature Compensated Crystal Oscillator</td></tr><tr><td>PLL :</td><td colspan="3">Phase-Locked Loop</td></tr><tr><td>RF :</td><td colspan="3">Radio Frequency</td></tr><tr><td>PFD :</td><td colspan="3">Phase-Frequency Detector</td></tr><tr><td>UUT :</td><td colspan="3">Unit Under Test</td></tr><tr><td>FM :</td><td colspan="3">Frequency Modulation</td></tr><tr><td>EMI :</td><td colspan="3">Electro Magnetic Interference</td></tr><tr><td>EMC :</td><td colspan="3">Electro Magnetic Compatibility</td></tr><tr><td>ESS :</td><td colspan="3">Environmental Stress Screening</td></tr><tr><td>EUT :</td><td colspan="3">Equipment Under Test</td></tr><tr><td>LISN :</td><td colspan="3">Line Impedance Stabilization Network</td></tr></table>

![](images/165295fbe23916ba13c113ddf93c22fff11255337e08ebb69fba8b4a1e3e28f3.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr><tr><td colspan="4">CONTENTS</td></tr><tr><td>1 INTRODUCTION</td><td></td><td></td><td>9</td></tr><tr><td>1.1 Scope</td><td></td><td></td><td>9</td></tr><tr><td>1.2 Description and BLOCK DIAGRAM</td><td></td><td></td><td>9</td></tr><tr><td>2 List of applicable Document</td><td></td><td></td><td>11</td></tr><tr><td>3 Reference Standards</td><td></td><td></td><td>11</td></tr><tr><td>4 TECHNICAL SPECIFICATIONS OF &quot;S-BAND 2WATT TRANSMITTER&quot;</td><td></td><td></td><td>12</td></tr><tr><td>4.1 Electrical specifications</td><td></td><td></td><td>12</td></tr><tr><td>4.1.1 Power Supply Requirements</td><td></td><td></td><td>12</td></tr><tr><td>4.1.2 Input Specifications</td><td></td><td></td><td>12</td></tr><tr><td>4.1.3 Output Specifications</td><td></td><td></td><td>13</td></tr><tr><td>4.2 Mechanical Specifications</td><td></td><td></td><td>13</td></tr><tr><td>4.3 Operational Requirements</td><td></td><td></td><td>14</td></tr><tr><td>4.4 Operating &amp; Storage Temperature</td><td></td><td></td><td>14</td></tr><tr><td>4.5 Reliability Requirement</td><td></td><td></td><td>14</td></tr><tr><td>4.6 Storage Details</td><td></td><td></td><td>14</td></tr><tr><td>4.7 Grounding Scheme</td><td></td><td></td><td>14</td></tr><tr><td>5 Electrical Interface Requirements (Connectors)</td><td></td><td></td><td>15</td></tr><tr><td>5.1 J1 Connector Details</td><td></td><td></td><td>15</td></tr><tr><td>5.2 J2, j3 Connector details</td><td></td><td></td><td>16</td></tr><tr><td>5.3 J4 Connector details</td><td></td><td></td><td>16</td></tr><tr><td>6 Quality Assurance Plan</td><td></td><td></td><td>17</td></tr><tr><td>7 Qualification Test Flow Chart</td><td></td><td></td><td>18</td></tr><tr><td>8 CEMILAC SCREENING TEST FOR POPULATED PCBS</td><td></td><td></td><td>19</td></tr><tr><td>8.1 Visual Examination</td><td></td><td></td><td>19</td></tr><tr><td>8.2 high Temperature storage (Stabilization Bake) Test</td><td></td><td></td><td>19</td></tr><tr><td>8.3 Thermal Shock Test</td><td></td><td></td><td>20</td></tr><tr><td>8.4 Burn-in Test</td><td></td><td></td><td>21</td></tr><tr><td>9 Acceptance Test Flow Chart</td><td></td><td></td><td>22</td></tr><tr><td>10 Agencies</td><td></td><td></td><td>23</td></tr><tr><td>11 Quality Assurance</td><td></td><td></td><td>23</td></tr><tr><td>12 Incoming Inspection Stage</td><td></td><td></td><td>24</td></tr><tr><td>13 Incoming Good Inspection</td><td></td><td></td><td>25</td></tr><tr><td>13.1 Introduction</td><td></td><td></td><td>25</td></tr><tr><td>13.2 Sub System / Sub Assembly</td><td></td><td></td><td>25</td></tr></table>

![](images/2c8cf2838328a30361754ecb74efcd320a37b7fddb84139aef4cab1de021c321.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr><tr><td>13.3 Out Sourcing of Material / Work</td><td colspan="3">26</td></tr><tr><td>13.4 Mechanical Items</td><td colspan="3">26</td></tr><tr><td>13.5 Imported Components</td><td colspan="3">26</td></tr><tr><td>13.6 Standard bought-out items</td><td colspan="3">27</td></tr><tr><td>13.7 Sub contract items (Quality standards, traceability to be included)</td><td colspan="3">27</td></tr><tr><td>13.8 Mechanical manufactured/fabricated parts</td><td colspan="3">27</td></tr><tr><td>13.9 PRE-REQUISITES for Testing</td><td colspan="3">28</td></tr><tr><td>13.10 Non-Conformance</td><td colspan="3">29</td></tr><tr><td>13.11 Production Quality Test (PQT)</td><td colspan="3">29</td></tr><tr><td>14 Traceability and Identification</td><td colspan="3">29</td></tr><tr><td>14.1 Identification</td><td colspan="3">29</td></tr><tr><td>14.2 Traceability</td><td colspan="3">29</td></tr><tr><td>14.3 Standard Operating Procedure</td><td colspan="3">30</td></tr><tr><td>14.4 Inwards Goods</td><td colspan="3">31</td></tr><tr><td>14.5 Finished Goods Production</td><td colspan="3">31</td></tr><tr><td>14.6 Storage</td><td colspan="3">32</td></tr><tr><td>14.7 Records</td><td colspan="3">32</td></tr><tr><td>15 Test jig / ATP software</td><td colspan="3">32</td></tr><tr><td>15.1 Implementation feed back</td><td colspan="3">32</td></tr><tr><td>15.2 Customer Communication</td><td colspan="3">32</td></tr><tr><td>15.3 Process Flow Chart-I</td><td colspan="3">33</td></tr><tr><td>15.4 Process Flow Chart-II</td><td colspan="3">35</td></tr><tr><td>15.5 DESCRIPTION OF Process Flow Chart-I</td><td colspan="3">38</td></tr><tr><td>16 QA Matrix</td><td colspan="3">42</td></tr><tr><td>17 QA Directive 06/2018- Kit of Parts</td><td colspan="3">46</td></tr><tr><td>18 MECHANICAL DIMENSION INSPECTION</td><td colspan="3">48</td></tr><tr><td>19 PCB Inspection REPORT</td><td colspan="3">49</td></tr><tr><td>20 Internal WIRING Diagram</td><td colspan="3">50</td></tr><tr><td>21 Safety Precaution</td><td colspan="3">51</td></tr><tr><td>22 Handling</td><td colspan="3">51</td></tr><tr><td>23 Packaging</td><td colspan="3">51</td></tr><tr><td>24 Storage</td><td colspan="3">51</td></tr><tr><td>25 Transportation Instruction</td><td colspan="3">51</td></tr><tr><td>26 Assembly And Disassembly</td><td colspan="3">52</td></tr><tr><td>27 Failure Analysis Report</td><td colspan="3">54</td></tr><tr><td colspan="4">EI Wave Digitech (I) Pvt Ltd., Hyderabad.</td></tr></table>

![](images/f004ce6ba4d1a796ae1a452f10614224e8537aa6858a74bd375b9398838be551.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr><tr><td colspan="4">List of Tables</td></tr><tr><td colspan="3">Table 1: Reference Documents</td><td>11</td></tr><tr><td colspan="3">Table 2: Reference Standards</td><td>11</td></tr><tr><td colspan="3">Table 3: Power Supply Requirements</td><td>12</td></tr><tr><td colspan="3">Table 4: Input Specifications</td><td>12</td></tr><tr><td colspan="3">Table 5: Output Specification</td><td>13</td></tr><tr><td colspan="3">Table 6: Mechanical Specification</td><td>13</td></tr><tr><td colspan="3">Table 7: Operational Requirements</td><td>14</td></tr><tr><td colspan="3">Table 8: Electrical Interface Requirements</td><td>15</td></tr><tr><td colspan="3">Table 9: J1 Connector Details</td><td>15</td></tr><tr><td colspan="3">Table 10: J2 &amp; J3 Connector Details</td><td>16</td></tr><tr><td colspan="3">Table 11: J4 Connector Details</td><td>16</td></tr><tr><td colspan="3">Table 12: Visual Examination Test</td><td>19</td></tr><tr><td colspan="3">Table 13: High Temperature Test</td><td>19</td></tr><tr><td colspan="3">Table 14: Thermal Shock test</td><td>20</td></tr><tr><td colspan="3">Table 15: Burn-in test</td><td>21</td></tr><tr><td colspan="3">Table 16: Agencies</td><td>23</td></tr><tr><td colspan="3">Table 17: QA Matrix</td><td>45</td></tr><tr><td colspan="3">Table 18: Wiring details</td><td>50</td></tr><tr><td colspan="4">List of figures</td></tr><tr><td colspan="3">Figure 1:Block Diagram of S-Band 2-Watt Transmitter</td><td>10</td></tr><tr><td colspan="3">Figure 2:Grounding Scheme</td><td>14</td></tr></table>

![](images/13bd8191fec7aa9f287409073a80ef4153863eef2ff6f1118c42794d22f8254f.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr><tr><td colspan="4">PROPRIETARY INFORMATION</td></tr><tr><td colspan="4">a) This document is proprietary of DRDO, Min. of Defence.</td></tr><tr><td colspan="4">b) This document along with drawings issued here with shall not be used for any other purpose whatsoever without the written permission of issuing authority.</td></tr><tr><td colspan="4">c) Any information contained in this document or drawings shall not be passed on to any person / Organization without the consent of RCI.</td></tr><tr><td colspan="4">d) This document along with all Drawings etc. must be returned on the submission of tender or on completion of the order.</td></tr><tr><td colspan="4">e) The vendor shall carefully read the document and the drawings supplied before commencing manufacture. Any errors, omission, ambiguity or clarification required shall be immediately reported to Document Issuing Authority and work shall not proceed on affected parts until the necessary authentic clearances are received.</td></tr><tr><td colspan="4">f) QC / QA shall be carried out by Main Contractor&#x27;s / Vendor&#x27;s QC. R&amp;QA shall be the QA authority as mentioned in Supply Order.</td></tr><tr><td colspan="4">g) Proposals for changes, if any, to any aspect in the document or to the drawing shall be addressed in the prescribed Amendment Format for Document / Drawing respectively to the issuing Authority. The Amendment approved by Project Director and issued from time to time shall be binding on the manufacturer.</td></tr><tr><td colspan="4">h) The Document Issuing Authority reserves the right to incorporate any changes in the specification and corresponding drawings without assigning any reasons thereof.</td></tr><tr><td colspan="4">i) Indian and International Standards have been referred and quoted in this document for reference.</td></tr><tr><td colspan="4">j) Any Changes to the QAP shall be with written Permission from R&amp;QA.</td></tr></table>

![](images/7288dec0b593a143ac3c0addcc7d66313a6550e0a65ec487e8615817607c3e9a.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>
# Quality Assurance Plan Document of S-Band 2-Watt Transmitter for Project SAAW

![](images/d7a6a8df4be9c23b0f96890ae218822a3af3099ceb5c973800db85dc9c89aa3b.jpg)

<table><tr><td>Document No.</td><td>EIWAVE/TX222SAW/QAP</td></tr><tr><td>PO No</td><td>3220010735, Dated: 16thNov 2022</td></tr><tr><td>Model No./Part No.</td><td>EI-02-SB-2W-TX</td></tr><tr><td>Date of Issue</td><td>10thApril 2025</td></tr><tr><td>No. of Pages</td><td>54</td></tr></table>

# EI WAVE DIGITECH (I) PVT LTD

![](images/84f597cffa9a3cebbb21d5bcf8fcff6d3ec46c616b70ef60a4e70a11a8c1f3fa.jpg)

Website: www.eiwave.com

E-mail: sales@eiwave.com

8-2-693/2/29, Mithila Nagar, Banjara Hills Road No:12, Hyderabad -500 034, T.S., INDIA

Email - sales@eiwave.com PH No: 040 - 23376799

![](images/2c4579e4bcc0195471a29edf6ef2d7a5f73bb70e1d3ed7cea8de7317c0dbde82.jpg)

![](images/cac0341f401b8c7c24be6e9bd0bbdf575b840f8ce8a5f08518ff45480ab285e7.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td rowspan="4" colspan="2">RCI - DRDO</td><td>Document No.:</td><td colspan="3">EIWAVE/TX222SAW/QAP</td></tr><tr><td>Issue No.:</td><td>01</td><td>Issue Date:</td><td>10thApril 2025</td></tr><tr><td>Copy No.:</td><td>01</td><td>No. of Pages:</td><td>54</td></tr><tr><td colspan="2">Document Classification</td><td colspan="2">Restricted</td></tr><tr><td colspan="4">Title:</td><td colspan="2">Project/ System :</td></tr><tr><td rowspan="3" colspan="4">Quality Assurance Plan Document of S-Band 2-Watt Transmitter for Project SAAW</td><td colspan="2">SAAW</td></tr><tr><td colspan="2">Part No.</td></tr><tr><td colspan="2">EI-02-SB-2W-TX</td></tr><tr><td>Task</td><td colspan="2">Group</td><td colspan="2">Members</td><td>Signature</td></tr><tr><td rowspan="2">Prepared By</td><td colspan="2">EI WAVE DIGITECH</td><td colspan="2">Anand Kumar, Jr. Engr</td><td>Amit Kawai</td></tr><tr><td colspan="2">EI WAVE DIGITECH</td><td colspan="2">K.Ramesh Babu, Sr.Engr</td><td>K.Panish Babu</td></tr><tr><td rowspan="3">Verified By</td><td colspan="2">EI WAVE DIGITECH</td><td colspan="2">Arun Verma, COO</td><td>Arun</td></tr><tr><td colspan="2">DOFI, RCI</td><td colspan="2">Rohit Kumar Upadhyaya, Sc &#x27;B&#x27;</td><td>Rupadhyaya</td></tr><tr><td colspan="2">Project EO -SAAW</td><td colspan="2">Naresh Bhukya, Sc &#x27;E&#x27;</td><td>A. Reeth</td></tr><tr><td rowspan="3">Reviewed By</td><td colspan="2">DR&amp;QA,RCI (Elec)</td><td colspan="2">Anil Kumar Prajapati, Sc &#x27;B&#x27;</td><td>Vshil Kumar 18/02/2026</td></tr><tr><td colspan="2">RCMA (Missile)</td><td colspan="2">B.Sri latha, Sc &#x27;D&#x27;</td><td></td></tr><tr><td colspan="2">DOFI,RCI</td><td colspan="2">Dr. K. Sudarsana Reddy, Sc &#x27;G&#x27;</td><td></td></tr><tr><td rowspan="3">Approved By</td><td colspan="2">DR&amp;QA,RCI(TD-Elec)</td><td colspan="2">Dr.G.Mallikarjuna Rao, Sc &#x27;G&#x27;</td><td></td></tr><tr><td colspan="2">DOFI,RCI (TD)</td><td colspan="2">M.Atul Pawar, Sc &#x27;H&#x27;</td><td></td></tr><tr><td colspan="2">RCMA (Missile), RD</td><td colspan="2">Dr. Akhilesh Pathak, OS</td><td></td></tr><tr><td>Issue Authorized By</td><td colspan="2">PD, EO-SAAW</td><td colspan="2">Vinod Kumar Kabra, Sc &#x27;G&#x27;</td><td></td></tr><tr><td colspan="6">EI WAVE DIGITECH (I) PVT LTD
8-2-693/2/29, Mithila Nagar, Banjara Hills Road No:12,
Hyderabad -500 034, T.S., INDIA
Email - sales@eiwave.com PH No: 040 - 23376799</td></tr><tr><td colspan="6">Distribution List:
1) Project EO-SAAW
2) DOFI-RCI
3) RCMA (Missile)
4) DR&amp;QA</td></tr></table>

![](images/40956cb7cd9ae9b236bc6f6c444cb6225ec694d3502b82a78dc10b1b832d4fd1.jpg)

AMENDMENTS RECORD SHEET   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td rowspan="2">S.No</td><td colspan="2">Amendment</td><td rowspan="2">Amendment pertains to S.No/ Para No/ Column No</td><td rowspan="2">Authority</td><td rowspan="2">Amended by name
(Signature &amp; Date)</td></tr><tr><td>Number</td><td>Date</td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2"></td><td></td><td></td><td></td></tr></table>

NOTE:   
Entries to be made by holder of the document as and when amendment/addendum to the Document received, duly vetted by the stakeholders

![](images/50a28c4c99d7449381e66bbdde33d7125d9747ea585b61f98219b22ab3985609.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr><tr><td colspan="4">ABBREVIATION</td></tr><tr><td>PREET :</td><td colspan="3">Pre- Environmental Test</td></tr><tr><td>INSET :</td><td colspan="3">In SITU Environmental Test</td></tr><tr><td>POET :</td><td colspan="3">Post Environmental Test</td></tr><tr><td>AT :</td><td colspan="3">Acceptance Tests</td></tr><tr><td>QT :</td><td colspan="3">Qualification Tests</td></tr><tr><td>TS :</td><td colspan="3">Technical Specifications</td></tr><tr><td>VCO :</td><td colspan="3">Voltage Controlled Oscillator</td></tr><tr><td>TCXO :</td><td colspan="3">Temperature Compensated Crystal Oscillator</td></tr><tr><td>PLL :</td><td colspan="3">Phase-Locked Loop</td></tr><tr><td>RF :</td><td colspan="3">Radio Frequency</td></tr><tr><td>PFD :</td><td colspan="3">Phase-Frequency Detector</td></tr><tr><td>UUT :</td><td colspan="3">Unit Under Test</td></tr><tr><td>FM :</td><td colspan="3">Frequency Modulation</td></tr><tr><td>EMI :</td><td colspan="3">Electro Magnetic Interference</td></tr><tr><td>EMC :</td><td colspan="3">Electro Magnetic Compatibility</td></tr><tr><td>ESS :</td><td colspan="3">Environmental Stress Screening</td></tr><tr><td>EUT :</td><td colspan="3">Equipment Under Test</td></tr><tr><td>LISN :</td><td colspan="3">Line Impedance Stabilization Network</td></tr></table>

![](images/165295fbe23916ba13c113ddf93c22fff11255337e08ebb69fba8b4a1e3e28f3.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr><tr><td colspan="4">CONTENTS</td></tr><tr><td>1 INTRODUCTION</td><td></td><td></td><td>9</td></tr><tr><td>1.1 Scope</td><td></td><td></td><td>9</td></tr><tr><td>1.2 Description and BLOCK DIAGRAM</td><td></td><td></td><td>9</td></tr><tr><td>2 List of applicable Document</td><td></td><td></td><td>11</td></tr><tr><td>3 Reference Standards</td><td></td><td></td><td>11</td></tr><tr><td>4 TECHNICAL SPECIFICATIONS OF &quot;S-BAND 2WATT TRANSMITTER&quot;</td><td></td><td></td><td>12</td></tr><tr><td>4.1 Electrical specifications</td><td></td><td></td><td>12</td></tr><tr><td>4.1.1 Power Supply Requirements</td><td></td><td></td><td>12</td></tr><tr><td>4.1.2 Input Specifications</td><td></td><td></td><td>12</td></tr><tr><td>4.1.3 Output Specifications</td><td></td><td></td><td>13</td></tr><tr><td>4.2 Mechanical Specifications</td><td></td><td></td><td>13</td></tr><tr><td>4.3 Operational Requirements</td><td></td><td></td><td>14</td></tr><tr><td>4.4 Operating &amp; Storage Temperature</td><td></td><td></td><td>14</td></tr><tr><td>4.5 Reliability Requirement</td><td></td><td></td><td>14</td></tr><tr><td>4.6 Storage Details</td><td></td><td></td><td>14</td></tr><tr><td>4.7 Grounding Scheme</td><td></td><td></td><td>14</td></tr><tr><td>5 Electrical Interface Requirements (Connectors)</td><td></td><td></td><td>15</td></tr><tr><td>5.1 J1 Connector Details</td><td></td><td></td><td>15</td></tr><tr><td>5.2 J2, j3 Connector details</td><td></td><td></td><td>16</td></tr><tr><td>5.3 J4 Connector details</td><td></td><td></td><td>16</td></tr><tr><td>6 Quality Assurance Plan</td><td></td><td></td><td>17</td></tr><tr><td>7 Qualification Test Flow Chart</td><td></td><td></td><td>18</td></tr><tr><td>8 CEMILAC SCREENING TEST FOR POPULATED PCBS</td><td></td><td></td><td>19</td></tr><tr><td>8.1 Visual Examination</td><td></td><td></td><td>19</td></tr><tr><td>8.2 high Temperature storage (Stabilization Bake) Test</td><td></td><td></td><td>19</td></tr><tr><td>8.3 Thermal Shock Test</td><td></td><td></td><td>20</td></tr><tr><td>8.4 Burn-in Test</td><td></td><td></td><td>21</td></tr><tr><td>9 Acceptance Test Flow Chart</td><td></td><td></td><td>22</td></tr><tr><td>10 Agencies</td><td></td><td></td><td>23</td></tr><tr><td>11 Quality Assurance</td><td></td><td></td><td>23</td></tr><tr><td>12 Incoming Inspection Stage</td><td></td><td></td><td>24</td></tr><tr><td>13 Incoming Good Inspection</td><td></td><td></td><td>25</td></tr><tr><td>13.1 Introduction</td><td></td><td></td><td>25</td></tr><tr><td>13.2 Sub System / Sub Assembly</td><td></td><td></td><td>25</td></tr></table>

![](images/2c8cf2838328a30361754ecb74efcd320a37b7fddb84139aef4cab1de021c321.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr><tr><td>13.3 Out Sourcing of Material / Work</td><td colspan="3">26</td></tr><tr><td>13.4 Mechanical Items</td><td colspan="3">26</td></tr><tr><td>13.5 Imported Components</td><td colspan="3">26</td></tr><tr><td>13.6 Standard bought-out items</td><td colspan="3">27</td></tr><tr><td>13.7 Sub contract items (Quality standards, traceability to be included)</td><td colspan="3">27</td></tr><tr><td>13.8 Mechanical manufactured/fabricated parts</td><td colspan="3">27</td></tr><tr><td>13.9 PRE-REQUISITES for Testing</td><td colspan="3">28</td></tr><tr><td>13.10 Non-Conformance</td><td colspan="3">29</td></tr><tr><td>13.11 Production Quality Test (PQT)</td><td colspan="3">29</td></tr><tr><td>14 Traceability and Identification</td><td colspan="3">29</td></tr><tr><td>14.1 Identification</td><td colspan="3">29</td></tr><tr><td>14.2 Traceability</td><td colspan="3">29</td></tr><tr><td>14.3 Standard Operating Procedure</td><td colspan="3">30</td></tr><tr><td>14.4 Inwards Goods</td><td colspan="3">31</td></tr><tr><td>14.5 Finished Goods Production</td><td colspan="3">31</td></tr><tr><td>14.6 Storage</td><td colspan="3">32</td></tr><tr><td>14.7 Records</td><td colspan="3">32</td></tr><tr><td>15 Test jig / ATP software</td><td colspan="3">32</td></tr><tr><td>15.1 Implementation feed back</td><td colspan="3">32</td></tr><tr><td>15.2 Customer Communication</td><td colspan="3">32</td></tr><tr><td>15.3 Process Flow Chart-I</td><td colspan="3">33</td></tr><tr><td>15.4 Process Flow Chart-II</td><td colspan="3">35</td></tr><tr><td>15.5 DESCRIPTION OF Process Flow Chart-I</td><td colspan="3">38</td></tr><tr><td>16 QA Matrix</td><td colspan="3">42</td></tr><tr><td>17 QA Directive 06/2018- Kit of Parts</td><td colspan="3">46</td></tr><tr><td>18 MECHANICAL DIMENSION INSPECTION</td><td colspan="3">48</td></tr><tr><td>19 PCB Inspection REPORT</td><td colspan="3">49</td></tr><tr><td>20 Internal WIRING Diagram</td><td colspan="3">50</td></tr><tr><td>21 Safety Precaution</td><td colspan="3">51</td></tr><tr><td>22 Handling</td><td colspan="3">51</td></tr><tr><td>23 Packaging</td><td colspan="3">51</td></tr><tr><td>24 Storage</td><td colspan="3">51</td></tr><tr><td>25 Transportation Instruction</td><td colspan="3">51</td></tr><tr><td>26 Assembly And Disassembly</td><td colspan="3">52</td></tr><tr><td>27 Failure Analysis Report</td><td colspan="3">54</td></tr><tr><td colspan="4">EI Wave Digitech (I) Pvt Ltd., Hyderabad.</td></tr></table>

![](images/f004ce6ba4d1a796ae1a452f10614224e8537aa6858a74bd375b9398838be551.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr><tr><td colspan="4">List of Tables</td></tr><tr><td colspan="3">Table 1: Reference Documents</td><td>11</td></tr><tr><td colspan="3">Table 2: Reference Standards</td><td>11</td></tr><tr><td colspan="3">Table 3: Power Supply Requirements</td><td>12</td></tr><tr><td colspan="3">Table 4: Input Specifications</td><td>12</td></tr><tr><td colspan="3">Table 5: Output Specification</td><td>13</td></tr><tr><td colspan="3">Table 6: Mechanical Specification</td><td>13</td></tr><tr><td colspan="3">Table 7: Operational Requirements</td><td>14</td></tr><tr><td colspan="3">Table 8: Electrical Interface Requirements</td><td>15</td></tr><tr><td colspan="3">Table 9: J1 Connector Details</td><td>15</td></tr><tr><td colspan="3">Table 10: J2 &amp; J3 Connector Details</td><td>16</td></tr><tr><td colspan="3">Table 11: J4 Connector Details</td><td>16</td></tr><tr><td colspan="3">Table 12: Visual Examination Test</td><td>19</td></tr><tr><td colspan="3">Table 13: High Temperature Test</td><td>19</td></tr><tr><td colspan="3">Table 14: Thermal Shock test</td><td>20</td></tr><tr><td colspan="3">Table 15: Burn-in test</td><td>21</td></tr><tr><td colspan="3">Table 16: Agencies</td><td>23</td></tr><tr><td colspan="3">Table 17: QA Matrix</td><td>45</td></tr><tr><td colspan="3">Table 18: Wiring details</td><td>50</td></tr><tr><td colspan="4">List of figures</td></tr><tr><td colspan="3">Figure 1:Block Diagram of S-Band 2-Watt Transmitter</td><td>10</td></tr><tr><td colspan="3">Figure 2:Grounding Scheme</td><td>14</td></tr></table>

![](images/13bd8191fec7aa9f287409073a80ef4153863eef2ff6f1118c42794d22f8254f.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr><tr><td colspan="4">PROPRIETARY INFORMATION</td></tr><tr><td colspan="4">a) This document is proprietary of DRDO, Min. of Defence.</td></tr><tr><td colspan="4">b) This document along with drawings issued here with shall not be used for any other purpose whatsoever without the written permission of issuing authority.</td></tr><tr><td colspan="4">c) Any information contained in this document or drawings shall not be passed on to any person / Organization without the consent of RCI.</td></tr><tr><td colspan="4">d) This document along with all Drawings etc. must be returned on the submission of tender or on completion of the order.</td></tr><tr><td colspan="4">e) The vendor shall carefully read the document and the drawings supplied before commencing manufacture. Any errors, omission, ambiguity or clarification required shall be immediately reported to Document Issuing Authority and work shall not proceed on affected parts until the necessary authentic clearances are received.</td></tr><tr><td colspan="4">f) QC / QA shall be carried out by Main Contractor&#x27;s / Vendor&#x27;s QC. R&amp;QA shall be the QA authority as mentioned in Supply Order.</td></tr><tr><td colspan="4">g) Proposals for changes, if any, to any aspect in the document or to the drawing shall be addressed in the prescribed Amendment Format for Document / Drawing respectively to the issuing Authority. The Amendment approved by Project Direc
# 1 INTRODUCTION

# 1.1 SCOPE

It describes Quality Assurance Plan of the Synthesized S-Band 2Watt Transmitter which is used in SAAW Project.

# 1.2 DESCRIPTION AND BLOCK DIAGRAM

The S-Band 2Watt Transmitter mainly consists of Synthesizer, Power Supply, Power Amplifier Section followed by Power Divider Section.

The PLL synthesizer circuit consists of VCO, RF synthesizer, a TCXO reference oscillator and modulation input circuit. The VCO is tuned in such a way that to cover the required frequency band (2200MHz to 2300MHz) and to meet the FM modulation requirements in the operating temperature range.

The fractional N frequency synthesizer consists of a low noise digital phase frequency detector, a precision charge pump, and a programmable reference divider. There is a delta sigma based fractional interpolator to allow programmable fractional N-division. The INT, Frac and MOD registers define overall Fractional N division. In addition the 4 bit reference counter allows selectable RF-in frequencies at the PFD input. It has the internal phase detector, which delivers the current pulses to drive external loop filter to control the tuning port of the VCO to bring it in to lock state.

Modulation Input section consists of Isolation transformer for Modulation input isolation. The power amplifier chain consists of driver amplifiers with the power of 22 dBm and having P1dBm of 23dBm. It requires VDD of +5V DC. Power amplifier is a high linearity 2Watt PA with good OIP3 performance and exponentially good PAE at 1dB gain compression point, achieved through GaN HEMT depletion enhancement mode process.

The S230SMICW Isolator is a two-port device that transmits radio frequency power in only one direction. It consists of 20dB isolation and 0.5dB insertion loss. It can handle the power up to 100 Watt.

The amplified RF carrier from VCO is further filtered by a low pass Filter to meet the harmonics specification of -60dBc. The final stage amplifier output 30dBm (1 Watt) power is divided by using "power divider circuit" to provide Power output in two ports, each port delivers +30dBm (min) power (SMA, Female).

D.C. Power Supply +28V from the 7 pin socket is fed to this section. This section consisting of Reverse polarity protection diode. This filtered voltage is further converted into regulated +24Volts and +5Volts by using DC-DC Converter and fed to all the circuits. +5 Volts further converted into +3.3V for PLL synthesizer as well as TCXO crystal oscillator supply and -2V for Power amplifier, -5V for Operational Amplifier.

![](images/2f8d66c4f7eef9032efb0694ade7bc19b4f450139b47dcc6ca964e137b7adafc.jpg)  
Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW   
Doc No: EIWAVE/TX222SAW/QAP   
Classified: Restricted   
Date: $10^{\text{th}}$ April 2025   
Figure 1:Block Diagram of S-Band 2-Watt Transmitter   
EI Wave Digitech (I) Pvt Ltd., Hyderabad.

2 LIST OF APPLICABLE DOCUMENT   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

Table 1: Reference Documents   

<table><tr><td>S.No.</td><td>Description</td><td>Document No.</td><td>Approval Status</td></tr><tr><td>1.</td><td>Supply Order</td><td>3220010735, Dt:16-11-2022</td><td>Approved</td></tr><tr><td>2.</td><td>PDR</td><td>EIW/BDL/PDR/S2WT/01, Dt:10-05-2024</td><td>Approved</td></tr><tr><td>3.</td><td>TS</td><td>RCI/DOFI/SAAW/2W/TS, Dt:09-01-2025</td><td>Under Approval</td></tr><tr><td>4.</td><td>BOM</td><td>EIWAVE/TX222SAW/BOM, Dt:22-03-2025</td><td>Under Approval</td></tr><tr><td>5.</td><td>MDI Mechanical</td><td>EIWAVE/TX222SAW/MDI, Dt:10-04-2025</td><td>Under Approval</td></tr><tr><td>6.</td><td>MDI Electrical</td><td>EIWAVE/TX222SAW/MDI-ELE,Dt:18-08-2025</td><td>Under Approval</td></tr><tr><td>7.</td><td>QTP</td><td>EIWAVE/TX222SAW/QT, Dt:22-03-2025</td><td>Under Approval</td></tr><tr><td>8.</td><td>ATP</td><td>EIWAVE/TX222SAW/AT, Dt:22-03-2025</td><td>Under Approval</td></tr><tr><td>9.</td><td>IPD</td><td>EIWAVE/TX222SAW/IPD,Dt:18-08-2025</td><td>Under Approval</td></tr></table>

3 REFERENCE STANDARDS   
Table 2: Reference Standards   

<table><tr><td>S. No.</td><td>STANDARD No.</td><td>STANDARD DESCRIPTION</td></tr><tr><td>1.</td><td>MIL-STD-810G</td><td>Environmental Stress Methods for Electrical &amp; Electronics LRU&#x27;s</td></tr><tr><td>2.</td><td>MIL-STD-2164(EC)</td><td>Environmental Stress Screening</td></tr><tr><td>3.</td><td>MIL-HDBK-217F</td><td>Reliability Prediction of Electronic Equipment</td></tr><tr><td>4.</td><td>MIL-STD-2155</td><td>FRACAS</td></tr><tr><td>5.</td><td>IPC-A-610F</td><td>Acceptability of Electronic Assemblies</td></tr><tr><td>6.</td><td>IPC/WHMA-A-620</td><td>Wiring Standard Requirements &amp; Acceptance for cable and wire harness assemblies</td></tr><tr><td>7.</td><td>MIL-STD-461F/G</td><td>EMI-EMC Standard</td></tr><tr><td>8.</td><td>MIL-A-46146</td><td>RTV Potting</td></tr><tr><td>9.</td><td>MIL-I-46058C/IPC 830</td><td>Conformal Coating</td></tr></table>

# 4 TECHNICAL SPECIFICATIONS OF "S-BAND 2WATT TRANSMITTER"

POWER SUPPLY REQUIREMENTS: S-Band 2Watt Transmitter derives the 28V power supply from the LTB/Power & Pyro Switching Unit PPSU at weapon level which derives power from the aircraft/ regulated power supply at lab level.

# 4.1 ELECTRICAL SPECIFICATIONS

# 4.1.1 POWER SUPPLY REQUIREMENTS

Table 3: Power Supply Requirements   

<table><tr><td>S. No</td><td>Description</td><td>Specification</td></tr><tr><td>1</td><td>Operating Voltage</td><td>28V ± 4V DC</td></tr><tr><td>2</td><td>Power Consumption</td><td>18W max</td></tr><tr><td>3</td><td colspan="2">Reverse voltage and short circuit protection to be provided in the circuit.</td></tr></table>

# 4.1.2 INPUT SPECIFICATIONS

Table 4: Input Specifications   

<table><tr><td>S. No</td><td>Parameters</td><td>Specification</td></tr><tr><td>1.</td><td>Carrier Frequency</td><td>2255.5 MHz</td></tr><tr><td>2.</td><td>Tunability of CF</td><td>2.2 GHz to 2.3 GHz with 0.5 MHz step size</td></tr><tr><td>3.</td><td>Carrier Frequency Stability</td><td>±0.003% over temperature range</td></tr><tr><td>4.</td><td>Type of Modulation</td><td>FM</td></tr><tr><td>5.</td><td>Modulation I/P voltage</td><td>1 to 5 Vp-p</td></tr><tr><td>6.</td><td>Modulation I/P impedance</td><td>10KΩ(nominal)</td></tr><tr><td>7.</td><td>Operating Voltage</td><td>28V ± 4V DC</td></tr><tr><td>8.</td><td>Current</td><td>0.5A Typical @28V</td></tr><tr><td>9.</td><td colspan="2">Isolation between DC supply return, Modulation Input return and Unit body to be provided.</td></tr><tr><td>10.</td><td colspan="2">Internal isolation at RF output to be provided for open / short conditions</td></tr><tr><td>11.</td><td colspan="2">801-009-02M6-7SA, Mighty mouse series 801, MIL-DTL-38999 circular connector to be provided for interfacing power and modulation input.</td></tr></table>

# 4.1.3 OUTPUT SPECIFICATIONS

Table 5: Output Specification   

<table><tr><td>S.No</td><td>Parameters</td><td>Specification</td></tr><tr><td rowspan="4">1.</td><td>RF output power 2 Watt</td><td>2 Watt (33dBm)</td></tr><tr><td>a) RF Power output at each port (2 ports)</td><td>30dBm min (CW)</td></tr><tr><td>b) Amplitude imbalance</td><td>0.3dB max</td></tr><tr><td>c) Isolation</td><td>20dB min.</td></tr><tr><td>2.</td><td>Deviation Sensitivity</td><td>1MHz/Vp-p, ±10% Over temperature range.</td></tr><tr><td>3.</td><td>Modulation Band Width</td><td>Up to 7MHz</td></tr><tr><td>4.</td><td>Incidental frequency modulation</td><td>≤ 8KHz</td></tr><tr><td>5.</td><td>Spurious</td><td>Better than -60dBc</td></tr><tr><td>6.</td><td>Harmonic</td><td>Better than -60dBc</td></tr><tr><td>7.</td><td colspan="2">SMA straight connector to be provided one for each port (No of ports 2)</td></tr></table>

# 4.2 MECHANICAL SPECIFICATIONS

Table 6: Mechanical Specification   

<table><tr><td>S.NO</td><td>Description</td><td>Specification</td></tr><tr><td rowspan="2">1.</td><td>Dimensions
(with connectors)</td><td>Length: 111.5 mm ± 0.15mm
Width: 80 mm ± 0.15mm
Height: 34mm ± 0.15mm</td></tr><tr><td>Dimensions without
connectors</td><td>Length: 89.9mm ± 0.15mm
Width: 80 mm ± 0.15mm
Height: 34mm ± 0.15mm</td></tr><tr><td>2.</td><td>Weight</td><td>1000Grams (Max)</td></tr><tr><td>3</td><td>Platform Installation details</td><td>Hard Mounting in nose section</td></tr><tr><td>4.</td><td>Cooling requirements</td><td>Natural cooling</td></tr><tr><td>5.</td><td>Chassis material</td><td>HE-15, AL Alloy HE 15
AA2014 T652</td></tr><tr><td>6.</td><td>Plating</td><td>(Outside plating) Metallic Black Anodize AC15 as per IS 1868 (Non-Shiny).
(Inside Plating) yellow chromate conversion coating as per IS-11232 Class-2.</td></tr></table>

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 4.3 OPERATIONAL REQUIREMENTS

Table 7: Operational Requirements   

<table><tr><td>S.No</td><td>Description</td><td>Specification</td></tr><tr><td>1</td><td>Flight Duration</td><td>650 sec</td></tr><tr><td>2</td><td>Minimum Restart time</td><td>Less than 10 min</td></tr><tr><td>3</td><td>Life Span</td><td>Unit should have a shelf life of 10 years. Under the storage condition in controlled environment of 25+5°C &amp; RH 65-75%</td></tr><tr><td>4</td><td>Cumulative operating hours</td><td>500 hours</td></tr><tr><td>5</td><td>Maintenance Requirements</td><td>At least yearly once unit will be switched ON, main parameters to be noted.</td></tr><tr><td>6</td><td>Maximum continuous operating time</td><td>4 hrs</td></tr></table>

# 4.4 OPERATING & STORAGE TEMPERATURE

a. $-40^{\circ}\mathrm{C}$ to $+71^{\circ}\mathrm{C}$ - Operating Temperature.   
b. $-55^{\circ} \mathrm{C}$ to $+85^{\circ} \mathrm{C}$ - Storage Temperature.

# 4.5 RELIABILITY REQUIREMENT

The Reliability of the Subsystem is greater than 0.98

# 4.6 STORAGE DETAILS

Unit must be stored in safe ESD box.

# 4.7 GROUNDING SCHEME

![](images/8940cfeac4170fc6f748b15dbd65011567281478eac37bf541ed8d31a30fdeec.jpg)  
Figure 2:Grounding Scheme

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 5 ELECTRICAL INTERFACE REQUIREMENTS (CONNECTORS)

Table 8: Electrical Interface Requirements   

<table><tr><td>Connector
Reference</td><td>Connector type</td><td>Purpose</td></tr><tr><td>J1</td><td>CON CIR (F) 7Pin STCAB</td><td>For power and modulation input</td></tr><tr><td>J2</td><td>MIL-STD SMA (F) Straight</td><td>For RF output interface with antenna-1</td></tr><tr><td>J3</td><td>MIL-STD SMA (F) Straight</td><td>For RF output interface with antenna-2</td></tr><tr><td>J4</td><td>CON Micro D (M) 9 PIN</td><td>For Programming connector (RS422 interface) &amp; For power up and down control.</td></tr></table>

# 5.1 J1 CONNECTOR DETAILS

Power Supply and Modulation Input

P/No : 801-009-02M6-7SA / 2M801-009-02M6-7SA

Table 9: J1 Connector Details  

<table><tr><td>Connector</td><td>Type</td><td>Signal Characteristics</td><td>Pin No</td><td>Description</td></tr><tr><td rowspan="7">J1</td><td rowspan="7">7 pin Socket</td><td>28V +ve</td><td>1</td><td rowspan="2">Power Supply 28V High</td></tr><tr><td>28V +ve</td><td>2</td></tr><tr><td>28V -ve</td><td>3</td><td rowspan="2">Power Supply 28V Low</td></tr><tr><td>28V -ve</td><td>4</td></tr><tr><td>MOD +ve</td><td>5</td><td>Modulation Input High</td></tr><tr><td>MOD -ve</td><td>6</td><td>Modulation Input Low</td></tr><tr><td>NC</td><td>7</td><td>--</td></tr></table>

![](images/011fe1da6a6c7f16c7236b304df447b45f075f50412aabf447f58c785205a642.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 5.2 J2, J3 CONNECTOR DETAILS

Transmitter Output to Antennas

P/No: 132146

Table 10: J2 & J3 Connector Details  

<table><tr><td>Connector</td><td>Type</td><td>Signal Characteristics</td></tr><tr><td>J2, J3</td><td>SMA (F)</td><td>50Ω Impedance</td></tr></table>

# 5.3 J4 CONNECTOR DETAILS

RS422 Communication Connector Details

P/No: M83513/03-A03N / M83513/03-A14N

Table 11: J4 Connector Details   

<table><tr><td>Connector</td><td>Type</td><td>Signal Characteristics</td><td>Pin No</td><td>Description</td></tr><tr><td rowspan="9">J4</td><td rowspan="9">9pin</td><td>TX+</td><td>1</td><td rowspan="2">Differential Input-Transmitter</td></tr><tr><td>TX-</td><td>2</td></tr><tr><td>RX+</td><td>3</td><td rowspan="2">Differential Input-Receiver</td></tr><tr><td>RX-</td><td>4</td></tr><tr><td>PD+</td><td>5</td><td rowspan="2">Differential Input-Power Up&amp;Power Down</td></tr><tr><td>PD-</td><td>6</td></tr><tr><td>GND</td><td>7</td><td>Ground</td></tr><tr><td>CLK</td><td>8</td><td>Clock</td></tr><tr><td>RESET</td><td>9</td><td>Reset</td></tr></table>

![](images/0f827870aeaf22dd0dcd63adf5e9442fc5e7bdb02941d5904eb5100189c7b148.jpg)

# 6 QUALITY ASSURANCE PLAN

The S-Band 2-Watt Transmitter unit will be built in accordance with CEMILAC / RCMA approved standard of preparation (BOM / MDI drawings). The units are assembled as per the BOM / MDI which are referral and authorized document(s) for identification of materials / items / parts / components / modules. BOM / MDI provide information on build standard, process, finish and functionality aspects.

Quality Assurance Plan (QAP) and Flow Chart encompasses various quality verification activities, which need to be undertaken. The flow chart covers various stage inspections and type of QA checks to be performed by Main contractor QA and R&QA as per QA Matrix and General Flow Chart.

All stages duly witnessed / Co-ordinate by QA of the Main Contractor / Designer and R&QA as per QA Matrix through Memo duly signed by Authorized R&QA Rep. All QA related communication is to be routed through Main Contractors QA department only.

For all Sub-assemblies /Sub-parts / Modules / Assembly of PCB's an internal checklist shall be prepared and assigned to every manufactured unit. Inspection & verification process are elaborated in grand flow chart & subsequent paragraphs based on the nature of work and activities undertaken at various stages and levels.

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 7 QUALIFICATION TEST FLOW CHART

![](images/bfcfb8064462cbbeed9ffcb509ab3ee4dbd399534ba41fa4a3f12fb87189414d.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 8 CEMILAC SCREENING TEST FOR POPULATED PCBS

Purpose : This procedure applies to PCB's populated with COTS components. the PCB levels screening shall be adapted only when it is not possible to undertake $100\%$ component level screening and in that case components are not required to be screened separately.

# 8.1 VISUAL EXAMINATION

Table 12: Visual Examination Test   

<table><tr><td>Title of the Test</td><td>Test details</td><td>Requirements</td></tr><tr><td>Visual Examination</td><td>a) Carryout Physical/Visual Examination of the assembled PCB for non-conformities/ abnormalities and correct the same.
b) Performance Check</td><td>As specified.</td></tr></table>

# 8.2 HIGH TEMPERATURE STORAGE (STABILIZATION BAKE) TEST

Table 13: High Temperature Test   

<table><tr><td>Title of the Test</td><td>Test details</td><td>Requirements</td></tr><tr><td>High Temperature Storage Test (Stabilization Bake)</td><td>As per test No:22 of JSS 50101, after introduction of PCB&#x27;s, increase the chamber temperature to +85°C with tolerance +5°C/0°C Expose the assembled PCB for 24 hours continuously at +85°C</td><td>Visual Examination and Functional Checks at ambient temperature. Record failures observed if any.</td></tr></table>

# Rework

Repair/Replace components as required using fresh components. The new components must undergo stabilization bake test before assembly.

# 8.3 THERMAL SHOCK TEST

The PCB, which has undergone the test at paragraph 4.2 above, shall be subjected to 10 cycles of continuous Thermal Shock (In power OFF condition) as follows:

Table 14: Thermal Shock test   

<table><tr><td>Title of the Test</td><td>Test details</td><td>Requirements</td></tr><tr><td>Thermal Shock Test</td><td>As per test No:22 of JSS 50101, Low Temperature: - 40°C with tolerance of 0°C/+5°C.
High Temperature: +85°C with tolerance of 0°C/+5°C.
Transfer Time: 2minutes
Period of Exposure: 30minutes
No.of Cycles: 10
Operation: OFF condition.</td><td>PCB assembly must be free from any visual damages or distortions namely cracking and de-lamination of finishes, cracking and crazing of embedding and encapsulating compounds, opening of thermal seals and case seams, leakage of filling materials, rupturing or cracking of hermetic seals and changes in electrical characteristics due to mechanical displacement or rupture of conductors or of insulating materials.</td></tr><tr><td>Visual Examination</td><td>On completion of 10 cycles, carryout Visual Examination using magnifying glass with magnifying factor of 30 for detection of failure.</td><td></td></tr><tr><td>Electrical Measurements</td><td>Carryout Performance Checks as per QTP</td><td>As specified in QTP.</td></tr></table>

# Acceptance Criteria

In case of failures, analyze the defects in consultation with Certification/Quality Assurance Agency. Failed Components shall be replaced and new components shall undergo stabilization bake and Thermal Shock before assembly, repeat Visual Examination and Performance Checks.

![](images/9677c217809c2e6cb3afefd72427afb91c58400900212aed99dd53592ced424a.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 8.4 BURN-IN TEST

Table 15: Burn-in test   

<table><tr><td>Title of the Test</td><td>Test details</td><td>Requirements</td></tr><tr><td>Burn-in Test</td><td>1. The PCB shall be placed in a chamber. All arrangements shall be made externally to carry out Functional Checks on the PCB at every five hours period. This constitutes one cycle of 5hours.
2. The temperature of the chamber shall be raised to maximum rated operating temperature(+71℃) the populated PCB is designed to perform with tolerance +5℃/+0℃.
3. PCB shall be maintained at this temperature continuously for 48 hours in power ON / condition.
4. In case of failure, the components shall be replaced by components which have gone and passed High temperature Storage and Thermal Shock before assembly and continue the test for remaining hours. If the failure occurs after the 46th /47th /48th hour, expose the PCB for further 03hours to confirm the adequacy of the repair work.
5. On completion of Burn-in test, switch OFF the chamber.
6. Take out the PCB assembly for conducting Visual Examination; PCB assembly shall be free from any visual damages or distortions as stipulated at 24 above.
Carry out the Performance Checks as per QTP on the PCB assembly and record the results.</td><td>Visual Examination and Functional Checks at ambient temperature.
Record failures observed if any.
The last three hours shall be defective free. +71℃ max operating temperature.</td></tr></table>

# Marking

The assembly PCB on passing the above tests shall be marked suitably for easy identification to avoid mixing up screened and un-screened PCB's.

![](images/eb3c9bb8738a60844d967b4d85b75400334167abcb2d877e80ab57f6640cf457.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 9 ACCEPTANCE TEST FLOW CHART

![](images/aa974536e50592ee6d083130eee314589bdeae8a7d6777de200e720b8fa4ecd8.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

# 10 AGENCIES

The Agencies associated in manufacturer's project are shown below. EO-SAAW, RCI

Table 16: Agencies   

<table><tr><td>a)</td><td>Ordering agency</td><td></td></tr><tr><td>b)</td><td>Design agency</td><td>EI Wave Digitech (I) Pvt Ltd</td></tr><tr><td>c)</td><td>Certifying agency</td><td>CEMILAC/ RCMA (Missiles)</td></tr><tr><td>d)</td><td>QAP Approving Authority</td><td>R&amp;QA</td></tr><tr><td>e)</td><td>Control of Documents</td><td>PD,SAAW RCI and R&amp;QA RCI HYD.
Controlled Copies shall be distributed as per Master document entries. The document shall be copied or distributed only with the concurrence of the PD and R&amp;QA Project.</td></tr></table>

# Control of Records:

Control of Record
TDRS records / Job cards / Inspection reports shall be maintained in soft and hard format by the manufacturer (DECS), Production agency and will be retained as per contract or 5 years from the date of dispatch of the item.

# Review and acceptance of Quality plan:

Review and accept Quality plan will be reviewed by the main contractor and inspection agencies and Approval will be given R&QA and RCMA. Approved quality plan shall be followed for realizing the unit. Revision if any to the document shall be reflected in the amendment sheet with approval of QA authority.

# 11 QUALITY ASSURANCE

The activities are primarily divided into 3 tiers,

Transaction at Manufacturing / Vendor Premises   
a. Inspection at mania.   
b. Quality Control by the Administrative Body   
c. Quality Assurance by the Risk-Checking of Critical Stages and Audit.

The inspection and quality control at the Main designer / contractor / Manufacturer's Premises shall comprise of the following

a. Incoming goods inspection and Tractability establishment (Refer AQA Directive 06/2018) and traceability requirements.   
b. In-process inspection (Manufacturing processes, Assembly process, Acceptance Record Generation, Deviation management and Non-conformance recordings) Acceptance Tagging.   
c. Acceptance tests for sub-assemblies and stage clearance as per above.   
d. Final integration, conformance tests and acceptance tests.

# Quality Assurance process shall comprise of the following:

a. Manufacturing Process conformance to Design Quality   
b. Quality audit checks   
c. Spot Checks   
d. Stage Clearances

# 12 INCOMING INSPECTION STAGE

In this stage, all incoming materials are subjected to inspection as per Firm's inspection procedure in order to ensure material / items / components conformity to specification by means of physical verification, dimensional verification, drawing specification, COC's, reports, release notes etc. (whichever is applicable).

All discrete components shall be accepted as per relevant data sheet and COC from the OEM. In the absence of COC from OEM or from OEM authorized distributors, prior approval shall be obtained in writing from the Technical Approval Authorities (TAA) on the method of acceptance of the components.

Apart from inspection procedure, referral documents shall be SOP (MDI & BOM) duly approved and released by approving authorities. As per AQA Directive 06/2018, Main Contractor's QC shall coordinate with others in preparing Data of Component Kit inspection Report, Annexures A to D, and forward it to R&QA for clearance before proceeding for assembly / Integration.

![](images/f0fcc9cead13ff7b0d13c8cc57bc177ca6da35b5e5c637a6383cbfa2b41ec564.jpg)

# 13 INCOMING GOOD INSPECTION

# 13.1 INTRODUCTION

Inward Goods Inspection is a process established for acceptance of ordered parts and it acceptance, marking and traceability establishment. The Quality Control department of the Main designer/ Contractor is responsible to ensure the quality of the Contracted /sub contracted Items/material /sub systems are received, accepted and stored properly. The components /material /sub systems shall be inspected as per the quality plan.

The material procurement by the production agency or its sub-contractors shall be as per the specifications mentioned in the approved drawings/bill of materials. The compliance to the requirements specified in the manufacturing documentation in respect of all the incoming goods shall be ensured by the authorized inspection agency. The incoming goods shall be inspected by IGQC. For all raw materials, parts, components and sections procured from external sources, the procedure given in succeeding paragraphs shall be adopted.

TDRS / Formats to be generated for recording the important parameters, tolerance values, observed values & physical parameters are to be included in the test schedule document as per Approved Technical Specification and Test Schedule. Values in TDRS shall be validated w.r.t TS only.

# 13.2 SUB SYSTEM / SUB ASSEMBLY

The manufacturing of components shall be carried out as per the process laid down in DAL / Drawing / Processes to achieve the required dimensions with tolerance and other parameters. The sub-contractor/ vendor shall ensure quality of the store must be achieved using appropriate tools, machines and manpower. IGQC of Main Contractor shall ensure the quality during process of manufacturing / assembly. The vendor shall provide the infrastructure facilities for the inspection of the components / sub systems (Traceability).

a. Stores / Components shall normally be procured from sources approved as per the relevant TS / Drawings duly approved by the Design clearance Authorities. Necessary COC with test report shall be attached along with reports for acceptance. Necessary Traceability shall be established.

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

b. Stores procured shall meet standard specifications mentioned in the Approved Production Drawings / Bill of materials / Acceptance Test Procedures.   
c. All relevant information is to be provided in the purchase documents, to facilitate acceptance of stores.

# 13.3 OUT SOURCING OF MATERIAL / WORK

The Vendor/Contractor to whom the parts are outsourced towards realization of hardware need to be AS 9100 / ISO 9001 certified. Design assessment of the firm will be carried out by Project group, RCMA / CEMILAC, R&QA and Quality control assessment of the firm.

# 13.4 MECHANICAL ITEMS

All mechanical components and materials like Aluminium Forgings/Extrusions, Aluminium sheets/ fasteners, Gaskets, rubber parts, other materials shall be accepted based on release note or CoC's along with test reports of the supplier/ DIN/ISO/BN/MIL standard etc., before use.

a. All raw materials for mechanical components / items shall be procured from approved sources duly inspected by R&QA and Manufacturer's Quality control. Raw material procured shall be manufactured as per R&QA approved Test schedule. Samples from the lot shall be stamped by the Main Designer / contractor's QC inspection, prior to dispatch for further processing. Proper Release note shall be obtained from Airworthiness agencies. Changes to raw material other than mentioned in BOM shall be added to BOM with necessary change notes duly approved by CEMILAC / RCMA   
b. All Gaskets/rubber items after acceptance shall be packed in heat-sealed foil lined paper packing and chalk powder with relevant markings outside the packing. The sealed packets are to be stored in places where the packets are not directly exposed to sunlight. The markings shall include store reference number, quantity, life of expiry, etc.

# 13.5 IMPORTED COMPONENTS

All imported components shall be accepted after verifying their certificate of conformance /test reports / manufacturer's part no issued by the OEM concerned. The items shall also be subjected to acceptance tests wherever applicable prior to use. Necessary clearances shall be obtained before use from concerned Airworthiness agencies.

# 13.6 STANDARD BOUGHT-OUT ITEMS

All standard bought-out items shall be procured as per test schedule approved by R&QA from registered / approved vendors only. The same shall be tested as per the relevant Technical specification / SOP /Check sheets /Test Schedule. All hardware items shall be procured as per IS/DIN/BN/MIL standard or equivalent standard as mentioned in the BOM.

# 13.7 SUB CONTRACT ITEMS (QUALITY STANDARDS,TRACEABILITY TO BE INCLUDED)

All Sub Contractors are required to comply with the quality standards specified in the document. Sub-Contractors shall establish inspection and testing facilities / arrangements to validate firm's products compliance with Technical specification requirements.

All sub-contracted items shall be accepted after necessary QC / QA checks including dimensions, weight and material test reports.

For the specified item mentioned in the approved document, Traceability and Identification of the product shall be established starting from raw material stage to packaging.

# 13.8 MECHANICAL MANUFACTURED/FABRICATED PARTS

Machined blocks and plates used for building up of Wing EMA Unit. XXXXX Designs supplies all the requisite drawings to its approved sub vendors through PO for converting it in to finished item/component. Final inspection will be carried out at vendor/supplier premises for acceptance of item. The referral document for dimensional verification of an individual part is it's duly approved and controlled copy of drawing. The manufactured/fabricated mechanical parts are initially subjected to visual examination and for attributes mentioned in Inward Inspection Report- Mechanical referred at Appendix-B. Dimensional verification as per the sample plan of the work centre will be done after visual examination. Final acceptance of mechanical manufactured / fabricated parts shall be by R&QA based on raw material inspection reports and dimensional inspection reports submitted by Main contractor QC. Rejected material will be returned to stores with Red tag for disposal. Dimensional report will be recorded.

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr><tr><td colspan="4">a) Aero Grade Fasteners: All Fasteners shall be in conformance to the aero grade requirements as per BOM of the unit. Fasteners shall confirm to the R&amp;QA approved test schedule and shall be verified for its compliance to approved test schedule. The same shall be reflected in the COC with its conditioning and properties as per schedule
b) Surface treatment of parts and structure: Parts used for build-up of Unit are subjected to surface treatment as specified in the drawing. The visual inspection carried out on all parts and inspection report is compiled. Project QA should coordinate the inspection and Clearance to be taken by R&amp;QA.
c) Unit Assembly: Unit assembly is done as per various assembly drawings and Integration Process Document (IPD). Accepted parts / items as per BOM / MDI shall be used in assembling the unit. Electrical and Electronic items / Components / sub-assemblies are installed on to the unit as per IPD. R&amp;QA shall carry out inspection of the assembly coordinated by project QC. Dimensional verification is carried out in accordance with GA drawing and findings shall be recorded in inspection report / Production Process Card.</td></tr><tr><td colspan="4">13.9 PRE-REQUISITES FOR TESTING</td></tr><tr><td colspan="4">a. QA Coverage shall be as per approved Quality Assurance Procedure (QAP). Inspections of components as per the BOM / MDI / Drawings / Schematics / Data sheets / CoC&#x27;s etc. with proper traceability records / marking.
b. Only approved fixtures are to be used during En-tests and the mounting scheme during En-tests shall replicate the same as mounting scheme in flights. The fixture drawings shall be vetted by main designer&#x27;s QA team and approved by RCMA before commences of tests. Further, the compliance of the &quot;Test Fixture&quot; to the approved Drawing requirements and its clearance shall be accorded by R&amp;QA.
c. Test Jigs / rigs if any to be used during evaluation / Testing shall be cleared by R&amp;QA based on Technical specification and duly approved by RCMA. Test jigs used for validation of the system / sub-system has to be cleared by R&amp;QA before commencement of the test.
d. All standard equipment being used as part of test-jig and test facilities used for the qualification test shall have valid calibration certificates from NABL approved labs.</td></tr></table>

# 13.10NON-CONFORMANCE

Any Non-conformance / Deviation observed during any stage of inspection will be recorded in the format and action as per DDPMAS -2021 shall be followed. Refer Main Flow chart for procedure.

Any change in design during production stage shall be brought to the notice of R&QA with proper change request and thereof recorded in ECN and approval obtained from CEMILAC. All QA related issues shall be approved by R&QA.

# 13.11 PRODUCTION QUALITY TEST (PQT)

Production Quality tests (PQT) will be finalized mutually between R&QA and Manufacturer as and when a Batch/Heat Changes or One in 100 units or one in fresh order, where change in manpower, Material, Manufacturing Process or Firm is envisaged. These tests shall be limited to 10 to $20 \%$ of the QT severity.

# 14 TRACEABILITY AND IDENTIFICATION

# 14.1 IDENTIFICATION

It is required to monitor the inspection status. It could be a tag, a sticker or a job number on the piece being produced. Also during production process the organization would need to have the connection between the product and the monitoring and measuring requirements. To put it in simple words, the organization need to establish what measurement was taken with what gauge. For example, the pressure test on this was done using the Pressure Gauge PR-003. Once you know the gauge you can look at the gauge calibration record. You identify the product by putting a tag, sticker, etching or permanent marker etc.

# 14.2TRACEABILITY

Coming to the next item in this clause, which is traceability. In some cases, you would need to keep the record of product for long time. You would have seen batch numbers on medicines. These are put to keep the traceability. At any later day by knowing the batch number, the company will be able to pull out all production and test reports for that batch. Traceability can help in finding out what all went into making of this piece.

Pallet IDs are created to identify every pallet of manufactured finished goods, which will contain information of a unique Product code and Batch Production Number.

1. All steps throughout the Manufacturing Process are tracked via Manufacturing Instruction (MI) documents, maintained by the Technical Service team unique for each product code. Full traceability is assured through issuing appropriate documentation and maintaining records that accompany every step in batch manufacturing status.   
2. All components, Raw Materials and Finished Products undergo inspection and testing at various stages of their processing to verify their adherence or otherwise to standards which is detailed in relevant documentation. On completion of every inspection and test procedure, resulting in a change to the status of the item a record is generated to attest that the item is allowed to proceed to the next stage in its processing.   
3. The change in status of a product/batch can be marked by various ways like Authorized people's signature and date on the forms and records, applying stickers e.g. released sticker.   
4. Only authorized warehouse person will receive incoming goods and sign and date on the Goods Receipt Slips. Authorized dispensary personnel will sample the Raw material / component laboratory testing. Authorized production personnel will request material/component for a BPN through Material Transfer Orders. Authorized laboratory personnel will test Raw Materials, Components and Finished Goods according to approved Specification and Test Reports. In each of the case the material or batch status will be changed, which authorized persons sign and date on the forms and record reflects. Appropriate stickers are applied to mark those changes. Goods undergoing manufacturing are continuously in process tested, the status "done / not done" is noted when the entry is made in the Manufacturing Instructions.

# 14.3 STANDARD OPERATING PROCEDURE

Product traceability system allows for complete and up to date histories of all batches of products from the starting materials to the complete final product. Identification and status of materials is provided by unique and controlled numbering system. The system can be interrogated to provide reports to allow for full traceability.

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr></table>

# 14.6 STORAGE

Pallet IDs are created to identify every pallet of manufactured finished goods, which will contain information of a unique Product code and Batch Production Number.

All steps throughout the Manufacturing Process are tracked via Manufacturing Instruction (MI) documents, maintained by the Technical Service team unique for each product code. Full traceability is assured through issuing appropriate documentation and maintaining records that accompany every step in batch manufacturing status.

# 14.7 RECORDS

The completed Manufacturing Instruction (MI) sheets form the record of batch production. Based on these guidelines the traceability and identification has to be made depending on the type of manufacturing involved. This is a guideline and can be amended as per requirement by the firm and used for implementation.

# 15 TEST JIG / ATP SOFTWARE

Test Jig / ATP software details included in ATP document. The test Jig with its documents shall be offered to QA agencies with details for clearance before using them for testing.

# 15.1 IMPLEMENTATION FEED BACK

In case of any feedback received from any stage and from any stakeholder the feedback will be discussed with all the stakeholders and necessary action will be incorporated with prior approval.

# 15.2 CUSTOMER COMMUNICATION

All communication shall be routed through respective QA departments only. All R&QA Stages shall be offered through Memo via BDL, Hyderabad.

![](images/28a482d87230179d03408a77f5e7d19e0af420a137f5cf6756cf83e7a045e338.jpg)

# 15.3 PROCESS FLOW CHART-I

![](images/9a58285404b86fd6960b3ead494a9c0cdf90defb7eae6faf60aebf0e4b42f521.jpg)

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr><tr><td colspan="3">Environmental test as per the QAP document</td><td>*#</td></tr><tr><td colspan="3">Final Isolation &amp; continuity Checks and Functional Test</td><td>*#</td></tr><tr><td colspan="3">Packing &amp; dispatch</td><td>*</td></tr><tr><td>END</td><td colspan="3">* - INTERNAL QC
# - R&amp;QA</td></tr><tr><td colspan="4">15.4 PROCESS FLOW CHART-II</td></tr><tr><td>Collection of PCBs from Store</td><td>Stores</td><td colspan="2">Collection of Components and wires from Store</td></tr><tr><td>cleaning</td><td></td><td colspan="2">Preparation of components (including lead tinning, Cleaning and lead forming where-ever required)</td></tr><tr><td>Visual inspection &amp; Continuity checks as per netlist (One PCB from batch</td><td>Rejected</td><td colspan="2">Components Mounting</td></tr><tr><td>Accepted</td><td></td><td>Re-work</td><td>Inspection</td></tr><tr><td>Baking</td><td></td><td colspan="2">Soldering</td></tr><tr><td>Visual Inspection</td><td>NOT OK</td><td colspan="2">Cleaning with IPA</td></tr><tr><td>OK</td><td></td><td>Re-work</td><td>Inspection</td></tr><tr><td></td><td></td><td>NO</td><td>Accepted</td></tr><tr><td></td><td></td><td colspan="2">Are all stages of component mounting Over?</td></tr><tr><td></td><td>Continued</td><td>YES</td><td></td></tr></table>

EI Wave Digitech (I) Pvt Ltd., Hyderabad.

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10thApril 2025</td></tr><tr><td>Continued
Final Cleaning
INSPECTION
by R&amp;QA/
Project
group
OK
Mechanical Assembly &amp; Ready
for Functional Test
Testing &amp; Tuning
Functional
Test
OK
R&amp;QA / Project group
inspection
Accepted
QT / AT Test(s)</td><td>REV No:00</td><td></td><td></td></tr></table>

![](images/81c9e7cf7b7a4b1ee2f6fcdb33ea288d3c27b02bb19fc92c0c77b27405d55648.jpg)  
EI Wave Digitech (I) Pvt Ltd., Hyderabad.

15.5 DESCRIPTION OF PROCESS FLOW CHART-II   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td>S.No</td><td>Description</td><td>Tools</td><td>Remarks</td></tr><tr><td>1</td><td>Bare PCB Inspection</td><td></td><td></td></tr><tr><td></td><td>1. Clean the PCB&#x27;s with isopropyl alcohol in proper cleaning tray
2. Visually inspect the PCB&#x27;s using magnifier for any voids, burns, bubbles, surface imperfections etc.
3. Dimensions: The finished printed circuit board shall meet the dimensions (such as cutouts, overall thickness, periphery, etc.)requirements as specifying the drawing.
4. Continuity checks The continuity checks of one PCB from the batch of each type shall be carried out as per the net list.
5. Vcc-GND isolation is cleared
6. The open circuit/short circuit Shall be checked and recorded.</td><td>Microscope &amp;
Multimeter</td><td>Inspection by R&amp;QA/
Project Group Rep</td></tr><tr><td>2</td><td>Components Inspection</td><td></td><td></td></tr><tr><td></td><td>1. Identify the components as per the bill of material and collect from stores
2. Check the component part numbers, visually inspect Components for any damages</td><td>Visual</td><td>Inspection by Internal QC&amp;
R&amp;QA</td></tr><tr><td>3</td><td>PCB Baking</td><td></td><td></td></tr><tr><td></td><td>1. Clean the PCB&#x27;s with isopropyl alcohol
2. Baking of PCB&#x27;s at 110°C for 2 hours
3. Visually inspect the PCB&#x27;s for any damages</td><td>Thermal
Chamber</td><td>Internal QC</td></tr><tr><td>4</td><td>Assembly of components</td><td></td><td></td></tr><tr><td></td><td>Ensure that proper grounding of worktable, floor mat and cleaning tray. Wear the wrist strap
1. Clean the components thoroughly using Isopropyl Alcohol by brush and tray method and shall be verified by internal QC
2. Components shall be assembled as per the layout diagrams
3. IC&#x27;s have to be placed according to the legend
Polarities of the components have to be checked.</td><td>Flux, lead, Soldering iron or SMT</td><td>Inspection by R&amp;QA/
Project Group Rep</td></tr></table>

<table><tr><td colspan="4">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td colspan="2">Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td colspan="3">Date: 10thApril 2025</td></tr><tr><td>S.No</td><td colspan="2">Description</td><td>Tools</td><td colspan="2">Remarks</td></tr><tr><td>5</td><td colspan="2">Cleaning of PCB's</td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2">Ensure that proper grounding of worktable, floor mat and cleaning tray. Wear the wrist strap.
1. The PCB shall be cleaned by using a two tray cleaning method.
2. The trays shall be filled with Isopropyl alcohol.
3. The unclean PCB shall be placed in first tray for 30 minutes.
4. Now, brush it with a nylon brush.
5. The PCB is now put in the second tray for 15 minutes and again cleaned with a brush and air dried for 30 minutes</td><td>Isopropyl alcohol, Nylon brush, Two trays</td><td colspan="2">Internal QC</td></tr><tr><td>6</td><td colspan="2">Wires Routing &amp; Harnessing</td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2">1. Wires shall be routed with shortest length and minimum no. of bends. All wires shall be kept parallel in a hardness bundle. Wires shall not have a moving frictional contact. Wires shall not be pulled, twisted or stressed during assembly.
2. Wire bunches shall be free from dirt, loose hardware and lacing tape scraps etc. Continuity checks from PCB to the mechanical connectors</td><td>Visual</td><td colspan="2">Inspection by R&amp;QA/ Project Group Rep</td></tr><tr><td>7</td><td colspan="2">Physical Inspection</td><td></td><td></td><td></td></tr><tr><td></td><td colspan="2">1. The inspection shall be carried out as per the assembly drawing and BOM.
2. The following checklist shall be ensured.
a. All components assembled are as per the drawing and are at proper position.
b. Check the component count as per the BOM.
c. Check for standard mounting.
d. Check if any component has been damaged during assembly.
e. Check for correct polarity of the tantalum capacitors.
f. Misalignment of parts with solder pads.
g. Check for sufficient stress relief
h. Check for excess length of leads
i. Check that proper mounting have been done for heavy components.
(Since This Unit is Radio frequency related, before functional test all PCB's to be mounted on chassis)</td><td>Microscope</td><td colspan="2">Inspection by R&amp;QA/ Project Group Rep</td></tr><tr><td>8</td><td colspan="2">Functional Testing</td><td></td><td colspan="2"></td></tr><tr><td></td><td colspan="2">Perform the functional testing of the PCB with components mounted in the mechanical housing as per functional test procedure.</td><td>Function Generator, Spectrum Analyzer, Os-cilscope,</td><td colspan="2">Inspection by R&amp;QA/Project Group Rep</td></tr><tr><td>9</td><td colspan="2">Burn in Test</td><td></td><td colspan="2"></td></tr><tr><td></td><td colspan="2">Perform the burning test of the PCB's with components mounted power on condition at temperature of maximum rated operating temperature for 48 hours. Inspection by R&amp;QA/Project Group Rep once in 24 hours for 2days.</td><td></td><td colspan="2">Inspection by R&amp;QA/Project Group Rep</td></tr><tr><td>10</td><td colspan="2">Potting</td><td></td><td colspan="2"></td></tr><tr><td></td><td colspan="2">1. Clean the PCB's thoroughly with isopropyl alcohol.
2. Potting shall be carried out on the components which are specified.
3. Potting shall be done on heavy components on PCB's which are marked in the layout drawing.
4. Allow it dry for at least 24hours at room temperature.
Potting shall be applied on DC-DC converters, Toroid, inductor Beeds, Tantalum Capacitors and Wires</td><td>Visual</td><td colspan="2">Inspection by R&amp;QA/Project Group Rep</td></tr><tr><td>11</td><td colspan="2">Conformal Coating</td><td></td><td colspan="2"></td></tr><tr><td></td><td colspan="2">1. Apply the conformal coating uniformly on both sides of PCB by spraying, dipping, brushing or flow coating and allow it to dry for duration of 30min.
2. The coating thickness is less then specified apply second coating
3. After conformal coating the PCB's shall be cured either at room temperature or at higher temperature as per the specification sheet
4. Visually inspect for uniform application of conformal coating throughout the PCB.
5. There shall be no air bubbles, blistering of coating after drying.</td><td>Micro-scope</td><td colspan="2">Inspection by R&amp;QA/Project Group Rep</td></tr><tr><td>12</td><td colspan="2">Initial Tests</td><td></td><td colspan="2"></td></tr><tr><td></td><td colspan="2">Visual Inspection:Check the unit externally for connectors Identification &amp; Connector Pins, proper mounting provisionIsolation Checks:With multi-meter measure the resistance for 28V supplyLow to chassis and modulation input low to chassis (in the 7 Pin Socket)The above lines should not short to the chassis.Continuity Checks:With multi-meter measure the resistance Between Pin to Pin.Functional Tests:Functional tests shall be carried out as per test procedure</td><td>Multi-meter,FunctionGenerator,SpectrumAnalyzer&amp;Oscilloscope.</td><td colspan="2">Inspectionby R&amp;QA/ProjectGroup Rep</td></tr><tr><td>13</td><td colspan="2">ENTESTS</td><td></td><td colspan="2"></td></tr><tr><td></td><td colspan="2">Environmental tests shall be carried out as per test procedure given.</td><td></td><td colspan="2">Inspectionby R&amp;QA/ProjectGroup Rep</td></tr><tr><td>14</td><td colspan="2">Final Test</td><td></td><td colspan="2"></td></tr><tr><td></td><td colspan="2">Isolation Checks :With multi-meter measure the resistance for 28V supplyLow to chassis and modulation input low to chassis (in the 7Pin Socket)The above lines should not short (zero Ohms) to the chassis.Continuity Checks:With multi-meter measure the resistance Between Pin to Pin.Functional Test:Functional tests shall be carried out as per test procedure.</td><td>Multi-meter,FunctionGenerator,SpectrumAnalyzer&amp;Oscilloscope.</td><td colspan="2">Inspectionby R&amp;QA/ProjectGroup Rep</td></tr></table>

16 QA MATRIX   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td rowspan="2">S.
No.</td><td rowspan="2">Process
Activity</td><td rowspan="2">Quality
Characteristics</td><td rowspan="2">Type of Check</td><td rowspan="2">Sample
Size</td><td rowspan="2">Reference Document</td><td rowspan="2">Format of
Records</td><td colspan="2">Inspection Agency</td></tr><tr><td>Supplier
QC</td><td>R&amp;QA</td></tr><tr><td rowspan="3">1.</td><td rowspan="3">Inspection of Manufactured Parts
(Mechanical Components &amp; Fasteners)</td><td>a) Material</td><td>Type Approval</td><td>100 %</td><td>RCMA Approved MDI</td><td>Inspection Report</td><td>P</td><td>W</td></tr><tr><td>b) Dimension</td><td>Dimensional
Verification</td><td>100%</td><td>RCMA Approved MDI</td><td>Inspection Report</td><td>P</td><td>W</td></tr><tr><td>c) Protective
Coating</td><td>Visual Inspection</td><td>100 %</td><td>RCMA Approved MDI</td><td>Inspection Report</td><td>P</td><td>V</td></tr><tr><td rowspan="3">2.</td><td rowspan="3">Bare PCB Inspection</td><td>Batch Code/Date
Code &amp; SI No</td><td>Physical Verification on PCB with record and along with COC</td><td>100%</td><td rowspan="3">Master Drawing Index (MDI) &amp; Bill Of Materials</td><td>IR</td><td>P</td><td>R</td></tr><tr><td>Dimensional
Verification</td><td>Measurement as Per IR Template</td><td>Sample
30%</td><td>IR</td><td>P</td><td>R</td></tr><tr><td>Electrical
Inspection</td><td>Continuity Check
across various Pwr,
Gnd &amp; Signal Points</td><td>100%</td><td>IR</td><td>P</td><td>R</td></tr><tr><td rowspan="7">3.</td><td rowspan="7">Kit Clearance (Mechanical, Electrical &amp; Electronic Parts Kitting)</td><td>Visual</td><td rowspan="7">Inspection as per acceptance Test Plan</td><td rowspan="7">100%</td><td rowspan="7">As per Approved BOM</td><td rowspan="7">Annexure A to D</td><td rowspan="7">P</td><td rowspan="7">V</td></tr><tr><td>Package</td></tr><tr><td>Part Code</td></tr><tr><td>Source</td></tr><tr><td>Batch Code</td></tr><tr><td>QTY Verification
w.r.t BOM</td></tr><tr><td>COC</td></tr><tr><td rowspan="2">4.</td><td rowspan="2">PCB Assembly</td><td>Alignment of Components</td><td rowspan="2">Visual Inspection as per GA</td><td rowspan="2">100%</td><td rowspan="2">MDI Document</td><td rowspan="2">IR</td><td rowspan="2">P</td><td rowspan="2">V</td></tr><tr><td>Polarity or Orientation of Components</td></tr></table>

EI Wave Digitech (I) Pvt Ltd., Hyderabad.

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

EI Wave Digitech (I) Pvt Ltd., Hyderabad.   

<table><tr><td rowspan="2">S.
No.</td><td rowspan="2">Process
Activity</td><td rowspan="2">Quality
Characteristics</td><td rowspan="2">Type of Check</td><td rowspan="2">Sample
Size</td><td rowspan="2">Reference Document</td><td rowspan="2">Format of
Records</td><td colspan="2">Inspection Agency</td></tr><tr><td>Supplier
QC</td><td>R&amp;QA</td></tr><tr><td rowspan="2"></td><td rowspan="2"></td><td>Soldering
Defects</td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td></tr><tr><td>Component
Missing</td></tr><tr><td>5.</td><td>Unit Assembly</td><td>Workmanship
Fasteners</td><td>As per Document</td><td>100%</td><td>MDI Document</td><td>IR</td><td>P</td><td>W</td></tr><tr><td rowspan="3">6.</td><td rowspan="3">Initial Isolation
&amp; Continuity
Checks</td><td>Continuity Check</td><td rowspan="3">Resistance Check</td><td rowspan="3">100%</td><td rowspan="3">QT/AT Document</td><td rowspan="3">TDRS</td><td rowspan="3">P</td><td rowspan="3">W</td></tr><tr><td>Isolation Check</td></tr><tr><td>Power Supply
Check</td></tr><tr><td>7.</td><td>Initial
Functional Test</td><td>Functional
Requirement</td><td>As per document</td><td>100%</td><td>QT/AT Document</td><td>TDRS</td><td>P</td><td>W</td></tr><tr><td rowspan="3">8.</td><td rowspan="3">CEMILAC
Screening</td><td>High Temp
storage test</td><td rowspan="3">Functional Test
before &amp; after
Screening Test</td><td rowspan="3">100%</td><td rowspan="3">As per CEMILAC
Standard/QT/AT/TS
Document</td><td rowspan="3">IR</td><td rowspan="3">P</td><td rowspan="3">W</td></tr><tr><td>Thermal Shock
test</td></tr><tr><td>Burn-in test</td></tr><tr><td>9.</td><td>Potting</td><td>Potting Material
Potting of PCB</td><td>Potting Material
Potting as per
Drawing</td><td>100%</td><td>BOM/MDI Document</td><td>IR</td><td>P</td><td>W</td></tr><tr><td rowspan="4">10.</td><td rowspan="4">Conformal
Coating</td><td>Coating material</td><td rowspan="4">Conformal Coating
Material</td><td rowspan="4">100%</td><td rowspan="4">BOM/MDI Document</td><td rowspan="4">IR</td><td rowspan="4">P</td><td rowspan="4">W</td></tr><tr><td>Uniformity of
coating</td></tr><tr><td>Thickness</td></tr><tr><td>Finish</td></tr></table>

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

EI Wave Digitech (I) Pvt Ltd., Hyderabad.   

<table><tr><td rowspan="2">S.
No.</td><td rowspan="2">Process 
Activity</td><td rowspan="2">Quality 
Characteristics</td><td rowspan="2">Type of Check</td><td rowspan="2">Sample 
Size</td><td rowspan="2">Reference Document</td><td rowspan="2">Format of 
Records</td><td colspan="2">Inspection Agency</td></tr><tr><td>Supplier 
QC</td><td>R&amp;QA</td></tr><tr><td rowspan="3">11.</td><td rowspan="3">Initial Isolation &amp; Continuity Checks</td><td>Continuity Check</td><td rowspan="3">Resistance Check</td><td rowspan="3">100%</td><td rowspan="3">QT/AT Document</td><td rowspan="3">TDRS</td><td rowspan="3">P</td><td rowspan="3">W</td></tr><tr><td>Isolation Check</td></tr><tr><td>Power Supply Check</td></tr><tr><td>12.</td><td>Initial Functional Test</td><td>Functional Requirement</td><td>As per functional test</td><td>100%</td><td>QT/AT Document</td><td>TDRS</td><td>P</td><td>W</td></tr><tr><td rowspan="3">13.</td><td rowspan="3">ESS</td><td>Pre-Random Vibration (RV1)</td><td rowspan="3">Preet, Insert &amp; Poet</td><td rowspan="3">100%</td><td rowspan="3">QT / AT Document</td><td rowspan="3">TDRS</td><td rowspan="3">P</td><td rowspan="3">W</td></tr><tr><td>Thermal Cycling</td></tr><tr><td>Post Random Vibration (RV2)</td></tr><tr><td rowspan="13">14.</td><td rowspan="13">Qualification test</td><td>EMI/EMC</td><td rowspan="13">Preet, Insert &amp; Poet</td><td rowspan="13">100%</td><td rowspan="13">QT Document</td><td rowspan="13">TDRS</td><td rowspan="13">P</td><td rowspan="13">W</td></tr><tr><td>High Temperature</td></tr><tr><td>Low Temperature</td></tr><tr><td>CATH Test</td></tr><tr><td>Thermal Shock</td></tr><tr><td>Tropical Heating</td></tr><tr><td>Random Vibration</td></tr><tr><td>Shock Test</td></tr><tr><td>Bump test</td></tr><tr><td>Acceleration Test</td></tr><tr><td>Fungus Test</td></tr><tr><td>Saline Test</td></tr><tr><td>Continuous Run Test</td></tr></table>

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

Table 17: QA Matrix   

<table><tr><td rowspan="2">S.
No.</td><td rowspan="2">Process 
Activity</td><td rowspan="2">Quality 
Characteristics</td><td rowspan="2">Type of Check</td><td rowspan="2">Sample 
Size</td><td rowspan="2">Reference Document</td><td rowspan="2">Format of 
Records</td><td colspan="2">Inspection Agency</td></tr><tr><td>Supplier 
QC</td><td>R&amp;QA</td></tr><tr><td rowspan="4">15.</td><td rowspan="4">Acceptance 
Test</td><td>EMI/EMC</td><td rowspan="4">Preet, Insert &amp; Poet</td><td rowspan="4">100%</td><td rowspan="4">AT Document</td><td rowspan="4">TDRS</td><td rowspan="4">P</td><td rowspan="4">W</td></tr><tr><td>Tropical Heating</td></tr><tr><td>Shock test</td></tr><tr><td>Continuous Run Test</td></tr><tr><td rowspan="3">16.</td><td rowspan="3">Final Isolation 
&amp; continuity 
Checks</td><td>Continuity Check</td><td rowspan="3">Resistance Check</td><td rowspan="3">100%</td><td rowspan="3">QT/AT Document</td><td rowspan="3">TDRS</td><td rowspan="3">P</td><td rowspan="3">W</td></tr><tr><td>Isolation Check</td></tr><tr><td>Power Supply Check</td></tr><tr><td rowspan="2">17.</td><td rowspan="2">Final 
Functional Test</td><td>Functional Requirement</td><td rowspan="2">As per functional test</td><td rowspan="2">100%</td><td rowspan="2">QT/AT Document</td><td rowspan="2">TDRS</td><td rowspan="2">P</td><td rowspan="2">W</td></tr><tr><td>Visual 
Connector, Caps, Tightness of fasteners, Packing Case, SI No. of Unit &amp; Packing box</td></tr><tr><td>18.</td><td>Report 
Generation &amp; 
Clearance</td><td>Verification as per QT/AT Document</td><td>Report Verification</td><td>100%</td><td>IR</td><td>IR</td><td>P</td><td>R</td></tr></table>

P- Perform; V- Verify; R- Review; W- Witness, TDRS- Test Data Record sheet, IR- Inspection Report.

<table><tr><td colspan="16">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td colspan="3">Classified: Restricted</td></tr><tr><td colspan="9">Doc No: EIWAVE/TX222SAW/QAP</td><td colspan="3">Is. No:01</td><td colspan="4">Rev No:00</td><td colspan="3">Date: 10thApril 2025</td></tr><tr><td colspan="19">17 QA DIRECTIVE 06/2018- KIT OF PARTS
Annexure &#x27;A&#x27; - Kit Inspection format (Electrical/Electronics)</td></tr><tr><td colspan="19">REQUIREMENT AS PER BILL OF MATERIAL (BOM)</td></tr><tr><td colspan="2">BOM SL. No</td><td colspan="2">Part No. / 
Type No.</td><td colspan="2">Description</td><td colspan="3">OEM / 
Manufacturer Part 
No.</td><td colspan="2">Qty. / Set</td><td colspan="2">Lead Finish</td><td colspan="3">Component Category (MIL 
/ QML / QPL / LCSO / 
Industrial / Automotive</td><td colspan="2">Component grade 
/ Operational 
Temp and Storage</td><td></td></tr><tr><td colspan="2"></td><td colspan="2"></td><td colspan="2"></td><td colspan="3"></td><td colspan="2"></td><td colspan="2"></td><td colspan="3"></td><td colspan="3"></td></tr><tr><td colspan="19">Annexure &#x27;B&#x27; - Kit Inspection Format for Electronics Components</td></tr><tr><td colspan="19">Data of Received Part</td></tr><tr><td>G 
R 
N 
o</td><td>Ma
nuf 
act 
ur</td><td>Manufacture 
r Part No. 
marking on 
the item 
Pack&#x27; COC</td><td>On 
item 
marki 
ng</td><td>Date 
code/ 
batch 
code</td><td>COC 
(OE 
M/ 
OEM 
Franc 
ises</td><td>Test 
reports/ 
Material 
Analysi 
s Report</td><td>Qty. 
offere 
d/che 
cked</td><td>Exp 
iry 
Date</td><td>ESD 
or 
Non 
ESD</td><td>MSD of 
Non- 
MSD</td><td>ROH 
S or 
Non 
ROHS</td><td>Pack. 
Type</td><td>Lead 
Finish/ 
Solder 
coated/ Go 
ld plated / 
Surface 
Finish and 
Thickness</td><td>Nos. 
of 
Pins</td><td>Visual 
Inspection / 
Testing at 
MI 
Visual 
Inspection / 
Corrosion / 
rust / pitting 
/ scratches / 
cracks</td><td>Di 
me 
nsi 
on/ 
Siz 
e</td><td>Re 
mar 
ks</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Annexure 'C'- Kit inspection format (Mechanical)   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td>Sl No.</td><td>BO M S1 No.</td><td>Raw material Batch No.</td><td>Material Specification/ Material Code</td><td>Spectrometric Verification of Material</td><td>Manufacturing Process of Item</td><td>Heat Treatment/Brazing/an annealing/ forging etc. of the item, Process and Batch No.</td><td>Mechanical properties test on samples(heat treatment</td><td>Non Destructive Testing on the components</td><td>Micro metric Examination</td><td>Surfac e Treatment</td><td>Functional/Fi tment test</td><td>Any Speci al test</td><td>Final Accepta nce/Itemization/ Tag Generation</td><td>Preservati on Details/Tag Endorse ment</td><td>Visual Inspection before assembly/detail part inspect for assembly</td><td>Remarks</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Annexure 'D'- Kit Inspection format (consumables)   

<table><tr><td>Sl 
No.</td><td>Raw 
Material 
Batch No</td><td>Material 
Specification/ 
Material Code</td><td>Part No.</td><td>Nomenclature</td><td>Date of 
Manufacturing</td><td>Shelf life/ Date of 
Expiry</td><td>Qty per Packing</td><td>Total Packed Qty</td><td>Storage Conditions</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

![](images/f3b58372df832d68423271e72137519cd90b95f6c3ede1b1e6185e3834ae7c55.jpg)

18 MECHANICAL DIMENSION INSPECTION   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date: 10th April 2025</td></tr></table>

<table><tr><td colspan="3">PROJECT: SAAW</td><td colspan="5">MODULE NAME: S-Band 2W Transmitter</td><td colspan="2">MODEL No.: El-02-SB-2W-TX</td><td colspan="2">DATE:</td></tr><tr><td rowspan="2">Item S.No.</td><td colspan="3">LENGTH</td><td colspan="2">WIDTH</td><td colspan="2">HEIGHT</td><td rowspan="2">HOLE / TAPPED</td><td rowspan="2">FINISH</td><td>OBSERVED</td><td>REMARKS</td></tr><tr><td>SPECIFIED</td><td>OBSERVED</td><td>SPECIFIED</td><td>OBSERVED</td><td>SPECIFIED</td><td>OBSERVED</td><td></td><td>OK / NOT OK</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="8">SPECIFIED WEIGHT OF THE UNIT: 1.0 Kgs (Max)</td><td colspan="4">OBSERVED WEIGHT OF THE UNIT:</td></tr><tr><td colspan="3">QC PASSED / REJECTED:</td><td colspan="9"></td></tr></table>

QC PASSED/REJECTED:

![](images/067f9b1261ec35e7dd7b15689a28ae79d0b3e81e143aa1ece4c14ad4de997063.jpg)

EI WAVE Rep

R&QA Rep

19 PCB INSPECTION REPORT   

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date:10th April 2025</td></tr></table>

<table><tr><td>Project</td><td>SAAW</td><td>Date</td><td></td></tr><tr><td>Item Name</td><td>S-Band 2W Transmitter</td><td>Rev No</td><td>00</td></tr><tr><td>Model No</td><td></td><td>PCB Description</td><td></td></tr><tr><td>Drawing No</td><td></td><td>PCB S/N</td><td></td></tr><tr><td>PCB Manufacturer</td><td></td><td>QTY Received</td><td></td></tr><tr><td>Test Data Received</td><td></td><td>COC Received</td><td></td></tr></table>

<table><tr><td>S/N</td><td>PERAMETERS</td><td>RESULTS</td><td>USED INSTRUMENTS NAME &amp; S/N &amp; MODEL NO</td><td>REMARKS</td></tr><tr><td>1</td><td>PCB Material</td><td></td><td></td><td></td></tr><tr><td>2</td><td>PCB Dimensions</td><td></td><td></td><td></td></tr><tr><td>3</td><td>PCB Thickness</td><td></td><td></td><td></td></tr><tr><td>4</td><td>PCB No of Layers</td><td></td><td></td><td></td></tr><tr><td>5</td><td>PCB Level / Version</td><td></td><td></td><td></td></tr><tr><td>6</td><td>PCB Masking</td><td></td><td></td><td></td></tr><tr><td>7</td><td>PCB Final Surface Finish</td><td></td><td></td><td></td></tr><tr><td>8</td><td>PCB NET list</td><td></td><td></td><td></td></tr><tr><td>9</td><td>PCB Tracks Top &amp; Bottom Side</td><td></td><td></td><td></td></tr><tr><td>10</td><td>PTHs and NPTH</td><td></td><td></td><td></td></tr><tr><td>11</td><td>Cricuit Diagram</td><td></td><td></td><td></td></tr><tr><td>12</td><td>Components and IC&#x27;s Direction</td><td></td><td></td><td></td></tr><tr><td>13</td><td>Components and IC&#x27;s Packages</td><td></td><td></td><td></td></tr></table>

Remarks if any:

Inspected by

Approved by

Name & Designation

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date:10th April 2025</td></tr></table>

![](images/add9e24a694fb7fcce6295fcad19d1b1e88339aba2e0d32fba5810cc6039e93f.jpg)  
20 INTERNAL WIRING DIAGRAM

Table 18: Wiring details   

<table><tr><td>Reference</td><td>Description</td><td>From</td><td>To</td></tr><tr><td>W1</td><td>PS HIGH 28V±4V</td><td>J1 -Pin1</td><td>TP8</td></tr><tr><td>W2</td><td>PS HIGH 28V±4V</td><td>J1 -Pin2</td><td>TP8</td></tr><tr><td>W3</td><td>PS LOW 28V±4V</td><td>J1 -Pin3</td><td>TP7</td></tr><tr><td>W4</td><td>PS LOW 28V±4V</td><td>J1 -Pin4</td><td>TP7</td></tr><tr><td>W5</td><td>MOD HIGH (H)</td><td>J1 -Pin5</td><td>TP1</td></tr><tr><td>W6</td><td>MOD LOW (L)</td><td>J1 -Pin6</td><td>TP2</td></tr><tr><td>W7</td><td>TX+</td><td>J4 -Pin1</td><td>PS_TX+</td></tr><tr><td>W8</td><td>TX-</td><td>J4 -Pin2</td><td>PS_TX-</td></tr><tr><td>W9</td><td>RX+</td><td>J4 -Pin3</td><td>PS_RX+</td></tr><tr><td>W10</td><td>RX-</td><td>J4 -Pin4</td><td>PS_RX-</td></tr><tr><td>W11</td><td>PD+</td><td>J4 -Pin5</td><td>PS_PD+</td></tr><tr><td>W12</td><td>PD-</td><td>J4 -Pin6</td><td>PS_PD-</td></tr><tr><td>W13</td><td>GND</td><td>J4 -Pin7</td><td>PS_GND</td></tr><tr><td>W14</td><td>CLOCK</td><td>J4 -Pin8</td><td>PS_CLOCK</td></tr><tr><td>W15</td><td>RESET</td><td>J4 -Pin9</td><td>PS_RESET</td></tr><tr><td>W16</td><td>FORWARD POWER</td><td>PS_TP14</td><td>PA_FWD</td></tr><tr><td>W17</td><td>REVERSE POWER</td><td>PS_TP13</td><td>PA_REV</td></tr><tr><td>W18</td><td>24V</td><td>PS_TP9</td><td>PA_24V</td></tr><tr><td>W19</td><td>-2V</td><td>PS_TP10</td><td>PA_-2V</td></tr><tr><td>W20</td><td>3.3V</td><td>PS_TP16</td><td>PA_3.3V</td></tr><tr><td>W21</td><td>5V</td><td>PS_TP11</td><td>PA_5V</td></tr><tr><td>W22</td><td>TEMP</td><td>PS_TP15</td><td>PA_TEMP</td></tr><tr><td>W23</td><td>RF OUT</td><td>PS_RF_OUT</td><td>PA_RF_IN</td></tr><tr><td>W24</td><td>REVERSE POWER</td><td>PA_REV</td><td>PD</td></tr><tr><td>W25</td><td>FORWARD POWER</td><td>PA_FWD</td><td>PD</td></tr></table>

![](images/a4791eebbbe1c732b4d2489a16fc999f92c77cb6df0aacbcc243354f3dff9f60.jpg)

# 21 SAFETY PRECAUTION

S-Band 2 WATT Transmitter is a ruggedized Microwave RF sub-system. This has been designed to operate under harsh environmental conditions and does not need any special precautions while handling and store except that it should not be dropped from undue heights. All the connectors should be covered with dust caps provided when not in use. these dust caps to be removed before integrating into flight vehicles.

# 22 HANDLING

Static electric charges any electrical device may be susceptible to damage when exposed to static electrical charges. To avoid damage to the Transmitter observe the following

Operator/ installer should follow the proper ESD (Electrostatic Discharge) protection procedures before handling the Transmitter components.

Ground the body of the device before making any electrical connections.

When disconnecting, remove the ground last! The Shield and drain wire in the cable (if supplied) is not connected to the transmitter body and is not a suitable ground.

# 23 PACKAGING

Product should be properly packed in the box. All connectors should be covered with dust caps.

# 24 STORAGE

Storage The Transmitter must be stored in dry, clean conditions, within room temperature, protected against direct exposure to sunlight and protected against impact damage.

# 25 TRANSPORTATION INSTRUCTION

Safety The Transmitter should be protected against the effects of knocks and impacts. These device should only be transported in the packaging provided to prevent damage. The device should only be transported in a clean condition (free of residues of measuring media).

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date:10thApril 2025</td></tr><tr><td colspan="4">Transport inspection Delivery should be checked for completeness and potential damage due to transport. In the event damage, delivery must not be accepted, or only accepted subject to reservation of the scope of the damage being recorded.
Storage the pressure gauge must be stored in dry, clean conditions, within the room temperature, protected against direct exposure to sunlight and protected against impact damage.
26 ASSEMBLY AND DISASSEMBLY
Assembly:
1. First assembly the components on the Bare PCB&#x27;s. Then clean the PCB&#x27;s with Alcohol and then dry the PCB with dryer
2. Next integrate the PCB&#x27;s in the Housing. Then fix the screws tightly
3. Now fix the Isolator with screws.
4. Next fix the connectors in the housing. Solder the wires of connectors on the PCB&#x27;s as per Wiring Diagram which is given below.
5. Check continuity of connectors with Multi-meter. See that all 4 connectors are tightly fixed with screws.
6. Now check continuity of IC&#x27;s and Chip components. If OK then proceed with Functional Checks.
7. After testing remove all sharp edges and also clean the PCB&#x27;s with Alcohol.
8. Potting for screws, wires to be done. Then leave it for one day to get dried.
9. Then Final conformal coating to be done for Power Supply PCB.
10. Place the gasket on the top and bottom plate.
11. Then fix the screws of top and bottom plate.
12. At last fix the Unit in the SAAW Missile.
Disassembly:
1. Remove the screws of the unit.
2. Then open the Top and Bottom plate.</td></tr></table>

<table><tr><td colspan="4">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date:10thApril 2025</td><td></td></tr><tr><td colspan="5">UNIT CONFIGURATION REPORT:</td></tr><tr><td>S.No</td><td>PCB No</td><td>Description</td><td colspan="2">Remarks</td></tr><tr><td>1</td><td>EI-02-SB-2W-TX-01-0A</td><td>Power Supply &amp; 
PLL SYNTH PCB</td><td colspan="2"></td></tr><tr><td>2</td><td>EI-02-SB-2W-TX-02-0E</td><td>Power Amplifier PCB</td><td colspan="2"></td></tr><tr><td>3</td><td>EI-02-SB-2W-TX-03-0A</td><td>Power Divider PCB</td><td colspan="2"></td></tr></table>

<table><tr><td colspan="3">Doc Name: QAP Document of S-Band 2-Watt Transmitter for Project SAAW</td><td>Classified: Restricted</td></tr><tr><td>Doc No: EIWAVE/TX222SAW/QAP</td><td>Is. No:01</td><td>Rev No:00</td><td>Date:10thApril 2025</td></tr><tr><td colspan="4">27 FAILURE ANALYSIS REPORT
RCI Failure Analysis/ R&amp;QA form-FA</td></tr><tr><td>1. Name of the project</td><td>:</td><td></td><td></td></tr><tr><td>2. Failure Reported by</td><td>:</td><td></td><td></td></tr><tr><td>3. Date</td><td>:</td><td></td><td></td></tr><tr><td>4. Sub System</td><td>:</td><td></td><td></td></tr><tr><td>Drawing No</td><td>:</td><td></td><td></td></tr><tr><td>Description</td><td>:</td><td></td><td></td></tr><tr><td>Operating Time</td><td>:</td><td></td><td></td></tr><tr><td>Module</td><td>:</td><td></td><td></td></tr><tr><td>Assembly</td><td>:</td><td></td><td></td></tr><tr><td>Sub- Assembly</td><td>:</td><td></td><td></td></tr><tr><td>5. Failure Observed During</td><td>: Pre- Screen Test</td><td></td><td></td></tr><tr><td></td><td></td><td>Environment Test</td><td></td></tr><tr><td></td><td></td><td>Post-Screen Test</td><td></td></tr><tr><td>6. Description of Failure</td><td>:</td><td></td><td></td></tr><tr><td>7. Analysis / Cause of Failure</td><td colspan="3">: Incorrect Operation / Incorrect Handling
Improper Design / Manufacturing</td></tr><tr><td>8. Follow UP/ Corrective Action</td><td>:</td><td></td><td></td></tr><tr><td>For Defect Rectification</td><td>:</td><td></td><td></td></tr><tr><td colspan="4">9. Remarks/ Review of Corrective or Preventive action taken :</td></tr><tr><td>Project Manager</td><td>:</td><td></td><td></td></tr><tr><td>DR&amp;QA</td><td>:</td><td></td><td></td></tr><tr><td>RDAQA(GW&amp;M)/MSQAA</td><td>:</td><td></td><td></td></tr><tr><td>RRCMA(Msl)</td><td>:</td><td></td><td></td></tr><tr><td colspan="3">Approved by: 
RD.RCMA(Msl)</td><td>(R&amp;QA Rep)</td></tr><tr><td colspan="3">El Wave Digitech (I) Pvt Ltd., Hyderabad.</td><td>54</td></tr></table>
