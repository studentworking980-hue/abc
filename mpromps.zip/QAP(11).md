 <table><tr><td colspan="2">RESEARCH CENTRE IMARAT</td><td colspan="2">DOC. No.: RCI/DOFI/CPSCPV2.2/QAP(E)/01
ISSUE No.: 00
REV No.: 0
Project Name: VSHORADS-SF
Date: 10-05-2025
Supply Order No:
Total No. Of Pages:161</td></tr><tr><td colspan="4">DOCUMENT CLASSIFICATION:&quot;RESTRICTED&quot;
Document Name: QUALITY ASSURANCE PLAN(QAP)
System Name: Critical Parameter Signal Conditioning Package Version 2.2(CPSCP)</td></tr><tr><td>TASK</td><td>NAME &amp; DESIGNATION</td><td>GROUP</td><td>SIGN</td></tr><tr><td>PREPARED BY:</td><td>Ch. vikas</td><td>ATL</td><td>Qik#</td></tr><tr><td rowspan="3">VERIFIED BY:</td><td>Sudhir Kommuri, Project Manager</td><td>ATL</td><td>Sudle#</td></tr><tr><td>T.K. Pavan Sai To -‘A’</td><td>DOFI, RCI</td><td>T.K. Pawan#</td></tr><tr><td>Mr. Ashish Kumar Sc &#x27;E&#x27;</td><td>DOFI, RCI</td><td>Ash#</td></tr><tr><td rowspan="3">REVIEWED BY:</td><td>K Srinivasu Reddy, General Manager</td><td>ATL</td><td>K S#</td></tr><tr><td>Mrs. Shivani Garg Sc&#x27;G&#x27;</td><td>DOFI,RCI</td><td>Mg#</td></tr><tr><td>Anil kumar prajapati, Sc&#x27;B&#x27;</td><td>DR&amp;QA,RCI</td><td>Anil Kumar#</td></tr><tr><td>APPROVED BY:</td><td>Dr.G Mallikarjuna Rao Sc&#x27;G&#x27;</td><td>DR&amp;QA,RCI</td><td></td></tr><tr><td>APPROVED BY:</td><td>Atul Pawar, Sc-&#x27;G&#x27;
Technology director</td><td>DOFI, RCI</td><td></td></tr><tr><td>ISSUE
AUTHORISED
BY:</td><td>Kaushik Ghoshal Sc&#x27;F&#x27;
Project director,VSHORADS-SF</td><td>RCI</td><td></td></tr><tr><td>DISTRIBUTION:</td><td colspan="3">1. DOFI
2. DR&amp;QA, RCI
3. VSHORADS-SF, RCI
4. ANANTH TECHNOLOGIES PVT. LTD.</td></tr></table>

# I.O.N

No. RCI/SF VSH/QA/08_01

Dated: 04.08.2025

Ref:

1. ENTEST Specifications for VSHORADS Missile, Doc No. RCI/VSHORADS/ENTEST Dated 22.04.2021   
2. ENTEST Specifications for VSHORADS Ground Systems, Doc No. RCI/VSHORADS/ENTEST/GS Dated Sept 2021

# SUBJECT: INTERMEDIATE APPLICABILITY OF VSHORADS ENTEST SPECIFICATIONS FOR SF VSHORADS WEAPON SYSTEM

1. DCMM Proj/SF VSHORADS is an RCI Build-up effort to realize a shoulder fired weapon system. Multiple number of Hardware are being realized for the project through inhouse efforts of RCI/DRDL/ASL/HEMRL/ARDE and Industries.   
2. The ENTEST document for SF VSHORADS is under approval and will be published subsequently.   
3. But principally VSHORADS ENTEST specification for the missile and Ground systems is the superset of SF VSHORADS ENTEST specifications, as VSHORADS experiences more manoeuvrability (higher axial & lateral 'g') & shock on avionics/ electrical LRUs (Head end Rocket Motor Ignition) compared with SF VSHORADS (lesser axial & lateral 'g' and Nozzle end Rocket Motor Ignition). Otherwise, from trial operation view point both are similar, i.e., tube launched (3 rails per tube) and to be launched from same ground-based tripod launcher (till developmental trials). In addition to that form factor and thrust of SF VSHORADS weapons system are lesser offering lesser restraining / recoil forces.   
4. Hence as intermediate solution, till publication of SF VSHORADS ENTEST Specification and till maiden control flight of SF VSHORADS AND for realizing the SF VSHORADS Hardware (avionic, electrical & mechanical), VSHORADS ENTEST documents can be followed and based upon the same Clearance certificate/Green Card/Boarding Passes can be issued by associated QA Agencies of all work centres.

Kaushke (Kaushik Ghoshal)  
Scientist - F  
Team Leader,  
SF VSHORADS, RCI

5nly5n.

(Sandeep M Satav)

OS & TD - DETT, RCI

Vice Charman,

SF VSHORADS - ENTEST Committee

Sandeep M. Satay

To,

Sc-H/OS & TD, DETT

1. Concerned QA Agencies (RCI, DRDL, ASL, HEMRL, ARDE)   
2. Technology Directors & System Managers (RCI, DRDL, ASL, HEMRL, ARDE)

# CONTENTS

<table><tr><td>Sl. No.</td><td>Description</td><td>Page No</td></tr><tr><td>1.</td><td>AMENDMENT RECORD SHEET</td><td>3</td></tr><tr><td>2.</td><td>ABBREVIATIONS</td><td>4</td></tr><tr><td>3.</td><td>INTRODUCTION</td><td>5</td></tr><tr><td>3.1.</td><td>Scope of the Document</td><td>5</td></tr><tr><td>3.2.</td><td>List of Figures</td><td>6</td></tr><tr><td>3.3.</td><td>List of Tables</td><td>6</td></tr><tr><td>3.4.</td><td>List of Reference Documents</td><td>7</td></tr><tr><td>3.5.</td><td>List of Standards</td><td>7</td></tr><tr><td>3.6.</td><td>List of Channels</td><td>7</td></tr><tr><td>4</td><td>SYSTEM TECHNICAL SPECIFICATIONS</td><td>8</td></tr><tr><td>4.1.</td><td>Power supply requirements</td><td>8</td></tr><tr><td>4.2.</td><td>Sensor Module Output and CPSCP Input Specifications</td><td>8-11</td></tr><tr><td>4.3.</td><td>Output Specifications</td><td>12</td></tr><tr><td>4.4.</td><td>Mechanical Specifications</td><td>13</td></tr><tr><td>4.5.</td><td>PCB Specifications</td><td>14</td></tr><tr><td>4.6</td><td>Connector Details</td><td>14</td></tr><tr><td>5</td><td>CONNECTOR PIN ASSIGNMENTS</td><td>15-16</td></tr><tr><td>6</td><td>SEQUENCE OF ACTIVITIES</td><td>17</td></tr><tr><td>7</td><td>SYSTEM OVERVIEW</td><td>18</td></tr><tr><td>7.1.</td><td>Functional Description</td><td>19</td></tr><tr><td>7.2.</td><td>Test Procedure For Critical Parameters Signal Condition Packets(Cpsc) Testing</td><td>19</td></tr><tr><td>7.3.</td><td>Board Level Tests</td><td>20-21</td></tr><tr><td>7.4</td><td>Initial Functional Checks</td><td>22-39</td></tr><tr><td>8</td><td>LIST OF DRAWINGS</td><td>30</td></tr><tr><td>9.</td><td>PROCESS FLOW CHART</td><td>31-33</td></tr><tr><td>10</td><td>PROCESS FLOW DESCRIPTION</td><td>34-37</td></tr><tr><td>11</td><td>QUALITY AASSURANCE MATRIX</td><td>38-40</td></tr><tr><td>11.1</td><td>Screening Procedures for Cots Components/PCBS</td><td>41</td></tr><tr><td>11.2</td><td>Screening Test for Discrete Components</td><td>42-43</td></tr><tr><td>11.3</td><td>Screening Test for Populated PCB'S</td><td>44-46</td></tr><tr><td>12</td><td>SEQUENCE OF ACTIVITES</td><td>47</td></tr><tr><td>13</td><td>QUALIFICATION AND ACCEPTANCE TEST(QT-AT)</td><td>48-49</td></tr><tr><td>13.1</td><td>Flow Charts</td><td>49</td></tr><tr><td>13.2</td><td>EMI/EMC TESTS</td><td>50-53</td></tr><tr><td>13.3</td><td>ESS TEST</td><td>54-55</td></tr><tr><td>13.4</td><td>HIGH TEMPERATURE</td><td>56</td></tr><tr><td>13.5</td><td>LOW TEMPERATURE</td><td>57</td></tr><tr><td>13.6</td><td>ACCELERATION TEST</td><td>58</td></tr><tr><td>13.7</td><td>SHOCK TEST</td><td>59</td></tr><tr><td>13.8</td><td>TROPICAL EXPOSURE TEST</td><td>60</td></tr><tr><td>13.9</td><td>DAMP HEAT TEST</td><td>61</td></tr><tr><td>13.10</td><td>AT Matrix</td><td>62</td></tr><tr><td>13.11</td><td>QT Matrix</td><td>63</td></tr><tr><td>14</td><td>ENVIRONMENTAL TEST SPECIFICATION</td><td>64</td></tr><tr><td>14.1</td><td>Qualification Testing</td><td>64</td></tr><tr><td>14.2</td><td>Acceptance Testing</td><td>65</td></tr><tr><td>15</td><td>Safety Requirements</td><td>66</td></tr><tr><td>16</td><td>Handling</td><td>66</td></tr><tr><td>16.1</td><td>Handling of Static Charge Sensitive Devices</td><td>66</td></tr><tr><td>16.2</td><td>Handling during Assembly</td><td>67</td></tr><tr><td>16.3</td><td>Handling of Packages</td><td>67</td></tr><tr><td>16.4</td><td>Handling during Conformal Coating</td><td>68</td></tr><tr><td>17</td><td>Storage</td><td>68</td></tr><tr><td>17.1</td><td>Storage Control</td><td>68</td></tr><tr><td>17.2</td><td>Transit Stores</td><td>68</td></tr><tr><td>18</td><td>Packaging</td><td>69</td></tr><tr><td>18.1</td><td>General</td><td>69</td></tr><tr><td>18.2</td><td>Packing for Transportation</td><td>69</td></tr><tr><td>19</td><td>Transportation</td><td>69</td></tr><tr><td>20</td><td>PROCESS INSPECTION REPORTS</td><td>66-79</td></tr><tr><td>20.1</td><td>Internal Wiring Details</td><td>84</td></tr><tr><td></td><td>Test Reports</td><td></td></tr><tr><td></td><td>Appendix A: Test Leaf for Unit Level</td><td>85-104</td></tr><tr><td></td><td>Appendix B: Entest test Reports</td><td>105-121</td></tr><tr><td></td><td>Appendix C: Test Leaf for Board Level Checks</td><td>122-126</td></tr><tr><td></td><td>Appendix D: Isolation Resistance Checks</td><td>127-150</td></tr><tr><td></td><td>Appendix E: RTD Temperature vs. Resistance Table</td><td>151-154</td></tr><tr><td></td><td>Appendix F: Conformance Reports</td><td>155-159</td></tr><tr><td>21</td><td>Failure Analysis</td><td>160</td></tr><tr><td>22</td><td>Scale Factor For Conversion of Count to Physical Value</td><td>161</td></tr></table>

1. AMENDMENT RECORD SHEET   

<table><tr><td>Sl. No</td><td>Version No.</td><td>Date (DD/MM/YYYY)</td><td>Change Description</td><td>Authorized Signatory</td><td>Remarks</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>-</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Note: All amendments to this QAP will be reviewed and approved by PROJECT and DR&QA*.

# 2. ABBREVIATIONS

<table><tr><td>ATL</td><td>Ananth Technologies Limited</td></tr><tr><td>CATH</td><td>Combined Altitude, Temperature and Humidity</td></tr><tr><td>DR&amp;QA</td><td>Reliability &amp; Quality Assurance</td></tr><tr><td>CPSCP</td><td>Critical Parameter Signal Conditioning Package Version 2.2</td></tr><tr><td>NRZ-L</td><td>Non Return to Zero</td></tr><tr><td>DC-DC</td><td>Direct Current to Direct Current</td></tr><tr><td>Biφ-L</td><td>Bi-Phasal</td></tr><tr><td>RTD</td><td>Resistance Temperature Detector</td></tr><tr><td>FPGA</td><td>Field Programmable gate array</td></tr><tr><td>ITS</td><td>Integrated Telemetry System</td></tr><tr><td>RF</td><td>Radio Frequency</td></tr><tr><td>IPD</td><td>Integration Process Document</td></tr><tr><td>JTAG</td><td>Joint Test Action Group</td></tr><tr><td>QAP</td><td>Quality Assurance Plan</td></tr><tr><td>PCM</td><td>Pulse code modulation</td></tr><tr><td>FIR</td><td>Finite Impulse Response Filter</td></tr><tr><td>IRIG</td><td>Inter Range instrumentation Group</td></tr><tr><td>PGA/PA</td><td>Programmable Gain Amplifier/Programmable Attenuator</td></tr><tr><td>QT</td><td>Qualification Test</td></tr><tr><td>MIUT</td><td>Missile Interface Unit [with Telemetry(PCM &amp; Transmitter)]</td></tr></table>

# 3. INTRODUCTION

Telemetry is the process by which an object's characteristics are measured (such as velocity of an aircraft), and the results transmitted to a distant station where they are displayed, recorded, and analyzed. The transmission media may be air and space for satellite applications, or copper wire and fiber cable for static ground applications like power generating plants.

Pulse Code Modulation (PCM) Telemetry is a way of acquiring data in one location, converting the data samples to digital words, encoding the data in a serial digital format, and transmitting it on a carrier (FM) to another location for decoding and analysis. PCM systems are less susceptible to noise than analog systems, and the digital data is easier to transmit, record, and analyze. Integrated Telemetry system provides integration of Data Acquisition System with sensors and antenna.

Integrated Telemetry system acquires data from following sources

ITS Encodes the data acquired from the above sources as per IRIG-106-04 (chapter-4) compliant PCM frame format. A digitally implemented pre-modulation filter limits the RF bandwidth and provides data for FM transmission. Then the data stream is transmitted to ground stations through the transmitter and transmitting antenna.

Integrated Telemetry System is an end-to-end solution being developed by DOFI, for flight instrumentation of various Projects. It is intended to collect data from various subsystems of the vehicle and to transmit the collected data to the ground station for health monitoring and performance evaluation of the vehicle.

A Subset of ITS is used to collect data from various analog channels and to form a packet to be sent over RS422 to IAM-SF, where it is formed in a Telemetry frame along with digital parameters and provides data for FM transmission.

This system has been named as Critical Parameter Signal Conditioning Package (CPSCP V3.0)

# 3.1. Scope of the Document

The purpose of this document is to bring-out the test procedure of Critical Parameter Signal Conditioning Package which includes SCP and Power Card, test procedures; test leafs with acceptance criteria, QT/AT conformance reports

# 3.2. List of Figures

<table><tr><td>List of Figures</td><td>Page No</td></tr><tr><td>Figure 1:RTD Temperature Sensor PT100</td><td>10</td></tr><tr><td>Figure 2:CPSCP Mechanical Chassis</td><td>13</td></tr><tr><td>Figure 3:Top Level Representation of the System</td><td>18</td></tr><tr><td>Figure 4:Block Diagram for functional representation of cards</td><td>18</td></tr><tr><td>Figure 5:Anti-Aliasing Filter Test Set Up</td><td>20</td></tr><tr><td>Figure 6:Burn-In Test Setup</td><td>21</td></tr><tr><td>Figure 7:Power Consumption Test Set Up</td><td>22</td></tr><tr><td>Figure 8:Test Setup - Current Excitation to RTD and Strain Gauge</td><td>23</td></tr><tr><td>Figure 9:Test Setup -Pressure Channel Excitation</td><td>24</td></tr><tr><td>Figure 10:Test Setup - RTD Channels Calibration</td><td>25</td></tr><tr><td>Figure 11:Test Setup - Strain Gauge Channels</td><td>25</td></tr><tr><td>Figure 12:Test Setup - Pressure Channels</td><td>26</td></tr><tr><td>Figure 13:Test Setup - Vibration Channels</td><td>27</td></tr><tr><td>Figure 14:Test Setup - Shock Channels</td><td>28</td></tr><tr><td>Figure 15:Test Setup - Filter Cut-off Frequencies</td><td>29</td></tr><tr><td>Figure 16:Test Setup - RS422 Interface Test</td><td>29</td></tr><tr><td>Figure 17:Test Setup - Environmental tests</td><td>48</td></tr></table>

# 3.3.List of Tables

<table><tr><td>List of Tables</td><td>Page No</td></tr><tr><td>Table 1 List of Abbreviations</td><td>4</td></tr><tr><td>Table 2 List of Standards</td><td>7</td></tr><tr><td>Table 3 List of channels</td><td>7</td></tr><tr><td>Table 4 CPSCP chassis Dimensions</td><td>13</td></tr><tr><td>Table5 PCB Specification</td><td>14</td></tr><tr><td>Table 6 List of Drawings</td><td>30</td></tr></table>

# 3.4. List of Reference Documents

1. Bill of Material for CPSCP_SMAV2.2

Doc No: RCIO/DOFI/T3S(D)/CPSCP SMA24.2(V.2.2)/BOM/01 dated 24/01/2025

Issue No: 01

2. MDI Document for CPSCP_SMAV2.2

Doc No RCI/DOFI/VISHORADSF/SCP/001 dated : 19/12/2024 ,Issue No: 01

EN-TEST Document for CPSCP_SMAV2.2

Doc No:

Issue No:

Note: Entest document for VISHORAD-SF is under progress by project. It was informed work center to consider Entest of VSHORADS project only. Please refer last page of this document

# 3.5.List of Standards

Table 2 List of Standard   

<table><tr><td>S. No.</td><td>Description</td><td>Standard/Directive No.</td></tr><tr><td>1.</td><td>Serial communication</td><td>RS 422</td></tr><tr><td>2.</td><td>Environmental Testing</td><td>MIL-STD-810G, JSS 0256-01, MIL HDBK 1670</td></tr><tr><td>3.</td><td>EMI/EMC Testing</td><td>MIL-STD-461E</td></tr><tr><td>4.</td><td>CEMILAC Screening Directive</td><td>CEMILAC/5390/1 Dt. 10-01-2004</td></tr><tr><td>5.</td><td>PCB inspection</td><td>JSG 761</td></tr><tr><td>6.</td><td>PCB workmanship inspection</td><td>IPC 610 F , Class 3</td></tr><tr><td>7.</td><td>Environmental Stress Screening</td><td>MIL HDBK 344 A</td></tr><tr><td>8.</td><td>ESS Process</td><td>MIL-HDBK-2164A</td></tr><tr><td>9.</td><td>QA Agency</td><td>DR&amp;QA, RCI</td></tr></table>

# 3.6.List of Channels

<table><tr><td>S. No.</td><td>Parameter</td><td>No of channels</td><td>Range</td><td>Unity Gain Bandwidth(Hz)</td><td>3dB Bandwidth (Hz)</td><td>Sensor / make</td></tr><tr><td>1.</td><td>Uni-axial-Vibration</td><td>6</td><td>±100g</td><td>2000</td><td>49.8KHz</td><td>J326A44 / PCB</td></tr><tr><td>2.</td><td>Pressure</td><td>1</td><td>350bar</td><td>1000</td><td>3687Hz</td><td>ETM-375M / KULITE</td></tr><tr><td>3.</td><td>RTD</td><td>2</td><td>-50°C to 400°C</td><td>25</td><td>3687Hz</td><td>FMC2102-UST-SLNS-2M-PT100UST</td></tr><tr><td>4.</td><td>Strain Gauge</td><td>4</td><td>±10000 μst</td><td>25</td><td>3687Hz</td><td>CEA-06-125UR-350/CEA-13-125UR-350 / VISHAY</td></tr><tr><td>5.</td><td>Shock Sensors</td><td>1</td><td>±500g</td><td>8000</td><td>49.8KHz</td><td>352C03 / PCB</td></tr></table>

Data Rate   

<table><tr><td>S. No.</td><td>Channel</td><td>Data rate</td><td>No. of channels</td></tr><tr><td>1</td><td>RS422 Transmitting (Tx)</td><td>2 Mbps</td><td>1</td></tr></table>

# 4. SYSTEM TECHNICAL SPECIFICATIONS

This section covers the input specifications, output specifications, RS422 communication and power supply requirements of CPSCP V2.2.

# 4.1. Power Supply Requirements

CPSCP unit receives $+5\mathrm{V}$ from IAM unit to SCP Card. This 5V output is given to SCP Card. Sufficient filtering and adequate decoupling is provided for maintaining low power-supply noise.

Isolated 5V,500mA input is provided from IAM to CPSCP V2.2 unit

Power supply Specifications   

<table><tr><td>Voltage</td><td>5V Nominal</td></tr><tr><td>Current</td><td>0.30±0.04A approximately (without sensor) at 5V</td></tr><tr><td>Transient Input Voltage Range</td><td>5V Provided</td></tr><tr><td>Reverse Voltage Protection</td><td>Not Provided</td></tr></table>

Note: Power Variation checks are not applicable as +5V input is isolated input coming from IAM

# 4.2. Sensor Module Output and CPSCP Input Specifications

# 4.2.1. Tri-axial Vibration sensor

<table><tr><td>Parameter</td><td>Specification</td></tr><tr><td>Type of sensor P/N and Make</td><td>J326A44, PCB</td></tr><tr><td>Type of sensor</td><td>Tri-axial</td></tr><tr><td>G-range(g)</td><td>±100 g, programmable</td></tr><tr><td>Bandwidth (KHz)</td><td>5 KHz</td></tr><tr><td>Sensitivity (±10%)</td><td>50 mV/g</td></tr><tr><td>Output Voltage Range</td><td>±5V</td></tr><tr><td>No of wires</td><td>4-wire (Tri-axial)</td></tr><tr><td>Operating Temp. range</td><td>-54°C to +121°C</td></tr><tr><td colspan="2">CPSCP SPECIFICATION</td></tr><tr><td>Sensor Interface Type</td><td>ICP/IEPE/LIVM</td></tr><tr><td>Number of channels</td><td>6 uni-axial</td></tr><tr><td>Analog Filter</td><td>2 Pole (Sallen-key), 49.798 kHz cut-off frequency</td></tr><tr><td>Digital Filter</td><td>FIR Filter 2KHz</td></tr><tr><td>Input Range</td><td>Fixed (±5V Input)</td></tr><tr><td>Over Voltage Protection</td><td>Provided</td></tr><tr><td>Excitation
Excitation Type</td><td>Constant Voltage 25V</td></tr></table>

# 4.2.2. Pressure Sensor

<table><tr><td>Parameter</td><td>Specification</td></tr><tr><td>Pressure sensor P/N and make.</td><td>ETM-375(M), KULITE</td></tr><tr><td>Number of Pressure sensors</td><td>1 (P1:350 bar)</td></tr><tr><td>Pressure Measured</td><td>Absolute</td></tr><tr><td>Pressure Range</td><td>0 to 350 Bar</td></tr><tr><td>Excitation Voltage</td><td>13-32 Vdc</td></tr><tr><td>Max Current</td><td>25 mA</td></tr><tr><td>No of wires</td><td>4(VIN+, VIN-, EXC+, EXC-)</td></tr><tr><td>Output Voltage</td><td>5VDC±150mV</td></tr><tr><td>Operating Temp. range</td><td>-55°C to +120°C</td></tr><tr><td>CPSCP Specification</td><td></td></tr><tr><td>Analog Filter</td><td>Single pole, 3.687KHz cut-off frequency</td></tr><tr><td>Digital Filter</td><td>FIR Filter 2KHz</td></tr><tr><td>Input Range</td><td>Fixed (0 to 5V)</td></tr><tr><td>Over voltage protection</td><td>Provided</td></tr><tr><td>Excitation
Excitation Type</td><td>Constant Voltage 15V</td></tr></table>

# 4.2.3. RTD Sensors

<table><tr><td>Parameter</td><td>Specification</td></tr><tr><td>RTD sensor P/N and make.</td><td>FMC2102-UST-SLNS-2M-PT100UST</td></tr><tr><td colspan="2">CPSCP SPECIFICATION</td></tr><tr><td>Number of RTD channels</td><td>2</td></tr><tr><td>Analog Filter</td><td>Single pole, 3.687KHz cut-off frequency</td></tr><tr><td>Digital Filter</td><td>FIR Filter 2KHz</td></tr><tr><td>CPSCP No of wires</td><td>4 (VIN+, VIN-, CUR_OUT, GND)</td></tr><tr><td>Input Range</td><td>Fixed [-50°C(80.306Ω) to 400°C(247.092Ω)]</td></tr><tr><td colspan="2">Excitation</td></tr><tr><td>Excitation Type</td><td>Constant Current 0.402mA</td></tr><tr><td>Excitation Current range</td><td>Fixed current 0.402mA</td></tr></table>

# RTD Temperature Sensor Pt100 with Cable :

Wire extensions & insulated with high temperature cement

![](images/61fc5db91885cde16545d1c95b2075df72c4d99d310203edcef0c54862db9f7a.jpg)  
Figure 1

# Temperature sensor with Cable

- Sensor Type: PT100 surface mount Thin film Platinum RTD   
Nominal Resistance: 100 Ohms at 0 deg C   
- Sensor Element Dimensions : 4mm X 5mm X 0.8mm   
Number of leads : 2 wire , Wire Length: 1 meter   
Temperature Range: -50°C to +500°C   
Accuracy: Class B, Standard: DIN EN 60751, Temp. Coefficient: TC = 3850 ppm/K   
- Separate insulation is provided to the leads of $8\mathrm{mm}$ length from the sensor   
- Wire extensions and element leads are insulated with very high temperature cement.   
- Sensor will be flexible for surface mounting; extension leads should be insulated to withstand very high temperatures.   
- Temperature sensor must be according to the drawing (figure:1)   
COC will be provided for sensor element only from OEM   
- Full range step by step calibration to be provided from NABL accreditation Lab for at least 10 steps for one unit.

Resistance Measurement of each sensor to be provided.

# 4.2.3. Strain Gauge Sensors

<table><tr><td>Parameter</td><td>Specification</td></tr><tr><td>Strain sensor P/N and make.</td><td>CEA-06-125UR-350 (Steel)
CEA-13-125UR-350 (Aluminum)
(Vishay Micro Measurements USA)</td></tr><tr><td>Number of Strain channels</td><td>4</td></tr><tr><td>Strain Range</td><td>± 25000ust</td></tr><tr><td>Output resistance range</td><td>350±17.5Ω</td></tr><tr><td>Type</td><td>Rectangular rosette</td></tr><tr><td>No of wires</td><td>4(VIN+, VIN-, VIN1+,VIN1 GND)</td></tr><tr><td>Operating Temp. range</td><td>-75°C to +175°C</td></tr><tr><td colspan="2">CPSCP SPECIFICATION</td></tr><tr><td>Analog Filter</td><td>Single pole, 3.687KHz cut-off frequency</td></tr><tr><td>Digital Filter</td><td>FIR Filter 2KHz</td></tr><tr><td>Input Strain Range</td><td>± 10000ust (Fixed)</td></tr><tr><td>Input Range</td><td>343 ohm to 357 ohms</td></tr><tr><td>Channel Type</td><td>350 Ohm Wheatstone bridge</td></tr><tr><td>Over Voltage Protection</td><td>Provided</td></tr><tr><td colspan="2">Excitation</td></tr><tr><td>Excitation Type</td><td>Constant Voltage 5V (Wheat stone bridge)</td></tr></table>

# 4.2.3. Shock Sensors

<table><tr><td>Parameter</td><td>Specification</td></tr><tr><td>Type of sensor P/N and Make</td><td>352C03,PCB</td></tr><tr><td>Type of sensor</td><td>Shock</td></tr><tr><td>Number of channels</td><td>1</td></tr><tr><td>G-range(g)</td><td>±500g</td></tr><tr><td>Bandwidth (KHz)</td><td>8Khz</td></tr><tr><td>Sensitivity (±10%)</td><td>10mV/g</td></tr><tr><td>Output Voltage Range</td><td>±5V</td></tr><tr><td>No of wires</td><td>2 (VIN+, GND)</td></tr><tr><td>Operating temperature</td><td>-54°C to +121°C</td></tr><tr><td colspan="2">CPSCP SPECIFICATION</td></tr><tr><td>Sensor Interface Type</td><td>ICP/IEPE/LIVM</td></tr><tr><td>Analog Filter</td><td>2 Pole (Sallen-key), 49.798 kHz cut-off frequency</td></tr><tr><td>Digital Filter</td><td>FIR Filter 2KHz</td></tr><tr><td>Input Range</td><td>±5V</td></tr><tr><td>Over Voltage Protection</td><td>Provided</td></tr><tr><td colspan="2">Excitation</td></tr><tr><td>Excitation Type</td><td>Constant Voltage</td></tr><tr><td>Compliance</td><td>25V</td></tr></table>

# 4.3. Output Specifications

# RS-422

Number of Channels : 2

Mode of operation : Transmitting

Following is the frame which is transmitted through RS422 interface

![](images/50befd63869f6c6cc2953b402cad0db1440708171ac36f88ca6a8f32a69043da.jpg)

![](images/2dbec955025644be6eff38aaa228345a86de8eaa3cb18630baf7030497c322b6.jpg)  
Frame Count 1

![](images/ec86c16df1c9957dd2a6fbb3d1af674a2f99020e0169f89e28cf29176c2424d0.jpg)

![](images/8fc03f0ebc51bc36428f7f79e1efc4c37270ae8b6b1fd2de07576bc7666f7761.jpg)

![](images/2013091ce1d6d80511e5ac7dc38de172414d37c72e77a1907ba631f2e7740004.jpg)

\*S1- not in use.

Data rate calculation:

$DR(\beta) = \text{Base frequency} * \text{no. of timesampling} * \text{no. of bits}$

* Totalnumberofwords

Base frequency $= 500\mathrm{Hz}$

Total number of words $= 80$

No. of times sampling $= 4$

No of bits $= 8$

Datarate $= {500} * {80} * 4 * 8 = {1280000}\mathrm{{Hz}}$ for 8 bit

Datarate $= 500*80*4*12 = 1920000Hz$ for 12 bit

$$
b i t r a t e = \frac {\# \text {o f b i t s}}{\text {w o r d}} * \frac {\# \text {o f w o r d s}}{\text {m i n o r f r a m e}} * \left(\frac {\# \text {o f m i n o r f r a m e s}}{\text {m a j o r f r a m e}}\right) * \left(\frac {1}{\text {f r a m e} _ {\text {t i m e}}}\right)
$$

$$
1 2 * 8 0 * 1 * 2 K H Z = 2 M b p s
$$

Abbreviation of Channels in GUI as per Test leaf.   

<table><tr><td>Sl.No</td><td>Parameter</td><td>Channels As per Test Leaf</td><td>Bit Number/ Channels as per GUI</td></tr><tr><td rowspan="6">1</td><td rowspan="6">Tri Axial Vibration Channels</td><td>TV1X</td><td>10/V0</td></tr><tr><td>TV1Y</td><td>11/V1</td></tr><tr><td>TV1Z</td><td>4/V2</td></tr><tr><td>TV2X</td><td>5/V3</td></tr><tr><td>TV2Y</td><td>6/V4</td></tr><tr><td>TV2Z</td><td>9/V5</td></tr><tr><td rowspan="4">2</td><td rowspan="4">Strain Channels</td><td>SG1</td><td>35/ST0</td></tr><tr><td>SG2</td><td>40/ST1</td></tr><tr><td>SG3</td><td>55/ST2</td></tr><tr><td>SG4</td><td>60/ST3</td></tr><tr><td>3</td><td>Pressure Channels</td><td>P1</td><td>16/P0</td></tr><tr><td rowspan="2">4</td><td rowspan="2">RTD Channels</td><td>RTD1</td><td>15/R0</td></tr><tr><td>RTD2</td><td>20/R1</td></tr><tr><td>5</td><td>Shock channel</td><td>SH</td><td>7/S0</td></tr></table>

Here, AA and BB are header. Counter values is to know the packet count value to observe continuity of received packets. CC is End of Frame. Packet update rate is $500\mathrm{Hz}$ , based on sampling frequency of each channel; repetition of each channel is assigned in the packet. RS422

will work on baud rate of 2Mbps. Frame is in hexadecimal representation. Hence convert to decimal and note the decimal value in test leafs.

# RS232

As per the Project requirements, the measurements to be made by CPSCP V2.2 are fixed, I.e. no programmability required. Hence unlike ITS-3, programmability through RS232 has not been provided.

However, if requirement comes, the unit can be programmed at FPGA level.

# 4.4. Mechanical Specifications

Table 4 CPSCP Chassis Dimensions   

<table><tr><td>Mechanical Dimensions</td><td>Dimensions (in mm)</td><td>remarks (in mm)</td></tr><tr><td>Length</td><td>51mm</td><td>Mating Connector is not included</td></tr><tr><td>Diameter Φ</td><td>67mm</td><td>68 mm With mechanical ring</td></tr></table>

![](images/45592afe29de04f6a1fb2a83240250f7e7f819da9522a4f7a9e009917b8743d2.jpg)  
Figure 2: CPSCP Mechanical Casing

To meet the above dimensional requirements, the electronic circuit of CPSCP V2.0 has been configured on two PCB cards. The Signal Conditioning Card (Signal conditioning has to be split on two PCB's SCP Module-1 and SCP Module-2 due to space restriction. These PCBs are interconnected through flexi PCB).

# 4.5. PCB SPECIFICATIONS

Table 5 PCB Specification   

<table><tr><td>S.
No</td><td>Card Description</td><td>No. of 
Layers</td><td>Diameter Φ 
(in mm)</td><td>PCB 
Thickness 
(in mm)</td><td>Grade</td><td>Manufacturing</td></tr><tr><td>1</td><td>Signal Conditioning 
Card Module 1(J2)</td><td>10</td><td>67</td><td>2.4</td><td>MIL</td><td>Micropack</td></tr><tr><td>2</td><td>Signal Conditioning 
Card Module 2</td><td>10</td><td>67</td><td>2.4</td><td>MIL</td><td>Micropack</td></tr></table>

# 4.6. CONNECTOR DETAILS

One connector at the front to provide interface to the external world

Following connectors are used in the CPSCP

<table><tr><td>Card</td><td>Connector Model No.</td><td>Make</td><td>No .of Pins</td></tr><tr><td>Signal Conditioning Card</td><td>MK-332-051-135-2200</td><td>Air born</td><td>51</td></tr></table>

![](images/63a211b950b477fcff9052ecc6c74633d4462a50ab207246fba646c615179546.jpg)

# 5. CONNECTOR PIN ASSIGNMENTS

5.1. SCP Connector -P1(51 pin Micro-D)   

<table><tr><td rowspan="2">S. No.</td><td rowspan="2">Parameter</td><td rowspan="2">Sensor Range</td><td rowspan="2">Channel Input Bandwidth (Hz)</td><td>On External Connector</td></tr><tr><td>Pin Number</td></tr><tr><td>1</td><td>High</td><td>-</td><td>-</td><td>1</td></tr><tr><td>2</td><td>High</td><td>-</td><td>-</td><td>2</td></tr><tr><td>3</td><td>Low</td><td>-</td><td>-</td><td>3</td></tr><tr><td>4</td><td>Low</td><td>-</td><td>-</td><td>4</td></tr></table>

<table><tr><td rowspan="4">5</td><td rowspan="4">S1</td><td rowspan="4">±500g</td><td rowspan="4">25Hz</td><td>S1_VIN+</td><td>5</td></tr><tr><td>SG1_VIN+</td><td>6</td></tr><tr><td>S1_VIN-</td><td>7</td></tr><tr><td>S1_GND</td><td>8</td></tr><tr><td rowspan="4">6</td><td rowspan="4">S2</td><td rowspan="4">±500g</td><td rowspan="4">25Hz</td><td>S2_VIN+</td><td>9</td></tr><tr><td>SG2_VIN+</td><td>10</td></tr><tr><td>S2_VIN-</td><td>11</td></tr><tr><td>S2_GND</td><td>8</td></tr><tr><td rowspan="4">7</td><td rowspan="4">S3</td><td rowspan="4">±500g</td><td rowspan="4">25Hz</td><td>S3_VIN+</td><td>12</td></tr><tr><td>SG3_VIN+</td><td>13</td></tr><tr><td>S3_VIN-</td><td>14</td></tr><tr><td>S3_GND</td><td>15</td></tr><tr><td rowspan="4">8</td><td rowspan="4">S4</td><td rowspan="4">±500g</td><td rowspan="4">25Hz</td><td>S4_VIN+</td><td>16</td></tr><tr><td>SG4_VIN+</td><td>17</td></tr><tr><td>S4_VIN-</td><td>18</td></tr><tr><td>S4_GND</td><td>15</td></tr><tr><td rowspan="4">9</td><td rowspan="4">T1</td><td rowspan="4">400°C</td><td rowspan="4">25Hz</td><td>RTD_1_VIN+</td><td>19</td></tr><tr><td>RTD_1_VIN-</td><td>20</td></tr><tr><td>RTD CUR_OUT1</td><td>21</td></tr><tr><td>RTD_1_GND</td><td>22</td></tr><tr><td rowspan="4">10</td><td rowspan="4">T2</td><td rowspan="4">400°C</td><td rowspan="4">25Hz</td><td>RTD_2_VIN+</td><td>23</td></tr><tr><td>RTD_2_VIN-</td><td colspan="1">24</td></tr><tr><td>RTD CUR_OUT2</td><td colspan="1">25</td></tr><tr><td>RTD_2_GND</td><td colspan="1">26</td></tr><tr><td rowspan="5">11</td><td rowspan="5">P1</td><td rowspan="5">350bar</td><td rowspan="5">1000Hz</td><td>P1_VIN+</td><td>27</td></tr><tr><td>P1_VIN-</td><td colspan="1">28</td></tr><tr><td>ISO1</td><td colspan="1">29</td></tr><tr><td>P1_EXC+</td><td colspan="1">36</td></tr><tr><td>P1_EXC-</td><td colspan="1">37</td></tr><tr><td rowspan="6">12</td><td rowspan="6">RS422_1</td><td rowspan="6">-</td><td rowspan="6">-</td><td>RS422_RX2_P</td><td>32</td></tr><tr><td>RS422_RX2_N</td><td colspan="1">33</td></tr><tr><td>ISO2</td><td colspan="1">34</td></tr><tr><td>GND</td><td colspan="1">35</td></tr><tr><td>RS422_TX2_P</td><td colspan="1">30</td></tr><tr><td>RS422_TX2_N</td><td colspan="1">31</td></tr><tr><td rowspan="4">13</td><td rowspan="4">RS422_2</td><td rowspan="4">-</td><td rowspan="4">-</td><td>RS422_TX1_P</td><td>48</td></tr><tr><td>RS422_TX1_N</td><td colspan="1">49</td></tr><tr><td>RS422_RX1_P</td><td colspan="1">50</td></tr><tr><td>RS422_RX1_N</td><td colspan="1">51</td></tr><tr><td rowspan="2">14</td><td rowspan="2">SH1</td><td rowspan="2">-</td><td rowspan="2">-</td><td>SH1_VIN</td><td>38</td></tr><tr><td>SH1_GND</td><td colspan="1">39</td></tr><tr><td>15</td><td>TV1</td><td>-</td><td>-</td><td>TV1_GND</td><td>40</td></tr><tr><td>16</td><td>TV1X</td><td>-</td><td>-</td><td>TV1X_VIN</td><td>41</td></tr><tr><td>17</td><td>TV1Y</td><td>-</td><td>-</td><td>TV1Y_VIN</td><td>42</td></tr><tr><td>18</td><td>TV1Z</td><td>-</td><td>-</td><td>TV1Z_VIN</td><td>43</td></tr><tr><td>19</td><td>TV2X</td><td>-</td><td>-</td><td>TV2X_VIN</td><td>44</td></tr><tr><td>20</td><td>TV2Y</td><td>-</td><td>-</td><td>TV2Y_VIN</td><td>45</td></tr><tr><td>21</td><td>TV2Z</td><td>-</td><td>-</td><td>TV2Z_VIN</td><td>46</td></tr><tr><td>22</td><td>TV2</td><td>-</td><td>-</td><td>TV2_GND</td><td>47</td></tr></table>

# 6. SEQUENCE OF ACTIVITIES

Following is the sequence of activities to be followed for the fabrication and testing of the units.

# I Board Level Tests

1. RMT checks(Resistance Measurement Checks and Voltage checks)   
2. Anti-aliasing Filter Checks. (To be done for one unit per batch if machine soldering is done. If it is hand soldering, then it has to be done for all units)   
3. Burn-IN Test

# II Initial Functional Checks

# a. Electrical Checks

1. Isolation Resistance Checks   
1.1. All pins to Chassis (For every connector of every unit)   
1.2. All pins to all pins of connector (For every connector, for one unit per batch)   
2. Power Consumption, Reverse Voltage Protection and Power Supply Voltage variation checks

# b. Signal Conditioning Tests

1. Excitation Tests   
2. 5-Point calibration of Analog Channels   
3. Filter Cut-off Frequencies(Digital Filter testing) Note: Filter Testing Results will be approved by Designer Rep.

# III Functional & Performance Testing during ESS, AT, QT, EMI/EMC Test

# IV Final Functional Checks

# a. Electrical Checks

1. Isolation Resistance Checks All pins to Chassis (For every connector of every unit)   
2. Power Consumption, Reverse Voltage Protection and Power Supply Voltage variation checks

# b. Signal Conditioning Tests

1. Excitation Tests   
2. 5-Point calibration of Analog Channels   
3. Filter Cut-off Frequencies(Digital Filter testing)

Note: Filter Testing Results will be approved by Designer Rep

# 7. SYSTEM OVERVIEW

As described in the introduction, the function of CPSCP V2.2 is to acquire data from Physical channels (Uni-axial Vibration-6, Shock-1, Temperature (RTD)-2, Strain-4 and Pressure-1 Channels) and after processing, it is sent serially overRS422 to MIUT.

Following figure gives a top level representation of the system.

![](images/aeade092872ae8847fd171c7940f980ee85785e21261074db8b15413e8d58617.jpg)  
Figure 3: Top Level Representation of the System

The unit has two cards, Power Supply Card and Signal Conditioning Card split on two PCBs connecting via Flexible

![](images/e44272e3c16ebb5b79366f83e59a48bde98680aee4a86fcf0bcfe0dde7ecf43e.jpg)  
Figure 4: Block Diagram for functional representation of cards

# 7.1 FUNCTIONAL DESCRIPTION

The electronic circuit of CPSCP has been configured on two PCB cards. Consisting of two Signal Conditioning Cards.

# 1) SCP card

Comprises of 2 modules SCP Module-1 and SCP module-2, both modules are connected through Flexi PCB. SCP Consist of

a) Power supply circuit for generation of different voltages   
b) Signal conditioning circuit for 6 Vibration, 2 RTD, 4 Strain, 1 Shock, and 1 Pressure Channel.   
c) Digital Circuit for acquisition of analog data and transmission onRS422.

# 7.2 TEST PROCEDURE FOR CRITICAL PARAMETERS SIGNAL CONDITION PACKETS (CPSCP) TESTING

# 1) Accuracy

a) FSR of RTD is $-50^{\circ}\mathrm{C}$ to $400^{\circ}\mathrm{C}$ . So its accuracy will be better than $\pm 9^{\circ}\mathrm{C}$ , i.e. $\pm 2\%$ of $450^{\circ}\mathrm{C}$ (FSR)   
b) FSR of Pressure is 0 to 350 bar. So its accuracy will be better than $\pm 7$ bar, i.e. $\pm 2\%$ of 350 bar (FSR)   
c) FSR of Vibration is -100g to +100g. So its accuracy will be better than ±4g, i.e. ±2% of 200g (FSR)   
d) FSR of Shock is $-500\mathrm{g}$ to $+500\mathrm{g}$ . So its accuracy will be better than $\pm 20\mathrm{g}$ , i.e. $\pm 2\%$ of $1000\mathrm{g}$ (FSR)   
e) FSR of Strain Gauge is -10000μs to +10000μs. So its accuracy will be better than ±400μs, i.e. ±2% of 20000μs (FSR)

# Note:

Accuracy, CPSCPV2.2 alone 1%

Accuracy, CPSCPV2.2 with test jigs $2\%$ (Test jig accuracies add to CPSCPV2.2 accuracy)

# 2) TEST JIGS

a) RTD Test Jig, Strain Test Jig- Decade Resistance Box ( 1ohm to 400ohm)   
b) Pressure, Acceleration Test Jig. - Variable Voltage Source (-10V to 40V)   
c) Vibration, Shock Test Jig - Variable Sine Wave (100mV to 10V, DC to 60KHz)   
d) RS422 Simulator -MOXA Card

# 7.3. Board Level Tests

# 7.3.1. RMT checks (Resistance Measurement Checks) and Voltage measurement checks

Objective: The test is performed to measure resistance at various points on the board to validate the correctness of assembly before Power-On.

Setup: This check is performed first with the unit in power OFF condition and without any external connections. Again the connections to be made to provide 5V input to SCP card from Power card to measure voltage output of various ICs in SCP card

# Procedure:

1) Unit has to be in power OFF mode. Using Multimeter measure resistance between various points as mentioned in Test Leaf A-2 of Appendix 'A' and note down the readings.   
2) Power on the SCP card with 5V input from Power card and measure the voltage output of various ICs and mention in Test leaf A-2of Appendix 'A'

Note: Results to be verified only by DOFI

# 7.3.2. Anti-aliasing Filter Checks

Objective: The test is performed to note the anti-aliasing filter performance.

Setup: The test setup required for performing the test is shown in Figure 5.

Through Function Generator AC signal is generated, signal is fed to filter input and output of the filter is monitored in oscilloscope

![](images/0b487536c391371512a267d8412f3e3bf4bbb69c8442375e2a3a8fcd28159c17.jpg)  
Figure 5: Anti-Aliasing Filter Test Set Up.

# Procedure:

1. Power on the unit. Give input from function generator at filter stage input of channel. Probe the signal at output of anti-aliasing filter and Monitor output in oscilloscope and note down readings in Test Leaf A-1 of Appendix-A   
2. Repeat above step for all channels.

Note: Results to be verified only by DOFI, AAF checks to be done in 1 out of 10 units

# 7.3.3. Burn-IN

Setup: The test setup required for performing the test is shown in Figure 6. Functional Test Jigs are used to simulate data inputs to all channels. Output of the CPSCP is fed to the RS422 receiver.

![](images/e4c9388ad60a2d77afa610ba900daab091c89483f387b82732943b92308a3086.jpg)  
Figure 6: Burn-In Test Setup

# Procedure:

1) The Power-On Unit is placed in Thermal Chamber at a temperature of $65^{\circ}\mathrm{C}$ for 168 hours.   
2) Perform the single point calibration of the unit and record the readings for every 5hrs in Test Leaf-2.   
3) After 168 hrs the PCB's are visually examined for future tests.

# 7.4. Initial Functional Checks

# 7.4.1. Electrical Checks

# 7.4.2. Isolation checks

Objective: The test is performed to measure the isolation resistance between the chassis and all the pins of each connector.

Setup: This check is performed with the unit in power OFF condition and without any external connections.

# Procedure:

1) Using a multimeter, measure the isolation resistance between chassis and all pins of Power Supply Connector and SCP Connector. Record the reading in Test Leaf-1.   
2) Using a multimeter, measure the isolation resistance between all the pins of each connector. Record the readings in Test Leaf B-1 of 'Appendix B'.

# 7.4.2. Power Consumption Checks

Objective: The test is performed to measure the power consumed by CPSCP under normal load conditions, operation of unit within supply voltage range (5VDC)

Setup: The test setup required for performing the test is shown in Figure 7. Functional Test Jigs are used to simulate data inputs to all channels. Output of the CPSCP is fed to the RS422 receiver. Use a variable Power Supply with display of voltage and current.

![](images/444124e6dfeed09d90fd4127171d4cc729d4555c41d792ec44fea27b5413ba73.jpg)  
Figure 7: Power Consumption Test Set Up.

# Procedure:

1) Set Supply voltage of $5\mathrm{V}$ on the variable power supply.   
2) Note the current reading of the variable power supply, check values of the required parameter and record in Test Leaf-2.

# 7.4.3. Signal Conditioning Tests

# 7.4.3.1. Excitation Tests

# a) RTD

Objective: The test is performed to verify the accuracy of the excitation current provided for each RTD sensor. $0.402\mathrm{mA}$ current is provided for each RTD channel

Setup: The test setup required for performing the test is shown in Figure 8. A 100 Ω resistor is connected to Excitation sources of RTD Channels.

![](images/cb9288a3764a479ab6384459817d533f36436b11fb4c867ce966296ac6aa6d6f.jpg)  
Figure 8: Test Setup - Current Excitation to RTD and Strain Gauge

# Procedure:

1) Power on the Unit. 100 $\Omega$ , high precision resistors is connected to CPSCP excitation source of RTD channel.   
2) Measure the Voltage across the resistor through Multimeter.   
3) Record the voltage values in Test Leaf-3.

# b) Vibration/Shock/Acceleration Sensors

Objective: The test is performed to verify the accuracy of the supply voltage provided for Vibration/Shock/Acceleration sensors. 25V supply is provided to these channels.

Setup: The test setup required for performing the test is shown in Figure 9. A Digital Multimeter is connected to excitation source of Pressure channels.

![](images/290d038c5404ebeb16c33a7dd94361079b9b89dfd3955b4dd1ce53f7240feff7.jpg)  
Figure 9: Test Setup -Pressure Channel Excitation

# Procedure:

1) Power on the Unit. Measure voltage across the Excitation High and Low Pins with a multimeter.   
2) Repeat the above step for each channel and record the measurements in Test Leaf-4

# c) Pressure Sensors

Objective: The test is performed to verify the accuracy of the supply voltage provided for Pressure sensors. 15V supply is provided to Pressure Sensors P1.

Setup: The test setup required for performing the test is similar as shown in Figure 9. A Digital Multimeter is connected to excitation source of Pressure channels.

# Procedure:

1) Power on the Unit. Measure voltage across the Excitation High and Low of Pressure channel with a multimeter.   
2) Repeat the above step for each channel and record the measurements in Test Leaf-4

# 7.4.3.2. 5 - Point calibration of RTD Channels

Objective: The test is performed to verify the measurement and processing accuracy of the RTD channels in SCP Card.

Setup: The test setup required for performing the test is shown in Figure. 10.

![](images/7b7acdf4488c52b1f2b5d169de4c43ae3e99b20d016c87676195066a68325cdd.jpg)  
Figure 10: Test Setup - RTD Channels Calibration

# Procedure:

1) SCP Test jig is connected as shown in Figure 10.   
2) SCP test jig has resistor to simulate RTD. Along with excitation current, this resistance generates voltage which is feed back to CPSCP.   
3) The output from CPSCP is given to RS422 Receiver.   
4) The results are noted down in Test Leaf-5   
5) Repeat the steps from 1 to 4 for all RTD Channels.

# 7.4.3.3. 5 Point Calibration of Strain Channels

Objective: The test is performed to verify the measurement and processing accuracy of the Strain Gauge Channels in SCP Cards.

Setup: The test setup required for performing the test is shown in Fig. 11.

![](images/f42ed9077afc87fc1766a9c6be35e9b8763fd9c7230d40bd7a0d2919dc7ed61b.jpg)  
Figure 11: Test Setup - Strain Gauge Channels

# Procedure:

1. Variable Resistor is connected as given in figure 11.   
2. The voltage across the variable resistor is fed back to CPSCP.   
3. The output from CPSCP is given to RS422 Receiver.   
4. The results are noted down in Test Leaf-6.   
5. Repeat the steps from 1 to 4 for all Strain Gauge Channels.

# 7.4.3.4. 5-Point calibration of Pressure Channel

Objective: The test is performed to verify the measurement and processing accuracy of the Pressure Channels in SCP Cards.

Setup: The test setup required for performing the test is shown in Figure. 12.

![](images/eb3c92f6c1a16c038997c455e3a4423daef28260d06cc6d59de34ccab32654a0.jpg)  
Figure 12: Test Setup - Pressure Channels

# Procedure:

1) SCP Test jig has Variable DC Voltage Source to simulate pressure. It is connected as shown in Figure 12.   
2) The output from CPSCP is given to RS422 Receiver.   
3) Results are noted in Test Leaf-7.   
4) Repeat steps 1 to 3 for every Pressure channel in CPSCP

# 7.4.3.5. 5-Point Calibration of Vibration Channels

Objective: The test is performed to verify the measurement and processing accuracy of the Vibration Channels of SCP cards.

Setup: The test setup required for performing the test is shown in Fig. 13.

![](images/8f0899c02d428e98c0f28056d26e037b30be75f68496d81490969b4553687d75.jpg)  
Figure 13: Test Setup-Vibration Channel

# Procedure:

1. Apply specified sine wave input from function generator.   
2. Change the inputs as mentioned in the Test Leaf-8.   
3. The output from CPSCP is given to RS422 Receiver.   
4. The results are noted in Test Leaf-8.   
5. Repeat the above steps for all Vibration Channels.

# 7.4.3.6. 5-Point calibration of Shock Channels

Objective: The test is performed to verify the accuracy of the Shock channels.

Setup: The test setup required for performing the test is shown in Figure 14.

# Procedure:

1. Apply specified sine wave input from function generator.   
2. Change the inputs as mentioned in the Test Leaf-9.   
3. The output from CPSCP is given to RS422 Receiver.   
4. The results are noted down in Test leaf-9.   
5. Repeat steps 1 to 4 for all channels.

![](images/b74f4faba9671d378b8b5d38fca952444cd71c61c4b93596ca9b8ff7687a12f0.jpg)  
Figure 14: Test Setup -Shock Channels

# 7.4.3.7. Digital Filter Cut-off Frequency

Objective: The test is performed to verify the cut-off frequencies of digital filter. The selection of channel bandwidth in GUI should be such that there is no effect of Analog anti-aliasing Filter.

Setup: The test setup required for performing the test is shown in Figure. 15. Function Generator is used to generate sin wave signals. Chosen parameter (channel) is monitored on monitoring unit.

# Procedure:

1) Configure CPSCP as per format.   
2) Set function generator to generate sine wave frequencies and amplitude.   
3) Gradually increase the sine wave frequency to 3dB and 30 dB point.   
4) Observe the counts in monitoring unit and record the observed counts in Test Leaf-10.

Note: FIR filter checks to be done in 1 out of 10 units

![](images/59b99972c2ec5c0b2b6d005e16ae49442694109beb75aa071463850b29a00a48.jpg)  
Figure 15: Test Setup - Filter Cut-off Frequencies

# 7.4.3.8. RS422 Interface Test

Objective: The test is performed to verify the acquisition of RS422 data in ITS3

Setup: The test setup required for performing the test is shown in Fig. 18. Data from CPSCP unit is fed to Bit synchronizer through MOXA card to Monitoring Unit. A RS422 simulator is used to simulate messages to CPSCP. Output is Seen in Monitoring Unit.

![](images/23fb5be7bb016871622dc192952430ac4e62939fa28e70399cb8cb6f12cad575.jpg)  
Figure 16: Test Setup - RS422 Interface Test

# Procedure:

1. Configure CPSCP V2.2 with selected test format.   
2. Connect RS422 Transmit channels to MOXA card (Receive) and observe data on PC.   
3. Observe RS422 data in Monitoring Unit and note down the data in Test leaf-11.

Acceptance Criteria: CPSCP V2.2 transmits correct data on RS422 b

8. LIST OF DRAWINGS   
Table no-6   

<table><tr><td>SL.
No.</td><td>NOMENCLATURE</td><td>DRAWING No.</td><td>MATERIAL</td><td>FINISH</td><td>REV.
No.</td><td>REM.</td></tr><tr><td>1</td><td>CP SIGNAL CONDITIONING
PACKAGER</td><td>667 09 00 00 00 00</td><td>---</td><td>---</td><td>0</td><td></td></tr><tr><td>2</td><td>CASING</td><td>667 09 00 00 00 01</td><td>SS-304/SS-321</td><td>Passivation as per
AMS 2700 E</td><td>0</td><td></td></tr><tr><td>3</td><td>CP SCP PCB SUB-ASSEMBLY</td><td>667 09 01 00 00 00</td><td>---</td><td>---</td><td>0</td><td></td></tr><tr><td>4</td><td>CP SCP PCB</td><td>667 09 01 00 00 01</td><td>FR4</td><td>---</td><td>0</td><td></td></tr></table>

![](images/eae32009f9a4ea914f1a053bb309cd231a71a5bcac352114e89d307b3f321042.jpg)

![](images/744840edc562f9f332929c6f00a3b778cef864e9363d44a8539942ba6d6f3801.jpg)

![](images/68a38a35fa23bba1c8d3be74eb6113444c86165167c3756934233d9083d4a1a0.jpg)  
Note: 1. External Inspection done in the presence of DR&QA marked with ‘*’

# 10. PROCESS FLOW DESCRIPTION

<table><tr><td>Sl.No</td><td>Description</td><td>Tools</td><td>Remarks</td></tr><tr><td>1.</td><td>Bare PCB inspection</td><td></td><td></td></tr><tr><td></td><td>i)The visual inspection of the PCB'S using 10 X microscope for any voids, burns, bubbles, surface Imperfections etc.ii)Dimensions: The finished printed wiring board shall meet the dimensional (such as cut-outs, overall thickness, periphery etc...) requirements as specified in chapter 5.4.iii) Group A certificates shall be checked for each PCB.iv) Group B certificates for a batch shall be checked.v) Micro sectioning reports shall be checked for PCB lot. vi)Continuity checksa) The continuity checks of the bare PCB shall be carried out as per the Net list. 1PCB from lot.b) VCC ground isolation is clearedc) The open circuit short circuit will be checked and Recorded.</td><td>10X Microscope</td><td>Inspection by Internal QC&amp;DR &amp;QA</td></tr><tr><td>2</td><td>PCB Baking</td><td></td><td></td></tr><tr><td></td><td>i) Clean the PCBs with isopropyl alcohol.ii) Baking of PCBs at 110°C for 2 hours .Verify PCB for any damages.</td><td>Thermal Chamber</td><td>Internal QC</td></tr><tr><td>3</td><td>Component inspection</td><td></td><td></td></tr><tr><td></td><td>i) Identify the components as per the Bill of material and collect from stores.ii)Check the component part numbers as per BOM,conformance certificates and screening certificatesiii) Visually inspect components if any damages are there.iv) Assembly of Connectors with screws and torque value.v) Date code of Components verification &amp; connectors screening.vi) Identify the component as per the BOM &amp;Date code to be verified.</td><td>10X Microscope</td><td>Inspection by Internal QC&amp;DR &amp;QA</td></tr><tr><td>4</td><td>Assembly of Components</td><td></td><td></td></tr><tr><td></td><td>i) All MSL components are required to be baking as per standard before mountingii)Components shall be assembled as per the layout diagrams by Reflow method(SMD)iii) ICs have to be placed according to the legend and polarities of the components have to be checked. Silpad has to be placed according to the drawing.iv) Connectors and passive components have to be placed with proper sleeves</td><td>Flux,Lead,SolderingIron</td><td>Inspection by Internal QC&amp;DR &amp;QA</td></tr><tr><td>S.No</td><td>Description</td><td>Tools</td><td>Remarks</td></tr><tr><td></td><td>v) The Through-Hole components are soldered on the PCB by Hand soldering/Manual soldering.</td><td></td><td></td></tr><tr><td>5.</td><td>Cleaning of PCBs</td><td></td><td></td></tr><tr><td></td><td>i) The PCB shall be cleaned by using a three tray cleaning method.ii) The trays shall be filled with isopropyl alcohol.iii) The unclean PCB shall be placed in first tray for 30 min.iv) Now Brush it with a nylon brush.v) The PCB is now put in the second tray for 15 min and again Clean with a brush and air dried for 30 min.vi) The PCB is now put in the third tray for 5 min and again cleans with a brush.vii) For 1st and 2nd tray alcohol to be replaced with new alcohol for every 8 PCBs..</td><td></td><td>Inspection byInternalQC</td></tr><tr><td>6</td><td>Wiring</td><td></td><td></td></tr><tr><td></td><td>i) Connector-EMI-Filter-DC/DC converter shielded wires to be usedii) Preparation of wires &amp; soldering as per the integration details. Crimping the wires in to Pins with appropriate locators and insertion to connectors.iii) Retention test on crimping connectors to be carried out.iv) Continuity checks to be done as per the integration details.v) Wires routing to be in shortest length and minimum bends.vi) Cable harness to be checked as per the cable loom drawing</td><td></td><td>Inspection byInternalQC&amp;DR&amp;QA</td></tr><tr><td>7</td><td>Physical Inspection</td><td></td><td></td></tr><tr><td></td><td>i) The inspection shall be carried out as per the assembly drawing and BOMii) The following checklist shall be ensured. a) All components assembled are as per the drawing and are at proper position. b) Check the component count as per the BOM c) Check for standard mounting d) Check if any component has been damaged during assembly.e) Check for correct polarity of the tantalum capacitors. f) All components assembled are as per the drawing and are at proper position. g) Misalignment of parts with solder pads h) Sleeve clearances from tracks for metal bodied parts i) Check for improper lead formation j) Check for sufficient stress relief k) Check for excess length of leads l) Check that proper mounting have been done for heavy components. m) Check for any corrosion on leads. n) De-wetting Non-Wetting, Flux Residue, Wicking. o) Connectors wires position Resistance and capacitor values</td><td>10X Microscope</td><td>Inspection byInternalQC&amp;DR&amp;QA</td></tr><tr><td></td><td>p) Check for connectors mounting &amp; tightnessq)X-RAY Inspection for BGA,DFN &amp;QFN and CLCC packages</td><td></td><td></td></tr><tr><td>8</td><td>Temporary integration</td><td></td><td></td></tr><tr><td></td><td>Temporary integration with minimum no of screws and nuts for temporary integration.</td><td></td><td>Inspection by Internal QC</td></tr><tr><td>9.</td><td>Functional Testing</td><td></td><td></td></tr><tr><td></td><td>After Temporary Integration, Perform the Isolation &amp; Functional testing of the unit as per functional test procedure record the test results.</td><td>Test jig</td><td>Inspection by DR&amp;QA</td></tr><tr><td>10</td><td>CEMILAC</td><td></td><td></td></tr><tr><td></td><td>High Temperature- Test shall be conducted At card level before conformal coating (after functional test) for 24 Hrs. at +85°C, Power-off condition. The temperature of +85°C is fixed considering that some of the components is of Industrial grade. Take the Preet and Poet reading in presence of internal QC &amp; DR&amp;QA(RCI).Thermal Shock-Tested PCB's are kept in the thermal chamber in power off condition, at low temperature maintained at-40°C for 30 minutes. After those boards are transferred to high temperature chamber maintained at +85°C, Transfer time has to be less than 2 minutes and kept for 30 minutes. Repeat 10 cycles Take the Preet and Poet reading in presence of DR&amp;QA(RCI)Burn-IN Test-Test shall be conducted At card level before conformal coating (after functional test) for 48 Hrs. at +71°C, Power-off condition. The temperature of +71°C is fixed considering that some of the components is of Industrial grade. Take the Preet and Poet reading in presence of internal QC &amp; DR&amp;QA. First and last reading will be taken by DR&amp;QA (RCI),INSET 30Min/1 hour before.</td><td>Chamber</td><td>Inspection by DR&amp;QA</td></tr><tr><td>11</td><td>Potting &amp; Conformal coating</td><td></td><td></td></tr><tr><td></td><td>Potting &amp; Conformal coating shall be MIL grade, which is conforming to MIL-PRF-46146 &amp; MIL-1-46058. This has to be carried out after completion of Functional testing. i) Clean the PCBs thoroughly with 3 tray method. alcohol. ii) Baking of PCBs at 65°C for 4 hours iii) Potting shall be carried out on the components which are specified in Appendix iv) Potting shall be done with a MIL grade potting material which shall be conforming to MIL-PRF-46146 v) Before handling, read product, data sheets, container labels for safe use and Expiry date. vi) Potting (RTV 3140 or conforming to MIL standard) shall be done on heavy components on PCBs which are marked in the lay out drawing, check for expiry date. vii) Allow it dry for at least 24 hours at room temperature. viii) Pre-cure the PCBs with 65°C temperature for 4-hour duration conformal coating thickens to be measured and recorded. ix) Apply the conformal coating uniformly on both sides of PCB by spraying and allow it to dry.</td><td>For potting Dow corning RTV 3140 coating or MIL qualified product. And Silicone 1-2577 for conformal coating</td><td>Inspection by Internal QC, Inspection by DR&amp;QA (RCI)</td></tr><tr><td></td><td>x) The thickness of the coating will be 0.051 to 0.21mm microns, which will be measured in mm by considering PCB thickness using thickness measurement meter. 
xi) After conformal coating the PCBs shall be cured either at room temperature for 24 Hours. 
xii) Visually inspect of uniform application of conformal coating through-out the PCB there shall be no air bubbles, blistering of coating after drying. 
xiii) Retention checks to be done.</td><td></td><td></td></tr><tr><td>11.a</td><td>Integration</td><td></td><td></td></tr><tr><td></td><td>Fix Chassis mounting components like EMI filters &amp; DC-DC Connectors as per the drawing potting shall be carried out for EMI filter hook joints. 
Mechanical clearance report from DR&amp;QA, mechanical QC for chassis parts and components shall be produced before integration.</td><td></td><td>Inspection by 
DR&amp;QA</td></tr><tr><td>12</td><td>Initial Isolation &amp; Continuity Checks &amp; initial Functional test</td><td></td><td></td></tr><tr><td></td><td>With Digital multimetre measure the resistance between each pin to body it should be greater than 20 MΩ. Isolation checks (pin to return) if any as per appendix. 
Isolation ,Continuity &amp;functional perform in the presence of External QC and Table to be given for Recordings in appendix-1</td><td>Multi meter Test jig</td><td>Inspection by 
DR&amp;QA</td></tr><tr><td>13</td><td>Environmental Tests</td><td></td><td></td></tr><tr><td rowspan="11"></td><td>The environmental tests to be carried out as per the Procedure and record the test results.</td><td>Tool Kit, Vibration fixture Plate, Power Supply</td><td rowspan="11">Inspection by 
DR&amp;QA</td></tr><tr><td>AT Test</td><td colspan="1">QT Test</td></tr><tr><td>Limited EMI/EMC 
(CS118,RS103&amp;ESD)</td><td colspan="1">EMI/EMC</td></tr><tr><td>Pre-Random Vibration</td><td colspan="1">Pre-Random Vibration</td></tr><tr><td>Thermal Cycle</td><td colspan="1">Thermal Cycle</td></tr><tr><td>Post Random Vibrationn</td><td colspan="1">Post Random Vibrationn</td></tr><tr><td>Damp Heat Test</td><td colspan="1">High Temperature</td></tr><tr><td>Acceleration</td><td colspan="1">Low Temperature</td></tr><tr><td>Shock</td><td colspan="1">Acceleration</td></tr><tr><td></td><td colspan="1">Shock</td></tr><tr><td></td><td colspan="1">Tropical Exposure</td></tr><tr><td>14</td><td>Final solation &amp; Continuity Checks &amp;Final Functional test</td><td></td><td></td></tr><tr><td></td><td>The Isolation &amp; Final functional test shall be carried out after Environmental tests and record the test results in appendix.</td><td>Multi meter Test jig</td><td>Inspection by 
DR&amp;QA</td></tr></table>

11. QUALITY ASSURANCE MATRIX   

<table><tr><td>Sl.
No</td><td>Description</td><td>Quality Characteristics</td><td>Types of Checks</td><td>Sample Size</td><td>Reference Documents</td><td>Formats of Records</td><td>ATL QC</td><td>DR&amp;QA</td><td>Project</td></tr><tr><td rowspan="3">1.</td><td rowspan="3">Mechanical Chassis, Mechanical Components and fasteners</td><td>a. Material</td><td>Raw material testing</td><td>100%</td><td rowspan="3">1. Bill of Material
2. Master Drawing Index</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>b. Dimensions</td><td>Dimension verification</td><td>100%</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>c. Protective coating</td><td>Visual inspection</td><td>100%</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td rowspan="6">2.</td><td rowspan="6">Bare PCB</td><td>a. Group A and Group B reports</td><td rowspan="2">PCB records</td><td>100%</td><td rowspan="6">1. Bill of Material
2. Master Drawing Index</td><td>TC</td><td>V</td><td>V</td><td>R</td></tr><tr><td>b. Batch code/date code</td><td>100%</td><td>IR</td><td>V</td><td>V</td><td>R</td></tr><tr><td>c. Dimensional Verification</td><td>Measurement as per IR template</td><td>100%</td><td>IR</td><td>V</td><td>V</td><td>R</td></tr><tr><td>d. Warping/ bending</td><td>Measurement as per IR template</td><td>100%</td><td>IR</td><td>V</td><td>V</td><td>R</td></tr><tr><td>e. Electrical Inspection</td><td>Continuity check across various Power, ground and signal points</td><td>100%</td><td>IR</td><td>V</td><td>W</td><td>R</td></tr><tr><td>f. BBT</td><td>As per net list</td><td>One per batch</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td rowspan="7">3.</td><td rowspan="7">KIT clearance Mechanical and Electrical</td><td>a. Visual</td><td rowspan="7">Inspection of Kit components</td><td rowspan="7">100%</td><td rowspan="7">Bill of Material</td><td rowspan="7">IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>b. Package</td><td>P</td><td>W</td><td>R</td></tr><tr><td>c. Part Code</td><td>P</td><td>V</td><td>R</td></tr><tr><td>d. Source</td><td>P</td><td>V</td><td>R</td></tr><tr><td>e. Batch Code</td><td>P</td><td>V</td><td>R</td></tr><tr><td>f. Qty verification wrt BOM</td><td>P</td><td>V</td><td>R</td></tr><tr><td>g. CoC</td><td>P</td><td>R</td><td>R</td></tr><tr><td rowspan="4">4.</td><td rowspan="4">Assembly of PCB</td><td>a. Alignment of components</td><td rowspan="4">1. Visual Inspection
2. 40X inspection
3. X-ray for BGA</td><td rowspan="4">100%</td><td rowspan="4">1. MDI
2. IPC 610F
3. IPC 7722A</td><td rowspan="4">IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>b. Polarity or orientation of components</td><td>P</td><td>W</td><td>R</td></tr><tr><td>c. Soldering defects</td><td>P</td><td>W</td><td>R</td></tr><tr><td>d. Components missing</td><td>P</td><td>W</td><td>R</td></tr><tr><td>5.</td><td>Card level Functional Test</td><td>Functional Parameters</td><td>Performance Checks</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td rowspan="3">6.</td><td rowspan="3">Non MIL Screening</td><td>High Temperature Stabilization bake</td><td rowspan="3">Preet, INSET &amp; POET with ESS Jig/ Entest Test</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>Thermal Shock</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>Burn In</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td rowspan="2">7.</td><td rowspan="2">Potting</td><td>a. Potting Material</td><td rowspan="2">1. Potting material 2. Potting as per drawing</td><td rowspan="2">100%</td><td rowspan="2">MDI</td><td rowspan="2">IR</td><td>P</td><td>R</td><td>R</td></tr><tr><td>b. Potting of PCB</td><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td rowspan="4">8.</td><td rowspan="4">Conformal Coating</td><td>a. Coating Material</td><td rowspan="4">1. Coating material 2. Thickness as defined</td><td rowspan="4">100%</td><td rowspan="4">QAP</td><td rowspan="4">IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>b. Uniformity of coating</td><td>P</td><td>R</td><td colspan="1">R</td></tr><tr><td>c. Thickness</td><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>d. Finish</td><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>9.</td><td>Unit Assembly</td><td>Workmanship Fasteners</td><td>Visual inspection</td><td>100%</td><td>MQAP &amp; MDI</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td rowspan="2">10.</td><td rowspan="2">Initial Cold Check</td><td>1. Continuity Check</td><td rowspan="2">Visual inspection</td><td rowspan="2">100%</td><td rowspan="2">QAP/ QT-AT</td><td rowspan="2">IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>2. Isolation Check</td><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>11.</td><td colspan="2">Initial Functional test (unit level)</td><td>Functional test</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td rowspan="7">12.</td><td rowspan="7">Acceptance Tests</td><td rowspan="7">ESS 1. Limited EMI/EMC (CS118,RS103&amp;ESD) 2. Pre-Random Vibration 3. Thermal Cycle 4. Post Random Vibration 5. Damp Heat Test 6. Acceleration 7. Shock 8. Final Electrical Test</td><td rowspan="7">Preet, INSET &amp; POET with ESS Jig/ Entest Test</td><td rowspan="7">100%</td><td rowspan="7">QAP/ QT-AT</td><td rowspan="7">IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>P</td><td>W</td><td colspan="1">R</td></tr><tr><td>P</td><td>W</td><td colspan="1">R</td></tr></table>

<table><tr><td>Sl.No.</td><td>Description</td><td>Quality Characteristics</td><td>Types of Checks</td><td>Sample Size</td><td>Reference Documents</td><td>Formats of Records</td><td>ATL QC</td><td>DR&amp;QA</td><td>Project</td></tr><tr><td rowspan="9">13.</td><td rowspan="9">Qualification Tests</td><td>1. EMI/EMC (RE102,CE102,CS101,CS114, CS116,CS118,CS115,RS103,ESD)</td><td rowspan="7">Preet, INSET &amp; POET with ESS Jig/ Entest Test</td><td rowspan="5">100%</td><td rowspan="5">QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td rowspan="3">2.ESS 1.Pre-Random Vibration 2. Thermal Cycle 3. Post Random Vibration.</td><td rowspan="3">IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>P</td><td>W</td><td>R</td></tr><tr><td>P</td><td>W</td><td>R</td></tr><tr><td>3. High Temperature</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>4. Low Temperature</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>5. Acceleration</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>6. Shock</td><td>Preet&amp; POET With ESS Jig/Entest Test</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>7. Tropical Exposure</td><td>Preet, INSET &amp; POET with ESS Jig/ Entest Test</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td rowspan="2">14.</td><td rowspan="2">Final Cold Checks</td><td>1. Continuity Check</td><td rowspan="2">Functional test</td><td rowspan="2">100%</td><td rowspan="2">QAP/ QT-AT</td><td rowspan="2">IR</td><td>P</td><td>W</td><td>R</td></tr><tr><td>2. Isolation Check</td><td>P</td><td>W</td><td>R</td></tr><tr><td>15.</td><td colspan="2">Final Functional test</td><td>Functional test</td><td>100%</td><td>QAP/ QT-AT</td><td>IR</td><td>P</td><td>W</td><td>R</td></tr></table>

* QT &AT En-tests also to be carried out.   
P - Perform   
R - Review   
W - Witness   
IR - Inspection report   
V - Verify

# 11.1. Screening Procedures for Cots Components/PCBS

# 11.1.1. Purpose

This test Procedure read in conjunction with clause 15 of JSG 761:2001 describes Screening Test Procedures for service Electronic Components procured as COTS Components or PCBs. The Tests specified herein are intended to Screen out Components having Manufacturing Defects & potential early Life failures. Screening Test Procedures are a group of Tests imposed on a production Batch to assist in achieving the desired levels of Quality & Reliability for the Components commensurate with intended application. In general options for performance screening tests are as follows:

a) Screening by Manufacturer: Screening Tests may be done at the Components Manufacturers end. The cost of such Testing is likely to be Low.   
b) Screening by the User: Screening Tests may be performed by the User or Original Equipment Manufacturer (OEM) whenever such facilities exit with them. The test data integrity would be high in such cases.   
c) Screening by using Independent Test Laboratories: Screening Test may be performed by using the test facilities and service available at the independent test laboratories. In such cases also, the test data integrity would be high.   
d) This Screening procedure is applicable only for COTS components and is not called for MIL Grade/ QML/ Screened as per JSS 50115 Components. If any difficulties are encountered in adhering to the established component screening procedures, the test procedures in the subsequent paragraphs may be adopted. From experience already gained, it is seen that SMDs (in roll or tape form) are not screen able at the component level at User End.

Therefore, the best option is to select SMDs from the QML sources. However, if SMDs of QML source are not available, the SMDs of COTS category may be qualified at card level.

# 11.1.2. Related Documents:

# Joint Services Specifications:

JSS 50101:1996 Environmental Test methods for Service Electronics Components

JSS 50115:1999 Screening test Procedures on Electronic Components.

JSG 755:2001Uniform implementation of COTS pertaining to Electronic Components in the services.

JSG 761:2001 Formulation of Quality Assurance Procedure: COTS items (Avionics)

# Other Specifications:

MIL-STD-202 Test method for Electronic and Electrical Components parts

MIL-STD-883 Test Methods and Procedures for Microelectronics

MIL-M-38535 General Specifications for Integrated Circuits (Microcircuits

# PART-A

# 11.2. Screening Test for Discrete Components

# 11.2.1. High Temperature Storage

<table><tr><td>Title of Test</td><td>Title of Test</td><td>Requirements</td></tr><tr><td>High Temperature Storage test
(Stabilization Bake)</td><td>As per Test Number 22 of JSS 50101;
a) Components requiring screening shall be placed in a meal tray are kept in the chamber.
b) The chamber temperature shall be increased to maximum rated storage temperature+85°C with tolerance +50°C/0°C.
Specified for the components under test.
c) The components shall be exposed for the 24hours continuously at the specified maximum storage temperature.</td><td>i) Visual Examination
ii) Electrical parameters Test at ambient temperature</td></tr></table>

After Visual Examinations and Electrical Tests, the components shall be selected which have met the requirements and be subjected to the following tests.

# 11.2.2. Thermal Shock

<table><tr><td>Title of Test</td><td>Title of Test</td><td>Requirements</td></tr><tr><td>Thermal Shock</td><td>As per Test No. 20 of JSS 50101Low temperature: Minus 40°C withtolerance of 0°C/Minus 5°CHigh temperature: +85°C with tolerance of0°C/ +5°C.Transfer Time: 2 minutesPeriod of Exposure: 30 MinutesNo. of cycle:10Operation: OFFConditionNotes:a) The components shall be placed in thetray or any suitable container andintroduced in the chamber already stabilizedat extreme low storages temperature of thecomponents.b) The tray to be transferred to the chamberalready stabilized at extreme high storagetemperature of the components</td><td>On completion of 10Cycles of thermal shocksand recovery carry out visualexamination,Electrical parameters/ (DCelectrical for Ics) tests onthe components at ambienttemperature.</td></tr></table>

After completion of Visual Examination and Electrical Tests, the components shall be selected which have met the requirements and be subjected to the following test.

# 11.2.3. Sealing Tests

Unless specified, hermetically sealed components shall be subjected to leak test in accordance with JSS 50101 Test method 18/ MIL-STD-202E Method 112B or MIL-STD-883 Method 1014.1 as applicable. IF hermetically sealed components have been screened for hermetically on $100\%$ basis at manufacturer facility as part of reliability program, then this test need not be carried out. Conformance Certificate must be produced.

# 11.2.4. Electrical Tests for Non-SMD Components

<table><tr><td>S. No.</td><td>Components Category</td><td>Tests to be done for</td></tr><tr><td>1.</td><td>Leaded Resistors for all varieties</td><td>Value to be checked for 100% of the batch.</td></tr><tr><td>2.</td><td>Capacitors of all varieties</td><td>Value to be checked for 100% of the batch.</td></tr><tr><td>3.</td><td>Inductors of all varieties</td><td>Value to be checked for 100% of the batch.</td></tr><tr><td>4.</td><td>Potentiometer</td><td>• Smooth rotation with value
• No jerks or discontinuities
(To be conducted on 100% of the batch)</td></tr><tr><td>5.</td><td>Potentiometer with switch</td><td>• Smooth rotation with value
• No jerks or discontinuities
• For positive switching action
(To be conducted on 100% of the batch)</td></tr><tr><td>6.</td><td>Diodes, Transistors and Zener Diodes</td><td>Check the DC parameters on curve tracer or semiconductor tester.
To be carried on 100% of the batch.</td></tr><tr><td>7.</td><td>Sensor Module</td><td>• PC Checks to be done by inserting in to the reference receivers
• To be conducted on 100% of the batch.</td></tr><tr><td>8.</td><td>DC-DC Converter</td><td>• As a module using separate test Jig
• To be conducted on 100% of the batch</td></tr></table>

# 11.2.5. Acceptance criteria

The batch shall be accepted/ rejected after completion of screening tests on components, as per defined criteria established with concerned Quality Assurance Authority.

# 11.2.6. Assembly Practices

The PCB shall be assembled with the components that have passed the above screening tests. SMD components are permitted to be used provided they have been procured from MIL/QML/QPL sources. The general industry Standard/general assembly drawing to be followed by the assembled PCB shall be suitably marked for identification & traceability.

NOTE: Caution shall be exercised in control of moisture absorption in Plastic

Encapsulated Microcircuits (PEMs). This involves keeping PEMs packages as dry as possible by any one of the methods, such as storage in desiccant environment, High Temperature Bake (+125 o C for 16 to 24 Hours) and Low temperature Bake (limited to +40 o C and low RH < 10% using dry nitrogen or Dry air purg

# PART-B

# 11.3. Screening Test of Populated PCBs

Purpose: This procedure applies to PCBs populated with COTS components. The PCB level screening shall be adopted only when it is not possible to undertake $100\%$ component level screening and in that case components are not required to be screened separately.

# 11.3.1. Visual Examination

<table><tr><td>Title of Test</td><td>Title of Test</td><td>Requirements</td></tr><tr><td>Visual Examination</td><td>a. Carryout Physical/Visual Examination of the assembled PCB for Non-Conformities/abnormalities and correct the same.
b. Performance Check</td><td>Electrical parameters/ (DC electrical for Ics) tests on the components at ambient temperature.</td></tr></table>

# 11.3.2. High Temperature Storage (Stabilization Bake) Test

<table><tr><td>Title of Test</td><td>Test details</td><td>Requirements</td></tr><tr><td>High Temperature Storage (Stabilization Bake) Test</td><td>As per test no 22 of JSS 50101, after introduction of PCBs, increase chamber temperature to +85°C with tolerance +5°C /0°C. Expose the assembled PCB for 24 Hours continuously at +85°C.</td><td>Visual Examination and Functional checks at ambient Temperature.
Record failures Observed, if any.</td></tr></table>

# 11.3.3. Rework

Repair/Replace components as required using fresh components. The new components must undergo stabilization bake test before assembly.

# 11.3.4. Thermal shock Test

The PCB, which has undergone the test at paragraph 11.3.2 above, shall be subjected to 10 cycles of continuous Thermal Shock (In power 'OFF' condition) as follows:

<table><tr><td>Title of Test</td><td>Test details</td><td>Requirements</td></tr><tr><td>Thermal Shock Test</td><td>As per Test No. 20 of JSS 50101
Low temperature: Minus 40°C with tolerance of 0°C/ + 5°C.
Minus 5°C
High temperature: +85°C with tolerance of 0°C/ +5°C.</td><td>PCB assembly must be free from any visual damages or distortions namely cracking and delamination of finishes, cracking and crazing of embedding encapsulating compounds, opening of thermal seals and case seams, leakage of</td></tr><tr><td></td><td>Transfer Time: 2 minutes
Period of Exposure: 30 Minutes
No. of cycle:10
Operation: OFF Condition</td><td>filling materials, rupturing, or cracking of Hermetic seals and changes in electrical characterizes due to mechanical displacement or rupture of conductors or of insulating materials.</td></tr><tr><td>Visual 
Examinations</td><td>On completion of 10 Cycles, 
carryout visual examination using magnifying glass with magnification factor of 30 for detection of failure.</td><td></td></tr><tr><td>Electrical 
Measurements</td><td>Carryout Performance checks as per QTP</td><td>As specified in QTP</td></tr></table>

# 11.3.5. Acceptance Criteria

In case of failures, analyse the defects in consultation with Certification/Quality Assurance Agency. Failed components shall be replaced and new components shall undergo stabilization bake and thermal Shock before assembly, repeat visual Examination and Performance Checks.

# 11.3.6. Burn-in Test

<table><tr><td>Title of Test</td><td>Title of Test</td><td>Requirements</td></tr><tr><td>Burn-in test</td><td>1. The PCB Shall be placed in a chamber. All arrangements shall be made externally to carryout Functional Checks on PCB at every 5 hours period. This constitutes one cycle of 5 hours.
2. The temperature of the chamber shall be raised up to +71°C rated operating temperature; the populated PCB is designed to perform with tolerance +5°C / 0°C.
3. PCB Shall is maintained at this temperature continuously for 48 hours in power ON condition.
4. In case of failure, the components shall be replaced by components which have gone and passed high temperature Storage and thermal Shock before assembly and continue the test for remaining hours. If the failure occurs after the 46th / 47th / 48th hour, expose the PCB for further 03 hours to confirm the adequacy of the repair work.
5. On the completion of Burn-in Test, Switch OFF the chamber.
6. Take out the PCB assembly for conducting Visual Examination; PCB assembly shall be free from the visual damages of distortions as stipulated at 11.3.1. above.
7. Carry out the performance Checks as per QTP/ATP on the PCB assembly and record the results.</td><td>The last 3 hours shall be defect free</td></tr></table>

# 11.3.7. Marking

The Assembly PCB on passing the above tests shall be marked suitably for easy identification to avoid mixing up.

# 11.3.8. Post Burn-in

Subject the PCB assembly for completed performance Checks, as per the respective test documents. If the PCB assembly cannot be tested independently, insert it in the system/test rig and check for the performance. Any non-conformity found during functional checks is to be recorded for further analysis and initiate appropriate corrective action.

# 11.3.9. Storage

Preserved the screened PCB assembly (duly marked for identification) in anti-static pouches safely and controlled environment for further integration with the equipment.

# 11.3.10. Record

Keep a record of all stage inspections and performance checks on the PCB, identified with it serial numbers for lateral verification and trace-abil

# 12. SEQUENCE OF ACTIVITIES

Following is the sequence of activities to be followed for the fabrication and testing of the units. i. Board Level Tests

1. RMT checks (Resistance Measurement Checks and Voltage checks)

2. Anti-aliasing Filter Checks. (To be done for one unit per batch if machine soldering is done. If it is hand soldering, then it has to be done for all units)

3. Burn-IN Test

ii. Initial Functional Checks

c. Electrical Checks

3. Isolation Resistance Checks

3.1. All pins to Chassis (For every connector of every unit)

3.2. All pins to all pins of connector (For every connector, for one unit per batch)

4. Power Consumption, Reverse Voltage Protection and Power Supply Voltage variation checks

d. Signal Conditioning Tests

1. Excitation Tests

2. 5-Point calibration of Analog Channels

3. Filter Cut-off Frequencies(Digital Filter testing)

Note: Filter Testing Results will be approved by Designer Rep.

iii. Functional & Performance Testing during ESS, AT, QT, EMI/EMC Test

iv. Final Functional Checks

c. Electrical Checks

1. Isolation Resistance Checks All pins to Chassis (For every connector of every unit)

2. Power Consumption, Reverse Voltage Protection and Power Supply Voltage variation checks

d. Signal Conditioning Tests

1. Excitation Tests

2. 5-Point calibration of Analog Channels

3. Filter Cut-off Frequencies (Digital Filter testing)

Note: Filter Testing Results will be approved by Designer Rep.

# 13. Qualification and Acceptance Tests (QT/AT)

Following QT and AT tests are to be carried out as mentioned in 13.1(Flow Charts)

Following set up and procedure is to be followed for each environmental test

Setup: The test setup required for performing the test is shown in Figure. 17

![](images/b89563edbef3afdda978048346e2ddf07d7869ee6c0bbbbe7d387ed17641aa61.jpg)  
Figure 17 Test Setup - Environmental tests

# Procedure:

1) Unit has to be powered ON whenever reading has to be taken.   
2) SCP Test jigs and RS 422 receiver have to be connected to the unit   
3) The output from CPSCP is given to RS422 Receiver.   
4) Results are noted in Test Leaf-12.   
5) All channels must be provided with input signal simultaneously.

After completion of all the environmental tests, conformance report to be filled as given in Appendix D

# ENTEST PROCEDURE:

Objective : The test is performed to verify the functionality and performance of CPSCP. This test is carried out to checks the functionality/performance during various stages of qualification & acceptance test (QT/AT)

Before starting any environmental test below test to be carried out

1. Ensure that all A.C. distribution board are cleared for use and voltage are checked (L-N: $230\mathrm{V} \pm 10\mathrm{V}$ , L-E: $230\mathrm{V} \pm 10\mathrm{V}$ and E-N: $< 1\mathrm{V}$ )

2. Ensure that all the test cables, UUT and testing equipment's are cleared.   
3. Ensure that the earthing of the power supply and other test equipment are done.

# NOTE:

A. ESS should be carried out in sequence remaining test sequence is not mandatory.   
B. Salt spray &Mould Growth On test Coupons only

# 13.1. FLOW CHARTS

Test Flow Charts for QT-AT Sequences:

![](images/a607fa9a0f46c064933bd224b9ae98515936be0235c012b846a6be53d749fd80.jpg)  
Qualification test (QT) Sequence

![](images/a164abbc36ab02043445dfbf8a9bc6ef23bad42791a7af59d3b9f7aa68266635.jpg)  
Acceptance Test (AT)Sequence

# 13.2 EMI/EMC TEST

Note: EMI/EMC Test to be conducted on missile level, treating VSHORADS-SF missile as a single EUT for all EMI-EMC tests. Thus, these tests are not under vendor's scope.

# Test Level

<table><tr><td>Frequency Band</td><td>Test Method</td></tr><tr><td>QT:RE102; CE 102; CS 101; CS 114; CS 116; CS 118; CS115; RS 103</td><td rowspan="2">MIL STD 461E
PREET, INSET/ POET</td></tr><tr><td>AT:CS 115;RS 103&amp;ESD</td></tr></table>

# Test Procedure:

1. Put the unit inside the chamber and make the set up as mentioned on Pages No:51-53   
2. Ensure that the chamber is calibrated.   
3. Ensure that all the test equipment are grounded properly   
4. Switched ON power supply and note down the PREET values of monitoring channels at room temperature.   
5. Program the test chamber as per specification.   
6. Subject the unit to EMI/EMC chamber test as per specification and note down the INSET values of the monitoring channels.   
7. After completion of test bring the chamber to the normal condition and note down the POET values of the monitoring channels.   
8. Result to be noted in test report.

<table><tr><td>SI.
No.</td><td>Test</td><td>Test Description</td><td>Applicability/Limit Line/Test Procedure</td><td>Test Duration</td><td>Test Method</td></tr><tr><td>1</td><td>RE102</td><td>Radiated Emissions (Electric field)10KHz to 18GHz</td><td>Applicability: Emissions from equipment and their interconnecting cables at 1 meter distance from the equipment will be measured.
Spec. Limit Line: Emissions from equipment shall not be radiated in excess of those shown in figure RE102-3 (fixed wing internal&lt; 25 meters).
Test setup and Test Procedure:
As per MIL-STD-461E</td><td>NA</td><td>PREET
INSET
POET</td></tr><tr><td>2</td><td>CE102</td><td>Conducted Emissions (Power Interconnecting Leads) 10KHz to 10MHz</td><td>Applicability: Applicable on AC and DC input power leads, including returns which are not grounded internally that obtain power from the other sources.
Spec. Limit Line: Emissions on 28V power leads will not be exceeded the values shown in figure CE102-1(basic curve).
Test setup and Test Procedure:
As per MIL-STD-461E</td><td>NA.</td><td>PREET
INSET
POET</td></tr><tr><td>3</td><td>CS101</td><td>Conducted Susceptibility power leads, 30Hz to 150 KHz</td><td>Applicability: Applicable to subsystem AC and DC input power leads, not including returns. On AC lines this requirement is applicable starting from the second harmonic of the equipment under test power frequency.
Spec. Limit Line: The equipment will not exhibit any malfunction, degradation of performance or deviation from specified indications/ tolerances, when subjected to signal voltage levels as shown in Figure CS 101-1. Curve #1 for source voltage higher than 28V &amp; curve #2 for 28V or below.
Test setup and Test Procedure:
As per MIL-STD-461E</td><td>The test signal voltage will be applied on to each power lead separately for the complete band of frequency. That is approx. 30 minutes for each test run.</td><td>PREET
INSET
POET</td></tr><tr><td>4</td><td>CS114</td><td>Conducted Susceptibility, bulk cable injection, 10KHz to 400MHz</td><td>Applicability:Applicable to all interconnecting cables, including power cables and separately on positive (high) line/wire, excluding neutral/grounding lines.
Spec. Limit Line:The equipment will not exhibit any malfunction or degradation of performance when subjected to signal voltage selected from Table VI
Limit curves(curve#5)
Test setup and Test Procedure:
As per MIL-STD-461E</td><td>The test signal current will be applied on to each cable for the complete band of frequency. That is approx. 90 minutes for each test run.</td><td>PREET
INSET
POET</td></tr><tr><td>5</td><td>CS116</td><td>Conducted Susceptibility, damped sinusoidal transients, Cables and Power Leads 10KHz to 100MHz</td><td>Applicability:Applicable to all interconnecting cable bundles, power cable, and separately on positive (high) line / wire, excluding neutral / ground lines.
Spec. Limit Line:The equipment shall not malfunction or degradation of performance when subjected to the signal waveform and current as shown in figures CS116-1 and CS116-2, for minimum of six spot frequencies. That is 10KHz, 100KHz, 1MHz, 10MHz, 30MHz.
Test setup and Test Procedure:
As per Mil-Std-461E</td><td>The test signal current shall be applied on to each cable four of six spot frequencies. That is approx. 45 minutes for each test run.</td><td>PREET
INSET
POET</td></tr><tr><td>6</td><td>CS118</td><td>A Pulse of Amplitude 8 KVCharged through 150pF capacity Discharged through 330 Ω resistor Two Pulses shall be discharged on each connector on EUT and the chassis with a time interval of 5s between each discharge.</td><td>Applicability:Electrical, electronic, electromechanical subsystems and equipments that have a man-machine interface.
Spec. Limit Line:
a) Test Voltage Level: ±8 kV for contact discharge method.
b) Apply 5 positive discharges and 5 negative discharges to each EUT test point.
c) EUT shall be powered on condition during the test.
Test setup and Test Procedure:
As per MIL-STD-461G</td><td>The test signal will be applied on each cable for duration of 60 seconds.</td><td>PREET
INSET
POET</td></tr><tr><td>7</td><td>CS115</td><td>Conducted Susceptibility, Bulk Cable injection, Impulse Excitation</td><td>Applicability: Applicable to all interconnecting cables, Including power cables and separately on positive (high) line/wire, excluding neutral/ground lines.
Spec. Limit Line: The equipment shall not exhibit any malfunction or degradation of performance, when subjected to signal characteristics as shown in figure CS 115-1.
Test setup and Test Procedure:
As per MIL-STD-461E</td><td>The test signal will be applied on each cable for duration of 60 seconds.</td><td>PREET
INSET
POET</td></tr><tr><td>8</td><td>RS103</td><td>Radiated Susceptibility, Electric Field, 2MHz to 40GHz.</td><td>Applicability: Applicable to all Equipment / Subsystem enclosures with interconnecting cables.
Spec. Limit: The equipment will not exhibit any malfunction or degradation in performance, when subjected to field strength of 50V/m selected from Table VII RS103 limits shown below with pulse modulation, 50% duty cycle, in the test frequency range at 1 mtr from equipment for both vertical and horizontal polarizations.
Test setup and Test Procedure:
As per MIL-STD-461E.</td><td>The electric field shall be applied for duration of 60 seconds complete band of frequency with the scan rates specified.</td><td>PREET
INSET
POET</td></tr><tr><td>9</td><td>ESD</td><td>Electrostatic Discharge</td><td>Applicability: Applicable to all the interfacing connectors mounted on the equipment and chassis.
Spec. Limit: The equipment shall not exhibit any malfunction or degradation of performance, when discharged a 20kV Pulse with RC network of 150 Ohms and 150 pF
Test setup and Test Procedure:
As per IEC 61000-4-2/Mil-standard-1686.</td><td>2 Pulses to be discharged on each connector &amp; equipment chassis</td><td>PREET
INSET
POET</td></tr></table>

# 13.3. ESS TEST

# 13.3.1. PRE/POST RANDOM VIBRATION TEST

Objective: To determine the suitability of equipment to withstand specified severities of vibration and to bring out the workmanship and latent defects.

Test Level   

<table><tr><td>Frequency Band</td><td>Duration (Sec)/axis</td><td>Test Method</td></tr><tr><td>20 Hz – 100 Hz ; +6 dB/Octave</td><td>300 s, long.&amp; lat. Axes</td><td>PREET, INSET, POET</td></tr><tr><td>100-1000 – 0.04 g2/Hz</td><td>Note: applicable for QT &amp;</td><td></td></tr><tr><td>1000-2000 Hz ; -6dB/Octave;</td><td>AT</td><td></td></tr></table>

# Test Procedure:

1. Mount the unit on vibration table and make the set up as per figure Pre/Post Random vibration test.   
2. Ensure that the vibration shaker is calibrated.   
3. Ensure that Environmental test specification levels are programmed and maintained. The same specification should be reflected on test formats.   
4. Switched ON power supply and note down the PREET reading value of monitoring channels at room temperature.   
5. Subject the unit to vibration as per specification and note down the INSET reading value of monitoring channels.   
6. After completion of test note down the POET reading of the monitoring channels   
7. Repeat the same for all 3 axes   
8. Results to be noted in test report.

![](images/0de58fe4f8defcd9d7d339a7498e392a8638b3b4694b75fbfd79d56b535fb8d0.jpg)  
PSD $g^2 /Hz$   
Figure: PRE/POST- Random vibration test

# 13.3.2 THERMAL CYCLING TEST

Objective: To bring out the workmanship and latent defects in the test item by subjecting it to rapid temperature cycling stress.

# Test Level

<table><tr><td>Frequency Band</td><td colspan="2">Duration</td><td>Test Method</td></tr><tr><td>-30°C for 60 min.</td><td colspan="2">Rate of change of Temp:10°C /min</td><td>PREET, INSET, POET</td></tr><tr><td>+70°C for 60 min.</td><td></td><td></td><td></td></tr><tr><td></td><td>QT</td><td>AT</td><td></td></tr><tr><td></td><td>8 Cycles</td><td>6 Cycles</td><td></td></tr></table>

# Test Procedure:

1. Put the unit inside the chamber and make the set up as per figure thermal cycling test.   
2. Ensure that the chamber is calibrated.   
3. Ensure that Environmental test specification levels are programmed and maintained. The same specification should be reflected on test formats.   
4. Switched ON power supply and note down the PREET reading value of monitoring channels at room temperature.

# INSET:

1. Start the thermal chamber and switch off all systems (UUT). Decrease the chamber temperature to $-30^{\circ}\mathrm{C}$ .   
2. After attaining the specified temperature $(-30^{\circ}\mathrm{C})$ , soak the unit for 1 hour.   
3. After 45 minutes of dwelling, switch ON all power supply and note down the INSET reading of the monitoring channels, switch OFF all systems.   
4. Increase the chamber temperature to $+70^{\circ}\mathrm{C}$ .   
5. After 45 minutes of dwelling, switch ON all power supply and note down the INSET reading of the monitoring channels, switch OFF all systems.   
6. This complete one cycle. Repeat the same procedure for remaining cycles.   
7. Care should be taken that the systems are not to be switched ON during changing over from $+70^{\circ}\mathrm{C}$ to $-30^{\circ}\mathrm{C}$ and vice versa.   
8. After completion of test note down the POET reading of the monitoring channels.   
9. Repeat the same for remaining cycles.   
10. Results to be noted in test report.

![](images/63311e43a55f407c2b277614ec7d4cad48e45948afb09ad4caf91c30258ea26a.jpg)  
Figure: Thermal Cycling

# 13.4. HIGH TEMPERATURE

Objective: To determine the resistance of equipment to high temperature that may be encountered during service life either in storage or use.

# Test Level

<table><tr><td>Frequency Band</td><td>Duration</td><td>Test Method</td></tr><tr><td>55 ± 3°C; 6 hrs.</td><td rowspan="3">Last 1 hr. Operation Only in QT</td><td rowspan="3">Test No 16 JSS 0256-01 PREET, INSET/POET</td></tr><tr><td>65 ± 3°C; 4 hrs.</td></tr><tr><td>55 ± 3°C; 6 hrs.</td></tr></table>

# Test Procedure:

1. Put the unit inside the chamber and make the set up as per figure high temperature.   
2. Ensure that the chamber is calibrated.   
3. Switched ON power supply and note down the PREET values of monitoring channels at room temperature.   
4. Program the test chamber as per specification.   
5. Subject the unit to high temperature test as per specification and note down the INSET values of the monitoring channels in last60 minutes at $55^{\circ}\mathrm{C}$ of soaking.   
6. After completion of test bring the chamber to the room temperature and note down the POET values of the monitoring channels.   
7. Test is of 16 hours duration.   
8. Result to be noted in test report.

![](images/952e57ebf92b926c086f3fd04fcc6b0cd70ccdc9cd0cea6955279bc761ea4869.jpg)  
Figure: High Temperature

# 13.5. LOW TEMPERATURE

Objective: The temperature suitability of the equipment for use/storage at specified low ambient temperature condition.

Test Level

<table><tr><td>Frequency Band</td><td>Duration</td><td>Test Method</td></tr><tr><td>-30 ± 3°C; 16 hrs.</td><td>Last 1 hr. Operation Only in QT</td><td>Test No 2 JSS 0256-01
PREET, INSET/POET</td></tr></table>

# Test Procedure:

1. Put the unit inside the chamber and make the set up as per figure Low temperature.   
2. Ensure that the chamber is calibrated.   
3. Switched ON power supply and note down the PREET values of monitoring channels at room temperature.   
4. Program the test chamber as per specification.   
5. Subject the unit to low temperature test as per specification and note down the INSET values of the monitoring channels in last 60 minutes at $-30^{\circ}\mathrm{C}$ of soaking.   
6. After completion of test bring the chamber to the room temperature and note down the POET values of the monitoring channels   
7. 1 such cycle is of 16 hours duration and total cycle 1.   
8. Result to be noted in test report

![](images/d593692ad020afefe9038a3c6b78be070e7c5c4a030abfe1810ca0e79e974361.jpg)  
Figure: Low Temperature

# 13.6. ACCELERATION TEST

Objective: To determine the suitability of equipment to withstand specified severities of shocks and to bring out the workmanship and latent defects.

# Test Level

<table><tr><td>Frequency Band</td><td>Duration</td><td>Test Method</td></tr><tr><td>QT: Long.: 75 g; 45 s</td><td rowspan="3">6 Directions, 2 directions in each axis</td><td>Test No 16 JSS 0256-01</td></tr><tr><td>Lateral: 60 g; 45 s</td><td rowspan="2">PREET, INSET/POET</td></tr><tr><td>AT: Long.: 50 g; 45 s</td></tr><tr><td>Lateral: 40 g; 45 s</td><td>Refer - Page No1-13</td><td></td></tr></table>

# Test Procedure:

1. Mount the unit on vibration table and make the set up as per figure Acceleration test.   
2. Ensure that the Acceleration Machine is calibrated.   
3. Ensure that Environmental test specification levels are programmed and maintained. The same specification should be reflected on test formats.   
4. Switched ON power supply and note down the PREET reading value of monitoring channels at room temperature.   
5. Subject the unit to acceleration as per specification and note down the INSET reading value of monitoring channels.   
6. After completion of test note down the POET reading of the monitoring channels.   
7. Repeat the same for all 6 directions X axis: longitudinal mounting of R2T of missile airframe on fixture   
8. Y axis: lateral mounting (90° change) of same fixture while keeping missile airframe untouched   
9. Z axis: lateral mounting of fixture but R1R of missile airframe will give -zaxis   
10. Z axis: lateral mounting of fixture but R1L of missile airframe will give $+\mathbf{z}$ axisDirections.   
11. Results are noted in test report

![](images/8244344f8a5dfeca46446606adcf76b773bd7ea8a430948ca821c122e6c1290d.jpg)  
M/S ADSTL Po No.4500380257 Date:20/11/2024 on ATL   
Figure:Acceleration Test

# 13.7. SHOCK TEST

Objective: To determine the suitability of equipment to withstand specified severities of shocks and to bring out the workmanship and latent defects:

Test Level   

<table><tr><td>Frequency Band</td><td>Duration</td><td>Test Method</td></tr><tr><td>60g; 3 shocks per axis QT (3 Axes)</td><td rowspan="2">3 Axes, 6 Directions. 3 ms each.</td><td rowspan="2">Should be Based on shock responses measured in Static and HOT test (Nominal functionality will be checked)</td></tr><tr><td>40 g; 2 shocks per axis AT (3 Axes)</td></tr></table>

# Test Procedure:

1. Mount the unit on vibration table and make the set up as per figure Shock test.   
2. Ensure that the vibration shaker is calibrated.   
3. Ensure that Environmental test specification levels are programmed and maintained. The same specification should be reflected on test formats.   
4. Switched ON power supply and note down the PREET reading value of monitoring channels at room temperature.   
5. Subject the unit to vibration as per specification and note down the INSET reading value of monitoring channels.   
6. After completion of test note down the POET reading of the monitoring channels.   
7. Repeat the same for all 6 axes.   
8. Results are noted in test report.

![](images/8f73d5befcc181fafc3812b36cd2a16fa661cecb4a8b3137189e66a30ebca003.jpg)  
Q

![](images/d33401e0e8a230f7aa35d232f552e45feeff506f5583a69a3cfcd7fcc4616658.jpg)  
Figure: Shock Test

# 13.8. TROPICAL EXPOSURE TEST

Objective: To determine the suitability of equipment for use and storage condition of high humidity when combined with cycle temperature changes

# Test Level

<table><tr><td>Frequency Band</td><td>Duration</td><td>Test Method</td></tr><tr><td>20 ± 2°C; 6 hrs. Ramp Up to 45°C in 3 hrs. 
45 ± 2°C; 12 hrs. 
Ramp Down to 20°C in 3 hrs. RH &gt; 95%</td><td>Cycles – 14 
Only in QT</td><td>PREET, INSET during last 
30 minutes (@40 ± 2°C; 
RH &gt; 95%) 
followed by POET</td></tr></table>

# Test Procedure:

1. Put the unit inside the chamber and make the set up as per tropical exposure test.   
2. Ensure that the chamber is calibrated.   
3. Switched ON power supply and note down the PREET values of monitoring channels at room temperature.   
4. Program the test chamber as per specification.   
5. Subject the unit to tropical heating test as per specification and note down the INSET values of the monitoring channels in $7^{\mathrm{th}}$ and $14^{\mathrm{th}}$ day at $50^{\circ}\mathrm{C}$ of soaking.   
6. After completion of test bring the chamber to the room temperature and note down the POET values of the monitoring channels.   
7. 1 such cycle is of 24 hours duration and total cycles 14.   
8. Result to be noted in test report.

![](images/b1887c5a6d4c0b478c470610cb9c4193fb1b5a00852b93f4a97dcf492e5d8b36.jpg)  
Figure: Tropical Exposure

# DAMP HEAT TEST

Objective: To determine the suitability of equipment for use and storage condition of high humidity when combined with constant temperature.

# Test Level

<table><tr><td>Frequency Band</td><td>Duration</td><td>Test Method</td></tr><tr><td>40 ±2°C; RH ≥ 95%</td><td>8 hrs. only in AT TEST</td><td>PREET, INSET, POET</td></tr></table>

# Test Procedure:

1. Put the unit inside the chamber and make the set up as per figure Damp heat.   
2. Ensure that the chamber is calibrated.   
3. Switched ON power supply and note down the PREET values of monitoring channels at room temperature.   
4. Program the test chamber as per specification.   
5. Subject the unit to damp heating test as per specification and note down the INSET values of the monitoring channels during last 30 minutes at $40^{\circ}\mathrm{C}$ of soaking.   
6. After completion of test bring the chamber to the room temperature and note down the POET values of the monitoring channels.   
7. Result to be noted in test report

![](images/1953049a5d0cd6c40bc6a97b270522afe321270a06f8cbe76e3c3870936fa7e1.jpg)  
Figure:Damp Heat Test

# 13.10. AT MATRIX

<table><tr><td>SI.NO</td><td>TEST</td><td>PREET</td><td>INSET</td><td>POET</td><td>Parameter monitoring</td></tr><tr><td rowspan="4">1.</td><td>CEMILAC</td><td colspan="3"></td><td rowspan="4">As per Screening test Format</td></tr><tr><td>High-Temperature stabilization bake</td><td>A</td><td>NA</td><td>A</td></tr><tr><td>Thermal Shock</td><td>A</td><td>NA</td><td>A</td></tr><tr><td>Burn In Test</td><td>A</td><td>A</td><td>A</td></tr><tr><td>2.</td><td>Isolation Continuity &amp; Initial functional Test</td><td>NA</td><td>NA</td><td>NA</td><td>As per initial/final Isolation checks and continuity checks, Initial/Final functional test format and format for performance test</td></tr><tr><td>3.</td><td>EMI EMC (Applicable for 20% of total quality)</td><td>A</td><td>A</td><td>A</td><td>AS Environmental Test</td></tr><tr><td>4.</td><td>ESS</td><td>A</td><td>A</td><td>A</td><td>AS Environmental Test</td></tr><tr><td>5.</td><td>Damp Heat</td><td>A</td><td>A</td><td>A</td><td>AS Environmental Test</td></tr><tr><td>6.</td><td>Acceleration</td><td>A</td><td>A</td><td>A</td><td>AS Environmental Test</td></tr><tr><td>7.</td><td>Shock</td><td>A</td><td>NA</td><td>A</td><td>AS Environmental Test</td></tr><tr><td>8.</td><td>Isolation Continuity &amp; Final functional Test</td><td>NA</td><td>NA</td><td>NA</td><td>As per initial/final Isolation checks and continuity checks, Initial/Final functional test format and format for performance test</td></tr></table>

# 13.11. QT MATRIX

<table><tr><td>SI.NO.</td><td>TEST</td><td>PREET</td><td>INSET</td><td>POET</td><td>Parameter monitoring</td></tr><tr><td rowspan="4">1.</td><td>CEMILAC</td><td colspan="3"></td><td rowspan="4">As per Screening test Format</td></tr><tr><td>High-Temperature stabilization bake</td><td>A</td><td>NA</td><td>A</td></tr><tr><td>Thermal Shock</td><td>A</td><td>NA</td><td>A</td></tr><tr><td>Burn In Test</td><td>A</td><td>A</td><td>A</td></tr><tr><td>2.</td><td>Isolation Continuity &amp; Initial functional Test</td><td>NA</td><td>NA</td><td>NA</td><td>As per initial/final Isolation checks and continuity checks, Initial/Final functional test format and format for performance test</td></tr><tr><td>3.</td><td>ESS</td><td>A</td><td>A</td><td>A</td><td>As Per Environmental Test</td></tr><tr><td>4.</td><td>EMI EMC</td><td>A</td><td>A</td><td>A</td><td>As Per Environmental Test</td></tr><tr><td>5.</td><td>High Temperature</td><td>A</td><td>A</td><td>A</td><td>As Per Environmental Test</td></tr><tr><td>6.</td><td>Low Temperature</td><td>A</td><td>A</td><td>A</td><td>As Per Environmental Test</td></tr><tr><td>7.</td><td>Acceleration</td><td>A</td><td>A</td><td>A</td><td>As Per Environmental Test</td></tr><tr><td>8.</td><td>Shock Test</td><td>A</td><td>NA</td><td>A</td><td>As Per Environmental Test</td></tr><tr><td>9.</td><td>Tropical Exposure</td><td>A</td><td>A</td><td>A</td><td>As Per Environmental Test (Inset on 7th day and 14th day)</td></tr><tr><td>10..</td><td>Isolation Continuity &amp; Final functional Test</td><td>NA</td><td>NA</td><td>NA</td><td>As per initial/final Isolation checks and continuity checks, Initial/Final functional test format and format for performance test</td></tr></table>

# 14. ENVIRONMENTAL TEST SPECIFICATION

# 14.1 Qualification Testing:

<table><tr><td rowspan="2">Sl.
No</td><td rowspan="2">Test</td><td>Test Specification</td><td rowspan="2">Remarks</td></tr><tr><td>Qualification Testing</td></tr><tr><td>1.</td><td>ESS</td><td>Pre-vibration:
Freq:20 Hz - 2000 Hz
20 Hz - 100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes
ThermalCycling
-30°Cfor60min.
+70°Cfor 60 min.
Rate of changeofTemp:10°C /min. No. ofCycles: 8
Post- vibration:
20 Hz - 2000 Hz
20 Hz - 100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes</td><td>PREET, INSET/ POET</td></tr><tr><td>2.</td><td>Low Temperature</td><td>-30 ± 3°C; 16 hrs.
Last 1 hr. Operation.</td><td>Test No 2 JSS 0256-01
PREET, INSET/ POET</td></tr><tr><td>3.</td><td>High Temperature</td><td>55 ± 3°C; 6 hrs.
65 ± 3°C; 4 hrs.
55 ± 3°C; 6 hrs. Last 1 hr. Operation.</td><td>Test No 1 JSS 0256-01
PREET, INSET/ POET</td></tr><tr><td>4.</td><td>Tropical Exposure</td><td>20 ± 2°C; 6 hrs.
Ramp Up to 45°C in 3 hrs.
45 ±2°C; 12 hrs.
Ramp Down to 20°C in 3 hrs.
RH &gt; 95%, No. of Cycles - 14</td><td>PREET, INSET during last 30 minutes (@40 ±2°C; RH ≥ 95%) followed by POET</td></tr><tr><td>5.</td><td>Acceleration</td><td>Long.: 75 g; 45 s
Lateral: 60 g; 45 s
6 Directions, 2 directions in each axis</td><td>Test No 16 JSS 0256-01
PREET, INSET/POET</td></tr><tr><td>6.</td><td>Shock</td><td>60g; 3 ms
3 shocks per axis (Lon. Δaxis)
3 Axes, 6 Directions.</td><td>Should be Based on shock responses measured in Static and HOT test(Nominal functionality will be Checked)</td></tr><tr><td>7.</td><td>EMI / EMC Test</td><td>RE102; CE 102; CS 101; CS 114; CS 115; CS 116; CS118; RS 103</td><td>MIL STD 461E
PREET, INSET/ POET</td></tr></table>

14.2 Acceptance Testing:   

<table><tr><td rowspan="2">Sl.
No</td><td rowspan="2">Test</td><td>Test Specification</td><td rowspan="2">Remarks</td></tr><tr><td>Acceptance Testing</td></tr><tr><td>1.</td><td>ESS</td><td>Pre-vibration:
Freq:20 Hz - 2000 Hz
20 Hz -100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes
ThermalCycling
-30°Cfor60min.
+70°Cfor 60 min.
Rate of changeofTemp:10°C /min. No.
ofCycles: 6
Post- vibration:
20 Hz - 2000 Hz
20 Hz - 100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes</td><td>PREET, INSET/ POET</td></tr><tr><td>2.</td><td>Damp Heat</td><td>40 ±2°C; RH ≥ 95% --8 hrs.</td><td>PREET, INSET during last 30 minutes (@40 ±2°C; RH ≥ 95%) followed by POET</td></tr><tr><td>3.</td><td>Acceleration</td><td>Long.: 50 g; 45 s
Lateral: 40 g; 45 s
6 Directions, 2 directions in each axis</td><td>Test No 16 JSS 0256-01
PREET, INSET/POET</td></tr><tr><td>4.</td><td>Shock</td><td>40 g; 3 ms
2 shocks per axis (Long. Axis)
3 Axes, 6 Directions.</td><td>Should be Based on shock responses measured in Static and HOT test
(Nominal functionality will be checked)</td></tr><tr><td>5.</td><td>EMI / EMC Test</td><td>RS 103; CS 115,ESD
(Batch size 1 in 20)</td><td>MIL STD 461E
PREET, INSET/ POET</td></tr></table>

# 15. SAFETY REQUIREMENTS

- The operator shall discharge himself by touching the conductive table top or by touching the ESD ground or by wearing the anti-static wrist strap, before touching the unit or PCB's.   
- Worktable and floor shall be covered with conductive mat with proper ESD grounding.   
- Transportation of ESD sensitive sub-assemblies/packages from one place to another place shall be made in static safe shielded bags/ containers only, which shall be grounded before removing the sub-assemblies/packages from the bags/containers.   
- Check the QC / Test reports.   
- Check the S1.No., Model No. and Nomenclature of the unit.   
- Check the orientation of all the connectors while mating them.   
- Before applying power to the unit check the polarities of power supply connecting terminals.   
- Before switching 'ON' the power supply to the unit check for proper voltage setting.   
- Check the current drawn of the unit.   
- Dust caps must be provided for all connectors of the unit in storage condition.

# 16. HANDLING

# 16.1. Handling of Static Charge Sensitive Devices

Static charge sensitive devices are liable for damage due to improper handling. The most common damage is the gate rupture caused by static discharges. This can occur when a device is picked up by its case and the handler's body capacitance is discharged to ground through the series arrangement of the bulk to channel to gate capacitance to the MOS device. The precautions to be followed to prevent this damage are the following:

- All static charge sensitive devices shall be stored in anti-static conductive bags and before or after assembly they shall be kept in conductive trays only. Use of polythene plastic container is forbidden.   
- All Assembly and Test cables for static charge sensitive devices shall be covered with stainless steel sheets and the sheets shall be properly grounded.   
- All entrances to work areas shall have grounding plates on the door and / or floor, which must be contacted by people entering the area.   
- The operator shall wear conductive shoes so that the body charges are grounded.   
- Cotton gloves shall be worn while handling the parts. Nylon or rubber gloves shall not be used.   
- The humidity in the work area shall be controlled to not less than $35\%$ to help reduced generation of static voltages.   
Static charge sensitive axial lead devices shall be stored in a conductive form.   
- All equipment used in the assembly area shall be thoroughly grounded. Soldering irons must have grounded tips. Grounding must also be provided for solder pots, reflow soldering or wave soldering machines etc.

- While soldering CMOS IC's it is advisable to place grounding clip across the connector fingers to ground all leads and lines on the board.   
- Carpets should not be used in work areas.   
Devices should never be inserted or removed from a circuit with the power 'ON'.   
- All leads of the device should be shorted together either by metal shorting springs or by conductive foam. This is not required in devices where diode gate protection is built into the device.   
- The operator shall discharge himself by touching the conductive tabletop before touching a device.

# 16.2. Handling during Assembly

The relevant portions of the handling procedures listed above are applicable here also. In case where spacers are not provided, the PC card shall be kept over a sponge or rubber mat until wiring is completed. Very often, the PC assembly work will be completed only after a week or two of its initiation. After a day's work, the solder joints and adjacent areas should be cleaned with approved solvent, dried and the partly assembled PCB should be stored in a self-sealing polythene bag preferably with a bag of Silica gel. However, for onboard cards wired fully or partly they shall be kept only in desiccators.

- Operators/Inspectors shall wear overcoats made of cotton only.   
- Wearing of gloves during soldering is desirable. However, wearing of gloves is mandatory for onboard cards and cards with gold plating. This will avoid contamination of the board and solder joints with finger grease. The PCB assembly shall not be lifted by holding the components. It shall be done by holding on the PCB edges only.   
- Connectors and the wire bunch shall not be permitted to hang on its own weight. This will induce stress on the wires and solder joints. Approved tools only shall be used for lead bending and component mounting.   
- The pre-tinned components shall not be allowed to lie open for extended periods of time. Airtight plastic containers can be used for keeping them.   
- Soldering or repair work shall not be carried out in operation areas such as control room and ground stations. They shall be carried out in a separate area earmarked for such maintenance work.   
- operators shall avoid taking food or beverages or smoking in the work area.   
- Wet cloths shall be removed before entering the work area.   
- operators / Inspectors shall wear leather shoes during assembly and handling of packages. They shall not wear chapels.

# 16.3. Handling of Packages

The connectors shall be protected against dust particles by closing them with dust covers. Packages shall be kept in polythene covers during storage and transportation. It shall not come into abrasion against any hard surface. Abrasion will damage the surface finish of the package. Stacking of packages weighing more than $250\mathrm{g}$ is not permitted. Packages shall always be kept with its base side resting on ground so that connector side is not stressed. Machining operations such as drilling, milling, filling etc. shall not be carried out in electronic operations / assembly area. Packages shall not be hit against any surface or fall down. No heavy articles shall be kept

on the package. However if the package has suffered physical damages due to fall etc. the matter shall be reported to concerned QA agency for necessary action.

# 16.4. Handling during Conformal Coating

Conformal coating and potting are applicable only for onboard packages. However, for ground systems required to operate in hostile environment PC assembly may have appropriate protective coatings. Conformal coating shall be carried out in a separate area with appropriate exhaust facility. Conformal coating material shall be stored in proper environment or in a refrigerator as per manufacturer's instructions and also the expiry date shall be clearly marked on the containers. Care shall be taken to check the expiry date before usage of the material and shall be promptly removed after expiry date. Conformal coating is usually done at card level. The general handling procedures followed for PC assemblies are applicable here also. Some parts like connectors have to be protected during conformal coating. If the material goes inside the connectors, contact problems will arise; connector covers / caps may be used to close the connectors during conformal coating.

During conformal coating packages shall be handled with gloves. Cleaning before conformal coating is done in isopropyl alcohol using brushes. Some components are likely to get stressed if improper cleaning practices are adopted. Brushing shall be done parallel to the lengthwise direction of the component. Minimum pressure shall be applied on the brush.

Hot air drying is employed for drying after cleaning. It shall be ensured that the hot air temperature never exceeds 70oC. Pre-baking or post baking if employed, shall also be done at the same temperature.

The conformal coating room shall be free from dust and excessive moisture. It is preferable to keep the coated cards in a dust free glass enclosure until curing is completed. Conformal-coated cards shall be hanged to facilitate drying.

# 17. STORAGE

# 17.1. Storage Control

Storage area shall have three clearly demarcated areas viz.

1. Mechanical area for storing boxes, screws, chassis etc.   
2. Chemical area for storing cleaning solvents flux, potting compound etc.   
3. Electronic area for storing electronic parts.   
4. Special materials such as artworks, PCB films, laminates, and prepares shall also be stored properly in a separate area.

These areas shall be separately partitioned and there shall be separate access to these areas during storage and handling. Storage arrangements shall provide and control secure storage areas for items that are not in work. Storage areas shall be clearly marked "Space Hardware", have adequate areas for receiving, inventory and issue of stored items and be provided with documented operation procedures for the control and implementation of all storage functions. Storage shall be carried out in two places namely transit stores and bonded stores.

# 17.2. Transit Stores

Parts and materials as received from the manufacturer shall be stored in transit stores. Initial checks such as packing integrity, expiry date in case of limited life material etc., shall be carried out. The transit stores required shall be air-conditioned and with humidity controlled at

$55 + 5\%$ as per requirements at least during working hours. Manufacturer's instructions shall be complied with during unpacking of parts and materials.

# 18. PACKAGING

# 18.1. General

Packing material shall not add any hazard to the item i.e. electrostatic discharge and shall not contaminate any surface, optical items, mechanisms, liquid or gaseous supply lines that will not be processed or cleared before integration into a complete space system. only space qualified adhesive tapes shall be used on or within the immediate wrappings. PVC or other highly authorized polymers shall not be employed.

All electrical connections, coaxial connector's fluid or gaseous unions and mechanical interface provisions shall be protected with firmly secured closures or other devices of suitable material and in clean condition.

Inspections shall be performed as necessary to ensure that items meet the specified packaging requirements and that no damage has occurred and quality conformance inspection / tests are performed as a part of the acceptance of the packing items.

# 18.2. Packing for Transportation

Packages taken out for testing or site trials shall be securely packed following the procedures meant for a final finished product. This shall be strictly adhered to however, loose components, spares etc., and shall be taken securely and safely in appropriate manner.

- Inner protection: Items, which require a high degree of protection from water vapour, shall include an active desiccant within the water proof/vapour proof container.   
- Mechanical Protection: The inner container of package containing space hardware shall be cushioned to a degree determined by the induced environment. The outer container shall afford mechanical protection for the item and support for any cushioning required. Handleless and tie down prints shall be incorporated at suitable points. Provision shall be made for enclosing the documents at an easily visible location.

# 19. TRANSPORTATION

Only authorized personnel shall carry, receive and handle the packages before and during transportation with utmost care. Wherever possible an authorized person shall accompany the item during transportation.

All relevant and necessary precautions shall be taken during transportation especially for transport of critical items. Transportation containers that incorporate in their design provisions for the attenuation of mechanical and environmental elements to a level that the item can withstand without damage shall be used.

The design of specially built transport containers shall permit safe packing and unpacking and shall be such as to ensure that either the containers or the equipment they contain shall not suffer functional damage, due to handling or static electrical discharge. Items shall be transported only by approved transport agencies.

The containers and any auxiliary equipment shall have environmental controls, shock-absorbing, monitoring and warning features required to ensure that transport methods and routes are accomplished without stress, damage, contamination, corrosion or change in performance of the transport item. I.e. the requirements shall be avoided whenever possible but in any case shall be identified during the design phase of the project concerned.

# 20. PROCESS INSPECTION REPORTS

ATL/QA/PCBIR/04

ISSUE NO.: 01

DATE: 22-08-2007

No.:

# PCB INSPECTION REPORT

FABRICATOR: TITLE: PCB NO:

USER: QCA NO: DATE:

SUPPLIER INSPECTION REPORT REFERENCE NO.:

TYPE OF PCB: SOLDER COATED / SOLDER MASK / GOLD PLAT

DATE CODE:

<table><tr><td>DESCRIPTION</td><td>SPECIFICATION</td><td>OBSERVATION</td></tr><tr><td>BOARD QUALITY</td><td></td><td></td></tr><tr><td>A. Material</td><td>G10/ G11/ FR4/ FR5</td><td></td></tr><tr><td>B. Board thickness</td><td>1.58 □ 0.13 mm / 3.2 □ 10% / 2.4 □ 10%.</td><td></td></tr><tr><td>C. Foil Thickness</td><td>35 □ 10 Microns</td><td></td></tr><tr><td>D. Board warpage</td><td>&lt;1.0% of the greatest dimension</td><td></td></tr><tr><td>E. Edge Trimming</td><td>Smooth finishing, Hallowing/ Chipping &lt;2.5 mm</td><td></td></tr><tr><td>F. Measling</td><td>&lt;10 Sq. mm Continuous, should not more than 25% conductor/ Pad</td><td></td></tr><tr><td>G. Delamination</td><td>Nil</td><td></td></tr><tr><td>PROTECTIVE COATIN/ PLATING</td><td></td><td></td></tr><tr><td>A. Thickness</td><td>Solder/ Nickel/ Gold</td><td></td></tr><tr><td>*a. Solder Coating</td><td>Fused/ Non Fused</td><td></td></tr><tr><td>*b. Solder plated</td><td>&gt;4 microns; &gt;1 micron at Knee point</td><td></td></tr><tr><td>*c. Gold</td><td>&gt;8 microns; &gt;1 micron at Knee point</td><td></td></tr><tr><td></td><td>2 to 6 microns Ni and 0.5 to 2 microns Au</td><td></td></tr><tr><td></td><td>Absent over Solder plates</td><td></td></tr><tr><td>B. Dewetting</td><td>Not present</td><td></td></tr><tr><td>C. Granular appearance</td><td>As per master pattern</td><td></td></tr><tr><td>CONDUCTOR</td><td>0.25 mm (min.)</td><td></td></tr><tr><td>A. Width</td><td>0.25 mm (min.)</td><td></td></tr><tr><td>B. Spacing</td><td>&lt; 20% of track width; &lt; 0.1 mm shall safety minimum width/ Spacing</td><td></td></tr><tr><td>C. Nick, Cut, Projection</td><td>Not present</td><td></td></tr><tr><td></td><td>&lt; Copper thickness</td><td></td></tr><tr><td>D. Delamination</td><td>Not present</td><td></td></tr><tr><td>E. Under Cut/ Over Hang</td><td>PTH/ NPTH</td><td></td></tr><tr><td>F. Cu visibility</td><td>As per master pattern</td><td></td></tr><tr><td>PAD/ HOLE</td><td>&gt; 0.15 mm</td><td></td></tr><tr><td></td><td>&gt; 0.25 mm up to 0.8 mm hole</td><td></td></tr><tr><td>A. Location and diameter</td><td>&gt; 0.38 mm above 0.8 mm hole</td><td></td></tr><tr><td>B. Annular Ring a. PTH</td><td>Min. annular ring to be maintained</td><td></td></tr><tr><td></td><td>&gt; 25 microns</td><td></td></tr><tr><td>C. Pin holes on Pad</td><td>&gt;10% of PTH, No circumferential separation, Nil at interface</td><td></td></tr><tr><td>D. Barrel Copper</td><td>No opens and shots</td><td></td></tr><tr><td>E. Voids at PTH</td><td></td><td></td></tr><tr><td>F. BBT Check third party</td><td></td><td></td></tr></table>

Visual Inspection : Accepted/ Rejected Q.C Inspector ATL

Micro Sectioning Report : Accepted/ Rejected

Conclusion : Accepted/ Rejected\* for FM/Ground Us In-Charge Q.A

TL/QA/BK/04

ISSUE NO: 01

DATE:

No.:

# BAKING INSPECTION REPORT

PROJECT :

MODEL : CARD NAME :

PACKAGE No.:

PCB No. ：

Baking : Bare PCB

<table><tr><td>Sl.No.</td><td>Pàrameters</td><td>Specification</td><td>QC observations</td></tr><tr><td>1</td><td>Temperature and Duration of baking</td><td>110°C for 2 hours/105°C for 8 hours/125 °C 4 hours</td><td></td></tr><tr><td>2</td><td>Discoloration of PCB laminate</td><td>Not Acceptable</td><td></td></tr><tr><td>3</td><td>Pad/ Pattern damage / Lifting</td><td>Not Acceptable</td><td></td></tr><tr><td>4</td><td>Wrap/ Twist</td><td>Should be less than 1% of maximum dimension.</td><td></td></tr><tr><td>5</td><td>Other defects, if any</td><td>Shall not affect quality and reliability.</td><td></td></tr></table>

Remarks, if any:

Baking of the PCB is accepted/ Rejected and cleared for next process.

Signature of the On-Line QC Inspector

Name:

Date:

Baking : Before Conformal Coating (Populated PCB)

<table><tr><td>Sl.No.</td><td>Parameters</td><td>Specification</td><td>QC observations</td></tr><tr><td>1</td><td>Temperature and Duration of Baking</td><td>65°C for 4 hour/70°C for 1 hour</td><td></td></tr><tr><td>2</td><td>Discoloration of PCB laminate</td><td>Not Acceptable</td><td></td></tr><tr><td>3</td><td>Pad/ Pattern damage / Lifting</td><td>Not Acceptable</td><td></td></tr><tr><td>4</td><td>Wrap/ Twist</td><td>Should be less than 1% of maximum dimension.</td><td></td></tr><tr><td>5</td><td>Other defects, if any</td><td>Shall not affect quality and reliability.</td><td></td></tr></table>

Remarks, if any:

Cleaning of the PCB is accepted/ Rejected and cleared for next process.

Signature of the On-Line QC Inspector

Name:

Date:

ATL/QA/SASIR/04

ISSUE NO.: 01

No.:

DATE: 19-04-2016

# ANANTH TECHNOLOGIES PVT LTD. HYDERABAD

# SUB-ASSEMBLY SOLDERING INSPECTION REPORT

PCB No.:

Date:

<table><tr><td rowspan="2">Process</td><td rowspan="2">Date</td><td colspan="2">Rework</td><td rowspan="2">Name of Inspector</td><td rowspan="2">Status R/W 1</td><td rowspan="2">Status R/W 2</td><td rowspan="2">Remarks</td></tr><tr><td>DEF</td><td>QTY</td></tr><tr><td>Solder joints on PCB (PTH and NPTH)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Solder joints on relays, turrets, cores T/F etc.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Batch No: 2 Solder joints on PCB</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Solder joints on relays etc.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="8">Rework Percentage :</td></tr></table>

CHECK LIST DEFECT CODE:   

<table><tr><td>1. De-wetting</td><td>2. Non-wetting</td><td>3. Improper filet</td><td>4. Delaminating</td><td>5. Epoxy damage</td><td>6. Disturbed joint</td></tr><tr><td>7. Icicling</td><td>8. Cold joint</td><td>9. Over heated joint</td><td>10. Demarcation</td><td>11. Stress line</td><td>12. Fracture Joint</td></tr><tr><td>13. Bridging</td><td>14. Peaking</td><td>15. Solder splator</td><td>16. Wicking</td><td>17. Parts damage</td><td>18. Pin holes</td></tr><tr><td>19. Blow holes</td><td>20. Pad/ Track damage</td><td>21. Measling</td><td>22. Flux residue</td><td>23. Insufficient Solder</td><td>24. Excess Solder</td></tr></table>

BATCH 1: ACCEPTED/ REJECTED

BATCH 2: ACCEPTED/REJECTED

ASSY. COMPLETED/ INCOMPLETED

ASSY. COMPLETED/ INCOMPLETED

Sub-assembly accepted/ not accepted for EM/ FM/ QM

Inspected By:

Approved By:

SIGN

DATE

SIGN

DATE

ATL/QA/SAIR/03

ISSUE NO.: 01

No.:

DATE: 13-04-2005

# ANANTH TECHNOLOGIES PVT LTD. HYDERABAD

# SUB-ASSEMBLY INSPECTION REPORT

Sub-Assembly QCA No. PCB No.

Project Package Model: EM/QM/FM

# EXECUTIVE SUMMARY

1. COMPONENT DEVIATIONS   
2. WORKMANSHIP DEVIATIONS   
3. WAIVER DECISIONS   
4.CHANGES FROM CCD/QTAT

CLEARANCE STATUS : ACCEPTED/NOT ACCEPTED FOR EM/QM/FM

NAME OF THE INSPECTOR SIGNATURE DATE

PROCESS TRVELLER   

<table><tr><td>Date</td><td>Operation</td><td>Done By
Name &amp; Divn.</td><td>Remarks</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></table>

# ANANTH TECHNOLOGIES PVT LTD. HYDERABAD

# COMPONENT MOUNTING INSPECTION REPORT

Date:PCB No.:

<table><tr><td colspan="2">Description of Component</td><td rowspan="2">Corrective action</td><td rowspan="2">Q.C Remarks</td><td rowspan="2">Name of the Inspector</td><td rowspan="2">CHECK LIST</td></tr><tr><td>CKT-Identity</td><td>Def. code</td></tr><tr><td>Batch No: 1</td><td></td><td></td><td></td><td></td><td rowspan="14">1. PCB size and mounting hole2. Component count3. Conformance with component position diagram4. Non-standard mounting5. Parts damage6. Wrong polarity7. Unscreened part8. Misalignment of parts with solder pads9. Parts tilt10. Sleeving/ clearance from tracks for metal bodied parts11. Clearance from card edge/ chassis/ wire bunch12. Improper lead forming13. Insufficient stress relief14. Excess lead length15. Lead clearance for chassis mounting components16. Proper mounting of heavy/ special components17. Style and size18. Polarities / Pin Nos.19. Misalignment terminal with solder pads20. Clearance of components metallisation from other pads and patterns</td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="6"></td></tr><tr><td colspan="6">Total No. of components as per CCD / BOM :</td></tr><tr><td colspan="6">Total No. of components</td></tr><tr><td colspan="6">Mounted in batch No.: 1</td></tr><tr><td colspan="6">Balance Quantity</td></tr><tr><td colspan="6">Total No. of components</td></tr><tr><td colspan="6">Mounted in batch No.: 2</td></tr></table>

Total No. of components mounted on the PCB:

Component value and position check w.r.t. CCD/QTAT:

Comments:

Accepted/ not accepted for EM/ FM/ QM

Name of the inspector:

Sign.:

Date:

# ANANTH TECHNOLOGIES PVT LTD.

# HYDERABAD

# POTTING & CONFORMAL COATING INSPECTION REPORT

Date:

Package & sub-Assembly:

PCB No:

Pre-coating Inspection:   

<table><tr><td>Parameter</td><td>Status OK/ Not OK</td><td>QC Comments</td><td>Sign.</td><td>Check list/ Def. Code</td></tr><tr><td>Verification of Inspection report</td><td></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2">1. Soldering insp. /RW insp. Acceptance.
2. Torque on fasteners
3. Handling defects
4. Components screening date validity
5. Filleting (Potting) identification</td></tr><tr><td>Physical Inspection of Sub-Assembly Package</td><td></td></tr></table>

Materials:   

<table><tr><td>Process</td><td>Material issued</td><td>Batch No/ Exp. date</td></tr><tr><td>a. Conformal coating</td><td></td><td></td></tr><tr><td>b. Filleting (Potting)</td><td></td><td></td></tr></table>

Post Coating Inspection:

COATING DONE BY: DATE:

<table><tr><td>Process</td><td>Status ACC/RW</td><td>Def.Code</td><td>Sign</td><td>RW-1</td><td>Sign</td><td>Check list/ Defects</td></tr><tr><td>Component Filling (Potting)</td><td></td><td></td><td></td><td></td><td></td><td rowspan="3">1. Masking not as per Drawing
2. Curing not OK
3. Presence of contamination
4. Parts discoloration
5. Poor adhesion
6. Coating not uniform
7. Air bubbles
8. Pin holes
9. Coating thickness High/ Low</td></tr><tr><td>Print side Conformal coating</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Component side Conformal coating</td><td></td><td></td><td></td><td></td><td></td></tr></table>

Accepted/ not accepted

SIGN:

(ON LINE INSPECTOR)

NAME:

DATE:

ATL/QA/PIIR/03

ISSUE NO.: 01

No.:

DATE: 13-04-2005

# ANANTH TECHNOLOGIES PVT LTD.

# HYDERABAD

# PACKAGE INTEGRATION INSPECTION REPORT/HARNESSING

# INSPECTIONREPORT

PACKAGE NAME:

UNIT NO:

MODEL:

PROJECT:

<table><tr><td colspan="2">Description</td><td>Qty.</td><td>Status
ACC/RW</td><td>DEF.
Code</td><td>QC Sign. &amp; Date /
Remarks</td><td>CHECH LIST</td></tr><tr><td colspan="2">I.Wires Preparation And Tinning</td><td></td><td></td><td></td><td></td><td rowspan="16">1. Strand Separation
2. Burnt Insulation
3. Wicking
4. Improper insulation Clearance
5. Less stress Relief
6. Inadequate bunching
7. Improper Soldering
8. Improper crimping
9. Wires/ Bunches interfering with components/ chassis
10. Connector Pin damage/ not locked/ Missing
11. Improper Clearance between assemblies &amp; chassis/ Components
12. Improper torque of mounting screws
13. Improper routing of wires/ bunches</td></tr><tr><td colspan="2">II.CHASSIS 
MOUNTED PARTS 
a) Tinning 
b)Mounting 
c) Soldering</td><td></td><td></td><td></td><td></td></tr><tr><td colspan="6">III. INTER CONNECTIONS BETWEEN SUB-ASSEMBLIES AND 
CONNECTORS</td></tr><tr><td>No.</td><td>Sub-Assy/ 
Connector 
Identity</td><td>No. Of 
Solder/ 
Crimp 
Joints</td><td>Status 
ACC/RW</td><td>Def.
Code</td><td>QC Sign. &amp; Date /Remarks</td></tr><tr><td>1</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td></td><td></td><td></td><td></td><td></td></tr></table>

Wire harnessing, routing, anchoring checked. Interconnections continuity checked as per integration check list given in CCD/QTAT.

SIGN :

SIGN:

NAME:

NAME:

DATE:

DATE:

(I/C PRODUCTION)

(ONLINE QC)

ATL/QA/CLPIR/01

ISSUE NO:01

# ANANTH TECHNOLOGIES PVT LTD

# HYDERABAD

# CARD LEVEL PHYSICAL INSPECTION REPORT

# PROJECT:

# DATE:

# CARD NAME:

<table><tr><td>SL.No</td><td>Parameters</td><td>Internal QC Observation</td><td>DR&amp;QA Observation</td><td>Remarks</td></tr><tr><td>1</td><td>Ensure that all the required components w.r.t QAP and QT-AT document</td><td></td><td></td><td></td></tr><tr><td>2</td><td>Pad/Pattern/Laminate damage</td><td></td><td></td><td></td></tr><tr><td>3</td><td>Soldering joints</td><td></td><td></td><td></td></tr><tr><td>4</td><td>Component body damage</td><td></td><td></td><td></td></tr><tr><td>5</td><td>Other defects if any</td><td></td><td></td><td></td></tr><tr><td>6</td><td>Verification conformance certificates</td><td></td><td></td><td></td></tr></table>

ATL (QC)

DR&QA

SIGN:

SIGN:

DATE:

DATE:

NAME:

NAME:

DESIGN:

DESIGN:

ATL/QA/SATIR/03

ISSUE NO.: 01

DATE: 13-04-2005

No.:

# ANANTH TECHNOLOGIES PVT LTD. HYDERABAD

# SUB-ASSEMBLY TORQUE INSPECTION REPORT

Date:

PCB No.:

<table><tr><td colspan="2">Location</td><td rowspan="2">Screw Size</td><td rowspan="2">Qty.</td><td rowspan="2">Specified Torque Level</td><td rowspan="2">Sign./Date</td><td rowspan="2">Check List for Mechanical</td><td></td></tr><tr><td>From</td><td>To</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan="23">➢Less Spacing between Tracks and washers
➢Not as per Drawing
➢Insufficient Screw Length
➢Minimum clearance between fasteners and components
➢Spacing between parts and PCB when card is Stacked
➢Earth tags mounting to Chassis (for insuring proper electrical contact)
➢Wire jamming or crushing due to fasteners
➢Connectors mating</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td>➢Connectors mating</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>Qty.</td><td>Specified Torque Level</td><td>Sign./Date</td><td>Check List for Mechanical</td><td></td></tr></table>

Tools Used:

Calibration Due Date:

Comments:

Accepted/Not Accepted for EM/QM/FM

Name of the Inspector:

Sign.

Date:

# ANANTH TECHNOLOGIES PVT LIMITED

# HYDERABAD

TEST REPORT-1

BARE PCB'S INSPECTION

DATE:

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td colspan="2">Unit Sl. No.</td><td colspan="2"></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td colspan="2">Work Centre</td><td colspan="2"></td></tr><tr><td>Unit Manufacturer</td><td colspan="5"></td></tr><tr><td>Supply Order No.</td><td colspan="5"></td></tr><tr><td>Project Name</td><td colspan="5"></td></tr><tr><td>Reference Document</td><td colspan="5">RCI/DOFI/CPSCP V2.2/ATP/01</td></tr><tr><td>Test Description</td><td colspan="5">Unit Configuration</td></tr><tr><td>Test Location</td><td colspan="2"></td><td colspan="2">Date</td><td></td></tr><tr><td>Time</td><td colspan="5"></td></tr></table>

<table><tr><td>S.NO</td><td>NAME OF THE PCB</td><td>PCB NO.</td><td>QTY</td><td>BATCH NO.</td><td>REMARKS</td></tr><tr><td>1.</td><td>CPSCP BOARD</td><td></td><td></td><td></td><td></td></tr></table>

Visual Inspection: The above mentioned Bare PCB's are inspected visually and found ok.

(CLEARED/NOT CLEARED)

MANUFACTURER

DOFI/RCI

DR&QA

# ANANTH TECHNOLOGIES PVT LIMITED

# HYDERABAD

# TEST REPORT-2

# COMPONENTS INSPECTION REPORT

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td colspan="2">Unit Sl. No.</td><td colspan="2"></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td colspan="2">Work Centre</td><td colspan="2"></td></tr><tr><td>Unit Manufacturer</td><td colspan="5"></td></tr><tr><td>Supply Order No.</td><td colspan="5"></td></tr><tr><td>Project Name</td><td colspan="5"></td></tr><tr><td>Reference Document</td><td colspan="5">RCI/DOFI/CPSCP V2.2/ATP/01</td></tr><tr><td>Test Description</td><td colspan="5">Unit Configuration</td></tr><tr><td>Test Location</td><td colspan="2"></td><td colspan="2">Date</td><td></td></tr><tr><td>Time</td><td colspan="5"></td></tr></table>

<table><tr><td>SI.No.</td><td>Description</td><td>Remark</td></tr><tr><td>1.</td><td>Check the Part number of the component whether it is matching with the BOM</td><td></td></tr><tr><td>2.</td><td>Check quantity received is as per the required units.</td><td></td></tr><tr><td>3.</td><td>Check for COC/Test reports availability.</td><td></td></tr></table>

All components as per the above check list and BOM, Visual Inspection was carried out and cleared for further process

# (CLEARED/NOT CLEARED)

MANUFACTURER

DOFI/RCI

DR&QA

# ANANTH TECHNOLOGIES PVT LIMITED

# HYDERABAD

# TEST REPORT-3

# POPULATED PCB'S INSPECTION

DATE:   

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td colspan="2">Unit Sl. No.</td><td colspan="2"></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td colspan="2">Work Centre</td><td colspan="2"></td></tr><tr><td>Unit Manufacturer</td><td colspan="5"></td></tr><tr><td>Supply Order No.</td><td colspan="5"></td></tr><tr><td>Project Name</td><td colspan="5"></td></tr><tr><td>Reference Document</td><td colspan="5">RCI/DOFI/CPSCP V2.2/ATP/01</td></tr><tr><td>Test Description</td><td colspan="5">Unit Configuration</td></tr><tr><td>Test Location</td><td colspan="2"></td><td colspan="2">Date</td><td></td></tr><tr><td>Time</td><td colspan="5"></td></tr></table>

<table><tr><td>S.NO</td><td>NAME OF THE PCB</td><td>PCB NO.</td><td>QTY</td><td>BATCH NO.</td><td>REMARKS</td></tr><tr><td>1.</td><td>CPSCP BOARD</td><td></td><td></td><td></td><td></td></tr></table>

Visual Inspection: The above mentioned Bare PCB's are visually inspected and found ok.

# (CLEARED/NOT CLEARED)

MANUFACTURER

DOFI/RCI

DR&QA

# ANANTH TECHNOLOGIES PVT LIMITED

# HYDERABAD

# TEST REPORT-4

# UNIT CONFIGURATION

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td>Unit Sl. No.</td><td></td><td></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td>Work Centre</td><td></td><td></td></tr><tr><td>Unit Manufacturer</td><td colspan="4"></td></tr><tr><td>Supply Order No.</td><td colspan="4"></td></tr><tr><td>Project Name</td><td colspan="4"></td></tr><tr><td>Reference Document</td><td colspan="4">RCI/DOFI/CPSCP V2.2/ATP/01</td></tr><tr><td>Test Description</td><td colspan="4">Unit Configuration</td></tr><tr><td>Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Time</td><td colspan="4"></td></tr></table>

<table><tr><td>Sl. No</td><td>Description</td><td>PCB Sl. No</td><td>Remarks</td></tr><tr><td>1</td><td>Power card</td><td></td><td></td></tr><tr><td>2</td><td>SCP Card</td><td></td><td></td></tr></table>

# UNIT CLEARED / NOT CLEARED FOR FURTHER PROCESS

MANUFACTURER

DOFI/RCI

DR&QA

# ANANTH TECHNOLOGIES PVT LIMITED

# HYDERABAD

# TEST REPORT-5

# POTTING AND CONFORMAL COATING INSPECTION

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td colspan="2">Unit Sl. No.</td><td colspan="2"></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td colspan="2">Work Centre</td><td colspan="2"></td></tr><tr><td>Unit Manufacturer</td><td colspan="5"></td></tr><tr><td>Supply Order No.</td><td colspan="5"></td></tr><tr><td>Project Name</td><td colspan="5"></td></tr><tr><td>Reference Document</td><td colspan="5">RCI/DOFI/CPSCP V2.2/ATP/01</td></tr><tr><td>Test Description</td><td colspan="5">Unit Configuration</td></tr><tr><td>Test Location</td><td colspan="2"></td><td colspan="2">Date</td><td></td></tr><tr><td>Time</td><td colspan="5"></td></tr></table>

<table><tr><td>S.NO</td><td>NAME OF THE PCB</td><td>PCB NO.</td><td>QTY</td><td>BATCH NO.</td><td>REMARKS</td></tr><tr><td>1</td><td>CPSCP BOARD</td><td>.</td><td></td><td></td><td>.</td></tr></table>

Visual Inspection: The above mentioned Bare PCB's are inspected visually and found ok.

# (CLEARED/NOT CLEARED)

MANUFACTURER

DOFI/RCI

DR&QA

# 20.1 Internal Wiring Details

# Top Layer

![](images/9d6f045bd05550eea6930b1450c2867428bc27f4901aeed3bb4c45ffd7dd2aac.jpg)

# Bottom Layer

![](images/758da4a461984395d8c159eedb0c7d6d510f84de163d5e957d191f0af55c6d8a.jpg)

# Appendix A

# Test Reports Unit Level

Test Setup Details   

<table><tr><td>Unit Name</td><td colspan="3">CPSCP_V2.2</td><td colspan="2">Unit Sl. No.</td><td colspan="2"></td></tr><tr><td>Model No.</td><td colspan="3">CPSCP_SMA_24.2</td><td colspan="2">Work Centre</td><td colspan="2"></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="6"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="6"></td></tr><tr><td colspan="2">Project Name</td><td colspan="6"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="6"></td></tr><tr><td colspan="2">Test Description</td><td colspan="6">QT/AT Testing</td></tr><tr><td colspan="2">Test Location</td><td colspan="3"></td><td colspan="2">Date</td><td></td></tr><tr><td colspan="3">Time</td><td colspan="5"></td></tr></table>

<table><tr><td>Date: 
S. No.</td><td>Test Instrument 
Title</td><td>Make</td><td>Model No</td><td>Serial No.</td><td>Calibration 
Date 
Done Due on</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-1   
CPSCP Connector P1:   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/ CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="3">IR checks and continuity checks (initial/final functional)</td></tr><tr><td colspan="2">Test Location</td><td></td><td>Date</td><td></td></tr></table>

<table><tr><td colspan="6">Isolation between Pin to Chassis</td></tr><tr><td>Connector P1 Pin No</td><td>Specified</td><td>Observed</td><td>Connector P1 Pin No</td><td>Specified</td><td>Observed</td></tr><tr><td>1.</td><td>&gt;20 M Ohm</td><td></td><td>27.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>2.</td><td>&gt;20 M Ohm</td><td></td><td>28.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>3.</td><td>&gt;20 M Ohm</td><td></td><td>29.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>4.</td><td>&gt;20 M Ohm</td><td></td><td>30.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>5.</td><td>&gt;20 M Ohm</td><td></td><td>31.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>6.</td><td>&gt;20 M Ohm</td><td></td><td>32.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>7.</td><td>&gt;20 M Ohm</td><td></td><td>33.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>8.</td><td>&gt;20 M Ohm</td><td></td><td>34.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>9.</td><td>&gt;20 M Ohm</td><td></td><td>35.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>10.</td><td>&gt;20 M Ohm</td><td></td><td>36.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>11.</td><td>&gt;20 M Ohm</td><td></td><td>37.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>12.</td><td>&gt;20 M Ohm</td><td></td><td>38.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>13.</td><td>&gt;20 M Ohm</td><td></td><td>39.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>14.</td><td>&gt;20 M Ohm</td><td></td><td>40.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>15.</td><td>&gt;20 M Ohm</td><td></td><td>41.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>16.</td><td>&gt;20 M Ohm</td><td></td><td>42.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>17.</td><td>&gt;20 M Ohm</td><td></td><td>43.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>18.</td><td>&gt;20 M Ohm</td><td></td><td>44.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>19.</td><td>&gt;20 M Ohm</td><td></td><td>45.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>20.</td><td>&gt;20 M Ohm</td><td></td><td>46.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>21.</td><td>&gt;20 M Ohm</td><td></td><td>47.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>22.</td><td>&gt;20 M Ohm</td><td></td><td>48.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>23.</td><td>&gt;20 M Ohm</td><td></td><td>49.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>24.</td><td>&gt;20 M Ohm</td><td></td><td>50.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>25.</td><td>&gt;20 M Ohm</td><td></td><td>51.</td><td>&gt;20 M Ohm</td><td></td></tr><tr><td>26.</td><td>&gt;20 M Ohm</td><td></td><td></td><td></td><td></td></tr></table>

# Continuity Checks (Pin to Pin):

CPSCP Connector P1:   

<table><tr><td rowspan="2">Pin No&#x27;s of P1 (CPSCP Connector)</td><td colspan="2">Continuity between Pin to Pin</td></tr><tr><td>Specified</td><td>Observed</td></tr><tr><td>J2.1-J2.2</td><td>Short</td><td></td></tr><tr><td>J2.3-J2.4</td><td>Short</td><td></td></tr><tr><td>J2.7-J2.8</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.8-J2.14</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.14-J2.15</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.15-J2.18</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.18-J2.22</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.22-J2.26</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.26-J2.37</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.37-J2.39</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.39-J2.40</td><td>&lt;2 Ohm</td><td></td></tr><tr><td>J2.40-J2.47</td><td>&lt;2 Ohm</td><td></td></tr></table>

Acceptance Criteria: Continuity between Pin to pin within the expected value.

# Remarks:

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-2   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="3">Power Consumption Checks (initial/final functional checks)</td></tr><tr><td colspan="2">Test Location</td><td></td><td>Date</td><td></td></tr></table>

<table><tr><td>Sr.
No.</td><td>Supply Voltage (V)</td><td>Polarity</td><td>Expected 
Current(A)</td><td>Measured 
Current (A)</td><td>Remark</td><td>PASS/FAIL</td></tr><tr><td>1.</td><td>5</td><td>Normal</td><td>0.30±0.04 A</td><td></td><td>Current without 
sensor</td><td></td></tr></table>

<table><tr><td rowspan="2">S.
No.</td><td rowspan="2">Channel
Specify</td><td rowspan="2">Input to
be given</td><td colspan="3">Expected Value</td><td>Reading on
Application</td><td rowspan="2">Result
Pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>5V</td></tr><tr><td>1</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td></tr><tr><td>2</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td></tr><tr><td>3</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td></tr><tr><td>4</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td></tr><tr><td>5</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td></tr><tr><td>6</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td></tr><tr><td>7</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td></tr><tr><td>8</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>9</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>10</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>11</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>12</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>14</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr></table>

Intentionally Left Blank

TEST LEAF-3   

<table><tr><td colspan="2">Unit Name</td><td colspan="3">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td colspan="2">Model No.</td><td colspan="3">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="3">Unit Manufacturer</td><td colspan="4"></td></tr><tr><td colspan="3">Supply Order No.</td><td colspan="4"></td></tr><tr><td colspan="3">Project Name</td><td colspan="4"></td></tr><tr><td colspan="3">Reference Document</td><td colspan="4">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="3">Test Description</td><td colspan="4">RTD Channels Excitation</td></tr><tr><td colspan="3">Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Voltage(5V)</td><td colspan="3">Current Drawn Expected (without sensor):</td><td>0.30±0.04 A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td rowspan="2">S.
No.</td><td rowspan="2">Channel</td><td colspan="2">Measure Across</td><td>Expected 
Current</td><td colspan="2">Termination 
Resistance in</td><td>Expected 
Range</td><td rowspan="2">Measu 
red 
Value 
(mV)</td><td rowspan="2">Result 
(Pass / 
Fail)</td></tr><tr><td>Positive</td><td>Negative</td><td rowspan="3">0.30±0.04 A</td><td>Resistance (Ω)</td><td>Measured 
Resistance (Ω)</td><td rowspan="3">(0.400±0.04)mA 
Measured 
Resistance</td></tr><tr><td>1.</td><td>RTD_1</td><td>RTD CUR 
_OUT1 
(P1.21)</td><td>RTD_1_ 
GND 
(P1.22)</td><td>100</td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>RTD CUR 
_OUT2 
(P1.25)</td><td>RTD_2_ 
GND 
(P1.26)</td><td>100</td><td></td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-4   

<table><tr><td>Unit Name</td><td colspan="3">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="3">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="4"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="4"></td></tr><tr><td colspan="2">Project Name</td><td colspan="4"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="4">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="4">Excitation to Pressure, Shock and Vibration Channels (initial/final functional checks)</td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Voltage (5V)</td><td colspan="2">Current Drawn Expected (without sensor):</td><td>0.30±0.04 A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td rowspan="2">Sr.
No.</td><td rowspan="2">Channel</td><td colspan="2">Measure across</td><td colspan="3">Expected Range</td><td rowspan="2">Measured Value (V)</td><td rowspan="2">Result (Pass / Fail)</td></tr><tr><td>Pos</td><td>Neg</td><td>Min (V)</td><td>Nom (V)</td><td>Max (V)</td></tr><tr><td>1.</td><td>P1</td><td>P1_EXC+ (P1.36)</td><td>P1_EXC- (P1.37)</td><td>14.0</td><td>15.0</td><td>16.0</td><td></td><td></td></tr><tr><td>2.</td><td>V1</td><td>TV1X_VIN (P1.41)</td><td>TV1_GND (P1.40)</td><td>24.0</td><td>25.0</td><td>26.0</td><td></td><td></td></tr><tr><td>3.</td><td>V2</td><td>TV1Y_VIN (P1.42)</td><td>TV1_GND (P1.40)</td><td>24.0</td><td>25.0</td><td>26.0</td><td></td><td></td></tr><tr><td>4.</td><td>V3</td><td>TV1Z_VIN (P1.43)</td><td>TV1_GND (P1.40)</td><td>24.0</td><td>25.0</td><td>26.0</td><td></td><td></td></tr><tr><td>5.</td><td>V4</td><td>TV2X_VIN (P1.44)</td><td>TV2_GND (P1.47)</td><td>24.0</td><td>25.0</td><td>26.0</td><td></td><td></td></tr><tr><td>6.</td><td>V5</td><td>TV2Y_VIN (P1.45)</td><td>TV2_GND (P1.47)</td><td>24.0</td><td>25.0</td><td>26.0</td><td></td><td></td></tr><tr><td>7.</td><td>V6</td><td>TV2Z_VIN (P1.46)</td><td>TV2_GND (P1.47)</td><td>24.0</td><td>25.0</td><td>26.0</td><td></td><td></td></tr><tr><td>8.</td><td>Sh1</td><td>Sh1_VIN (P1.38)</td><td>Sh1_GND (P1.39)</td><td>24.0</td><td>25.0</td><td>26.0</td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-5   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S. No.</td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="3">5-Point calibration of RTD Channels(initial/final functional checks)</td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td></tr><tr><td>Voltage(5V)</td><td colspan="2">Current Drawn Expected (without sensor):</td><td>0.30±0.04A</td><td>Current Drawn</td></tr></table>

<table><tr><td colspan="7">CHANNEL: RTD 1</td></tr><tr><td rowspan="2">Sr. No.</td><td rowspan="2">Input Setting in ohms</td><td colspan="3">Expected Value (°C)</td><td rowspan="2">Reading on Application (°C)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Min</td><td>Nom</td><td>Max</td></tr><tr><td>1.</td><td>80.31 (-50°C)</td><td>0</td><td>0</td><td>7</td><td></td><td></td></tr><tr><td>2.</td><td>149.82 (130°C)</td><td>92</td><td>99</td><td>106</td><td></td><td></td></tr><tr><td>3.</td><td>183.17 (220°C)</td><td>143</td><td>150</td><td>157</td><td></td><td></td></tr><tr><td>4.</td><td>215.57 (310°C)</td><td>194</td><td>201</td><td>208</td><td></td><td></td></tr><tr><td>5.</td><td>247.04 (400°C)</td><td>245</td><td>252</td><td>255</td><td></td><td></td></tr><tr><td colspan="7">CHANNEL: RTD 2</td></tr><tr><td rowspan="2">Sr. No.</td><td rowspan="2">Input Setting in ohms</td><td colspan="3">Expected Value (°C)</td><td rowspan="2">Reading on Application (°C)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum</td><td>Nominal</td><td>Maximum</td></tr><tr><td>1.</td><td>80.31 (-50°C)</td><td>0</td><td>0</td><td>7</td><td></td><td></td></tr><tr><td>2.</td><td>149.82 (130°C)</td><td>92</td><td>99</td><td>106</td><td></td><td></td></tr><tr><td>3.</td><td>183.17 (220°C)</td><td>143</td><td>150</td><td>157</td><td></td><td></td></tr><tr><td>4.</td><td>215.56 (310°C)</td><td>194</td><td>201</td><td>208</td><td></td><td></td></tr><tr><td>5.</td><td>247.04 (400°C)</td><td>245</td><td>252</td><td>255</td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-6   

<table><tr><td colspan="2">Unit Name</td><td colspan="3">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td colspan="2">Model No.</td><td colspan="3">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="3">Unit Manufacturer</td><td colspan="4"></td></tr><tr><td colspan="3">Supply Order No.</td><td colspan="4"></td></tr><tr><td colspan="3">Project Name</td><td colspan="4"></td></tr><tr><td colspan="3">Reference Document</td><td colspan="4">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="3">Test Description</td><td colspan="4">5-Point calibration of Strain Gauge Channels
(initial/final functional checks)</td></tr><tr><td colspan="3">Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Voltage(5V)</td><td colspan="3">Current Drawn Expected
(without Sensor):</td><td>0.30±0.04A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td colspan="7">CHANNEL: SG1</td></tr><tr><td rowspan="2">S.No</td><td rowspan="2">Input Setting(Ω)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (μst)</td><td rowspan="2">Result Pass /Fail</td></tr><tr><td>Minimum (μst)</td><td>Nominal(μst)</td><td>Maximum(μst)</td></tr><tr><td>1.</td><td>343Ω</td><td>0</td><td>0</td><td>19</td><td></td><td></td></tr><tr><td>2.</td><td>346.5Ω</td><td>44</td><td>63</td><td>82</td><td></td><td></td></tr><tr><td>3.</td><td>350Ω</td><td>108</td><td>127</td><td>146</td><td></td><td></td></tr><tr><td>4.</td><td>353.5Ω</td><td>172</td><td>191</td><td>210</td><td></td><td></td></tr><tr><td>5.</td><td>357Ω</td><td>236</td><td>255</td><td>255</td><td></td><td></td></tr><tr><td colspan="7">CHANNEL: SG2</td></tr><tr><td rowspan="2">S.No</td><td rowspan="2">Input Setting(Ω)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (μst)</td><td rowspan="2">ResultPass /Fail</td></tr><tr><td>Minimum (μst)</td><td>Nominal (μst)</td><td>Maximum (μst)</td></tr><tr><td>6.</td><td>343Ω</td><td>0</td><td>0</td><td>19</td><td></td><td></td></tr><tr><td>7.</td><td>346.5Ω</td><td>44</td><td>63</td><td>82</td><td></td><td></td></tr><tr><td>8.</td><td>350Ω</td><td>108</td><td>127</td><td>146</td><td></td><td></td></tr><tr><td>9.</td><td>353.5Ω</td><td>172</td><td>191</td><td>210</td><td></td><td></td></tr><tr><td>10.</td><td>357Ω</td><td>236</td><td>255</td><td>255</td><td></td><td></td></tr><tr><td colspan="7">CHANNEL: SG3</td></tr><tr><td rowspan="2">S.No</td><td rowspan="2">Input Setting(Ω)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application(μst)</td><td rowspan="2">Result Pass /Fail</td></tr><tr><td>Minimum(μst)</td><td>Nominal(μst)</td><td colspan="1">Maximum(μst)</td></tr><tr><td>11.</td><td>343Ω</td><td>0</td><td>0</td><td>19</td><td></td><td></td></tr><tr><td>12.</td><td>346.5Ω</td><td>44</td><td>63</td><td>82</td><td></td><td></td></tr><tr><td>13.</td><td>350Ω</td><td>108</td><td>127</td><td>146</td><td></td><td></td></tr><tr><td>14.</td><td>353.5Ω</td><td>172</td><td>191</td><td>210</td><td></td><td></td></tr><tr><td>15.</td><td>357Ω</td><td>236</td><td>255</td><td>255</td><td></td><td></td></tr><tr><td colspan="7">CHANNEL: SG4</td></tr><tr><td rowspan="2">S.No</td><td rowspan="2">Input Setting(Ω)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application(μst)</td><td rowspan="2">ResultPass /Fail</td></tr><tr><td>Minimum(μst)</td><td>Nominal(μst)</td><td colspan="1">Maximum(μst)</td></tr><tr><td>16.</td><td>343Ω</td><td>0</td><td>0</td><td>19</td><td></td><td></td></tr><tr><td>17.</td><td>346.5Ω</td><td>44</td><td>63</td><td>82</td><td></td><td></td></tr><tr><td>18.</td><td>350Ω</td><td>108</td><td>127</td><td>146</td><td></td><td></td></tr><tr><td>-19.</td><td>353.5Ω</td><td>172</td><td>191</td><td>210</td><td></td><td></td></tr><tr><td>20.</td><td>357Ω</td><td>236</td><td>255</td><td>255</td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-7   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S. No.</td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="3">5-Point calibration of Pressure Channels(initial/final functional checks)</td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td></tr><tr><td>Voltage(5V)</td><td>Current Drawn Expected (without Sensor) :</td><td>0.30±0.04A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td colspan="7">CHANNEL P1</td></tr><tr><td rowspan="2">Sr.No.</td><td rowspan="2">Input Setting In Voltage</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (bar)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (bar)</td><td>Typical (bar)</td><td>Maximum (bar)</td></tr><tr><td>1.</td><td>0 V (0 bar)</td><td>122</td><td>127</td><td>132</td><td></td><td></td></tr><tr><td>2.</td><td>1.25 V (87.5 bar)</td><td>154</td><td>159</td><td>164</td><td></td><td></td></tr><tr><td>3.</td><td>2.5 V (175 bar)</td><td>186</td><td>191</td><td>196</td><td></td><td></td></tr><tr><td>4.</td><td>3.75 V (262.5bar)</td><td>218</td><td>223</td><td>228</td><td></td><td></td></tr><tr><td>5.</td><td>5 V (350 bar)</td><td>249</td><td>252</td><td>255</td><td></td><td></td></tr></table>

Note: * The Pressure channel supports a sensor with output 0v to +5v max. While ADC range is +5V for 0 to 255 counts Hence counts will vary from 127 Count (0V) to 255 count(+5V). The tolerance allowed for any channel of CPSCP with test jig is 2%. Hence, any measurement can have a count tolerance of 5 counts.

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-8   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S.No.</td><td></td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td><td></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td><td></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td><td></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td><td></td></tr><tr><td colspan="2">Test Description</td><td colspan="3">5-Point Calibration of Vibration channels(initial/final functional checks)</td><td></td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Voltage(5V)</td><td colspan="2">Current Drawn Expected (without Sensor)</td><td>0.30±0.04A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td colspan="8">CHANNEL: TV1X ( Frequency 100Hz)</td></tr><tr><td rowspan="2">Sr. No.</td><td rowspan="2">Setting of Accelerometer Simulator (or) Function Generator (VP)</td><td rowspan="2">Reading on the DMM (VRMS)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (gp)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (gp)</td><td>Typical (gp)</td><td>Maximum (gp)</td></tr><tr><td>1.</td><td>-5</td><td>-3.54</td><td>0</td><td>0</td><td>3</td><td></td><td></td></tr><tr><td>2.</td><td>-2.5</td><td>-1.7675</td><td>60</td><td>63</td><td>66</td><td></td><td></td></tr><tr><td>3.</td><td>0</td><td>0</td><td>124</td><td>127</td><td>130</td><td></td><td></td></tr><tr><td>4.</td><td>2.5</td><td>1.7675</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>5.</td><td>5</td><td>3.54</td><td>249</td><td>252</td><td>255</td><td></td><td></td></tr><tr><td colspan="8">CHANNEL: TV1Y ( Frequency 100Hz)</td></tr><tr><td rowspan="2">Sr. No.</td><td rowspan="2">Setting of Accelerometer Simulator (or) Function Generator (VP)</td><td rowspan="2">Reading on the DMM (VRMS)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (gp)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (gp)</td><td>Typical (gp)</td><td>Maximum (gp)</td></tr><tr><td>1.</td><td>-5</td><td>-3.5</td><td>0</td><td>0</td><td>3</td><td></td><td></td></tr><tr><td>2.</td><td>-2.5</td><td>-1.7675</td><td>60</td><td>63</td><td>66</td><td></td><td></td></tr><tr><td>3.</td><td>0</td><td>0</td><td>124</td><td>127</td><td>130</td><td></td><td></td></tr><tr><td>4.</td><td>2.5</td><td>1.7675</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>5.</td><td>5</td><td>3,54</td><td>249</td><td>252</td><td>255</td><td></td><td></td></tr><tr><td colspan="8">CHANNEL: TV1Z (Frequency 100Hz)</td></tr><tr><td rowspan="2">Sr. No.</td><td rowspan="2">Setting of Accelerometer Simulator (or) Function Generator (VP)</td><td rowspan="2">Reading on the DMM (VRMS)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (gp)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (gp)</td><td>Typical (gp)</td><td colspan="1">Maximum (gp)</td></tr><tr><td>1.</td><td>-5</td><td>-3.54</td><td>0</td><td>0</td><td>3</td><td></td><td></td></tr><tr><td>2.</td><td>-2.5</td><td>-1.7675</td><td>60</td><td>63</td><td>66</td><td></td><td></td></tr><tr><td>3.</td><td>0</td><td>0</td><td>124</td><td>127</td><td>130</td><td></td><td></td></tr><tr><td>4.</td><td>2.5</td><td>1.7675</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>5.</td><td>5</td><td>3.54</td><td>249</td><td>252</td><td>255</td><td></td><td></td></tr><tr><td colspan="8">CHANNEL: TV2X (Frequency 100Hz)</td></tr><tr><td rowspan="2">Sr. No.</td><td rowspan="2">Setting of Accelerometer Simulator (or) Function Generator (VP)</td><td rowspan="2">Reading on the DMM (VRMS)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (gp)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (gp)</td><td>Typical (gp)</td><td colspan="1">Maximum (gp)</td></tr><tr><td>1.</td><td>-5</td><td>-3.5</td><td>0</td><td>0</td><td>3</td><td></td><td></td></tr><tr><td>2.</td><td>-2.5</td><td>-1.7675</td><td>60</td><td>63</td><td>66</td><td></td><td></td></tr><tr><td>3.</td><td>0</td><td>0</td><td>124</td><td>127</td><td>130</td><td></td><td></td></tr><tr><td>4.</td><td>2.5</td><td>1.7675</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>5.</td><td>5</td><td>3,54</td><td>249</td><td>2525</td><td>255</td><td></td><td></td></tr><tr><td colspan="8">CHANNEL: TV2Y (Frequency 100Hz)</td></tr><tr><td rowspan="2">Sr. No.</td><td rowspan="2">Setting of Accelerometer Simulator (or) Function Generator (VP)</td><td rowspan="2">Reading on the DMM (VRMS)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (gp)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (gp)</td><td>Typical (gp)</td><td colspan="1">Maximum (gp)</td></tr><tr><td>1.</td><td>-5</td><td>-3.51</td><td>0</td><td>0</td><td>3</td><td></td><td></td></tr><tr><td>2.</td><td>-2.5</td><td>-1.7675</td><td>60</td><td>63</td><td>66</td><td></td><td></td></tr><tr><td>3.</td><td>0</td><td>0</td><td>124</td><td>127</td><td>130</td><td></td><td></td></tr><tr><td>4.</td><td>2.5</td><td>1.7675</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>5.</td><td>5</td><td>354</td><td>249</td><td>252</td><td>255</td><td></td><td></td></tr><tr><td colspan="8">CHANNEL: TV2Z ( Frequency 100Hz)</td></tr><tr><td rowspan="2">Sr.
No.</td><td rowspan="2">Setting of Accelerometer Simulator (or) Function Generator (Vp)</td><td rowspan="2">Reading on the DMM (VRMS)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (gP)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (gP)</td><td>Typical (gP)</td><td colspan="1">Maximum (gP)</td></tr><tr><td>1.</td><td>-5</td><td>-3.54</td><td>0</td><td>0</td><td>3</td><td></td><td></td></tr><tr><td>2.</td><td>-2.5</td><td>-1.7675</td><td>60</td><td>63</td><td>66</td><td></td><td></td></tr><tr><td>3.</td><td>0</td><td>0</td><td>124</td><td>127</td><td>130</td><td></td><td></td></tr><tr><td>4.</td><td>2.5</td><td>1.7675</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>5.</td><td>5</td><td>3.54</td><td>249</td><td>252</td><td>255</td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-9   

<table><tr><td>Unit Name</td><td colspan="3">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="3">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="4"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="4"></td></tr><tr><td colspan="2">Project Name</td><td colspan="4"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="4">RCI/DOFI /CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="4">5-Point Calibration of Shock channels(initial/final functional checks)</td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Voltage(5V)</td><td colspan="2">Current Drawn Expected
(without sensor)</td><td>0.30±0.04A</td><td>Current Drawn</td><td></td></tr></table>

CHANNEL: Sh1 (Frequency 100Hz)   

<table><tr><td rowspan="2">Sr.
No.</td><td rowspan="2">Setting of Accelerometer Simulator (or) Function Generator (Vp)</td><td colspan="3">Expected Value</td><td rowspan="2">Reading on Application (gp)</td><td rowspan="2">Result Pass / Fail</td></tr><tr><td>Minimum (gp)</td><td>Typical (gp)</td><td>Maximum (gp)</td></tr><tr><td>1.</td><td>-5</td><td>0</td><td>0</td><td>3</td><td></td><td></td></tr><tr><td>2.</td><td>-2.5</td><td>60</td><td>63</td><td>66</td><td></td><td></td></tr><tr><td>3.</td><td>0</td><td>124</td><td>127</td><td>130</td><td></td><td></td></tr><tr><td>4.</td><td>2.5</td><td>188</td><td>191</td><td>194</td><td></td><td></td></tr><tr><td>5.</td><td>5</td><td>249</td><td>252</td><td>255</td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-10   

<table><tr><td colspan="2">Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td colspan="2">Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="4"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="4"></td></tr><tr><td colspan="2">Project Name</td><td colspan="4"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="4">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="4">Digital Filter Cut-off Frequency</td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Voltage (5V)</td><td colspan="2">Current withdrawn Expected(without sensor)</td><td>0.30±0.04A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td colspan="5">Pressure Channel (P1)-(5Vp-p, Offset 2.5V), fc(3db)=699Hz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>126(min)-251(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>699 Hz</td><td>147(min)-234(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>800 Hz</td><td>174(min)-209(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>1 KHz</td><td>190</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV1X)-(10Vp-p, Offset 0V), fc(3.1188db)=2.773KHz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>0(min)-250(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>2.7 KHz</td><td>24(min)-228(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>3.25 KHz</td><td>125(min)-129(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>5 KHz</td><td>126</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV1Y)-(10Vp-p, Offset 0V), fc(3.1188db)=2.773KHz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>0(min)-250(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>2.7 KHz</td><td>23(min)-230(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>3.25 KHz</td><td>124(min)-128(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>5 KHz</td><td>127</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV1Z)-(10Vp-p, Offset 0V), fc(3.1188db)=2.773KHz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>0(min)-250(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>2.7 KHz</td><td>24(min)-223(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>3.25 KHz</td><td>125(min)-129(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>5 KHz</td><td>126</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV2X)-(10Vp-p, Offset 0V), fc(3.1188db)=2.773KHz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>0(min)-250(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>2.7 KHz</td><td>23(min)-230(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>3.25 KHz</td><td>126(min)-129(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>5 KHz</td><td>126</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV2Y)-(10Vp-p, Offset 0V), fc(3.1188db)=2.773KHz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>0(min)-250(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>2.7 KHz</td><td>23(min)-23( max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>3.25 KHz</td><td>125(min)-129(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>5 KHz</td><td>126</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV2Z)-(10Vp-p, Offset 0V), fc(3.1188db)=2.773KHz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>0(min)-250(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>2.7 KHz</td><td>23(min)-23 (max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>3.25 KHz</td><td>125(min)-129(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>5 KHz</td><td>127</td><td></td><td></td></tr><tr><td colspan="5">Shock (Sh1)-(10Vp-p, Offset 0V), fc(3db)=9.087KHz</td></tr><tr><td>Sl.No.</td><td>I/P frequency</td><td>Expected Value</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>100 Hz</td><td>0(min)-251(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>2.</td><td>9.09 KHz</td><td>31(min)-222(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>3.</td><td>10 KHz</td><td>127(min)-128(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr><tr><td>4.</td><td>11 KHz</td><td>127(min)-131(max)</td><td></td><td>±5 counts tolerance from min &amp; max value</td></tr></table>

Note: The above results will be verified by designer.   
In case of RTD and Strain resistor value get changed with respect to physical parameter. So in this case filter response cannot be verified through function generator. But as the filter structure is same (both 199th order FIR and 39th order FIR) for RTD, Strain, Electrical, Pressure and Accelerometer, filter performance can be evaluated with respect to the readings observed in Electrical, Pressure and Accelerometer channels.

MANUFACTURER

DOFI/RCI

TEST LEAF-11   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="3">RS422 BUS Test (initial/final functional checks)</td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td></tr><tr><td>Voltage (5V)</td><td>Current Drawn Expected
(Without Sensor)</td><td>0.30±0.04A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td rowspan="2">S.No</td><td rowspan="2">Data sent from CPSCP V2.2</td><td colspan="2">No. of Bytes</td><td>Data Received in (HEX)</td><td>RX/ TX Data are Matching (Y/N)</td></tr><tr><td>Expected</td><td>Observed</td><td>Expected</td><td>Observed</td></tr><tr><td>1.</td><td>RS422_TX1</td><td>80</td><td></td><td>Header: AA BB,Footer: CC</td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

TEST LEAF-12   

<table><tr><td>Unit Name</td><td colspan="3">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="3">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="4"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="4"></td></tr><tr><td colspan="2">Project Name</td><td colspan="4"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="4">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="4">Environmental Test(initial/final) (Preat/Inte /Post)</td></tr><tr><td colspan="2">Test Location</td><td colspan="2"></td><td>Date</td><td></td></tr><tr><td>Voltage (5V)</td><td colspan="2">Current Drawn Expected(without Sensor)</td><td>0.30±0.04 A</td><td>Current Drawn</td><td></td></tr></table>

<table><tr><td rowspan="2">S.No.</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="3">Reading on Application</td><td rowspan="2">Result Pass/Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>PREET5V</td><td>INSET5V</td><td>POET5V</td></tr><tr><td>1</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>14</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

DR&QA

# Appendix - B Entest Test Report

HIGH TEMPERATURE STORAGE (STABILIZATION BAKE) TEST REPORT

Project Name: Vshorads-SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: QT /AT

Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04$ A

Specification: $85 \pm 5^{\circ}\mathrm{C}$ ; 24 hrs.

Remarks:   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel 
Specify</td><td rowspan="2">Input to 
be given</td><td colspan="3">Expected Value</td><td colspan="2">Reading on Application</td><td rowspan="2">Result pass / 
Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>PREET</td><td>POET</td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr></table>

ATL Rep

DR&QA Rep

DOFI

THERMAL SHOCK TEST REPORT

Project Name: Vshorads-SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: QT/AT

Voltage: 5V Current Drawn Expected Without sensor: $0.30 \pm 0.04$ A

Specification: $-40 \pm 5^{\circ}\mathrm{C}$ for 30 mins. $+85 \pm 5^{\circ}\mathrm{C}$ for 30 mins. No. of Cycles: 10

Remarks:   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="2">Reading on Application</td><td rowspan="2">Result pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>PREET</td><td>POET</td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td></tr></table>

ATL Rep DOFI DR&QA Rep

CEMILAC BURN-IN TEST REPORT   
Project Name: Vshorad -SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: AT/QT Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$ Specification: $+71^{\circ}\mathrm{C}$ for 48 hrs. Functional Checks on PCB at every 5 hours till $45^{\mathrm{th}}$ hour, three reading at every 1 hr. Power ON Condition.   

<table><tr><td rowspan="2">S.No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="8">Reading on Application</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>PREET</td><td>5thHour</td><td>10thHour</td><td>15thHour</td><td>20thHour</td><td>25thHour</td><td>30thHour</td><td>35thHour</td></tr><tr><td>1</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

CEMILAC BURN-IN TEST REPORT   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="6">Reading on Application</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>40thHour</td><td>45thHour</td><td>46thHour</td><td>47thHour</td><td>48thHour</td><td>Poet</td></tr><tr><td>1</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Remarks:

DR&QA Rep

DOFI

ATL Rep

PRE/POST RANDOM VIBRATION TEST REPORT

Project Name: Vshorads -SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: QT/AT

Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$

Specification:Freq:20 Hz - 2000 Hz;20 Hz - 100 Hz; +6 dB/Octave;100-1000 - 0.04 g2/Hz;1000-2000 Hz; -6dB/Octave; 300 s, long. & lat. Axes

Remarks:   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="10">Reading on Application</td><td>Result pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>X PREET</td><td>X INSET</td><td>X POET</td><td>Y PREET</td><td>Y INSET</td><td>Y POET</td><td>Z PREET</td><td>Z INSET</td><td>Z POET</td><td></td><td></td></tr><tr><td>1</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

ATL Rep DOFI DR&QA Rep

# THERMAL CYCLING TEST REPORT

Project Name: Vshorads -SF Unit Name: CPSCP V2.2 Unit SL No:   
Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$

Model: QT

Current:

Specification: $-30^{\circ}\mathrm{C}$ for $60\mathrm{min.} + 70^{\circ}\mathrm{C}$ for $60\mathrm{min}$ . Rate of changeofTemp: $10^{\circ}\mathrm{C}$ /min. No. of Cycles: 8

<table><tr><td rowspan="3">S. No</td><td rowspan="3">Channel Specify</td><td rowspan="3">Input to be given</td><td colspan="3">Expected Value</td><td colspan="9">Reading on Application</td><td rowspan="3">Result pass / Fail</td></tr><tr><td rowspan="2">Min</td><td rowspan="2">Typ</td><td rowspan="2">Max</td><td rowspan="2">PREET</td><td colspan="2">1StCYCLE</td><td colspan="2">2ndCYCLE</td><td colspan="2">3rdCYCLE</td><td colspan="2">4thCYCLE</td></tr><tr><td>-30°C</td><td>+70°C</td><td>-30°C</td><td>+70°C</td><td>-30°C</td><td>+70°C</td><td>-30°C</td><td>+70°C</td></tr><tr><td>1</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Remarks:   

<table><tr><td rowspan="3">S. No</td><td rowspan="3">Channel Specify</td><td rowspan="3">Input to be given</td><td colspan="3">Expected Value</td><td colspan="9">Reading on Application</td><td rowspan="3">Result pass / Fail</td></tr><tr><td rowspan="2">Min</td><td rowspan="2">Typ</td><td rowspan="2">Max</td><td rowspan="2">POET</td><td colspan="2">5thCYCLE</td><td colspan="2">6thCYCLE</td><td colspan="2">7thCYCLE</td><td colspan="2">8thCYCLE</td></tr><tr><td>-300C</td><td>+700C</td><td>-300C</td><td>+700C</td><td>-300C</td><td>+700C</td><td>-300C</td><td>+700C</td></tr><tr><td>1.</td><td>RTD_1</td><td>2670C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>2670C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

THERMAL CYCLING TEST REPORT   
Project Name: Vshorads -SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: 5V Current: Date: Model: AT Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$ Specification: $-30^{\circ}\mathrm{C}$ for $60\mathrm{min.} + 70^{\circ}\mathrm{C}$ for $60\mathrm{min}$ . Rate of changeofTemp: $10^{\circ}\mathrm{C}$ /min. No. of Cycles: 6   

<table><tr><td rowspan="3">S. No</td><td rowspan="3">Channel Specify</td><td rowspan="3">Input to be given</td><td colspan="3">Expected Value</td><td colspan="7">Reading on Application</td><td rowspan="3">Result pass / Fail</td></tr><tr><td rowspan="2">Min</td><td rowspan="2">Typ</td><td rowspan="2">Max</td><td rowspan="2">PREET</td><td colspan="2">1St CYCLE</td><td colspan="2">2nd CYCLE</td><td colspan="2">3rd CYCLE</td></tr><tr><td>-30°C</td><td>+70°C</td><td>-30°C</td><td>+70°C</td><td>-30°C</td><td>+70°C</td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Remarks:   

<table><tr><td rowspan="3">S. No</td><td rowspan="3">Channel Specify</td><td rowspan="3">Input to be given</td><td colspan="3">Expected Value</td><td colspan="8">Reading on Application</td></tr><tr><td rowspan="2">Mi n</td><td rowspan="2">Typ</td><td rowspan="2">Max</td><td colspan="2">4th CYCLE</td><td colspan="2">5th CYCLE</td><td colspan="2">6th CYCLE</td><td rowspan="2">POET</td><td rowspan="2">Result pass / Fail</td></tr><tr><td>-30°C</td><td>+70°C</td><td>-30°C</td><td>+70°C</td><td>-30°C</td><td>+70°C</td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

DR&QA Rep

DOFI

ATL Rep

LOW TEMPERATURE TEST REPORT

Project Name: Vshorads-SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: QT

Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$

Specification: $30\pm 3^{\circ}\mathrm{C}$ 16 hrs. Last 1 hr. Operation.

__________

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel 
Specify</td><td rowspan="2">Input to 
be given</td><td colspan="3">Expected Value</td><td colspan="3">Reading on Application</td><td rowspan="2">Result pass / 
Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>PREET</td><td>INSET</td><td>POET</td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr></table>

Remarks:

ATL Rep DOFI DR&QA Rep

HIGH TEMPERATURE TEST REPORT

Project Name: Vshorads -SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: QT

Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$

Specification: $55\pm 3^{\circ}\mathrm{C}$ 6 hrs. $65\pm 3^{\circ}\mathrm{C}$ 4 hrs. $55\pm 3^{\circ}\mathrm{C}$ 6 hrs. Last 1 hr. Operation.

Remarks:   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="3">Reading on Application</td><td rowspan="2">Result pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>PREET</td><td>INSET</td><td>POET</td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr></table>

DR&QA Rep

DOFI

ATL Rep

![](images/3d30f5b5b0c3c65785fef852b92f76e2062b54602df5289a5736b9081f4f4bb1.jpg)

TROPICALEXPOSURE TEST REPORT

Model: QT

Date:

Current:

Voltage:

Unit SL No.

Unit Name: CPSCP V2.2

Project Name: Vshorads -SF

Specification $20 \pm 2^{\circ} \mathrm{C}$ ; 6 hrs. Ramp Up to $45^{\circ} \mathrm{C}$ in 3 hrs. $45 \pm 2 \mathrm{C}$ ; 12 hrs. Ramp Down to $20^{\circ} \mathrm{C}$ in 3 hrs. RH > 95%, No. of Cycles - 14.   
Remarks:   

<table><tr><td rowspan="3">S. No</td><td rowspan="3">Channel Specify</td><td rowspan="3">Input to be given</td><td colspan="3">Expected Value (Count in Decimal)</td><td colspan="4">Reading on Application</td><td rowspan="3">Result pass / Fail</td></tr><tr><td rowspan="2">Min</td><td rowspan="2">Typ</td><td rowspan="2">Max</td><td rowspan="2">PREET</td><td colspan="2">INSET</td><td rowspan="2">POET</td></tr><tr><td>7TH DAY</td><td>14TH DAY</td></tr><tr><td>1.</td><td>RTD_1</td><td>2670C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>2670C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191.</td><td>194</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td></tr></table>

DR&QA Rep

DOFI

ATL Rep

ACCELERATION TEST REPORT

Model: AT/QT

Current: Date:

Voltage:

Project Name: Vshorads -SF Unit Name: CPSCP V2.2 Unit SL No:

Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$ Specification: Long: 75g; 45s, Lateral: 60g; 45s 6 directions for QT. Long: 50g; 45s, Lateral: 40g; 45s 6 directions for AT

Remarks:   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="9">Reading on Application</td><td rowspan="2">Result pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1.</td><td>RTD_1</td><td>\(267^0\text{C}\)</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>\(267^0\text{C}\)</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

DR&QA Rep

DOFI

ATL Rep

SHOCK TEST REPORT

Project Name: Vshorads -SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: AT/QT

Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$

Specification: 60g for QT/40g for AT; 3 ms 3 shocks for QT, 2 Shocks for AT per axis (Lon. Axis)

Remarks:   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="9">Reading on Application</td><td rowspan="2">Result pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

DR&QA Rep

DOFI

ATL Rep

DAMP HEAT TEST REPORT

Project Name: Vshorads -SF Unit Name: CPSCP V2.2 Unit SL No: Voltage: Current: Date: Model: AT: AT

Voltage: 5V Current Drawn Expected without sensor: $0.30 \pm 0.04\mathrm{A}$

Specification: $40 \pm 2^{\circ}\mathrm{C}; \mathrm{RH} > 95\%$ 8 hrs. Inset during last 30 minutes.

Remarks   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value (Count in Decimal)</td><td colspan="3">Reading on Application</td><td rowspan="2">Result pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td>PREET</td><td>INSET</td><td>POET</td></tr><tr><td>1.</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td></tr><tr><td>8.</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>9.</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>10.</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>11.</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>12.</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>13.</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr><tr><td>14.</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td></tr></table>

ATL Rep DOFI DR&QA Rep

EMI/EMC TEST REPORT

Model: QT

Date:

Current:

Voltage:

Unit SL No:

Unit Name: CPSCP V2.2

Project Name: Vshorads -SF

Note: EMI/EMC Test to be conducted on missile level, treating VSHORADS-SF missile as a single EUT for all EMI-EMC tests. Thus, these tests are not under vendor's scope

Remarks:   

<table><tr><td rowspan="2">S. No</td><td rowspan="2">Channel Specify</td><td rowspan="2">Input to be given</td><td colspan="3">Expected Value</td><td colspan="6">Reading on Application</td><td rowspan="2">Result pass / Fail</td></tr><tr><td>Min</td><td>Typ</td><td>Max</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1</td><td>RTD_1</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td>RTD_2</td><td>267°C</td><td>169</td><td>176</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>SG1</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>SG2</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td>SG3</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>SG4</td><td>352 Ω</td><td>145</td><td>164</td><td>183</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>P1</td><td>2.5 V</td><td>186</td><td>191</td><td>196</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>TV1_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>TV1_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>10</td><td>TV1_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>11</td><td>TV2_X</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12</td><td>TV2_Y</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>13</td><td>TV2_Z</td><td>2.5V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>14</td><td>Sh1</td><td>2.5 V</td><td>188</td><td>191</td><td>194</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

DR&QA Rep

DOFI

ATL Rep

# Appendix C

# Test Leaf for Board Level Check

TEST LEAF-A-1   

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td>Unit Manufacturer</td><td colspan="3"></td></tr><tr><td>Supply Order No.</td><td colspan="3"></td></tr><tr><td>Project Name</td><td colspan="3"></td></tr><tr><td>Reference Document</td><td colspan="3">RCI/DOFI /CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td>Test Description</td><td colspan="3">Analog Filter Cut-off Frequency</td></tr><tr><td>Test Location</td><td></td><td>Date</td><td></td></tr></table>

<table><tr><td colspan="5">RTD Channel 1 (RTD-1)-(30mVp-p, Offset 66mV)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected Values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>25Hz</td><td>30mV ± 1.5mV</td><td></td><td></td></tr><tr><td>2.</td><td>100Hz</td><td>30mV ± 1.5mV</td><td></td><td></td></tr><tr><td>3.</td><td>700Hz</td><td>29.5mV ± 1.5mV</td><td></td><td></td></tr><tr><td>4.</td><td>3.687KHz</td><td>21.2mV ± 1.5mV</td><td></td><td></td></tr><tr><td>5.</td><td>4KHz</td><td>20.3mV ± 1.5mV</td><td></td><td></td></tr><tr><td colspan="5">RTD Channel 2 (RTD-2)-(30mVp-p, Offset 66mV)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected Values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>25Hz</td><td>30mV ± 1.5mV</td><td></td><td></td></tr><tr><td>2.</td><td>100Hz</td><td>30mV ± 1.5mV</td><td></td><td></td></tr><tr><td>3.</td><td>700Hz</td><td>29. 5mV ± 1.5mV</td><td></td><td></td></tr><tr><td>4.</td><td>3.687KHz</td><td>21.2mV ± 1.5mV</td><td></td><td></td></tr><tr><td>5.</td><td>4KHz</td><td>20.3mV ± 1.5mV</td><td></td><td></td></tr><tr><td colspan="5">Pressure Channel (P1)-(5Vp-p, Offset 2.5V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>25Hz</td><td>5V±250mV</td><td></td><td></td></tr><tr><td>2.</td><td>100Hz</td><td>4.99V±250mV</td><td></td><td></td></tr><tr><td>3.</td><td>700Hz</td><td>4.91V±250mV</td><td></td><td></td></tr><tr><td>4.</td><td>3.687KHz</td><td>3.53V±250mV</td><td></td><td></td></tr><tr><td>5.</td><td>4KHz</td><td>3.38V±250mV</td><td></td><td></td></tr><tr><td colspan="5">Strain Gauge (S1)-(25mVp-p, Offset)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>25Hz</td><td>25mV± 1.25mV</td><td></td><td></td></tr><tr><td>2.</td><td>100Hz</td><td>24.99mV± 1.25mV</td><td></td><td></td></tr><tr><td>3.</td><td>700Hz</td><td>24.56mV± 1.25mV</td><td></td><td></td></tr><tr><td>4.</td><td>3.687KHz</td><td>17.67mV± 1.25mV</td><td></td><td></td></tr><tr><td>5.</td><td>4KHz</td><td>16.93mv± 1.25mV</td><td></td><td></td></tr><tr><td colspan="5">Strain Gauge (S2)-(25mVp-p, Offset)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>25Hz</td><td>25mV±1.25mV</td><td></td><td></td></tr><tr><td>2.</td><td>100Hz</td><td>24.99mV±1.25mV</td><td></td><td></td></tr><tr><td>3.</td><td>700Hz</td><td>24.56mV±1.25mV</td><td></td><td></td></tr><tr><td>4.</td><td>3.687KHz</td><td>17.67mV±1.25mV</td><td></td><td></td></tr><tr><td>5.</td><td>4KHz</td><td>16.93mV±1.25mV</td><td></td><td></td></tr><tr><td colspan="5">Strain Gauge (S3)-(25mVp-p, Offset)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>25Hz</td><td>25mV±1.25mV</td><td></td><td></td></tr><tr><td>2.</td><td>100Hz</td><td>24.99mV±1.25mV</td><td></td><td></td></tr><tr><td>3.</td><td>700Hz</td><td>24.56 mV±1.25mV</td><td></td><td></td></tr><tr><td>4.</td><td>3.687KHz</td><td>17.67mV±1.25mV</td><td></td><td></td></tr><tr><td>5.</td><td>4KHz</td><td>16.93mV±1.25mV</td><td></td><td></td></tr><tr><td colspan="5">Strain Gauge (S4)-(25mVp-p, Offset)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>25Hz</td><td>25mV±1.25mV</td><td></td><td></td></tr><tr><td>2.</td><td>100Hz</td><td>24.99mV±1.25mV</td><td></td><td></td></tr><tr><td>3.</td><td>700Hz</td><td>24.56 \(mV±1.25mV\)</td><td></td><td></td></tr><tr><td>4.</td><td>3.687KHz</td><td>17.67mV±1.25mV</td><td></td><td></td></tr><tr><td>5.</td><td>4KHz</td><td>16.93mV±1.25mV</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV1X)-(10Vp-p, Offset 0V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>1KHz</td><td>9.99V±500mV</td><td></td><td></td></tr><tr><td>2.</td><td>5KHz</td><td>9.91V±500mV</td><td></td><td></td></tr><tr><td>3.</td><td>10KHz</td><td>9.66V±500mV</td><td></td><td></td></tr><tr><td>4.</td><td>58.7KHz</td><td>4.57V±500mV</td><td></td><td></td></tr><tr><td>5.</td><td>70KHz</td><td>3.72V±500mV</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV1Y)-(10Vp-p, Offset 0V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>1KHz</td><td>9.99V±500mV</td><td></td><td></td></tr><tr><td>2.</td><td>5KHz</td><td>9.91V±500mV</td><td></td><td></td></tr><tr><td>3.</td><td>10KHz</td><td>9.66V±5 00mV</td><td></td><td></td></tr><tr><td>4.</td><td>58.7KHz</td><td>4.57V±500mV</td><td></td><td></td></tr><tr><td>5.</td><td>70KHz</td><td>3.72V±500mV</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV1Z)-(10Vp-p, Offset 0V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>1KHz</td><td>9.99V±500mV</td><td></td><td></td></tr><tr><td>2.</td><td>5KHz</td><td>9.91V±500mV</td><td></td><td></td></tr><tr><td>3.</td><td>10KHz</td><td>9.66V±5.00mV</td><td></td><td></td></tr><tr><td>4.</td><td>58.7KHz</td><td>4.57V±500mV</td><td></td><td></td></tr><tr><td>5.</td><td>70KHz</td><td>3.72V±500mV</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV2X)-(10Vp-p, Offset 0V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>1KHz</td><td>9.99V±500mV</td><td></td><td></td></tr><tr><td>2.</td><td>5KHz</td><td>9.91V±500mV</td><td></td><td></td></tr><tr><td>3.</td><td>10KHz</td><td>9.66V±500mV</td><td></td><td></td></tr><tr><td>4.</td><td>58.7KHz</td><td>4.57V±500mV</td><td></td><td></td></tr><tr><td>5.</td><td>70KHz</td><td>3.72V±500mV</td><td></td><td></td></tr></table>

<table><tr><td colspan="5">Vibration (TV2Y)-(10Vp-p, Offset 0V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>1KHz</td><td>9.99V±500mV</td><td></td><td></td></tr><tr><td>2.</td><td>5KHz</td><td>9.91V±500mV</td><td></td><td></td></tr><tr><td>3.</td><td>10KHz</td><td>9.66V±500mV</td><td></td><td></td></tr><tr><td>4.</td><td>58.7KHz</td><td>4.57V±500mV</td><td></td><td></td></tr><tr><td>5.</td><td>70KHz</td><td>3.72V±500mV</td><td></td><td></td></tr><tr><td colspan="5">Vibration (TV2Z)-(10Vp-p, Offset 0V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>1KHz</td><td>9.99V±500mV</td><td></td><td></td></tr><tr><td>2.</td><td>5KHz</td><td>9.91V±500mV</td><td></td><td></td></tr><tr><td>3.</td><td>10KHz</td><td>9.66V±5 00mV</td><td></td><td></td></tr><tr><td>4.</td><td>58.7KHz</td><td>4.57V±500mV</td><td></td><td></td></tr><tr><td>5.</td><td>70KHz</td><td>3.72V±500mV</td><td></td><td></td></tr><tr><td colspan="5">Shock (Sh1)-(10Vp-p, Offset 0V)</td></tr><tr><td>Sl. No.</td><td>I/P frequency</td><td>Expected values</td><td>Measured Value</td><td>Remarks</td></tr><tr><td>1.</td><td>1KHz</td><td>9.99V±500mV</td><td></td><td></td></tr><tr><td>2.</td><td>5KHz</td><td>9.91V±500mV</td><td></td><td></td></tr><tr><td>3.</td><td>10KHz</td><td>9.66V±5.00mV</td><td></td><td></td></tr><tr><td>4.</td><td>58.7KHz</td><td>4.57V±500mV</td><td></td><td></td></tr><tr><td>5.</td><td>70KHz</td><td>3.72V±500mV</td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

TEST LEAF-A-2   

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td>Unit Manufacturer</td><td colspan="3"></td></tr><tr><td>Supply Order No.</td><td colspan="3"></td></tr><tr><td>Project Name</td><td colspan="3"></td></tr><tr><td>Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td>Test Description</td><td colspan="3">Resistance Measurement Test (RMT) &amp; voltage Checks</td></tr><tr><td>Test Location</td><td></td><td>Date</td><td></td></tr></table>

# CPSCP Card

Voltage to Respective Ground Resistance Measurement   

<table><tr><td rowspan="2">S.No</td><td rowspan="2">Voltage</td><td rowspan="2">Point to Point</td><td rowspan="2">Expected Resistance</td><td rowspan="2">Measured Resistance</td><td>Power ON Test</td></tr><tr><td>Observed Voltage</td></tr><tr><td>1.</td><td>VCC_5V</td><td>Across C204</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>2.</td><td>VCC_5V_ANA</td><td>Across C205</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>3.</td><td>VCC_n5V</td><td>Across C202</td><td>7.7K±0.15KΩ</td><td></td><td></td></tr><tr><td>4.</td><td>VCC_n5V_ANA</td><td>Across C201</td><td>122±2.5Ω</td><td></td><td></td></tr><tr><td>5.</td><td>VCC_2V5</td><td>Across C209</td><td>810±16Ω</td><td></td><td></td></tr><tr><td>6.</td><td>VCC_n2V5</td><td>Across C206</td><td>1.75K±35Ω</td><td></td><td></td></tr><tr><td>7.</td><td>VCC_2V5_ANA</td><td>Across C210</td><td>810±16Ω</td><td></td><td></td></tr><tr><td>8.</td><td>VCC_2V5 AUX</td><td>Across C212</td><td>810±16Ω</td><td></td><td></td></tr><tr><td>9.</td><td>VCC_n2V5_ANA</td><td>Across C214</td><td>1.3K±26Ω</td><td></td><td></td></tr><tr><td>10.</td><td>VCC_3V3</td><td>Across C227</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>11.</td><td>VCC_3V3_DIG</td><td>Across C223</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>12.</td><td>VCC_3V3_ANA</td><td>C219</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>13.</td><td>VCC_3V3_ANA_DAC</td><td>C230</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>14.</td><td>VCC_1V2</td><td>Across C236</td><td>110±2.2Ω</td><td></td><td></td></tr><tr><td>15.</td><td>VCC_1V2_DIG</td><td>Across C237</td><td>110±2.2Ω</td><td></td><td></td></tr><tr><td>16.</td><td>VCC_1V8</td><td>Across C226</td><td>&gt;100Ω</td><td></td><td></td></tr><tr><td>17.</td><td>VCC_1V8_DIG</td><td>Across C234</td><td>&gt;100Ω</td><td></td><td></td></tr><tr><td>18.</td><td>VCC_25V</td><td>Across C253</td><td>2.9K±58Ω</td><td></td><td></td></tr><tr><td>19.</td><td>VCC_25V_EXC</td><td>Across C250</td><td>2.9K±58Ω</td><td></td><td></td></tr><tr><td>20.</td><td>VCC_15V</td><td>Across C243</td><td>1.53K±31Ω</td><td></td><td></td></tr><tr><td>21.</td><td>VCC_15V_EXC</td><td>Across C244</td><td>1.53K±31Ω</td><td></td><td></td></tr></table>

MANUFACTURER

DOFI/RCI

# Appendix D Isolation Resistance Checks

TEST LEAF-B-1   

<table><tr><td>Unit Name</td><td>CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td>CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td>Unit Manufacturer</td><td colspan="3"></td></tr><tr><td>Supply Order No.</td><td colspan="3"></td></tr><tr><td>Project Name</td><td colspan="3"></td></tr><tr><td>Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td>Test Description</td><td colspan="3">Isolation Checks between all pins</td></tr><tr><td>Test Location</td><td></td><td>Date</td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin to Pin of SCP Connector</td></tr><tr><td colspan="8">Resistance between Pin 1 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>2</td><td>&lt;2Ω</td><td></td><td></td><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td></tr><tr><td>3</td><td>175±3.5Ω</td><td></td><td></td><td>28</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>4</td><td>175±3.5Ω</td><td></td><td></td><td>29</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>5</td><td>350±0.7Ω</td><td></td><td></td><td>30</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>6</td><td>453.5±1.5KΩ</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>7</td><td>175±3.5Ω</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>8</td><td>175±3.5Ω</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>9</td><td>350±0.7Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>453.5±1.5KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>175±3.5Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>12</td><td>350±0.7Ω</td><td></td><td></td><td>37</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>13</td><td>453.5±1.5KΩ</td><td></td><td></td><td>38</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>14</td><td>175±3.5Ω</td><td></td><td></td><td>39</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>15</td><td>175±3.5Ω</td><td></td><td></td><td>40</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>16</td><td>350±0.7Ω</td><td></td><td></td><td>41</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>17</td><td>453.5±1.5KΩ</td><td></td><td></td><td>42</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>18</td><td>175±3.5Ω</td><td></td><td></td><td>43</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>19</td><td>&gt;100KΩ</td><td></td><td></td><td>44</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>20</td><td>&gt;100KΩ</td><td></td><td></td><td>45</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>21</td><td>480±9.6KΩ</td><td></td><td></td><td>46</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>22</td><td>175±3.5Ω</td><td></td><td></td><td>47</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>23</td><td>&gt;100KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;100KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

Resistance between Pin 2 to All Pins of SCP Connector   

<table><tr><td>25</td><td>480±9.6KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>26</td><td>175±3.5Ω</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>3</td><td>175±3.5Ω</td><td></td><td></td><td>28</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>4</td><td>175±3.5Ω</td><td></td><td></td><td>29</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>5</td><td>350±0.7Ω</td><td></td><td></td><td>30</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>6</td><td>453.5±1.5KΩ</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>7</td><td>175±3.5Ω</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>8</td><td>175±3.5Ω</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>9</td><td>350±0.7Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>453.5±1.5KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>175±3.5Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>12</td><td>350±0.7Ω</td><td></td><td></td><td>37</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>13</td><td>453.5±1.5KΩ</td><td></td><td></td><td>38</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>14</td><td>175±3.5Ω</td><td></td><td></td><td>39</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>15</td><td>175±3.5Ω</td><td></td><td></td><td>40</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>16</td><td>350±0.7Ω</td><td></td><td></td><td>41</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>17</td><td>453.5±1.5KΩ</td><td></td><td></td><td>42</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>18</td><td>175±3.5Ω</td><td></td><td></td><td>43</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>44</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>20</td><td>548±11KΩ</td><td></td><td></td><td>45</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>46</td><td>175±3.5Ω</td><td></td><td></td></tr><tr><td>22</td><td>175±3.5Ω</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>24</td><td>548±11KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>26</td><td>175±3.5Ω</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Resistance between Pin 3 to All Pins of SCP Connector   

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>4</td><td>&lt;2Ω</td><td></td><td></td><td>28</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>5</td><td>525±2.1Ω</td><td></td><td></td><td>29</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>6</td><td>453.5±1.5KΩ</td><td></td><td></td><td>30</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>7</td><td>&lt;2Ω</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>8</td><td>&lt;2Ω</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>9</td><td>525±2.1Ω</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>453.5±1.5KΩ</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>&lt;2Ω</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>525±2.1Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>13</td><td>453.5±1.5KΩ</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>14</td><td>&lt;2Ω</td><td></td><td></td><td>38</td><td>120±2.4KΩ</td><td></td><td></td></tr><tr><td>15</td><td>&lt;2Ω</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>16</td><td>525±2.1Ω</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>17</td><td>453.5±1.5KΩ</td><td></td><td></td><td>41</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>18</td><td>&lt;2Ω</td><td></td><td></td><td>42</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>43</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1Ω</td><td></td><td></td><td>44</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>45</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>46</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 4 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>5</td><td>525±2.1Ω</td><td></td><td></td><td>29</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>6</td><td>548±11KΩ</td><td></td><td></td><td>30</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>7</td><td>&lt;2Ω</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>8</td><td>&lt;2Ω</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>9</td><td>525±2.1Ω</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>548±11KΩ</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>&lt;2Ω</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>525±2.1Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>13</td><td>548±11KΩ</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>14</td><td>&lt;2Ω</td><td></td><td></td><td>38</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td colspan="8"></td></tr><tr><td>15</td><td>&lt;2Ω</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>16</td><td>525±2.1Ω</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>17</td><td>548±11KΩ</td><td></td><td></td><td>41</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>18</td><td>&lt;2Ω</td><td></td><td></td><td>42</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>43</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1KΩ</td><td></td><td></td><td>44</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>45</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>46</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 5 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>6</td><td>&gt;100KΩ</td><td></td><td></td><td>29</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>7</td><td>525±2.1Ω</td><td></td><td></td><td>30</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>8</td><td>525±2.1Ω</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>9</td><td>700±1.4KΩ</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>&gt;100KΩ</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>525±2.1Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>700±1.4KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>13</td><td>&gt;100KΩ</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>14</td><td>525±2.1Ω</td><td></td><td></td><td>37</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>15</td><td>525±2.1KΩ</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>16</td><td>700±1.4KΩ</td><td></td><td></td><td>39</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>40</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>18</td><td>525±2.1Ω</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>22</td><td>525±2.1Ω</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr></table>

Resistance between Pin 6 to All Pins of SCP Connector   

<table><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>47</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>26</td><td>525±2.1KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>7</td><td>&gt;453.5KΩ</td><td></td><td></td><td>30</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>8</td><td>&gt;453.5KΩ</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>9</td><td>&gt;453.5KΩ</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>&gt;500KΩ</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>&gt;453.5KΩ</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>&gt;453.5KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>13</td><td>&gt;500KΩ</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>14</td><td>&gt;453.5KΩ</td><td></td><td></td><td>37</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>15</td><td>&gt;453.5KΩ</td><td></td><td></td><td>38</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>16</td><td>&gt;453.5KΩ</td><td></td><td></td><td>39</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;500KΩ</td><td></td><td></td><td>40</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>18</td><td>&gt;453.5KΩ</td><td></td><td></td><td>41</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>19</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>20</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>21</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&gt;453.5KΩ</td><td></td><td></td><td>45</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>23</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;453.5KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;453.5KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;500KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 7 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>8</td><td>&lt;2Ω</td><td></td><td></td><td>30</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>9</td><td>&gt;500Ω</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>&gt;10KΩ</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>&lt;2Ω</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>&gt;500Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>13</td><td>&gt;100KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>14</td><td>&lt;2Ω</td><td></td><td></td><td>36</td><td>&gt;52K</td><td></td><td></td></tr><tr><td>15</td><td>&lt;2Ω</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>16</td><td>&gt;500Ω</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>18</td><td>&lt;2Ω</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 8 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>9</td><td>&gt;500Ω</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>10</td><td>&gt;100KΩ</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>&lt;2Ω</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>525±2.1Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>13</td><td>&gt;100KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>14</td><td>&lt;2Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>15</td><td>&lt;2Ω</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>16</td><td>&gt;500Ω</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>18</td><td>&lt;2Ω</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 9 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>10</td><td>&gt;100KΩ</td><td></td><td></td><td>31</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>11</td><td>&gt;500Ω</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>700±1.4KΩ</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>13</td><td>&gt;100KΩ</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>14</td><td>525±2.7Ω</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>15</td><td>525±2.7Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>16</td><td>700±1.4KΩ</td><td></td><td></td><td>37</td><td>525±2.7Ω</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>18</td><td>525±2.7Ω</td><td></td><td></td><td>39</td><td>525±2.7Ω</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>40</td><td>525±2.7Ω</td><td></td><td></td></tr><tr><td>20</td><td>525±2.7KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>21</td><td>548±11KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>22</td><td>525±2.7Ω</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.7KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>26</td><td>525±2.7Ω</td><td></td><td></td><td>47</td><td>525±2.7Ω</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2Ω</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 10 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>11</td><td>&gt;453.5KΩ</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>12</td><td>&gt;453.5KΩ</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>13</td><td>&gt;500KΩ</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>14</td><td>&gt;453.5KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>15</td><td>&gt;453.5KΩ</td><td></td><td></td><td>36</td><td>&gt;52MΩ</td><td></td><td></td></tr><tr><td>16</td><td>&gt;453.5KΩ</td><td></td><td></td><td>37</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;500KΩ</td><td></td><td></td><td>38</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>18</td><td>&gt;453.5KΩ</td><td></td><td></td><td>39</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>19</td><td>&gt;1MΩ</td><td></td><td></td><td>40</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>20</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>21</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&gt;453.5KΩ</td><td></td><td></td><td>43</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>23</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;453.5KΩ</td><td></td><td></td><td>47</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;453.5KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;500KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 11 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>12</td><td>&gt;500Ω</td><td></td><td></td><td>32</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>13</td><td>&gt;100KΩ</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>14</td><td>&lt;2Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>15</td><td>&lt;2Ω</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>16</td><td>&gt;500Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>18</td><td>&lt;2Ω</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr></table>

Resistance between Pin 12 to All Pins of SCP Connector   

<table><tr><td>20</td><td>525±2.7KΩ</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.7KΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>13</td><td>&gt;100KΩ</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>14</td><td>525±2.7Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>15</td><td>525±2.7Ω</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>16</td><td>700±1.4KΩ</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>37</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>18</td><td>525±2.7Ω</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>39</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>20</td><td>525±2.7KΩ</td><td></td><td></td><td>40</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>22</td><td>525±2.7Ω</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.7KΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>26</td><td>525±2.7KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>47</td><td>525±2.7Ω</td><td></td><td></td></tr><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 13 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>14</td><td>&gt;453.5KΩ</td><td></td><td></td><td>33</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>15</td><td>&gt;453.5KΩ</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>16</td><td>&gt;453.5KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;500KΩ</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>18</td><td>&gt;453.5KΩ</td><td></td><td></td><td>37</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>19</td><td>&gt;1MΩ</td><td></td><td></td><td>38</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>20</td><td>&gt;1MΩ</td><td></td><td></td><td>39</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>21</td><td>&gt;1MΩ</td><td></td><td></td><td>40</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&gt;453.5KΩ</td><td></td><td></td><td>41</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>23</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;453.5KΩ</td><td></td><td></td><td>45</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;453.5KΩ</td><td></td><td></td><td>46</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 14 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>15</td><td>&lt;2Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>16</td><td>&gt;500Ω</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>18</td><td>&lt;2Ω</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>38</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1KΩ</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 15 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>16</td><td>&gt;500Ω</td><td></td><td></td><td>34</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>18</td><td>&lt;2Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1KΩ</td><td></td><td></td><td>38</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>27</td><td>925±18.5KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 16 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>17</td><td>&gt;100KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>18</td><td>525±2.1Ω</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>19</td><td>548±11KΩ</td><td></td><td></td><td>37</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>20</td><td>525±2.1KΩ</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>39</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>22</td><td>525±2.1Ω</td><td></td><td></td><td>40</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1Ω</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>26</td><td>525±2.1Ω</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr></table>

Resistance between Pin 17 to All Pins of SCP Connector   

<table><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>525±2.1Ω</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>18</td><td>&gt;453.5KΩ</td><td></td><td></td><td>35</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>19</td><td>&gt;1MΩ</td><td></td><td></td><td>36</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>20</td><td>&gt;1MΩ</td><td></td><td></td><td>37</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>21</td><td>&gt;1MΩ</td><td></td><td></td><td>38</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&gt;453.5KΩ</td><td></td><td></td><td>39</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>23</td><td>&gt;1MΩ</td><td></td><td></td><td>40</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>43</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>44</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;453.5KΩ</td><td></td><td></td><td>45</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;500KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;453.5KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

Resistance between Pin 18 to All Pins of SCP Connector   

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>19</td><td>525±2.1KΩ</td><td></td><td></td><td>36</td><td>&gt;52KΩ</td><td></td><td></td></tr><tr><td>20</td><td>548±11KΩ</td><td></td><td></td><td>37</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>21</td><td>925±18.5KΩ</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&lt;2Ω</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>23</td><td>548±11KΩ</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>24</td><td>525±2.1KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>25</td><td>925±18.5KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr></table>

Resistance between Pin 19 to All Pins of SCP Connector   

<table><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>20</td><td>&gt;1MΩ</td><td></td><td></td><td>36</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>21</td><td>&gt;1MΩ</td><td></td><td></td><td>37</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&gt;100KΩ</td><td></td><td></td><td>38</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>23</td><td>&gt;1MΩ</td><td></td><td></td><td>39</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>40</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;100KΩ</td><td></td><td></td><td>42</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;400KΩ</td><td></td><td></td><td>43</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>44</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

Resistance between Pin 20 to All Pins of SCP Connector   

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>21</td><td>&gt;1MΩ</td><td></td><td></td><td>37</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>22</td><td>&gt;100KΩ</td><td></td><td></td><td>38</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>23</td><td>&gt;1MΩ</td><td></td><td></td><td>39</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>40</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;100KΩ</td><td></td><td></td><td>42</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;400KΩ</td><td></td><td></td><td>43</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>44</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

Resistance between Pin 21 to All Pins of SCP Connector   

<table><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;400KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>22</td><td>&gt;100KΩ</td><td></td><td></td><td>37</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>23</td><td>&gt;1MΩ</td><td></td><td></td><td>38</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>39</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>40</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;400KΩ</td><td></td><td></td><td>41</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;400KΩ</td><td></td><td></td><td>42</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;400KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

Resistance between Pin 22 to All Pins of SCP Connector   

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>23</td><td>&gt;100KΩ</td><td></td><td></td><td>38</td><td>&gt;120KΩ</td><td></td><td></td></tr><tr><td>24</td><td>&gt;100KΩ</td><td></td><td></td><td>39</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>25</td><td>&gt;100KΩ</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>26</td><td>&lt;2Ω</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;52KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&lt;2Ω</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 23 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>24</td><td>&gt;1MΩ</td><td></td><td></td><td>38</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>39</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;100KΩ</td><td></td><td></td><td>40</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;400KΩ</td><td></td><td></td><td>41</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>42</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;400KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;400KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 24 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>25</td><td>&gt;1MΩ</td><td></td><td></td><td>39</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>26</td><td>&gt;100KΩ</td><td></td><td></td><td>40</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;400KΩ</td><td></td><td></td><td>41</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>42</td><td>&gt;400K2</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;400KΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 25 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>26</td><td>&gt;400KΩ</td><td></td><td></td><td>39</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>27</td><td>&gt;400KΩ</td><td></td><td></td><td>40</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>28</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;400KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;400KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;100KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 26 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>27</td><td>9.88±0.2KΩ</td><td></td><td></td><td>40</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>28</td><td>&gt;100KΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;52KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&lt;2Ω</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;100KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&lt;2Ω</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 27 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>28</td><td>&gt;400KΩ</td><td></td><td></td><td>40</td><td>9.88±0.2KΩ</td><td></td><td></td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;110KΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>9.88±0.2KΩ</td><td></td><td></td></tr><tr><td>36</td><td></td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>9.88±0.2KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;110KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>9.88±0.2KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 28 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>29</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;400KΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;400KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;400KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;400KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 29 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>30</td><td>&gt;1MΩ</td><td></td><td></td><td>41</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

Resistance between Pin 30 to All Pins of SCP Connector   

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>31</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 31 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>32</td><td>&gt;1MΩ</td><td></td><td></td><td>42</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>33</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 32 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>33</td><td>122±2Ω</td><td></td><td></td><td>43</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;1MΩ.</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>42</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 33 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>34</td><td>&gt;1MΩ</td><td></td><td></td><td>43</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>42</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 34 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>35</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>42</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Resistance between Pin 35 to All Pins of SCP Connector   

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>36</td><td>&gt;1MΩ</td><td></td><td></td><td>44</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>37</td><td>&gt;1MΩ</td><td></td><td></td><td>45</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;1MΩ</td><td></td><td></td><td>46</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1MΩ</td><td></td><td></td><td>47</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1MΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;1MΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>42</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

Resistance between Pin 36 to All Pins of SCP Connector   

<table><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>37</td><td>&gt;1.6KΩ</td><td></td><td></td><td>45</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>38</td><td>&gt;100KΩ</td><td></td><td></td><td>46</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>39</td><td>&gt;1.6KΩ</td><td></td><td></td><td>47</td><td>&gt;1.6KΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1.6KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;100KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>42</td><td>&gt;100KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;100KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>44</td><td>&gt;100KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 37 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>38</td><td>&gt;100KΩ</td><td></td><td></td><td>45</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>39</td><td>&lt;2Ω</td><td></td><td></td><td>46</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>40</td><td>&lt;2Ω</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>41</td><td>&gt;100KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>42</td><td>&gt;100KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;100KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>44</td><td>&gt;100KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 38 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>39</td><td>&gt;1KΩ</td><td></td><td></td><td>46</td><td>&gt;1KΩ</td><td></td><td></td></tr><tr><td>40</td><td>&gt;1KΩ</td><td></td><td></td><td>47</td><td>&gt;1KΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;1KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>42</td><td>&gt;1KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;1KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>44</td><td>&gt;1KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>45</td><td>&gt;1KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 39 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>40</td><td>&lt;2Ω</td><td></td><td></td><td>46</td><td>&gt;100KΩ</td><td></td><td></td></tr><tr><td>41</td><td>&gt;100KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>42</td><td>&gt;100KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;100KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>44</td><td>&gt;100KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>45</td><td>&gt;100KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 40 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>41</td><td>&gt;100KΩ</td><td></td><td></td><td>47</td><td>&lt;2Ω</td><td></td><td></td></tr><tr><td>42</td><td>&gt;100KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;100KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>44</td><td>&gt;100KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>45</td><td>&gt;100KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>46</td><td>&gt;100KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 41 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>42</td><td>&gt;1KΩ</td><td></td><td></td><td>47</td><td>&gt;1KΩ</td><td></td><td></td></tr><tr><td>43</td><td>&gt;1KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>44</td><td>&gt;1KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>45</td><td>&gt;1KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>46</td><td>&gt;1KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 42 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/Not OK</td></tr><tr><td>43</td><td>&gt;1KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>44</td><td>&gt;1KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>45</td><td>&gt;1KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>46</td><td>&gt;1KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>47</td><td>&gt;1KΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 43 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>44</td><td>&gt;1KΩ</td><td></td><td></td><td>48</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>45</td><td>&gt;1KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>46</td><td>&gt;1KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>47</td><td>&gt;1KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 44 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>45</td><td>&gt;1KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>46</td><td>&gt;1KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>47</td><td>&gt;1KΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>48</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 45 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>46</td><td>&gt;1KΩ</td><td></td><td></td><td>49</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>47</td><td>&gt;1KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>48</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td colspan="8">Resistance between Pin 46 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>47</td><td>&gt;1KΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>48</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>49</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 47 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>48</td><td>&gt;1MΩ</td><td></td><td></td><td>50</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>49</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 48 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>49</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr><tr><td>50</td><td>&gt;1MΩ</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 49 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>50</td><td>&gt;1MΩ</td><td></td><td></td><td>51</td><td>&gt;1MΩ</td><td></td><td></td></tr></table>

<table><tr><td colspan="8">Resistance between Pin 50 to All Pins of SCP Connector</td></tr><tr><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td><td>Connector Pin No</td><td>Expected</td><td>Observed</td><td>OK/ Not OK</td></tr><tr><td>51</td><td>122±2Ω</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

Note: Pin to Pin test to be done in 1 out of lot.

MANUFACTURER

DOFI/RCI

# Connector 51 Pin Details

![](images/5f7664de8d57bcc5f4505597b906892bc5ae09437b2a735771efc8601a27a8f0.jpg)

# Appendix-E

# RTD Temperature vs. Resistance Table

(PT100 Table)

# Appendix-E

# RTD Temperature vs. Resistance Table

T&P

INSTRUMENTS

# Technical Information Data Bulletin

# Platinum 100 Ohms (Pt100)

α0.00385

# Temperature vs Resistance Table

Resistance @ $0^{\circ}\mathrm{C}$

Temperature Range

-320to1522F

-200to650C

Recommended Applications:

Where higher accuracy is needed in general purpose and industrial application.

Accuracy:

Grade A Tolerance = ±0.13 + 0.0017 °C

Grade B tolerance = ±0.25 + 0.0042 + 11°C

<table><tr><td>Temp</td><td>0</td><td>-1</td><td>-2</td><td>-3</td><td>-4</td><td>-5</td><td>-6</td><td>-7</td><td>-8</td><td>-9</td></tr><tr><td>-200</td><td>18.520</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>-190</td><td>22.826</td><td>22.397</td><td>21.967</td><td>21.538</td><td>21.108</td><td>20.677</td><td>20.247</td><td>19.815</td><td>19.384</td><td>18.952</td></tr><tr><td>-180</td><td>27.096</td><td>26.671</td><td>26.245</td><td>25.819</td><td>25.392</td><td>24.965</td><td>24.538</td><td>24.110</td><td>23.682</td><td>23.254</td></tr><tr><td>-170</td><td>31.335</td><td>30.913</td><td>30.490</td><td>30.067</td><td>29.643</td><td>29.220</td><td>28.796</td><td>28.371</td><td>27.947</td><td>27.522</td></tr><tr><td>-160</td><td>35.543</td><td>35.124</td><td>34.704</td><td>34.284</td><td>33.864</td><td>33.443</td><td>33.022</td><td>32.601</td><td>32.179</td><td>31.757</td></tr><tr><td>-150</td><td>39.723</td><td>39.306</td><td>38.889</td><td>38.472</td><td>38.055</td><td>37.637</td><td>37.219</td><td>36.800</td><td>36.382</td><td>35.963</td></tr><tr><td>-140</td><td>43.876</td><td>43.462</td><td>43.048</td><td>42.633</td><td>42.218</td><td>41.803</td><td>41.388</td><td>40.972</td><td>40.556</td><td>40.140</td></tr><tr><td>-130</td><td>48.005</td><td>47.593</td><td>47.181</td><td>46.769</td><td>46.356</td><td>45.944</td><td>45.531</td><td>45.118</td><td>44.704</td><td>44.290</td></tr><tr><td>-120</td><td>52.110</td><td>51.700</td><td>51.291</td><td>50.881</td><td>50.471</td><td>50.060</td><td>49.650</td><td>49.239</td><td>48.828</td><td>48.416</td></tr><tr><td>-110</td><td>56.193</td><td>55.786</td><td>55.378</td><td>54.970</td><td>54.562</td><td>54.154</td><td>53.746</td><td>53.337</td><td>52.928</td><td>52.519</td></tr><tr><td>-100</td><td>60.256</td><td>59.850</td><td>59.445</td><td>59.039</td><td>58.633</td><td>58.227</td><td>57.821</td><td>57.414</td><td>57.007</td><td>56.600</td></tr><tr><td>-90</td><td>64.300</td><td>63.896</td><td>63.492</td><td>63.088</td><td>62.684</td><td>62.280</td><td>61.876</td><td>61.471</td><td>61.066</td><td>60.661</td></tr><tr><td>-80</td><td>68.375</td><td>67.924</td><td>67.522</td><td>67.120</td><td>66.717</td><td>66.315</td><td>65.912</td><td>65.509</td><td>65.106</td><td>64.703</td></tr><tr><td>-70</td><td>72.335</td><td>71.934</td><td>71.534</td><td>71.134</td><td>70.733</td><td>70.332</td><td>69.931</td><td>69.530</td><td>69.129</td><td>68.727</td></tr><tr><td>-60</td><td>76.328</td><td>75.929</td><td>75.530</td><td>75.132</td><td>74.732</td><td>74.333</td><td>73.934</td><td>73.534</td><td>73.134</td><td>72.735</td></tr><tr><td>-50</td><td>80.306</td><td>79.909</td><td>79.512</td><td>79.114</td><td>78.717</td><td>78.319</td><td>77.921</td><td>77.523</td><td>77.125</td><td>76.726</td></tr><tr><td>-40</td><td>84.271</td><td>83.875</td><td>83.479</td><td>83.083</td><td>82.687</td><td>82.290</td><td>81.894</td><td>81.497</td><td>81.100</td><td>80.703</td></tr><tr><td>-30</td><td>88.222</td><td>87.827</td><td>87.433</td><td>87.038</td><td>86.643</td><td>86.248</td><td>85.853</td><td>85.457</td><td>85.062</td><td>84.666</td></tr><tr><td>-20</td><td>92.160</td><td>91.767</td><td>91.373</td><td>90.980</td><td>90.586</td><td>90.192</td><td>89.799</td><td>89.404</td><td>89.010</td><td>88.616</td></tr><tr><td>-10</td><td>96.086</td><td>95.694</td><td>95.302</td><td>94.909</td><td>94.517</td><td>94.124</td><td>93.732</td><td>93.339</td><td>92.946</td><td>92.553</td></tr><tr><td>0</td><td>100.000</td><td>99.609</td><td>99.218</td><td>98.827</td><td>98.436</td><td>98.044</td><td>97.653</td><td>97.261</td><td>96.870</td><td>96.478</td></tr><tr><td>Temp</td><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td></tr><tr><td>0</td><td>100.000</td><td>100.391</td><td>100.781</td><td>101.172</td><td>101.562</td><td>101.953</td><td>102.343</td><td>102.733</td><td>103.123</td><td>103.513</td></tr><tr><td>10</td><td>103.903</td><td>104.292</td><td>104.682</td><td>105.071</td><td>105.460</td><td>105.849</td><td>106.238</td><td>106.627</td><td>107.016</td><td>107.405</td></tr><tr><td>20</td><td>107.794</td><td>108.182</td><td>108.570</td><td>108.959</td><td>109.347</td><td>109.735</td><td>110.123</td><td>110.510</td><td>110.898</td><td>111.286</td></tr><tr><td>30</td><td>111.673</td><td>112.060</td><td>112.447</td><td>112.835</td><td>113.221</td><td>113.608</td><td>113.995</td><td>114.382</td><td>114.768</td><td>115.155</td></tr><tr><td>40</td><td>115.541</td><td>115.927</td><td>116.313</td><td>116.699</td><td>117.085</td><td>117.470</td><td>117.856</td><td>118.241</td><td>118.627</td><td>119.012</td></tr><tr><td>50</td><td>119.397</td><td>119.782</td><td>120.167</td><td>120.552</td><td>120.936</td><td>121.321</td><td>121.705</td><td>122.090</td><td>122.474</td><td>122.858</td></tr><tr><td>60</td><td>123.242</td><td>123.626</td><td>124.009</td><td>124.393</td><td>124.777</td><td>125.160</td><td>125.543</td><td>125.926</td><td>126.309</td><td>126.692</td></tr><tr><td>70</td><td>127.075</td><td>127.458</td><td>127.840</td><td>128.223</td><td>128.605</td><td>128.987</td><td>129.370</td><td>129.752</td><td>130.133</td><td>130.515</td></tr><tr><td>80</td><td>130.897</td><td>131.278</td><td>131.660</td><td>132.041</td><td>132.422</td><td>132.803</td><td>133.184</td><td>133.565</td><td>133.946</td><td>134.326</td></tr><tr><td>90</td><td>134.707</td><td>135.087</td><td>135.468</td><td>135.848</td><td>136.228</td><td>136.608</td><td>136.987</td><td>137.367</td><td>137.747</td><td>138.126</td></tr><tr><td>100</td><td>138.505</td><td>138.885</td><td>139.264</td><td>139.643</td><td>140.022</td><td>140.400</td><td>140.779</td><td>141.158</td><td>141.536</td><td>141.914</td></tr><tr><td>110</td><td>142.293</td><td>142.671</td><td>143.049</td><td>143.426</td><td>143.804</td><td>144.182</td><td>144.559</td><td>144.937</td><td>145.314</td><td>145.691</td></tr><tr><td>120</td><td>146.068</td><td>146.445</td><td>146.822</td><td>147.198</td><td>147.575</td><td>147.951</td><td>148.328</td><td>148.704</td><td>149.080</td><td>149.456</td></tr><tr><td>130</td><td>149.832</td><td>150.208</td><td>150.583</td><td>150.959</td><td>151.334</td><td>151.710</td><td>152.085</td><td>152.460</td><td>152.835</td><td>153.210</td></tr><tr><td>140</td><td>153.584</td><td>153.959</td><td>154.333</td><td>154.708</td><td>155.082</td><td>155.456</td><td>155.830</td><td>156.204</td><td>156.578</td><td>156.952</td></tr><tr><td>150</td><td>157.325</td><td>157.699</td><td>158.072</td><td>158.445</td><td>158.818</td><td>159.191</td><td>159.564</td><td>159.937</td><td>160.309</td><td>160.682</td></tr><tr><td>160</td><td>161.054</td><td>161.427</td><td>161.799</td><td>162.171</td><td>162.543</td><td>162.915</td><td>163.286</td><td>163.658</td><td>164.030</td><td>164.401</td></tr><tr><td>170</td><td>164.772</td><td>165.143</td><td>165.514</td><td>165.885</td><td>166.256</td><td>166.627</td><td>166.997</td><td>167.368</td><td>167.738</td><td>168.108</td></tr><tr><td>180</td><td>168.478</td><td>168.848</td><td>169.218</td><td>169.588</td><td>169.958</td><td>170.327</td><td>170.696</td><td>171.066</td><td>171.435</td><td>171.804</td></tr><tr><td>190</td><td>172.173</td><td>172.542</td><td>172.910</td><td>173.279</td><td>173.648</td><td>174.016</td><td>174.384</td><td>174.752</td><td>175.120</td><td>175.488</td></tr><tr><td>200</td><td>175.856</td><td>176.224</td><td>176.591</td><td>176.959</td><td>177.326</td><td>177.693</td><td>178.060</td><td>178.427</td><td>178.794</td><td>179.161</td></tr><tr><td>210</td><td>179.528</td><td>179.894</td><td>180.260</td><td>180.627</td><td>180.993</td><td>181.359</td><td>181.725</td><td>182.091</td><td>182.456</td><td>182.822</td></tr><tr><td>220</td><td>183.188</td><td>183.553</td><td>183.918</td><td>184.283</td><td>184.648</td><td>185.013</td><td>185.378</td><td>185.743</td><td>186.107</td><td>186.472</td></tr><tr><td>230</td><td>186.836</td><td>187.200</td><td>187.564</td><td>187.928</td><td>188.292</td><td>188.656</td><td>189.019</td><td>189.383</td><td>189.746</td><td>190.110</td></tr><tr><td>240</td><td>190.473</td><td>190.836</td><td>191.199</td><td>191.562</td><td>191.924</td><td>192.287</td><td>192.649</td><td>193.012</td><td>193.374</td><td>193.736</td></tr><tr><td>250</td><td>194.098</td><td>194.460</td><td>194.822</td><td>195.183</td><td>195.545</td><td>195.906</td><td>196.268</td><td>196.629</td><td>196.990</td><td>197.351</td></tr><tr><td>260</td><td>197.712</td><td>198.073</td><td>198.433</td><td>198.794</td><td>199.154</td><td>199.514</td><td>199.875</td><td>200.235</td><td>200.595</td><td>200.954</td></tr><tr><td>270</td><td>201.314</td><td>201.674</td><td>202.033</td><td>202.393</td><td>202.752</td><td>203.111</td><td>203.470</td><td>203.829</td><td>204.188</td><td>204.546</td></tr><tr><td>280</td><td>204.905</td><td>205.263</td><td>205.622</td><td>205.980</td><td>206.338</td><td>206.696</td><td>207.054</td><td>207.411</td><td>207.769</td><td>208.127</td></tr></table>

Temperature & Process Instruments Inc.

Visit us on the web at www.tnp-instruments.com

1767 Contral Avenue * Suite 112 * Yonkers * NY * USA * 10710 * Phone: (914) 673-0333 Fax: (866) 292-1456

# Temperature vs Resistance Table

# Resistance @ $0^{\circ}\mathrm{C}$

Temperature Range

129191562F

-200 to 850°C

Accuracy:

Grade A Tolerance = ±0.13 + 0.0017 * 100°C

Grade B tolerance = ±[0.25 + 0.0042] C

Recommended Applications:

Where higher accuracy is needed in general purpose and industrial application.

<table><tr><td>Temp</td><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td></tr><tr><td>290</td><td>208.484</td><td>208.841</td><td>209.198</td><td>209.555</td><td>209.912</td><td>210.269</td><td>210.626</td><td>210.982</td><td>211.339</td><td>211.695</td></tr><tr><td>300</td><td>212.052</td><td>212.408</td><td>212.764</td><td>213.120</td><td>213.475</td><td>213.831</td><td>214.187</td><td>214.542</td><td>214.897</td><td>215.252</td></tr><tr><td>310</td><td>215.608</td><td>215.962</td><td>216.317</td><td>216.672</td><td>217.027</td><td>217.381</td><td>217.736</td><td>218.090</td><td>218.444</td><td>218.798</td></tr><tr><td>320</td><td>219.152</td><td>219.506</td><td>219.860</td><td>220.213</td><td>220.567</td><td>220.920</td><td>221.273</td><td>221.626</td><td>221.979</td><td>222.332</td></tr><tr><td>330</td><td>222.685</td><td>223.038</td><td>223.390</td><td>223.743</td><td>224.095</td><td>224.447</td><td>224.799</td><td>225.151</td><td>225.503</td><td>225.855</td></tr><tr><td>340</td><td>226.206</td><td>226.558</td><td>226.909</td><td>227.260</td><td>227.612</td><td>227.963</td><td>228.314</td><td>228.664</td><td>229.015</td><td>229.366</td></tr><tr><td>350</td><td>229.716</td><td>230.066</td><td>230.417</td><td>230.767</td><td>231.117</td><td>231.467</td><td>231.816</td><td>232.166</td><td>232.516</td><td>232.865</td></tr><tr><td>360</td><td>233.214</td><td>233.564</td><td>233.913</td><td>234.262</td><td>234.610</td><td>234.959</td><td>235.308</td><td>235.656</td><td>236.005</td><td>236.353</td></tr><tr><td>370</td><td>236.701</td><td>237.049</td><td>237.397</td><td>237.745</td><td>238.093</td><td>238.440</td><td>238.788</td><td>239.135</td><td>239.482</td><td>239.829</td></tr><tr><td>380</td><td>240.176</td><td>240.523</td><td>240.870</td><td>241.217</td><td>241.563</td><td>241.910</td><td>242.256</td><td>242.602</td><td>242.948</td><td>243.294</td></tr><tr><td>390</td><td>243.640</td><td>243.986</td><td>244.331</td><td>244.677</td><td>245.022</td><td>245.367</td><td>245.713</td><td>246.058</td><td>246.403</td><td>246.747</td></tr><tr><td>400</td><td>247.092</td><td>247.437</td><td>247.781</td><td>248.125</td><td>248.470</td><td>248.814</td><td>249.158</td><td>249.502</td><td>249.845</td><td>250.189</td></tr><tr><td>410</td><td>250.533</td><td>250.876</td><td>251.219</td><td>251.562</td><td>251.906</td><td>252.248</td><td>252.591</td><td>252.934</td><td>253.277</td><td>253.619</td></tr><tr><td>420</td><td>253.962</td><td>254.304</td><td>254.646</td><td>254.988</td><td>255.330</td><td>255.672</td><td>256.013</td><td>256.355</td><td>256.696</td><td>257.038</td></tr><tr><td>430</td><td>257.379</td><td>257.720</td><td>258.061</td><td>258.402</td><td>258.743</td><td>259.083</td><td>259.424</td><td>259.764</td><td>260.105</td><td>260.445</td></tr><tr><td>440</td><td>260.785</td><td>261.125</td><td>261.465</td><td>261.804</td><td>262.144</td><td>262.483</td><td>262.823</td><td>263.162</td><td>263.501</td><td>263.840</td></tr><tr><td>450</td><td>264.179</td><td>264.518</td><td>264.857</td><td>265.195</td><td>265.534</td><td>265.872</td><td>266.210</td><td>266.548</td><td>266.886</td><td>267.224</td></tr><tr><td>460</td><td>267.562</td><td>267.900</td><td>268.237</td><td>268.574</td><td>268.912</td><td>269.249</td><td>269.586</td><td>269.923</td><td>270.260</td><td>270.597</td></tr><tr><td>470</td><td>270.933</td><td>271.270</td><td>271.606</td><td>271.942</td><td>272.278</td><td>272.614</td><td>272.950</td><td>273.286</td><td>273.622</td><td>273.957</td></tr><tr><td>480</td><td>274.293</td><td>274.628</td><td>274.963</td><td>275.298</td><td>275.633</td><td>275.968</td><td>276.303</td><td>276.638</td><td>276.972</td><td>277.307</td></tr><tr><td>490</td><td>277.641</td><td>277.975</td><td>278.309</td><td>278.643</td><td>278.977</td><td>279.311</td><td>279.644</td><td>279.978</td><td>280.311</td><td>280.644</td></tr><tr><td>500</td><td>280.978</td><td>281.311</td><td>281.643</td><td>281.976</td><td>282.309</td><td>282.641</td><td>282.974</td><td>283.306</td><td>283.638</td><td>283.971</td></tr><tr><td>510</td><td>284.303</td><td>284.634</td><td>284.966</td><td>285.298</td><td>285.629</td><td>285.961</td><td>286.292</td><td>286.623</td><td>286.954</td><td>287.285</td></tr><tr><td>520</td><td>287.616</td><td>287.947</td><td>288.277</td><td>288.608</td><td>288.938</td><td>289.268</td><td>289.599</td><td>289.929</td><td>290.258</td><td>290.588</td></tr><tr><td>530</td><td>290.918</td><td>291.247</td><td>291.577</td><td>291.906</td><td>292.235</td><td>292.565</td><td>292.894</td><td>293.222</td><td>293.551</td><td>293.880</td></tr><tr><td>540</td><td>294.208</td><td>294.537</td><td>294.865</td><td>295.193</td><td>295.521</td><td>295.849</td><td>296.177</td><td>296.505</td><td>296.832</td><td>297.160</td></tr><tr><td>550</td><td>297.487</td><td>297.814</td><td>298.142</td><td>298.469</td><td>298.795</td><td>299.122</td><td>299.449</td><td>299.775</td><td>300.102</td><td>300.428</td></tr><tr><td>560</td><td>300.754</td><td>301.080</td><td>301.406</td><td>301.732</td><td>302.058</td><td>302.384</td><td>302.709</td><td>303.035</td><td>303.360</td><td>303.685</td></tr><tr><td>570</td><td>304.010</td><td>304.335</td><td>304.660</td><td>304.985</td><td>305.309</td><td>305.634</td><td>305.958</td><td>306.282</td><td>306.606</td><td>306.930</td></tr><tr><td>580</td><td>307.254</td><td>307.578</td><td>307.902</td><td>308.225</td><td>308.549</td><td>308.872</td><td>309.195</td><td>309.518</td><td>309.841</td><td>310.164</td></tr><tr><td>590</td><td>310.487</td><td>310.810</td><td>311.132</td><td>311.454</td><td>311.777</td><td>312.099</td><td>312.421</td><td>312.743</td><td>313.065</td><td>313.386</td></tr><tr><td>600</td><td>313.708</td><td>314.029</td><td>314.351</td><td>314.672</td><td>314.993</td><td>315.314</td><td>315.635</td><td>315.956</td><td>316.277</td><td>316.597</td></tr><tr><td>610</td><td>316.918</td><td>317.238</td><td>317.558</td><td>317.878</td><td>318.198</td><td>318.518</td><td>318.838</td><td>319.157</td><td>319.477</td><td>319.796</td></tr><tr><td>620</td><td>320.115</td><td>320.435</td><td>320.754</td><td>321.073</td><td>321.391</td><td>321.710</td><td>322.029</td><td>322.347</td><td>322.666</td><td>322.984</td></tr><tr><td>630</td><td>323.302</td><td>323.620</td><td>323.938</td><td>324.256</td><td>324.573</td><td>324.891</td><td>325.208</td><td>325.526</td><td>325.843</td><td>326.160</td></tr><tr><td>640</td><td>326.477</td><td>326.794</td><td>327.110</td><td>327.427</td><td>327.744</td><td>328.060</td><td>328.376</td><td>328.692</td><td>329.008</td><td>329.324</td></tr><tr><td>650</td><td>329.640</td><td>329.956</td><td>330.271</td><td>330.587</td><td>330.902</td><td>331.217</td><td>331.533</td><td>331.848</td><td>332.162</td><td>332.477</td></tr><tr><td>660</td><td>332.792</td><td>333.106</td><td>333.421</td><td>333.735</td><td>334.049</td><td>334.363</td><td>334.677</td><td>334.991</td><td>335.305</td><td>335.619</td></tr><tr><td>670</td><td>335.932</td><td>336.246</td><td>336.559</td><td>336.872</td><td>337.185</td><td>337.498</td><td>337.811</td><td>338.123</td><td>338.436</td><td>338.748</td></tr><tr><td>680</td><td>339.061</td><td>339.373</td><td>339.685</td><td>339.997</td><td>340.309</td><td>340.621</td><td>340.932</td><td>341.244</td><td>341.555</td><td>341.867</td></tr><tr><td>690</td><td>342.178</td><td>342.489</td><td>342.800</td><td>343.111</td><td>343.422</td><td>343.732</td><td>344.043</td><td>344.353</td><td>344.663</td><td>344.973</td></tr><tr><td>700</td><td>345.284</td><td>345.593</td><td>345.903</td><td>346.213</td><td>346.522</td><td>346.832</td><td>347.141</td><td>347.451</td><td>347.760</td><td>348.069</td></tr><tr><td>710</td><td>348.378</td><td>348.686</td><td>348.995</td><td>349.303</td><td>349.612</td><td>349.920</td><td>350.228</td><td>350.536</td><td>350.844</td><td>351.152</td></tr><tr><td>720</td><td>351.460</td><td>351.768</td><td>352.075</td><td>352.382</td><td>352.690</td><td>352.997</td><td>353.304</td><td>353.611</td><td>353.918</td><td>354.224</td></tr><tr><td>730</td><td>354.531</td><td>354.837</td><td>355.144</td><td>355.450</td><td>355.756</td><td>356.062</td><td>356.368</td><td>356.674</td><td>356.979</td><td>357.285</td></tr><tr><td>740</td><td>357.590</td><td>357.896</td><td>358.201</td><td>358.506</td><td>358.811</td><td>359.116</td><td>359.420</td><td>359.725</td><td>360.029</td><td>360.334</td></tr><tr><td>750</td><td>360.638</td><td>360.942</td><td>361.246</td><td>361.550</td><td>361.854</td><td>362.158</td><td>362.461</td><td>362.765</td><td>363.068</td><td>363.371</td></tr><tr><td>760</td><td>363.674</td><td>363.977</td><td>364.280</td><td>364.583</td><td>364.886</td><td>365.188</td><td>365.491</td><td>365.793</td><td>366.095</td><td>366.397</td></tr><tr><td>770</td><td>366.699</td><td>367.001</td><td>367.303</td><td>367.604</td><td>367.906</td><td>368.207</td><td>368.508</td><td>368.810</td><td>369.111</td><td>369.412</td></tr><tr><td>780</td><td>369.712</td><td>370.013</td><td>370.314</td><td>370.614</td><td>370.914</td><td>371.215</td><td>371.515</td><td>371.815</td><td>372.115</td><td>372.414</td></tr><tr><td>790</td><td>372.714</td><td>373.013</td><td>373.313</td><td>373.612</td><td>373.911</td><td>374.210</td><td>374.509</td><td>374.808</td><td>375.107</td><td>375.406</td></tr></table>

Temperature & Process Instruments Inc.

Visit us on the web at www.np-instruments.com

1767 Contral Avenue * Suite 112 * Yonkers * NY * USA * 10710 * Phone: (914) 673-0333 Fax: (866) 292-1456

# Temperature vs Resistance Table

# Resistance @ $0^{\circ}\mathrm{C}$

Temperature Range

320 to 1962 F

-200 to 850°C

Accuracy:

Grade A toleance = ±0.13 + 0.0017 * 100

Grade B tolerance = [0.25 + 0.0042 h] °C

Recommended Applications:

Where higher accuracy is needed in general purpose and industrial application.

<table><tr><td>Temp</td><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td></tr><tr><td>800</td><td>375.704</td><td>376.002</td><td>376.301</td><td>376.599</td><td>376.897</td><td>377.195</td><td>377.493</td><td>377.790</td><td>378.088</td><td>378.385</td></tr><tr><td>810</td><td>378.683</td><td>378.980</td><td>379.277</td><td>379.574</td><td>379.871</td><td>380.167</td><td>380.464</td><td>380.761</td><td>381.057</td><td>381.353</td></tr><tr><td>820</td><td>381.649</td><td>381.946</td><td>382.242</td><td>382.537</td><td>382.833</td><td>383.129</td><td>383.424</td><td>383.720</td><td>384.015</td><td>384.310</td></tr><tr><td>830</td><td>384.605</td><td>384.900</td><td>385.195</td><td>385.489</td><td>385.784</td><td>386.078</td><td>386.373</td><td>386.667</td><td>386.961</td><td>387.255</td></tr><tr><td>840</td><td>387.549</td><td>387.843</td><td>388.136</td><td>388.430</td><td>388.723</td><td>389.016</td><td>389.310</td><td>389.603</td><td>389.896</td><td>390.188</td></tr><tr><td>850</td><td>390.481</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

# Appendix-F

# Conformance Reports

QT Conformance Report   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="3"></td></tr><tr><td colspan="2">Test Location</td><td></td><td>Date</td><td></td></tr></table>

<table><tr><td rowspan="2">Sl.
No</td><td rowspan="2">Test</td><td>Test Specification</td><td rowspan="2">Conforming
/Non-
Conforming</td><td rowspan="2">Remarks</td></tr><tr><td>Qualification Testing</td></tr><tr><td>1.</td><td>CEMILAC</td><td>- High temperature Storage
-Thermal Shock
- Burn in test</td><td></td><td></td></tr><tr><td>2.</td><td>Initial cold checks &amp; functional checks</td><td>Initial Performance Checks Cold checks, continuity checks and functional checks at 5V</td><td></td><td></td></tr><tr><td>3.</td><td>ESS</td><td>Pre-vibration:
Freq:20 Hz - 2000 Hz
20 Hz - 100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes
ThermalCycling
-30°Cfor60min.
+70°Cfor 60 min.
Rate of changeofTemp:10°C /min. No. ofCycles: 8
Post- vibration:
20 Hz - 2000 Hz
20 Hz - 100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes</td><td></td><td>PREET, INSET/POET</td></tr><tr><td>4.</td><td>Low Temperature</td><td>-30 ± 3°C; 16 hrs.
Last 1 hr. Operation.</td><td></td><td>Test No 2 JSS
0256-01PREET, INSET/POET</td></tr><tr><td>5.</td><td>High Temperature</td><td>55 ± 3°C; 6 hrs.
65 ± 3°C; 4 hrs.
55 ± 3°C; 6 hrs. Last 1 hr. Operation.</td><td></td><td>Test No 1 JSS
0256-01
PREET, INSET/POET</td></tr><tr><td>6.</td><td>Tropical Exposure</td><td>20 ± 2°C; 6 hrs.
Ramp Up to 45°C in 3 hrs.
45 ±2°C; 12 hrs.
Ramp Down to 20°C in 3 hrs.
RH &gt; 95%, No. of Cycles - 14</td><td></td><td>PREET, INSET during last 30 minutes (@40 ±2°C; RH ≥ 95%) followed by POET</td></tr><tr><td>7.</td><td>Acceleration</td><td>Long.: 75 g; 45 s
Lateral: 60 g; 45 s
6 Directions, 2 directions in each axis</td><td></td><td>Test No 16 JSS
0256-01
PREET, INSET/POET</td></tr><tr><td>8.</td><td>Shock</td><td>60g; 3 ms
3 shocks per axis (Lon. Axis)
3 Axes, 6 Directions.</td><td></td><td>Should be Based on shock responses measured in Static and HOT test(Nominal functionality will be Checked)</td></tr><tr><td>9.</td><td>EMI/EMC test</td><td>RE102; CE 102; CS 101; CS 114; CS 115; CS 116; CS118; RS 103</td><td></td><td>MIL STD 461E
PREET, INSET/POET</td></tr><tr><td>10</td><td>Final cold checks &amp; Final functional checks</td><td>Final Performance Checks Cold checks, continuity checks and Final functional checks at 5V</td><td></td><td></td></tr></table>

Observations:

UNIT: Cleared/Not cleared

MANUFACTURER

DOFI/RCI

DR&QA

AT Conformance Report   

<table><tr><td>Unit Name</td><td colspan="2">CPSCP_V2.2</td><td>Unit S.No.</td><td></td></tr><tr><td>Model No.</td><td colspan="2">CPSCP_SMA_24.2</td><td>Work Centre</td><td></td></tr><tr><td colspan="2">Unit Manufacturer</td><td colspan="3"></td></tr><tr><td colspan="2">Supply Order No.</td><td colspan="3"></td></tr><tr><td colspan="2">Project Name</td><td colspan="3"></td></tr><tr><td colspan="2">Reference Document</td><td colspan="3">RCI/DOFI/CPSCP_SMA24.2(V2.2)/ATP/01</td></tr><tr><td colspan="2">Test Description</td><td colspan="3"></td></tr><tr><td colspan="2">Test Location</td><td></td><td>Date</td><td></td></tr></table>

<table><tr><td rowspan="2">Sl.
No</td><td rowspan="2">Test</td><td>Test Specification</td><td rowspan="2">Conforming /Non-Conforming</td><td rowspan="2">Remarks</td></tr><tr><td>Acceptance Testing</td></tr><tr><td>1.</td><td>CEMILAC</td><td>- High temperature Storage
-Thermal Shock
- Burn in test</td><td></td><td></td></tr><tr><td>2.</td><td>Initial cold checks &amp; functional checks</td><td>Initial Performance Checks Cold checks, continuity checks and functional checks at 5V</td><td></td><td></td></tr><tr><td>3.</td><td>ESS</td><td>Pre-vibration:
Freq:20 Hz - 2000 Hz
20 Hz -100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes
ThermalCycling
-30°Cfor60min.
+70°Cfor 60 min.
Rate of changeofTemp:10°C /min. No. ofCycles: 6
Post- vibration:
20 Hz - 2000 Hz
20 Hz - 100 Hz; +6 dB/Octave
100-1000 - 0.04 g²/Hz
1000-2000 Hz; -6dB/Octave;
300 s, long.&amp; lat. Axes</td><td></td><td>PREET, INSET/ POET</td></tr><tr><td>4.</td><td>Damp Heat</td><td>40 ±2°C; RH ≥ 95% --8 hrs.</td><td></td><td>PREET, INSET during last 30 minutes (@40 ±2°C; RH ≥ 95%) followed by POET</td></tr><tr><td>5.</td><td>Acceleration</td><td>Long.: 50 g; 45 s
Lateral: 40 g; 45 s
6 Directions, 2 directions in each axis</td><td></td><td>Test No 16 JSS 0256-01
PREET, INSET/POET</td></tr><tr><td>6.</td><td>Shock</td><td>40 g; 3 ms
2 shocks per axis (Long. Axis)
3 Axes, 6 Directions.</td><td></td><td>Should be Based on shock responses measured in Static and HOT test
(Nominal functionality will be checked)</td></tr><tr><td>7.</td><td>EMI / EMC Test</td><td>RS 103; CS 115,ESD
(Batch size 1 in 20)</td><td></td><td>MIL STD 461E
PREET, INSET/ POET</td></tr><tr><td>8.</td><td>Final cold checks &amp; Final functional checks</td><td>Final Performance Checks Cold checks, continuity checks and Final functional checks at 5V</td><td></td><td></td></tr></table>

Observations:

UNIT: Cleared/Not cleared

MANUFACTURER

DOFI/RCI

DR&QA

# 21. Failure Analysis Report

RCI Failure Analysis/DR&QA form-FA

Name of the Project

2. Failure Reported by   
3. Date   
4. Sub System

Drawing No. :   
Description :   
Operating Time :   
Module   
Assembly   
Sub-Assembly

5. Failure Observed During : Pre-Screen Test

Environmental Test

Post-Screen Test

6.Description of Failure

7. Analysis / Cause of Failure Incorrect Operation / Incorrect Handling

Improper Design / Manufacturing

8. Follow UP / Corrective Action :

For Defect Rectification

9. Remarks / Review of Corrective or Preventive action taken

Project Manager

DR&QA

RDAQ(GW&M)/MSQAA :

RCMA (Msl)

Approved by:

RD, RCMA (Msl)

# 22. Scale Factor for Conversion of Count to Physical Value

<table><tr><td>S.No.</td><td>Channel</td><td>Range</td><td>Multiplication Factor(m)</td><td>Offset(c)</td></tr><tr><td>1</td><td>Strain</td><td>±10000μs</td><td>78.125 μs/Count</td><td>-10000 μs</td></tr><tr><td>2</td><td>Pressure</td><td>350 bar</td><td>1.3672bar/Count</td><td>0</td></tr><tr><td>3</td><td>Vibration</td><td>±100g</td><td>0.78125g/Count</td><td>-100g</td></tr><tr><td>4</td><td>Shock</td><td>±500g</td><td>3.90625g/Count</td><td>-500g</td></tr><tr><td>5</td><td>RTD</td><td>-50°C to 400°C</td><td>1.7578°C/Count</td><td>-50°C</td></tr></table>

Above multiplication Factor and offset values are applicable considering linear equation $y = mx + c$

Where $y =$ physical unit of parameter

$\mathbf{x} =$ Count Observed