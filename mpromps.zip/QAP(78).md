<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# QUALITY ASSURANCE PLAN (QAP) & AT/QT DOCUMENT

FOR

Resub-25108125

![](images/3ac223bc912471cbf64d12ab9306a8f9ca761386b317a32b5af0564f53870f5f.jpg)  
DATA LINK CONTROLLER AND MONITORING UNIT

# SYSTEM NAME: DATA LINK CONTROLLER AND MONITORING UNIT

PROJECT CODE: MM/21-22/DRDL-034

![](images/acf73f3c190eb4951c321373914812675c7e00651bc063f684b254af48f255ed.jpg)

RESEARCH CENTRE IMARAT,

HYDERABAD

JAN-2025

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td colspan="2">Research Centre Imarat</td><td rowspan="2" colspan="2">Document No.: 
LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003 
Issue No.:01 
Rev. No.:00 
Dated:31 Jan-2025 
Number of Pages:249</td></tr><tr><td colspan="2">Document Classification:RESTRICTED</td></tr><tr><td colspan="4">QUALITY ASSURANCE PLAN (QAP) &amp; AT, QT- DOCUMENT OF DATA LINK CONTROLLER AND MONITORING UNIT 
Project/Lab Name: PGLRSAM 
System Name: DATA LINK CONTROLLER AND MONITORING UNIT</td></tr><tr><td>Task</td><td>Group</td><td>Members</td><td>Signature</td></tr><tr><td rowspan="4">PREPARED BY:</td><td>LEKHA WIRELESS</td><td>Inayatalla Hanagandi, 
Tech Lead (QA)</td><td>Juyil</td></tr><tr><td>LEKHA WIRELESS</td><td>Vidyashree KV, 
Tech Lead (Hardware)</td><td>Vidyil</td></tr><tr><td>LEKHA WIRELESS</td><td>Shashank S 
Tech Lead (Mech),</td><td>Sha#d</td></tr><tr><td>DOFI, RCI</td><td>Kavuri Vinod Kumar, 
TO &#x27;A&#x27;</td><td>b. Vik#dun#</td></tr><tr><td rowspan="6">REVIEWED BY:</td><td>LEKHA WIRELESS</td><td>Raveendranath KR, 
Sr. Director - Engg</td><td>BS</td></tr><tr><td>DOFI, RCI</td><td>B.M.V.S.N.Maruthi, 
Sc &#x27;C&#x27;</td><td>B.alu#ti</td></tr><tr><td>DOFI, RCI</td><td>N Ram Mohan Rao, 
Sc &#x27;F&#x27;</td><td>N. Ram#h#</td></tr><tr><td>DMPDC &amp; QA/
R&amp;QA (M) Mat - RCI</td><td>C H V Satyanarayana Raju, 
Sc &#x27;F&#x27;</td><td>C.##</td></tr><tr><td>DMPDC &amp; QA/
R&amp;QA (M) Mech - RCI</td><td>E. V. Subbarao, 
Sc &#x27;F&#x27;</td><td>### 29/8</td></tr><tr><td>R&amp;QA(Elec.), RCI</td><td>Anil Kumar Prajapati, 
Sc &#x27;B&#x27;</td><td>vshil kum#t. ### 31-8
10/9/25</td></tr><tr><td rowspan="3">APPROVED BY:</td><td>TECHNOLOGY DIRECTOR 
DOFI, RCI,</td><td>Atul Pawar, 
Sc &#x27;G&#x27;</td><td>A.###</td></tr><tr><td>TECHNOLOGY DIRECTOR 
DR &amp; QA,</td><td>Dr.G.Malikarjuna Rao, 
Sc &#x27;G&#x27;</td><td>###</td></tr><tr><td>TECHNOLOGY DIRECTOR 
DMPDC &amp; QA, - RCI</td><td>R. J. K. Chari, 
Sc &#x27;G&#x27;</td><td>###</td></tr><tr><td>ISSUE AUTHORIZED BY:</td><td>PROJECT DIRECTOR 
LRSAM(IAF), DRDL</td><td>P.Ravindar Goud, 
Sc &#x27;G&#x27;</td><td>###</td></tr><tr><td colspan="4">Distribution list:</td></tr><tr><td colspan="2">1. LEKHA WIRELESS</td><td rowspan="5" colspan="2"></td></tr><tr><td colspan="2">2. PROJECT</td></tr><tr><td colspan="2">3. WC</td></tr><tr><td colspan="2">4. DR&amp;QA</td></tr><tr><td colspan="2">5. DMPDC&amp;QA</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Proprietary Information

Copyright: All Copy Rights Reserved-Lekha Wireless Solutions Pvt. Ltd.

This document is the proprietor of RCI-DRDO & Lekha Wireless Solutions Pvt. Ltd. (As RCI is clearing of issuing the document). No part of this code may be reproduced or used in part or whole in any form or by any means - graphics, electronic or mechanical - without the written permission from Lekha Wireless Solutions Pvt. Ltd. The intellectual and technical information contained in this file is proprietary to Lekha Wireless Solutions and may be covered by granted or in process national and international patents and are protected by trade secrets and copyright law. The use of this code and information contained therein is governed by the non-disclosure and service contract agreement.

Refer to the license agreement for terms of use and support.

The Content of this document cannot be used, modified or shared without explicit IP license agreement issued by Lekha Wireless Solutions

Record Of Amendments   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2">SL.No.</td><td rowspan="2">Amendment details</td><td rowspan="2">Issue Date</td><td rowspan="2">Page No.</td><td colspan="2">Requested by</td><td>Approved by</td><td rowspan="2">Approval Letter No./Remarks</td></tr><tr><td>Vendor QC sign</td><td>WC/Project sign</td><td>R&amp;QA, RCI/-External-QA Sign.</td></tr><tr><td>1.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7.</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

*Changes can be entered upon the receiving of addendum/reddendum note from the accepting authorities.

Table of Contents   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

Proprietary Information 3

Record Of Amendments 4

Table of Contents 5

List of Tables 13

List of Figures 16

List of Annexures. 18

List of Abbreviations 19

Glossary 20

1. General Requirements 21   
1.1. Scope and Purpose 21   
1.2. Introduction of System 21   
1.3. System Overview 22   
1.3.1. DLC-MU System Block Diagram Description 23   
1.4. System Configuration 24   
1.5. Technical Specifications 25   
1.5.1. Electrical Specifications 25   
1.5.1.1. PCB Specifications 25   
1.5.1.2. BBP Board Specification 25   
1.5.1.3. BOB Specification 27   
1.5.1.4. PSU Board Specification 28   
1.5.1.5. Tx Gain Stage Specification 29   
1.5.1.6. Rx Gain Stage Specification 29   
1.5.1.7. Display Device Specification 30   
1.5.1.8. Software Specification 34   
1.5.2. Mechanical Specifications 36   
1.5.2.1. Axis Diagram 37   
1.5.2.2. Unit Knock Down 38

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

1.5.2.3. Rack unit mechanical details. 39   
1.5.2.4. Rack unit mechanical details 40   
1.5.2.5. Unit Electrical & RF Specifications 42

1.5.3. Electrical ICD 43   
1.5.3.1. Panel Mount and Mating Connector Connectors 43   
1.5.3.1.1. J1 -Power Connectors Pin Details 45   
1.5.3.1.2. J3 -ETH Connectors Pin Details 46  
1.5.3.1.3. J2 -I/O Peripheral Connectors Pin Details 47  
1.5.3.1.4. J4 -USB Connectors Pin details 48   
1.5.3.1.5. J5-Tx Panel Connector Description 48   
1.5.3.1.6. J6 -Rx Panel Connector Description 48   
1.5.3.2. DLC-MU Interconnect-Wiring Details 49   
1.5.3.2.1. W1-Wiring details from Panel connector J1 to PSU Connector J3. 50   
1.5.3.2.2. W2-Wiring details from PSU Connector J758 to BBP Connector J19. 50   
1.5.3.2.3. W3- Wiring details from PSU Connector J758 to LW-TX Gain Stage Connector J1.50   
1.5.3.2.4. W4- Wiring details from PSU Connector J758 to LW-RX Gain Stage Connector J1. 50   
1.5.3.2.5. W5-Wiring details from BBP Connector J15 to LW-TX Gain Stage Connector TP1.51   
1.5.3.2.6. W6-Wiring details from PSU Connector J758 to LW-BOB-V1P0 Connector J8. 51   
1.5.3.2.7. W7- Wiring details from BOB Connector J8 to LW-RX Gain Stage Connector J1. 51   
1.5.3.2.8. W8-Wiring details from BBP Connector J11 to LW-RX Gain Stage Connector TP1.51   
1.5.3.2.9. W9-Wiring details from BBP Connector J9 to LW-BOB-V1PO Connector J8. 52   
1.5.3.2.10. W10-Wiring details from BBP Connector J9 to LW-BOB-V1P0 Connector J7. 52   
1.5.3.2.11. W11-Wiring details from LW-BOB-V1P0 Connector J7 to Panel Connector J2. 53   
1.5.3.2.12. W12-Wiring details from BBP Connector J7 to Panel Connector J2. 53   
1.5.3.2.13. W13-Wiring details from BBP Connector J7 to Panel Connector J4. 54   
1.5.3.2.14. W14-Wiring details from BBP Connector J7 to Panel Connector J3. 54   
1.5.3.2.15. W15-Wiring details from LW-TX Gain Stage Conn TP2 to Panel Conn J5. 54   
1.5.3.2.16. W16-Wiring details from LW-RX Gain Stage Conn TP3 to Panel Conn J6. 55   
1.6. List of Mechanical Component 56

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

1.7. List of Electrical Component 57   
1.8. Scope of work. 57   
1.9. Delivery Set List. 57   
1.10. List of Governing Documents 58   
1.11. List of Applicable Documents 58   
1.12. List of Applicable Standards 59   
2. Manufacturing 61   
2.1. Mechanical Component Manufacturing 61   
2.1.1. Raw Material 61   
2.1.2. Material Process and Testing 62   
2.1.3. Mechanical Component Fabrication: 62   
2.1.4. Non-Destructive Testing: 63   
2.1.5. Dimensional Inspection: 63   
2.1.6. Surface Coating & Painting details with Testing 64   
2.1.7. Special Process (HEAT TREATMENT, WELDING, BRAZING, PLATING ETC.) 64   
2.1.8. Bought Out Items 65   
2.1.9. Standard Parts (Helicoil, inserts, gaskets): 66   
2.1.10. Fasteners (Qualifying Fasteners): 67   
2.2. Electrical Component Manufacturing 69   
2.2.1. Electrical Components 69   
2.2.2. Analysis of PCB 70   
2.2.3. PCB Fabrication and Bare PCB Inspection 70   
2.2.4. QA Plan for components 73   
2.2.5. BOM Inspection 73  
2.2.6. Pre-assembly baking of PCBs 73   
2.2.7. Pre-assembly baking of Components 73   
11.2.8. Assembly and Inspection facilities 74   
11.2.9. Assembly of components on PCB 74   
1.2.10. Post-Assembly Inspection of PCB 74

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

2.3. Hardware/Component Realization: 76   
2.3.1. Dry Fit / Mock Assembly 76   
2.4. Assembly 76   
3. Quality Assurance & Quality Control Requirements 77   
3.1. Quality assurance Plan 77   
3.2. Quality Assurance Activities 78   
3.3. QA Agencies 78   
3.4. Configuration Management: 79   
3.5. Control Of Document/Drawings: 79   
3.6. Control Of Records: 80   
3.7. Control of Design & Development: 80   
3.8. Sub-Contract / Outsourcing: 81   
3.9. Identification: 81   
3.10. Traceability: 82   
3.11. Identification 82   
3.12. Material Acceptance: 82   
3.13. Non-Conformances: 82   
3.14. Re-sampling and Testing 83   
3.15. Defect Investigation: (FAB) 84   
3.16. Batch / Lot Acceptance: 84   
3.17. MIS, Test Jigs and Fixtures: 84   
3.18. Test Rigs: 85   
3.19. Review And Acceptance Of Quality Assurance Plan: 85   
3.20. Implementation Feedback: 85   
3.21. Training & Awareness 85   
3.21.1. Training Program: 85   
3.21.2. Awareness & Communication: 85   
3.22. Handling 86   
3.23. Storage 86

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

3.24. Packaging 86   
3.25. Transportation 86

4. Flow Charts 87   
4.1. Flow Chart-Mechanical 87   
4.2. Flow Chart -Electrical 90   
4.3. Process Flow chart - Unit level 92   
5. Quality Assurance Matrix 94   
5.1. Mechanical QA Matrix 94   
5.2. Electrical QA Matrix 103   
6. Electrical Testing on System after Assembly 109   
6.1. Test Flow 109   
6.2. Detailed Functional Test 110   
6.3. Burn-IN and ESS Test Specifications 111   
6.3.1. ESS Test Flow Chart. 112   
6.4. Acceptance Test Specifications 113   
6.4.1. AT Flow Chart. 114   
6.5. Qualification Test Specifications and Test Matrix 116   
6.5.1. QT Flow Chart. 121   
6.6. EMI/EMC Test Specifications 122   
6.6.1. EMI/EMC Test Flow Chart 123   
6.7. Pre-Requisites and Process checks 124   
6.7.1. BBP + BOB + PSU Assembled Board Functional Checks 125   
6.7.2. Tx Gain Stage Functional Checks 125   
6.7.3. Rx Gain Stage Functional Checks 125   
6.7.4. Initial/ Final Isolation Checks 125   
5.8. Unit Functional Test Procedures 126   
5.8.1. System Functional Readiness and RF Initialization 126   
5.8.2. Ethernet Test 127   
5.8.3. Transmitter FTP 128

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

6.8.3.1. Transmission Power Test 128   
6.8.4. Receiver FTP 130   
6.8.4.1. Receiver Sensitivity test 130   
6.8.5. Dynamic range Power Test -Design parameter evaluation (Bench test only) 132   
6.9. Unit Level Burn-In Test Procedure 133   
6.10. ESS Test Procedure for AT/QT 135   
6.10.1. Parameters to be checked during Burn-IN, ESS and ENV. 135   
6.10.2. Verification Unit Parameter during Burn-IN/ESS/AT/QT 135   
6.11. ESS/QT/AT Test Set UP. 136   
6.11.1. Pre-Random Vibration (ESS) 137   
6.11.2. Thermal Cycling (ESS) 138   
6.11.3. Post - Random Vibration (ESS) 140   
6.12. Environmental Test Procedures 141   
6.12.1. Humidity Test 141   
6.12.2. High Temperature-Operational 142   
6.12.3. Low Temperature - Operational 143   
6.12.4. Mechanical Shock 144   
6.12.5. Bump 146   
6.12.6. Acceleration 147   
6.12.7. Altitude. 148   
6.12.8. Vibration 149   
6.12.9. Mould Growth Test 150   
6.13. EMI/EMC Test Procedures 151   
5.13.1. Conducted Emission Tests 151   
5.13.1.1. CE102 151   
5.13.2. Conducted Susceptibility Tests 155   
5.13.2.1. CS101 155   
5.13.2.2. CS114 158   
5.13.2.3. CS115 163

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

6.13.2.4. CS116 166   
6.13.2.5. CS118 170   
6.13.3. Radiated Emission Tests. 171   
6.13.3.1. RE102 171   
6.13.4. Radiated Susceptibility Tests 175   
6.13.4.1. RS103 175   
7. Test Templates. 180   
7.1. Process Templates 180   
7.1.1. Mechanical Housing Inspection Report 180   
7.1.2. Mechanical Housing Unit Dimension Inspection Report 182   
7.1.3. Bare PCB Inspection Report 184   
7.1.4. Component Kit Inspection Report 186   
7.1.5. PCB Baking Inspection Report 187   
7.1.6. Component Baking Inspection Report 188   
7.1.7. Populated PCB Inspection Report 189   
7.1.8. Assembled Card Cold Checks 190   
7.1.9. Power Supply Checks 194   
7.1.10. Board Level Functional Checks. 197   
7.1.11. Potting and Conformal Coating Inspection Report 199   
7.2. FTR Templates 200   
7.2.1. Initial/Final Isolation Checks 200   
7.2.2. Unit Functional Test (Initial/ Final) 203   
7.2.2.1. System Function Readiness and RF Initialization, Ethernet Test 203   
7.2.2.2. Transmission Power Test 204   
7.2.2.3. Receiver Sensitivity Test 205   
7.2.2.4. Dynamic range Power Test -Design parameter evaluation (Bench test only) 206   
7.3. Test Reports for Burn-in Test, ESS and ENTEST - AT/QT 207   
7.3.1. Burn-in Test 207   
7.3.2. Random Vibration Test 208

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

7.3.3. Temperature Cycle Test 209   
7.3.4. Low Temperature, High Temperature, Humidity and Altitude Test 210   
7.3.5. Mechanical Shock, Bump, Acceleration Test 211   
7.3.6. Vibration Test 212   
7.3.7. EMI/EMC Tests 213   
7.4. Stage Clearance and Conformance Reports 215   
7.4.1. Stage 1 - Raw Material and clearance to Assembly 215   
7.4.2. Stage 2 - PCBA clearance Report 216   
7.4.3. Stage 3 - Unit Configuration and Assembly Clearance Report 217   
7.4.4. Stage 4 - ATP Conformance Report [Final Conformance Report] 219   
7.4.4.1. Certificate of Conformance - AT 219   
7.4.4.2. Certificate of Conformance - QT 221   
8. Annexures 224

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# List of Tables

Table 1: DLC-MU System Configuration. 24   
Table 2:DLC-MU BBP Board Specification 26   
Table 3:DLC-MU BOB Specification 27   
Table 4:DLC-MU PSU Board Specification 28   
Table 5:DLC-MU Tx Gain Stage Specification 29   
Table 6: Rx Gain Stage PCB Specification 29   
Table 7: Display Device Specification 30   
Table 8: Software Requirement Specification 34   
Table 9: Mechanical Specification 36   
Table 10: Electrical Specification. 42   
Table 11: Panel Mount Connector Details 44   
Table 12 : Panel mount Power connector Pin details 45   
Table 13: Panel mount LAN 1 Connector Pin details 46   
Table 14: Panel mount I/O Peripheral Connector Pin details 47   
Table 15: Panel mount USB Connector Pin details 48   
Table 16: Tx Panel Connector Description - Output Connector. 48   
Table 17: Rx Panel Connector Description - Output Connector 48   
Table 18: List of Mechanical Components. 56   
Table 19: List of Electrical Components 57   
Table 20: List of Delivery. 57   
Table 21: List of Governing documents 58   
Table 22: List of Applicable documents 58

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

Table 23: List of applicable standards. 59   
Table 24: Raw material 61   
Table 25: Brought Out Component 65   
Table 26: Unit Sub-blocks and PCB Types 69   
Table 27: PCB Fabrication and Reports. 70   
Table 28: Electrical QA matrix. 103   
Table 29: Test Specifications 109   
Table 30: Details Functional Test Specification 110   
Table 31: List of ESS Test Specification 111   
Table 32: AT Test Specification 113   
Table 33: AT Test Matrix 113   
Table 34: Environmental Specification for QT 116   
Table 35: QT Test Matrix. 119   
Table 36: List of EMI/EMC Tests 122   
Table 37: Pre-Requisites and Process Check. 124   
Table 38: Transmitter Test Setup Description 128   
Table 39: Receiver Test Setup Description 130   
Table 40: Burn IN Test Setup Description 133   
Table 41: ESS Test Setup Description. 136   
Table 42: Power Lead for Test 152   
Table 43:Bandwidth and Measurement Time 152   
Table 44: THRESHOLDS OF SUSCEPTABILITY FOR EMI/EMC TESTS 156   
Table 45: Susceptibility Scanning. 157   
Table 46: CS114 Limit Curves 160

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

Table 47: RS103 Limit 177   
Table 48: QA Plan for RAW Material. 225   
Table 49: List of Part component drawings of DLC-MU 226   
Table 50: Specification Mapping 237

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# List of Figures

Figure 1: Exploded View of DLC-MU 22

Figure 2-HL Block Diagram 23

Figure 3 : DLC-MU BBP Board Specification Block Diagram 25

Figure 4 : DLC-MU BOB Specification Block Diagram 27

Figure 5 : DLC-MU PSU Specification Block Diagram. 28

Figure 6 - Axis Diagram 37

Figure 7: DLC-MU Known Down. 38

Figure 8: GA for DLC-MU Unit 39

Figure 9: GA for Display Device 40

Figure 10: GA For Rack Mount illustration. 41

Figure 11: Panel Mount and Mating Connectors 43

Figure 12: DLC-MU inter connection Details 49

Figure 13: QA Process flow for Mechanical 87

Figure 14: QA PCB Process Flow 91

Figure 15: ESS Test Flow Chart 112

Figure 16: Flow Chart for AT Test. 114

Figure 17: ESS Thermal Cycle Test Profile 120

Figure 18: Composite wheeled vehicle road transportation Random Vibration Profile 120

Figure 19: Flow Chart for QT Test 121

Figure 20: Flow Chart for EMI/EMC 123

Figure 21: Transmitter Test Setup. 128

Figure 22: Receiver test setup. 130

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

Figure 23: Burn IN Test Setup 133   
Figure 24:ESS/QT/AT Test Setup 136   
Figure 25: Thermal Cycling Test Profile. 139   
Figure 26: Composite wheeled vehicle road transportation Random Vibration Profile 140   
Figure 27: Shock Pulse Graphical Representation 145   
Figure 28:CE102 limit (EUT power leads, AC and DC) for all applications. 153   
Figure 29: CE102 Test Configuration. 154   
Figure 30: Signal injection, DC or single-phase AC. 156   
Figure 31:CS101 voltage limit for all applications. 157   
Figure 32: CS114 calibration limit for all applications. 161   
Figure 33: CS114 Test Setup. 162   
Figure 34: CS115 signal characteristics for all applications 164   
Figure 35: CS115 Bulk cable injection Test Setup 165   
Figure 36: Typical CS116 damped sinusoidal waveform. 167   
Figure 37: CS116 limit for all applications. 168   
Figure 38: Typical set up for bulk cable injection of damped sinusoidal transients. 169   
Figure 39: RE102 limit all Ground applications. 173   
Figure 40: RE102 Basic test setup 174   
Figure 41: RS103 Test Setup 178

List of Annexures   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Annexures</td><td>Description</td><td>Remarks</td></tr><tr><td>Annexure-A</td><td>Quality Control Plan (QCP)</td><td>Available in QAP</td></tr><tr><td>Annexure-B</td><td>QA Plan for RAW Materials</td><td>Available in QAP</td></tr><tr><td>Annexure-C</td><td>List of DLC-MU Drawings</td><td>Available in QAP</td></tr><tr><td>Annexure-D</td><td>QA Plan for Powder Coating</td><td>Available in QAP</td></tr><tr><td>Annexure-E</td><td>Copy of Specifications</td><td>Available in QAP</td></tr><tr><td>Annexure-F</td><td>Specifications Mapping and Notes</td><td>Available in QAP</td></tr><tr><td>Annexure-G</td><td>Failure Analysis Proforma</td><td>Available in QAP</td></tr></table>

List of Abbreviations   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>S. No.</td><td>Abbreviations</td><td>Full Form</td></tr><tr><td>1.</td><td>AT</td><td>Acceptance Test</td></tr><tr><td>2.</td><td>ATP</td><td>Acceptance Test Procedure</td></tr><tr><td>3.</td><td>BBP</td><td>Base Band Processing</td></tr><tr><td>4.</td><td>BOB</td><td>Breakout Board</td></tr><tr><td>5.</td><td>BOM</td><td>Bill Of Material</td></tr><tr><td>6.</td><td>CoC</td><td>Certificate of Conformance</td></tr><tr><td>7.</td><td>COTS</td><td>Commercial Of The Shelf</td></tr><tr><td>8.</td><td>DLC-MU</td><td>Data Link Controller- Monitoring Unit</td></tr><tr><td>9.</td><td>EMC</td><td>Electromagnetic Compatibility</td></tr><tr><td>10.</td><td>EMI</td><td>Electromagnetic Interference</td></tr><tr><td>11.</td><td>ESS</td><td>Environmental Stress Screening</td></tr><tr><td>12.</td><td>FEC</td><td>Forward Error Correction</td></tr><tr><td>13.</td><td>FTP</td><td>Functional Test Procedure</td></tr><tr><td>14.</td><td>HL</td><td>High Level</td></tr><tr><td>15.</td><td>INSET</td><td>In Situ Environmental Testing</td></tr><tr><td>16.</td><td>IPD</td><td>Integration Process Document</td></tr><tr><td>17.</td><td>KOP</td><td>Kit of Parts</td></tr><tr><td>18.</td><td>MDI</td><td>Master Drawing Index</td></tr><tr><td>19.</td><td>NC</td><td>Non-Conformance/No Connection</td></tr><tr><td>20.</td><td>OEM</td><td>Original Equipment Manufacturer</td></tr><tr><td>21.</td><td>PCB</td><td>Printed Circuit Board</td></tr><tr><td>22.</td><td>PG-LRSAM</td><td>Precision Guided Long Range Surface to Air Missile</td></tr><tr><td>23.</td><td>POET</td><td>POST-Environmental Testing</td></tr><tr><td>24.</td><td>PREET</td><td>PRE-Environmental Testing</td></tr><tr><td>25.</td><td>QAP</td><td>Quality Assurance Plan</td></tr><tr><td>26.</td><td>QT</td><td>Qualification Test</td></tr><tr><td>27.</td><td>QC</td><td>Quality Control</td></tr><tr><td>28.</td><td>QA</td><td>Quality Assurance</td></tr><tr><td>29.</td><td>QTP</td><td>Qualification Test Procedure</td></tr><tr><td>30.</td><td>QCP</td><td>Quality Control Plan</td></tr><tr><td>31.</td><td>R&amp;QA</td><td>Reliability and Quality Assurance</td></tr><tr><td>32.</td><td>RFE</td><td>Radio Front End</td></tr><tr><td>33.</td><td>TDR</td><td>Test Data Report</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Glossary

Note: The reference to the categorization to be referred from classification document.

- LOT/BATCH FORMATION: Unless otherwise specified, a lot is that quantity which is produced according to the same production process in an unbroken continuous sequence by the manufacturer and from same lot/batch of material received fulfilling the condition of homogeneity without exceeding maximum quantity mentioned in specification.   
Critical Parameters: All marked and tolerance parameters / dimensions are earmarked as critical parameters.   
Major Deviation: Any deviation on the parts that affect the Functionality, Life of system, interchangeability, Main ability/Machine ability, and Strength & Safety (FLIMSS) factor should be considered as major deviations.   
Minor Deviation: If the deviation does not affect (FLIMSS) Factor shall be considered as minor deviation.   
Major Rework: Any rework that affects the critical Dimensions of drawing shall be considered as Major rework.   
Minor Rework: Any rework which does not affects the critical Dimensions of drawing shall be considered as Minor rework.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1. General Requirements

# 1.1. Scope and Purpose

Scope of Quality Assurance Plan and AT, QT document is to ensure the quality and testing of DLC-MU manufactured by M/s Lekha Wireless. This plan applies to Build-to Spec. (BTS) Manufacturing, Inspection and Testing of Components and System used in LRSAM. The objectives of document is to achieve zero defects, quality, quality policies, Procedures and process implement effective process control and ensure continuous improvement through various activities with the involvement of QA department.

# 1.2. Introduction of System

Lekha Wireless as the design Agency for Defense / Components is committed to assuring that the manufacturing process, inspection and testing meets the highest standards of the Quality, Reliability and Safety.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.3. System Overview

The Data-link Controller with Display is host of Ground Data-link system which provides an interface with Radar & FCS. The controller to be realized in 2U 19" rack mount cabinet. The system translates information on network, implements protocol conversion, ensures seamless data flow, monitors health & implements switchover algorithm for hot standby between main & Redundant Data-link system. The 19" 2U rack mount foldable 12" Display provides network traffic & health of data-link system.

The system should be designed using embedded processors with GB Ethernet with auto switch over logic of hot standby redundancy. It should provide secondary storage for logging network traffic, which is useful during post flight analysis. It should also facilitate internal data generation during data-link maintenance operation.

![](images/84e9df1e73d20c609d2d622d633aef4719e405536e0fc1f0ca15093183db4bca.jpg)  
Figure 1: Exploded View of DLC-MU

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.3.1. DLC-MU System Block Diagram Description

A high-level block diagram of the DLC-MU System is presented in the Figure below.

![](images/0d7874e30fa49dc3ce0d35c5c448d95f27eec3feac6429a6d33983bdcbb9302f.jpg)  
Figure 2-HL Block Diagram

The System comprises of the following major sub-blocks:

- Base Band Processing Board (DLC-MU-BBP)   
- DLC-MU Input Output Break-out Board (DLC-MU-BOB)   
DLC-MU Power Supply Unit Board (DLC-MU-PSU)   
Tx Gain Stage (DLC-MU Tx Gain)   
Rx Gain Stage (DLC-MU Rx Gain)   
- Display Device

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.4. System Configuration

DLC-MU System Configuration details is given in below Table 1

Table 1: DLC-MU System Configuration   

<table><tr><td>Name of the System/Unit</td><td>Data Link Controller and Monitoring Unit</td><td>Make:</td><td colspan="3">Lekha Wireless Solution</td></tr><tr><td>Lekha Part No</td><td>LE-LAKSHA-DLC-MU-S101</td><td>Model</td><td colspan="3">Laksha</td></tr><tr><td>Assembly DWG</td><td>LWS-DLC-MU-GA-01</td><td>Rev</td><td>0</td><td>Issue</td><td>01</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5. Technical Specifications

# 1.5.1. Electrical Specifications

# 1.5.1.1. PCB Specifications

The DLC-MU Unit assembly consists of the following sub-assembly cards

- Base-Band Processing Unit (BBP) - See Section 1.5.1.2   
- DLC-MU IO Break Out Board (IO BOB) - See Section 1.5.1.3   
- DLC-MU Input Power Supply Unit Board (PSU) - See Section 1.5.1.4   
DLC-MU Tx Gain Stage-- See Section 1.5.1.5   
- DLC-MU Rx Gain Stage-- See Section 1.5.1.6

# 1.5.1.2. BBP Board Specification

![](images/88c4288bebe0fd7ce70f4b58811aee62b88215fdf1cd0a0cca0bfd132937f047.jpg)  
Figure 3 : DLC-MU BBP Board Specification Block Diagram

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

DLC-MU BBP Board Specification is given in the below Table 2

Table 2:DLC-MU BBP Board Specification   

<table><tr><td>Sl. No</td><td>Parameter</td><td>Description</td><td>Remarks</td></tr><tr><td>1.</td><td>Processing Unit</td><td>Xilinx Zynq Soc7045 – XC7Z045-2FG900I</td><td></td></tr><tr><td>2.</td><td>Clock</td><td>40MHz TCXO</td><td></td></tr><tr><td>3.</td><td>Non-volatile Memory</td><td>NOR Flash, 256MB</td><td></td></tr><tr><td>4.</td><td>SDRAM</td><td>DDR3L, 8Gb</td><td></td></tr><tr><td>5.</td><td>SD card</td><td>Internal access only
Push – push R/A SMD (for Debug and development)</td><td></td></tr><tr><td>6.</td><td>EPROM</td><td>8Kb, Part of Non-volatile memory</td><td></td></tr><tr><td>7.</td><td>eMMC</td><td>16GB NAND Flash (For deployment Purposes)</td><td></td></tr><tr><td>8.</td><td>Transceiver</td><td>AD9364</td><td></td></tr><tr><td>9.</td><td>GB Ethernet</td><td>2 Ports</td><td></td></tr><tr><td>10.</td><td>USB to UART Bridge</td><td>1 UARTs at RS232 Level</td><td></td></tr><tr><td>11.</td><td>RS 422 Ports</td><td>4 Ports</td><td></td></tr><tr><td>12.</td><td>GPS</td><td>UART interface</td><td></td></tr><tr><td>13.</td><td>USB Interface</td><td>USB ULPI Interface (USB 2.0)</td><td></td></tr><tr><td>14.</td><td>USB Expansion</td><td>External USB expansion supported</td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.1.3. BOB Specification

![](images/a58c09ca437f85f7bf1eac347389a52df3adbcf6dc946a87d12c322037d8e3ca.jpg)  
Figure 4 : DLC-MU BOB Specification Block Diagram

DLC-MU BOB Board Specification is given in the below Table 3

Table 3:DLC-MU BOB Specification   

<table><tr><td>Sl. No</td><td>Parameter</td><td>Description</td><td colspan="2">Remarks</td></tr><tr><td>1</td><td>Inputs</td><td>2 - Inputs at 3.3V level</td><td colspan="2"></td></tr><tr><td rowspan="2">2</td><td rowspan="2">Outputs</td><td>2 - Outputs at 3.3V level</td><td colspan="2"></td></tr><tr><td>4 – UARTS at RS422 level</td><td colspan="4"></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.1.4. PSU Board Specification

![](images/8ccb3313cf4e68b872867e4d1363d3b300fac92c6a14d777b6450ec7c5dc213a.jpg)  
Figure 5 : DLC-MU PSU Specification Block Diagram.

DLC-MU PSU Board Specification is given in the below Table 4

Table 4:DLC-MU PSU Board Specification   

<table><tr><td>SI.
No</td><td>Parameter</td><td>Description</td><td colspan="2">Remarks</td></tr><tr><td>1</td><td>Input</td><td>220V to 260V 50Hz</td><td colspan="2"></td></tr><tr><td rowspan="2">2</td><td rowspan="2">Output</td><td>12V at 20A maximum</td><td colspan="2"></td></tr><tr><td>5V at 5A maximum</td><td colspan="4"></td></tr><tr><td rowspan="4">Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.1.5. Tx Gain Stage Specification

DLC-MU Tx Gain Stage Specification is given in the below Table 5.

Table 5:DLC-MU Tx Gain Stage Specification   

<table><tr><td>Sl.
No</td><td>Parameter</td><td>Description</td><td>Remarks</td></tr><tr><td>1</td><td>TX Gain Stage</td><td>Gain = 12dB
DC Power input = 5V</td><td></td></tr><tr><td>2</td><td>Tx Output power</td><td>1±1dBm</td><td></td></tr><tr><td>3</td><td>No of Rf Ports</td><td>1No</td><td></td></tr></table>

# 1.5.1.6. Rx Gain Stage Specification

Rx Gain stage Specification is given in the below Table 6.

Table 6: Rx Gain Stage PCB Specification   

<table><tr><td>SI.
No</td><td>Parameter</td><td>Description</td><td>Remarks</td></tr><tr><td>1</td><td>RX Gain Stage</td><td>Gain = 12dB
DC Power input = 5V</td><td></td></tr><tr><td>2</td><td>Sensitivity</td><td>-105dBm+/-3dBm</td><td></td></tr><tr><td>3</td><td>Dynamic Range</td><td>70dB</td><td></td></tr></table>

<table><tr><td rowspan="4">Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.1.7. Display Device Specification

A 12.0" rugged detachable tablet version is used for the display

The details are as follows:

<table><tr><td>S. No.</td><td>Parameter/ item</td><td>Specification/ Description</td></tr><tr><td>1</td><td>Make</td><td>Panasonic</td></tr><tr><td>2</td><td>Part Number</td><td>TOUGHBOOK CF-33 Tablet</td></tr><tr><td>3</td><td>Dimensions</td><td>(308(L) x 244(W) x 29(H)) mm without Tray</td></tr></table>

Display Device Technical Specification is given in the table below

Table 7: Display Device Specification   

<table><tr><td>SI.
No</td><td>Parameter</td><td>Description</td><td colspan="2">Remarks</td></tr><tr><td>1.</td><td>System</td><td>Intel® Core™ i7-10810U vPro™ Processor (12 MB cache, 1.1 GHz up to 4.9 GHz with Intel® Turbo Boost Technology)</td><td colspan="2"></td></tr><tr><td>1.1</td><td>CPU</td><td>Intel® Core™ i7-10810U vPro™ Processor</td><td colspan="2"></td></tr><tr><td>1.2</td><td>Frequency</td><td>1.1 GHz up to 4.9 GHz</td><td colspan="2"></td></tr><tr><td>1.3</td><td>L2 Cache</td><td>6MB</td><td colspan="2"></td></tr><tr><td>1.4</td><td>Memory (RAM)</td><td>16GB (max. 32GB) DDR4</td><td colspan="2"></td></tr><tr><td>1.5</td><td>Storage</td><td>512GB OPAL NVMe SSD (1TB optional)</td><td colspan="2"></td></tr><tr><td>1.6</td><td>Network (LAN)</td><td>2x10/100/1000/2500Mbps Ethernet</td><td colspan="2"></td></tr><tr><td>1.7</td><td>Expansion</td><td>1xM22230E-key for wireless card</td><td colspan="2"></td></tr><tr><td>1.8</td><td>Watchdog Timer</td><td>255 timer levels, setup by software</td><td colspan="2"></td></tr><tr><td>2</td><td colspan="4">Physical Characteristics</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>SI.
No</td><td>Parameter</td><td>Description</td><td>Remarks</td></tr><tr><td>2.1</td><td>Dimensions
(W x H x D)</td><td>308mm (W) x 243.6mm (H) x 21.6mm (D) without Tray</td><td></td></tr><tr><td>2.2</td><td>Weight</td><td>1.527Kg (Without Tray)</td><td></td></tr><tr><td>3</td><td>Operating System</td><td>Windows 10 Pro / free upgradable to Windows 11(64-bit)
Linux supported</td><td></td></tr><tr><td>4</td><td>Power Management:</td><td>Hot swap, Standby function, ACPI BIOS</td><td></td></tr><tr><td>4.1</td><td>AC Adapter:</td><td>Input: 100 V - 240 V AC, 50 Hz/ 60 Hz,
With AC-DC Adapter provided
Output: 15.6 V DC, 4.06A</td><td></td></tr><tr><td>4.2</td><td>Power Consumption</td><td>63W</td><td></td></tr><tr><td>4.3</td><td>Battery</td><td>Standard: x2 Li-Ion (3 cell, 22Whr) Extended: x2 Li-Ion optional</td><td></td></tr><tr><td>5</td><td colspan="3">LCD</td></tr><tr><td>5.1</td><td>Display Type</td><td>12.0&quot; Active Matrix (TFT) colour</td><td></td></tr><tr><td>5.2</td><td>Resolution</td><td>2160 x 1440 (QHD) LCD</td><td></td></tr><tr><td>5.3</td><td>Viewing Angle</td><td>85(left),85(right),89(up),89(down)</td><td></td></tr><tr><td>5.4</td><td>Luminance(cd/m2)</td><td>1.200cd/m2</td><td></td></tr><tr><td>5.5</td><td>Contrast Ratio</td><td>1000</td><td></td></tr><tr><td>5.6</td><td>Backlight Lifetime</td><td>30,000hr(min.)</td><td></td></tr><tr><td>5.7</td><td>Graphic Chip</td><td>Intel® UHD Graphics</td><td></td></tr><tr><td>5.8</td><td>Bluetooth™TM</td><td>5.1+ EDR Class 1</td><td></td></tr><tr><td>6</td><td colspan="3">Touch Screen</td></tr><tr><td>6.1</td><td>Touch Type</td><td>10 finger capacitive multi-touchscreen with digitizer.</td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>SI.
No</td><td>Parameter</td><td colspan="2">Description</td><td>Remarks</td></tr><tr><td>6.2</td><td>Controller</td><td colspan="2">USB interface</td><td></td></tr><tr><td>6.3</td><td>Durability
(Touches)</td><td colspan="2">Greaterthan 35million touches in one location without failure: Cover glass&gt;7H</td><td></td></tr><tr><td>6.4</td><td>Light
Transmission</td><td colspan="2">Daylight readability, Glove touch, Rain touch and Anti-Reflection capabilities</td><td></td></tr><tr><td>7</td><td>Wireless LAN</td><td colspan="2">Intel® WI-Fi6 AX201</td><td></td></tr><tr><td>8</td><td>Mobile
Broadband"</td><td colspan="2">4G LTE, supports 3G</td><td></td></tr><tr><td>9</td><td>GPS</td><td colspan="2">U-Blox NEO-M8N</td><td></td></tr><tr><td rowspan="3">10</td><td rowspan="3">Sound Camera</td><td colspan="2">WAVE and MIDI playback, Intel® High-Definition Audio subsystem support</td><td></td></tr><tr><td>Front:</td><td>2 MP with IR/privacy shutter
(Windows Hello compliant)</td><td></td></tr><tr><td>Rear:</td><td>8mpixel with autofocus and LED flash</td><td></td></tr><tr><td>11</td><td>Configuration port (Tablet)</td><td colspan="2">Serial, 2D Barcode Reader, 2nd USB 2.0</td><td></td></tr><tr><td rowspan="6">12</td><td rowspan="6">Interface</td><td>USB 3.1</td><td>x2</td><td></td></tr><tr><td>USB 2.0</td><td>X1</td><td></td></tr><tr><td>1xTypeC</td><td>X1</td><td></td></tr><tr><td>HDMI</td><td>x1</td><td></td></tr><tr><td>LAN</td><td>x1</td><td></td></tr><tr><td>DC In</td><td>x1</td><td></td></tr><tr><td>13</td><td>Business
Expansion
Module</td><td colspan="2">Smart Card Reader, NFC, Fingerprint Reader</td><td></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

<table><tr><td>Sl.
No</td><td>Parameter</td><td>Description</td><td>Remarks</td></tr><tr><td>14</td><td>Security</td><td>TPM (TCG V2.0 compliant) Password security (supervisor password, user password, hard disc lock) Integrated hardware security lock slot</td><td></td></tr><tr><td>15</td><td>Standard Configuration</td><td>CF-33mk2, 16GB RAM, 512GB SSD, 2x standard battery pack, IP55 digitizer pen</td><td></td></tr><tr><td>16</td><td colspan="3">Testing Standards</td></tr><tr><td>16.1</td><td>Operating Temperature</td><td>-10~50°C(14~122°F)</td><td>MIL-STD 810G, -29 °C to 60 °C qualified</td></tr><tr><td>16.2</td><td>Storage Temperature</td><td>-20~60°C(-4~140°F)</td><td>MIL-STD 810G qualified</td></tr><tr><td>16.3</td><td>Relative Humidity</td><td>10~95%@40°C(non-condensing)</td><td>MIL-STD 810G qualified</td></tr><tr><td>16.4</td><td>Shock</td><td>Operating 10Gpeak acceleration (11ms duration), following EC60068-2-27</td><td>MIL-STD 810G qualified</td></tr><tr><td>16.5</td><td>Vibration</td><td>Operating Random Vibration Test5-500Hz, 2Gms@withSSD-follow IEC60068-2-64</td><td>MIL-STD 810G qualified</td></tr><tr><td>16.6</td><td>EMC</td><td>CE, FCC Class B, BSMI, UKCA, VCCI</td><td>MIL-STD 461E qualified</td></tr><tr><td>16.7</td><td>Safety</td><td>CB, CCC, BSMI, UL, UKCA</td><td>Complied</td></tr></table>

Note: Acceptance based on OEM test Reports and COC, No En-Test will be conducted.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.1.8. Software Specification

Display Device Technical Specification is given in the table below

Table 8: Software Requirement Specification   

<table><tr><td>Parameter</td><td>Description</td><td colspan="3">Remarks</td></tr><tr><td colspan="5">SOFTWARE/ICD IMPLEMENTATION</td></tr><tr><td>Software</td><td>Linux OS. Vendor to provide C/C++ Code for ICD and external display.C/C++ Code &amp; Vivado Prj/EDK files to be provided. Software for local storage of data &amp; health parameters must be provided.</td><td colspan="3"></td></tr><tr><td>ICD Software</td><td>As per RCI ICD Document</td><td colspan="3"></td></tr><tr><td>Software Documents</td><td>Docs to be submitted for RCI I V&amp; V. 
Software clearance by Vendor.</td><td colspan="3"></td></tr><tr><td colspan="5">Control &amp; Monitor Signals</td></tr><tr><td>Code selection</td><td>loadable PN code by Software</td><td colspan="3"></td></tr><tr><td>FEC Selection</td><td>FEC ON/OFF by software selection</td><td colspan="3"></td></tr><tr><td>Frequency selection</td><td>L-Band/S-Band synchronizer by software</td><td colspan="3"></td></tr><tr><td>TM Signals</td><td>2-Buffered RSSI Signals, 2-Buffered PLL Health, 2-buffered decoder Health, 1 Buffered encoder Health</td><td colspan="3"></td></tr><tr><td>Monitor Firmware</td><td>The unit should update correlator measurement and health data such as correlation values, measured CNR, Measured Doppler Drift, slue rate, software version on TM Rs422 port.</td><td colspan="3"></td></tr><tr><td>RS-422 Protocol</td><td>115.2 baud, 8-bit, 1 stop bit, No parity &amp; GB Ethernet</td><td colspan="3"></td></tr><tr><td colspan="5">Crypto Module</td></tr><tr><td colspan="2">Implementation of AES Algorithm for Data packets</td><td colspan="4"></td></tr><tr><td colspan="2">Packet Conversion to Data Block for synchronization with AES</td><td colspan="4"></td></tr><tr><td colspan="2">Auto Switchover Algorithm</td><td colspan="4"></td></tr><tr><td colspan="2">Auto Switchover Algorithm for implementation of hot standby redundancy</td><td colspan="4"></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Parameter</td><td>Description</td><td colspan="3">Remarks</td></tr><tr><td colspan="2">Development of algorithm based on quality &amp; health of main &amp; redundant data link units</td><td colspan="4"></td></tr><tr><td colspan="2">The algorithm should implement PER of Data Link Monitoring System.</td><td colspan="4"></td></tr><tr><td colspan="2">Monitor &amp; Provide Data-link systems vitals</td><td colspan="4"></td></tr><tr><td colspan="2">Switch overtime should be less than 0.5 sec (Switch over time should be programmable)</td><td colspan="4"></td></tr><tr><td colspan="2">Transmitter</td><td colspan="4"></td></tr><tr><td colspan="2">Frequency: S-band (programmable in steps of 1KHz)</td><td colspan="4"></td></tr><tr><td colspan="2">Transmission rate: 4800 bps without FEC or 9600 with FEC</td><td colspan="4"></td></tr><tr><td colspan="2">Spreading code length: 127 or 31 programmable</td><td colspan="4"></td></tr><tr><td colspan="2">Signal Bandwidth (with RRC): less than 1MHz @127 code length 4800 data rate. 
Or less than 2MHz @127 code length 9600 Transmission rate (FEC ON) 
Signal Bandwidth @31-bit code 4800 data rate less than 0.25 MHz 
Signal Bandwidth @31-bit code 4800 data rate (9600bps Transmission rate) less than 0.5 MHz</td><td colspan="4"></td></tr><tr><td colspan="2">Modulation: BPSK</td><td colspan="4"></td></tr><tr><td colspan="2">Receiver</td><td colspan="4"></td></tr><tr><td colspan="2">Frequency: L-band (programmable in steps of 1 MHz)</td><td colspan="4"></td></tr><tr><td colspan="2">RF Bandwidth: 100 MHz, can operate at a different frequency</td><td colspan="4"></td></tr><tr><td colspan="2">CDMA decoder: band width Efficient Spread Spectrum</td><td colspan="4"></td></tr><tr><td colspan="2">Data Rate: 9600 without FEC, 4800 bps with FEC (1/2 rate convolution coding)</td><td colspan="4"></td></tr><tr><td colspan="2">Error Correction de Coding: Viterbi soft</td><td colspan="4"></td></tr><tr><td colspan="2">Signal Bandwidth: 15+1 MHz @9600bps data rate 1023 code length, 7.5+1 MHz 9600 bps data rate 511 code length</td><td colspan="4"></td></tr><tr><td colspan="2">Decoder: Decode single user data from 6 user CDMA data</td><td colspan="4"></td></tr><tr><td colspan="2">PN Code :511/1023, programmable to other code lengths</td><td colspan="4"></td></tr><tr><td colspan="2">Modulation: BPSK</td><td colspan="4"></td></tr><tr><td colspan="2">PER: 1 in 50 Packets at Sensitivity level</td><td colspan="4"></td></tr><tr><td colspan="2">Acquisition/Reacquisition Time:&lt; 10 ms</td><td colspan="4"></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.2. Mechanical Specifications

Table 9:Mechanical Specification   

<table><tr><td rowspan="3">Dimensions</td><td>Width (X)</td><td colspan="3">482.6±2 mm (19")</td></tr><tr><td>Depth (Y)</td><td colspan="3">350 ± 2 mm</td></tr><tr><td>Height (Z)</td><td colspan="3">88.40 ± 0.2 mm (2U)</td></tr><tr><td>Weight</td><td colspan="4">&lt;10 Kg</td></tr><tr><td>Chassis Material</td><td colspan="4">AL-ALLOY 6082-T6</td></tr><tr><td>Chassis Material as per RMQAP No</td><td colspan="4">RCI/DR&amp;QA/RMQAP/059</td></tr><tr><td>Surface Finish</td><td colspan="4">Yellow Chromation and Olive Green Powder coat RAL 6003</td></tr><tr><td>Surface Finish as per RMQAP No</td><td colspan="4">RCI/R&amp;QA/Coatings/01</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.2.1. Axis Diagram

An Axis diagram for the DLC-MU unit is presented in the Figure below.

![](images/45174af941173bff42363f6b154d72eebfdc729aa5486974dac54d7ddbb4d5d2.jpg)  
Figure 6 - Axis Diagram

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.2.2. Unit Knock Down

A DLC-MU Unit knock down is presented in the Figure below.

![](images/7b58554c0a54c9deb43071c906ac6849259b98b4918cd053b55cb66fccd7f9ca.jpg)

![](images/3f42e36bcfe0aeeda31afa356679e63462e334bdf51c8e66dba06b129739ef19.jpg)  
Figure 7: DLC-MU Known Down

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.2.3. Rack unit mechanical details

The dimension specifications, drawing and the isometric view for the mechanical design are presented in the Figure 8 below.

![](images/acfe8a7a006a8ff079323421e2a47ca857608a88f6016d048752a5ff2a3fd6f1.jpg)  
Figure 8: GA for DLC-MU Unit

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.2.4. Rack unit mechanical details

The details of the display mounting unit (supplied for testing purposes) is presented in the Figure 9 below.

![](images/b8dacf5b479944af07daf3690fe0aa88c9c458321a18b467802c0cde6032a155.jpg)  
Figure 9: GA for Display Device

Please note, the housing for the display and the rack assembly are not part of the supply scope of work. However, a functional unit will be delivered for testing purposes.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

The tentative mounting concept for the rack housing is as illustrated in the Figure 10 below.

![](images/1dd1cbb7e511b3b8f538968b2d0d2d22719a4330f0cc3e313a2c279f89d3af7f.jpg)  
Figure 10: GA For Rack Mount Illustration

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.2.5. Unit Electrical & RF Specifications

The Electrical specifications are as follows.

Table 10: Electrical Specification   

<table><tr><td>Parameter</td><td>Requirement</td></tr><tr><td>Input Voltage</td><td>AC 220-240 V, 50 Hz Supply</td></tr><tr><td>Current Budget for the platform</td><td>0.05±0.03A</td></tr><tr><td>RF Transmitter</td><td>S Band</td></tr><tr><td>RF Receiver</td><td>L Band</td></tr><tr><td>Sensitivity</td><td>-105dBm</td></tr><tr><td>Dynamic Range</td><td>70dB or Higher</td></tr><tr><td>RF Tx Output Power</td><td>1 ±1 dB</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.3. Electrical ICD

1.5.3.1. Panel Mount and Mating Connector Connectors

The illustration of panel mount connectors on the DLC-MU Unit is presented in the Figure below.

![](images/1d8f4ced63b542aa7dac8d7c35d3fcfda2976331f901e2a4184e87e8ae23202a.jpg)  
Figure 11: Panel Mount and Mating Connectors

Table 11: Panel Mount Connector Details   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Sl.
No</td><td>Legend</td><td>Description</td><td>Function</td><td>Part No</td><td>Mating Part</td><td>Dust Cap</td><td>Back Shell</td><td>Qty</td><td>Make</td><td>Grade</td></tr><tr><td>1</td><td>J1</td><td>6 Pin Circular D38999 Power Connector (PWR)</td><td>Input Power 220-240 VAC 50Hz</td><td>D38999/20WE6PN</td><td>D38999/26WE6SN</td><td>D38999/33W17R</td><td>M85049/38-17W</td><td>01 No</td><td>Amphenol /Equ</td><td>MIL</td></tr><tr><td>2</td><td>J2</td><td>Ruggedized circular connector for Peripheral (I/O)</td><td>4xRS422 and debug console port on circular connector</td><td>D38999/20WD35SN</td><td>D38999/26WD35PN</td><td>D38999/33W15R</td><td>M85049/38-15W</td><td>01 No</td><td>Amphenol</td><td>MIL</td></tr><tr><td>3</td><td>J3</td><td>Ruggedized circular connector (ETH)</td><td>Monitor and control</td><td>RJFTV21G</td><td>STD RJ45 Cable</td><td>RJFTVC2G</td><td>--</td><td>01 No</td><td>/Equ</td><td>MIL</td></tr><tr><td>4</td><td>J4</td><td>Ruggedized circular connector (USB)</td><td>Control</td><td>USBFTV21G</td><td>STD USB Female Cable</td><td>USBFTVC2G</td><td>--</td><td>01 No</td><td>Amphenol</td><td>MIL</td></tr><tr><td>5</td><td>J5</td><td>SMA Connector.(TX)</td><td>Tx RF output</td><td>ADP-SMAF-SMAF-F-G</td><td>STD SMA Male Cable</td><td>3-1478985-0</td><td>--</td><td>01 No</td><td rowspan="2">TE Connectivity /Eui</td><td>MIL</td></tr><tr><td>6</td><td>J6</td><td>SMA Connector.(RX)</td><td>Rx RF Input</td><td>ADP-SMAF-SMAF-F-G</td><td>STD SMA Male Cable</td><td>3-1478985-0</td><td>--</td><td>01 No</td><td>MIL</td></tr><tr><td>7</td><td>J7</td><td>Ground</td><td>Grounding</td><td>M6 Wing Nut</td><td>NA</td><td>NA</td><td>NA</td><td>01 No</td><td>LPS Bossard/Eqi</td><td>DIN-315</td></tr></table>

Note: All mating cables will be provided with each Unit.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.3.1.1. J1 -Power Connectors Pin Details

Table 12 : Panel mount Power connector Pin details

<table><tr><td colspan="5">Unit Mounted Panel Connector Part - D38999/20WE6PN (J1)</td></tr><tr><td colspan="5">Mating Cable end Connector Part - D38999/26WE6SN</td></tr><tr><td>Pin#</td><td>Logic Level</td><td>Signal Description</td><td>Direction</td><td>Application</td></tr><tr><td>1,2</td><td>220-240 VAC</td><td>Live</td><td>Input</td><td rowspan="3">Input Power connector</td></tr><tr><td>3,4</td><td>Return</td><td>Neutral</td><td>Input</td></tr><tr><td>5,6</td><td>Reference</td><td>Earth</td><td>Input</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

# 1.5.3.1.2. J3 -ETH Connectors Pin Details

Table 13: Panel mount LAN 1 Connector Pin details

<table><tr><td colspan="4">Unit Mounted Panel Connector Part# - RJFTV21G (J3)</td></tr><tr><td colspan="4">Mating Cable end Connector Part# - STD RJ45 Cable</td></tr><tr><td>Pin#</td><td>Signal Description</td><td>Direction</td><td>Application</td></tr><tr><td>1</td><td>ETH1_RX1_P</td><td>Bidirectional</td><td rowspan="8">Ethernet 1 for Controller Interface</td></tr><tr><td>2</td><td>ETH1_RX1_N</td><td>Bidirectional</td></tr><tr><td>3</td><td>ETH1_RX2_P</td><td>Bidirectional</td></tr><tr><td>4</td><td>ETH1_RX2_N</td><td>Bidirectional</td></tr><tr><td>5</td><td>ETH1_RX3_P</td><td>Bidirectional</td></tr><tr><td>6</td><td>ETH1_RX3_N</td><td>Bidirectional</td></tr><tr><td>7</td><td>ETH1_RX4_P</td><td>Bidirectional</td></tr><tr><td>8</td><td>ETH1_RX4_N</td><td>Bidirectional</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.3.1.3. J2 -I/O Peripheral Connectors Pin Details

Table 14: Panel mount I/O Peripheral Connector Pin details

<table><tr><td colspan="5">Unit Mounted Panel Connector Part# - D38999/20WD35SN (J2)</td></tr><tr><td colspan="5">Mating Cable end Connector Part# - D38999/26WD35PN</td></tr><tr><td>Pin#</td><td>Logic Level</td><td>Signal Description</td><td>Direction</td><td>Application</td></tr><tr><td>1</td><td>RS232</td><td>RS232_TX1</td><td>Output</td><td rowspan="3">Debug Console at RS232 Level</td></tr><tr><td>2</td><td>RS232</td><td>RS232_RX1</td><td>Input</td></tr><tr><td>3</td><td>Signal reference</td><td>GND</td><td>Reference</td></tr><tr><td>6</td><td>RS422</td><td>RS422_RX1_P1</td><td>Input</td><td rowspan="4">RS422 Port-1 for controller Interface</td></tr><tr><td>7</td><td>RS422</td><td>RS422_RX1_N1</td><td>Input</td></tr><tr><td>8</td><td>RS422</td><td>RS422_TX1_P1</td><td>Output</td></tr><tr><td>9</td><td>RS422</td><td>RS422_TX1_N1</td><td>Output</td></tr><tr><td>10</td><td>RS422</td><td>RS422_RX2_P1</td><td>Input</td><td rowspan="4">RS422 Port-2 for controller Interface</td></tr><tr><td>11</td><td>RS422</td><td>RS422_RX2_N1</td><td>Input</td></tr><tr><td>12</td><td>RS422</td><td>RS422_TX2_P1</td><td>Output</td></tr><tr><td>13</td><td>RS422</td><td>RS422_TX2_N1</td><td>Output</td></tr><tr><td>14</td><td>RS422</td><td>RS422_RX3_P1</td><td>Input</td><td rowspan="4">RS422 Port-3 for controller Interface</td></tr><tr><td>15</td><td>RS422</td><td>RS422_RX3_N1</td><td>Input</td></tr><tr><td>16</td><td>RS422</td><td>RS422_TX3_P1</td><td>Output</td></tr><tr><td>17</td><td>RS422</td><td>RS422_TX3_N1</td><td>Output</td></tr><tr><td>18</td><td>RS422</td><td>RS422_RX4_P1</td><td>Input</td><td rowspan="4">RS422 Port-4 for controller Interface</td></tr><tr><td>19</td><td>RS422</td><td>RS422_RX4_N1</td><td>Input</td></tr><tr><td>20</td><td>RS422</td><td>RS422_TX4_P1</td><td>Output</td></tr><tr><td>21</td><td>RS422</td><td>RS422_TX4_N1</td><td>Output</td></tr><tr><td>4 &amp; 5, 22 to 37</td><td>NC</td><td>NC</td><td>NC</td><td>NC</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

# 1.5.3.1.4. J4 -USB Connectors Pin details

Table 15: Panel mount USB Connector Pin details

<table><tr><td colspan="4">Unit Mounted Panel Connector Part - USBFTV21G (J4)</td></tr><tr><td colspan="4">Mating Cable end Connector Part# - STD USB Female Cable</td></tr><tr><td>Pin#</td><td>Signal Description</td><td>Direction</td><td>Application</td></tr><tr><td>1</td><td>USB_VBUSx</td><td>Output</td><td rowspan="5">USB for External Display</td></tr><tr><td>2</td><td>USB_Data_Nx</td><td>Bidirectional</td></tr><tr><td>3</td><td>USB_Data_Px</td><td>Bidirectional</td></tr><tr><td>4</td><td>GND-signal</td><td>Reference</td></tr><tr><td>5</td><td>SHLD</td><td></td></tr></table>

# 1.5.3.1.5. J5-Tx Panel Connector Description

Table 16: Tx Panel Connector Description - Output Connector

<table><tr><td>End Point - A</td><td>Panel connector part# ADP-SMAF-SMAF-F-G – STD SMA Male Cable (J5)</td></tr><tr><td>End Point - B</td><td>LW-Tx Gain-V1P0 PCB Mount connector J1, Part#132147-29
Mating Connector: STD SMA Male Cable</td></tr><tr><td>Cable Specification</td><td>RG405</td></tr></table>

# 1.5.3.1.6. J6 -Rx Panel Connector Description

Table 17: Rx Panel Connector Description - Output Connector

<table><tr><td>End Point - A</td><td>Panel connector part# ADP-SMAF-SMAF-F-G – STD SMA Male Cable(J6)</td></tr><tr><td>End Point - B</td><td>LW-Rx Gain-V1P0 PCB Mount connector J2, Part#132147-29
Mating Connector: STD SMA Male Cable</td></tr><tr><td>Cable Specification</td><td>RG405</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.3.2. DLC-MU Interconnect-Wiring Details

DLC-MU Interconnection details shown in below Figure 12

![](images/543af055782b09f895cb66a61e372b39183d1dc1b70ae7b5f481b93a82a22533.jpg)  
Figure 12: DLC-MU inter connection Details

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.5.3.2.1. W1-Wiring details from Panel connector J1 to PSU Connector J3

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect spec</td><td rowspan="2">Marking</td></tr><tr><td>J1
[D38999/20WE6PN]</td><td>J3
[C0024312]</td></tr><tr><td>1</td><td>A, B</td><td>1,2</td><td>IP ACPI-Power</td><td>Input</td><td>240V</td><td>12-30 AWG</td><td>Phase</td></tr><tr><td>2</td><td>C, D</td><td>3,4</td><td>L2/N</td><td>Input</td><td>240V</td><td>12-30 AWG</td><td>Neutral</td></tr><tr><td>3</td><td>E, F</td><td>5,6</td><td>Earth</td><td>Reference</td><td></td><td>12-30 AWG</td><td>Earth</td></tr></table>

# 1.5.3.2.2. W2-Wiring details from PSU Connector J758 to BBP Connector J19.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J758
[HE221J9Q20E02ZF0300]</td><td>J19
[NIN-0118CH]</td></tr><tr><td>1</td><td>J758.1,2,3</td><td>J19.1</td><td>VCC_12V</td><td>Output</td><td>12V</td><td>12-30 AWG</td><td>12V</td></tr><tr><td>2</td><td>J758.11,12,13</td><td>J19.2</td><td>GND</td><td>Reference</td><td>GND</td><td>12-30 AWG</td><td>GND</td></tr></table>

# 1.5.3.2.3. W3- Wiring details from PSU Connector J758 to LW-TX Gain Stage Connector J1.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J758
[HE221J9Q20E02ZF0300]</td><td>J1
[S1SDT-03-28-F-04.00-L]</td></tr><tr><td>1</td><td>J758.7,8</td><td>J1.1,3,5</td><td>VCC_5V</td><td>Output</td><td>5V</td><td>22-28 AWG</td><td>5V</td></tr><tr><td>2</td><td>J758.14,15</td><td>J1.2,4,6</td><td>GND</td><td>Reference</td><td>GND</td><td>22-28 AWG</td><td>GND</td></tr></table>

# 1.5.3.2.4. W4-Wiring details from PSU Connector J758 to LW-RX Gain Stage Connector J1.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J758
[HE221J9Q20E02ZF0300]</td><td>J1
[S1SDT-03-28-F-04.00-L]</td></tr><tr><td>1</td><td>J758.9,10</td><td>J1.1,3</td><td>VCC_5V</td><td>Output</td><td>5V</td><td>22-28 AWG</td><td>5V</td></tr><tr><td>2</td><td>J758.16,17</td><td>J1.4,6</td><td>GND</td><td>Reference</td><td>GND</td><td>22-28 AWG</td><td>GND</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

1.5.3.2.5. W5-Wiring details from BBP Connector J15 to LW-TX Gain Stage Connector TP1.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J15
[132102/Equiv]</td><td>TP1
[132102/Equiv]</td></tr><tr><td>1</td><td>J15.1</td><td>TP1.1</td><td>TX1A</td><td>Output</td><td>STD SMA Cable</td><td>TX1A</td></tr></table>

1.5.3.2.6. W6-Wiring details from PSU Connector J758 to LW-BOB-V1P0 Connector J8.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J758
[HE221J9Q20E0
ZF0300]</td><td>J8
[SFSDT-15-28-G-
12.00-SR]</td></tr><tr><td>1</td><td>J758.9,10</td><td>J8.9,11,13</td><td>VCC_5V</td><td>Output</td><td>5V</td><td>22-28 AWG</td><td>5V</td></tr><tr><td>2</td><td>J758.16,17</td><td>J9.15,17</td><td>GND</td><td>Reference</td><td>GND</td><td>22-28 AWG</td><td>GND</td></tr></table>

1.5.3.2.7. W7- Wiring details from BOB Connector J8 to LW-RX Gain Stage Connector J1.

<table><tr><td rowspan="2">SL No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal Name</td><td rowspan="2">Direction [Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect spec</td><td rowspan="2">Marking</td></tr><tr><td>J8 [SFSDT-15-28-G-12.00-SR]</td><td>J1 [S1SDT-03-28-GF-04.00-L]</td></tr><tr><td>1</td><td>J8.23</td><td>J1.2</td><td>RX Enable</td><td>Output</td><td>5V</td><td>22-28 AWG</td><td>Rx Enable</td></tr></table>

1.5.3.2.8. W8-Wiring details from BBP Connector J11 to LW-RX Gain Stage Connector TP1.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J11
[132102/Equiv]</td><td>TP1
[132102/Equiv]</td></tr><tr><td>1</td><td>J11.1</td><td>TP1.1</td><td>RX1A</td><td>Input</td><td>STD SMA Cable</td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

1.5.3.2.9. W9-Wiring details from BBP Connector J9 to LW-BOB-V1P0 Connector J8.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J9
[HA222I6Q34V
16F0150]</td><td>J8
[FSDT-15-28-G-
12.00-SR]</td></tr><tr><td>1</td><td>J9.9</td><td>J8.22</td><td>RX Enable</td><td>Output</td><td>3.3V</td><td>22-28 AWG</td><td>RX Enable</td></tr><tr><td>2</td><td>J9.33</td><td>J8.1,3</td><td>VCC3V3</td><td>Output</td><td>3.3V</td><td>22-28 AWG</td><td>3.3V</td></tr><tr><td>3</td><td>J9.34</td><td>J8.5,7</td><td>GND</td><td>Reference</td><td>GND</td><td>22-28 AWG</td><td>GND</td></tr></table>

1.5.3.2.10. W10-Wiring details from BBP Connector J9 to LW-BOB-V1P0 Connector J7.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J9
[HA222I6Q34V
16F0150]</td><td>J7
[FSDT-15-28-G-
12.00-SR]</td></tr><tr><td>1</td><td>J9.14</td><td>J7.16</td><td>UART1 TX</td><td>Output</td><td>3.3V</td><td>22-28 AWG</td><td>UART1 TX</td></tr><tr><td>2</td><td>J9.19</td><td>J7.18</td><td>UART1 RX</td><td>Input</td><td>3.3V</td><td>22-28 AWG</td><td>UART1 RX</td></tr><tr><td>3</td><td>J9.13</td><td>J7.19</td><td>UART2 TX</td><td>Output</td><td>3.3V</td><td>22-28 AWG</td><td>UART2 TX</td></tr><tr><td>4</td><td>J9.20</td><td>J7.17</td><td>UART2 RX</td><td>Input</td><td>3.3V</td><td>22-28 AWG</td><td>UART2 RX</td></tr><tr><td>5</td><td>J9.12</td><td>J7.22</td><td>UART3 TX</td><td>Output</td><td>3.3V</td><td>22-28 AWG</td><td>UART3 TX</td></tr><tr><td>6</td><td>J9.24</td><td>J7.20</td><td>UART3 RX</td><td>Input</td><td>3.3V</td><td>22-28 AWG</td><td>UART3 RX</td></tr><tr><td>7</td><td>J9.11</td><td>J7.12</td><td>UART4 TX</td><td>Output</td><td>3.3V</td><td>22-28 AWG</td><td>UART4 TX</td></tr><tr><td>8</td><td>J9.25</td><td>J7.14</td><td>UART4 RX</td><td>Input</td><td>3.3V</td><td>22-28 AWG</td><td>UART4 RX</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

1.5.3.2.11. W11-Wiring details from LW-BOB-V1P0 Connector J7 to Panel Connector J2.

<table><tr><td rowspan="2">SL No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal Name</td><td rowspan="2">Direction [Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect spec</td><td rowspan="2">Marking</td></tr><tr><td>J7 [SFSDT-15-28-G-12.00-SR]</td><td>J2 [D38999/20WD35SN]</td></tr><tr><td>1</td><td>J7.9</td><td>J2.6</td><td>RS422_TX1+</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX1+</td></tr><tr><td>2</td><td>J7.11</td><td>J2.7</td><td>RS422_TX1-</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX1-</td></tr><tr><td>3</td><td>J7.15</td><td>J2.8</td><td>RS422_RX1+</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX1+</td></tr><tr><td>4</td><td>J7.13</td><td>J2.9</td><td>RS422_RX1-</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX1-</td></tr><tr><td>5</td><td>J7.21</td><td>J2.10</td><td>RS422_TX2+</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX2+</td></tr><tr><td>6</td><td>J7.23</td><td>J2.11</td><td>RS422_TX2-</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX2-</td></tr><tr><td>7</td><td>J7.27</td><td>J2.12</td><td>RS422_RX2+</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX2+</td></tr><tr><td>8</td><td>J7.25</td><td>J2.13</td><td>RS422_RX2-</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX2-</td></tr><tr><td>9</td><td>J7.24</td><td>J2.14</td><td>RS422_TX3+</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX3+</td></tr><tr><td>10</td><td>J7.26</td><td>J2.15</td><td>RS422_TX3-</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX3-</td></tr><tr><td>11</td><td>J7.30</td><td>J2.16</td><td>RS422_RX3+</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX3+</td></tr><tr><td>12</td><td>J7.28</td><td>J2.17</td><td>RS422_RX3-</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX3-</td></tr><tr><td>13</td><td>J7.04</td><td>J2.18</td><td>RS422_TX4+</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX4+</td></tr><tr><td>14</td><td>J7.06</td><td>J2.19</td><td>RS422_TX4-</td><td>Output</td><td>RS422</td><td>22-28 AWG</td><td>RS422_TX4-</td></tr><tr><td>15</td><td>J7.10</td><td>J2.20</td><td>RS422_RX4+</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX4+</td></tr><tr><td>16</td><td>J7.08</td><td>J2.21</td><td>RS422_RX4-</td><td>Input</td><td>RS422</td><td>22-28 AWG</td><td>RS422_RX4-</td></tr></table>

1.5.3.2.12. W12- Wiring details from BBP Connector J7 to Panel Connector J2.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>J7
[HA222I6Q34V1
6F0150]</td><td>J2
[D38999/
20WD35SN]</td></tr><tr><td>1</td><td>J7.9</td><td>J2.1</td><td>UART0 TX</td><td>Output</td><td>RS232</td><td>22-28 AWG</td><td>UART0 TX</td></tr><tr><td>2</td><td>J7.10</td><td>J2.2</td><td>UART0 RX</td><td>Input</td><td>RS232</td><td>22-28 AWG</td><td>UART0 RX</td></tr><tr><td>3</td><td>J7.31</td><td>J2.3</td><td>GND</td><td>Reference</td><td>GND</td><td>22-28 AWG</td><td>GND</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

1.5.3.2.13. W13- Wiring details from BBP Connector J7 to Panel Connector J4.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect spec</td><td rowspan="2">Marking</td></tr><tr><td>J7
[HA222I6Q34V
16F0150]</td><td>J4
[USBFTV21G]</td></tr><tr><td>1</td><td>J7.14</td><td>J4.1</td><td>VBUS_USBx</td><td>Output</td><td>5V</td><td rowspan="5">STD USB Female Cable</td><td rowspan="5">USB</td></tr><tr><td>2</td><td>J7.12</td><td>J4.2</td><td>USB_Data_N</td><td>Bidirectional</td><td></td></tr><tr><td>3</td><td>J7.13</td><td>J4.3</td><td>USB_Data_P</td><td>Bidirectional</td><td></td></tr><tr><td>4</td><td>J7.15</td><td>J4.4</td><td>Ground signal</td><td>Reference</td><td></td></tr><tr><td>5</td><td>J7.17</td><td>J4.5</td><td>SHLD</td><td>Reference</td><td></td></tr></table>

1.5.3.2.14. W14-Wiring details from BBP Connector J7 to Panel Connector J3.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Level</td><td rowspan="2">Interconnect spec</td><td rowspan="2">Marking</td></tr><tr><td>J7
[HA222I6Q34
V16F0150]</td><td>J3
[RJFTV21G]</td></tr><tr><td>1</td><td>J7.8</td><td>J3.1</td><td>ETH1_RX1_P</td><td>Bidirectional</td><td rowspan="8">Ethernet</td><td rowspan="8">STD CAT-5 Cable</td><td rowspan="8">Ethernet</td></tr><tr><td>2</td><td>J7.7</td><td>J3.2</td><td>ETH1_RX1_N</td><td>Bidirectional</td></tr><tr><td>3</td><td>J7.6</td><td>J3.3</td><td>ETH1_RX2_P</td><td>Bidirectional</td></tr><tr><td>4</td><td>J7.5</td><td>J3.4</td><td>ETH1_RX2_N</td><td>Bidirectional</td></tr><tr><td>5</td><td>J7.4</td><td>J3.5</td><td>ETH1_RX3_P</td><td>Bidirectional</td></tr><tr><td>6</td><td>J7.3</td><td>J3.6</td><td>ETH1_RX3_N</td><td>Bidirectional</td></tr><tr><td>7</td><td>J7.2</td><td>J3.7</td><td>ETH1_RX4_P</td><td>Bidirectional</td></tr><tr><td>8</td><td>J7.1</td><td>J3.8</td><td>ETH1_RX4_N</td><td>Bidirectional</td></tr></table>

1.5.3.2.15. W15-Wiring details from LW-TX Gain Stage Conn TP2 to Panel Conn J5.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>TP2
[132102/Equiv]</td><td>J5
[132102/Equiv]</td></tr><tr><td>1</td><td>TP2.1</td><td>J5.1</td><td>TX</td><td>Output</td><td>STD SMA Cable</td><td>TX</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

1.5.3.2.16. W16-Wiring details from LW-RX Gain Stage Conn TP3 to Panel Conn J6.

<table><tr><td rowspan="2">SL
No</td><td>End Point A</td><td>End Point B</td><td rowspan="2">Signal
Name</td><td rowspan="2">Direction
[Wrt End Point A]</td><td rowspan="2">Interconnect
spec</td><td rowspan="2">Marking</td></tr><tr><td>TP3
[132102/Equiv]</td><td>J6
[132102/Equiv]</td></tr><tr><td>1</td><td>TP3.1</td><td>J6.1</td><td>RX</td><td>Output</td><td>STD SMA Cable</td><td>RX</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.6. List of Mechanical Component

The list of Mechanical components for DLC-MU given in below Table 18

Table 18: List of Mechanical Components   

<table><tr><td>S.
No.</td><td>Description</td><td>Drawing
No./Standard</td><td>MDI/BOM Ref</td><td>Qty/Unit</td><td>Make</td></tr><tr><td>1.</td><td>Front Plate</td><td>LWS-DLC-MU-PD-01</td><td rowspan="17">LW/DRDL/LRSAM/DLC-MU/SYS/DOC/MECH/MDI-BOM
Date: 31st Jan-2025</td><td>1 No.</td><td rowspan="17">Lekha
Wireless</td></tr><tr><td>2.</td><td>Top Plate</td><td>LWS-DLC-MU-PD-02</td><td>1 No.</td></tr><tr><td>3.</td><td>Rear Plate</td><td>LWS-DLC-MU-PD-03</td><td>1 No.</td></tr><tr><td>4.</td><td>LH Plate</td><td>LWS-DLC-MU-PD-04</td><td>1 No.</td></tr><tr><td>5.</td><td>RH Plate</td><td>LWS-DLC-MU-PD-05</td><td>1 No.</td></tr><tr><td>6.</td><td>Bottom Plate</td><td>LWS-DLC-MU-PD-06</td><td>1 No.</td></tr><tr><td>7.</td><td>BOB Top Plate</td><td>LWS-DLC-MU-PD-07</td><td>1 No.</td></tr><tr><td>8.</td><td>BBP Top Plate</td><td>LWS-DLC-MU-PD-08</td><td>1 No.</td></tr><tr><td>9.</td><td>PSU Top Plate-1</td><td>LWS-DLC-MU-PD-09</td><td>1 No.</td></tr><tr><td>10.</td><td>PSU Top Plate-2</td><td>LWS-DLC-MU-PD-10</td><td>1 No.</td></tr><tr><td>11.</td><td>PSU Leg</td><td>LWS-DLC-MU-PD-11</td><td>4 No.</td></tr><tr><td>12.</td><td>ETH Top Cover</td><td>LWS-DLC-MU-PD-12</td><td>1 No.</td></tr><tr><td>13.</td><td>TX Gain BT Plate</td><td>LWS-DLC-MU-PD-13</td><td>1 No.</td></tr><tr><td>14.</td><td>TX Gain TP</td><td>LWS-DLC-MU-PD-14</td><td>1 No.</td></tr><tr><td>15.</td><td>RX Gain BT Plate</td><td>LWS-DLC-MU-PD-15</td><td>1 no.</td></tr><tr><td>16.</td><td>RX Gain TP</td><td>LWS-DLC-MU-PD-16</td><td>1 no.</td></tr><tr><td>17.</td><td>Feed Thru Holder</td><td>LWS-DLC-MU-PD-17</td><td>1 no.</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.7. List of Electrical Component

The list of electrical components for DLC-MU given in below Table 19

Table 19: List of Electrical Components   

<table><tr><td>Sl. No</td><td>Description</td><td>Qty/Unit</td><td>Make</td></tr><tr><td>1.</td><td>Base Band Processing Board (DLC-MU-BBP)</td><td>01 No</td><td rowspan="7">Lekha Wireless</td></tr><tr><td>2.</td><td>Break-out Board (DLC-MU-BOB)</td><td>01 No</td></tr><tr><td>3.</td><td>Power Supply Unit Board (DLC-MU-PSU)</td><td>01 No</td></tr><tr><td>4.</td><td>Tx Gain Stage (DLC-MU Tax Gain</td><td>01 No</td></tr><tr><td>5.</td><td>Rx Gain Stage (DLC-MU Tax Gain)</td><td>01 No</td></tr><tr><td>6.</td><td>Display Device 19” Rack Mount</td><td>01 No</td></tr><tr><td>7.</td><td>Cable Harness</td><td>01 Set</td></tr></table>

# 1.8. Scope of work

Data Link Controller and Monitoring Unit scope of work refer Annexure-E: Copy of Specifications

# 1.9. Delivery Set List

Table 20: List of Delivery

<table><tr><td>SI. No</td><td>Description</td><td>Qty</td></tr><tr><td>1.</td><td>Data link controller and monitoring Unit (2 AT &amp; 1 QT)</td><td>03 Nos</td></tr><tr><td>2.</td><td>Data-link Controller and Monitoring unit with FTP &amp; AT reports</td><td>03 Set</td></tr><tr><td>3.</td><td>Rugged 12&quot; Display with COC</td><td>03 Nos</td></tr><tr><td>4.</td><td>RF Cables: Assorted</td><td>03 Set</td></tr><tr><td>5.</td><td>Data Cable: Assorted</td><td>03 Set</td></tr></table>

Note: 12" Rugged Display (3 No's): Acceptance based on FTP, OEM Test reports & COC only. No EN-Tests will be done for display unit

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.10. List of Governing Documents

Table 21: List of Governing documents   

<table><tr><td>SL No</td><td>Document name</td><td>Document No with Date</td><td>Issue No</td><td>Rev No</td><td>Status</td></tr><tr><td>1.</td><td>Supply order for Data Link Controller &amp; Monitoring Unit (PGLRSAM)</td><td>DRDL/PGLRSAM/1701/31P/23/191/0232 Dated: 25 June-2024</td><td>-</td><td>-</td><td>-</td></tr><tr><td>2.</td><td>Environment Test Specification for Ground Support Equipment of LRSAM KUSHA</td><td>LRSAM Ground System En Test Document Report Ver:1.1.0 Part Volume: 1.1.0</td><td>-</td><td>-</td><td>Approved</td></tr></table>

# 1.11. List of Applicable Documents

Table 22: List of Applicable documents   

<table><tr><td>SL No</td><td>Document name</td><td>Document No with Date</td><td>Issue No</td><td>Rev No</td><td>Status</td></tr><tr><td>1.</td><td>Electrical - BOM &amp; MDI</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/ELE/MDI-BOMRev:00 Dt: 21stMar-2025</td><td>1</td><td>0</td><td>Approved</td></tr><tr><td>2.</td><td>MDI-BOM (Mechanical)</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/MECH/MDI-BOMDate: 31stJan-2025</td><td>1</td><td>0</td><td>Approved</td></tr><tr><td>3.</td><td>IPD</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/IPD/004Date: 31stJan-2025</td><td>1</td><td>00</td><td>Approved</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1.12. List of Applicable Standards

Table 23: List of applicable standards   

<table><tr><td>S. No.</td><td>Document Reference No.</td><td>Description</td></tr><tr><td>1</td><td>MIL-STD-461E</td><td>Requirements for the control of Electromagnetic 
Interference Characteristic of Subsystems and 
Equipment</td></tr><tr><td>2</td><td>JSS 55555/ JSS 0256</td><td>Environmental test Methods</td></tr><tr><td>3</td><td>MIL-STD-883E</td><td>Test Method Standards - Microcircuits</td></tr><tr><td>4</td><td>MIL-STD-202</td><td>Test Method Standards for Electrical/ Electronic Parts</td></tr><tr><td>5</td><td>MIL-STD-38535E</td><td>Micro Circuits Manufacturing, General Specifications</td></tr><tr><td>6</td><td>MIL-STD-810F</td><td>Environmental Engineering considerations and 
laboratory Tests</td></tr><tr><td>7</td><td>MIL, LCSO, QML References</td><td>Electronic/ Electrical Components (Capacitors, 
Resistors, Relays, Connectors, IC&#x27;s etc.)</td></tr><tr><td>8</td><td>MIL-STD-2164A, MIL-STD-344A</td><td>Environmental Stress Screening</td></tr><tr><td>9</td><td>MIL-PRF-5511-F, MIL-PRF-31032</td><td>Printed Circuit Board - Rigid General Specifications</td></tr><tr><td>10</td><td>MIL-STD-S-45743E</td><td>Soldering Standards</td></tr><tr><td>11</td><td>MIL-STD-338</td><td>Reliability Engineering</td></tr><tr><td>12</td><td>IPC-610 G</td><td>Workmanship Standards</td></tr><tr><td>13</td><td>IEC 61000-4-2</td><td>Electromagnetic Compatibility - Testing and 
measurement techniques - Electrostatic discharge 
immunity test</td></tr><tr><td>14</td><td>MIL-STD-1686C</td><td>ESD test survival ability</td></tr><tr><td>15</td><td>AMS 4115/ IS 733</td><td>Specifications for wrought aluminum and aluminum 
alloy bars, rods and sections</td></tr><tr><td>16</td><td>AMS 2630C CLASS A1</td><td>Ultrasonic Test (UT)</td></tr><tr><td>17</td><td>ASTM E 1251-2017a Standards</td><td>Chemical Analysis Test</td></tr><tr><td>18</td><td>IS 1608 (Part-1) 2022 Standards</td><td>Tensile Test</td></tr><tr><td>19</td><td>ASTM-E-165</td><td>Dye Penetration Test (DP Test)</td></tr><tr><td>20</td><td>MIL-C-5541F TYPE1 CLASS 1A 
(YELOW)</td><td>Surface Treatment-Chromatisation</td></tr><tr><td>21</td><td>RAL 6003</td><td>Surface Treatment-Powder Coat</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Intentionally Left Blank Page

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT T</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2. Manufacturing

# 2.1. Mechanical Component Manufacturing

# 2.1.1. Raw Material

Details of raw material requirements, Applicable specification referred for fabrication of components are given in the Table below.

Table 24: Row material   

<table><tr><td rowspan="2">SI.
No</td><td colspan="2">Raw Material Requirement</td><td rowspan="2">Material
Classification
(Critical /
Non-Critical)</td><td rowspan="2">Material Test
Schedule</td><td rowspan="2">Reference
Std/RMQAP</td></tr><tr><td>Grade</td><td>Supply
Condition</td></tr><tr><td>1.</td><td>AA6082 T6
Flat/Bar/Plate/Sheet</td><td>T6</td><td>Critical</td><td>1. Raw Material
Identification
(Visual &amp;
Dimensional
Inspection)
2. Ultrasonic
Test
3. Chemical
Analysis
4. Tensile Test</td><td>RCI/DR&amp;QA/RMQAP/
059</td></tr></table>

For material acceptance selection of Material Test Schedule refer para 3.12 for reference

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.1.2. Material Process and Testing

a) Supplied material Identification and traceability shall be as per clause 3.9   
b) Mill form Materials procured from imported source/ Indian OEM shall have Test Release Certificate (TRC), CoC along with Traceability & product identification tag from Original Material Manufacturer. Traders/ Suppliers issued certificate in this regard shall not be acceptable.   
c) Process: Forged/rolled Raw material is to be realized as per raw-material supplier process plan (if processed from feedstock) Vendor has to prepare detailed process plan for the forgings/Rolling/Heat Treatment and obtain DMPDC, R&QA (Mat.) approval. On requirement, vendor has to submit the log sheet / process sheet for verifications.   
d) Testing: RMQAP mentioned at Clause 2.1.1 Sampling plan will be as per Material QA Matrix. /RMQAP.   
e) All the tests are to be carried out in NABL/MSME/ Govt. approved laboratories only.   
f) Post completion of tests, vendor has to submit consolidated test reports along with individual test certificates (NABL/MSME/Govt. approved labs only.) as per format enclosed (Ref. forms & formats for summary sheet) and submit it to R&QA - RCI. If found satisfactory, it will be forwarded to RDAQA (GW&M) for final acceptance.   
g} Failed samples to be submitted to R&QA, RCI for Defect investigation refer clause 3.11, 3.12 & 3.13   
h) QA Co-ordination & Stage clearance: as per Material QA Matrix. QA Matrix for various materials is placed at QA MATRIX chapter 5

# 2.1.3. Mechanical Component Fabrication:

a) Quality Control Plan (QCP) shall consist of Manufacturing Control Plan (MCP) (Process Plan) & Dimensional Inspection Plan (DI Plan) which shall be Prepared/generated by the manufacturers as per requirement/applicable drawing in the form of Tabular form (Ref. Annexure-A) before commencement of manufacturing. This includes process detail mentioning various stages of operation for all components from raw material procurement to the finished product fabrication including but not limited to machining, riveting, testing, surface protection and assembly.   
b) Any special process (Heat treatment, Welding, Brazing, Plating Etc.) which may affect product quality are to be clearly brought out in the process plan and quality plan for the same shall be included in this QAP /QA Matrix.   
c) List of jigs, fixtures and tools used for various operations and assembly shall also be mentioned and validated by R&QA-RCI.   
Any change in this Manufacturing process plan shall be intimated to R&QA-RCI in advance and approval shall be obtained. The validation report shall be shared with R&QA-RCI on need basis for review / Audit.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.1.4. Non-Destructive Testing:

a) Non-Destructive Testing is mandatory to all aeronautical components after final machining of Components to detect surface defects/discontinuities/cracks/pits etc. No defects are permissible.   
b) SOP / NDT Plan for applicable NDT process shall be approved by ASNT Level-III personnel and test has to be carried out and certified by Level-III personnel only.   
c) Dye Penetrant (DP) test as per ASTM E 1417 of at least sensitivity Level-II shall be used for all critical aeronautical components.   
d) For non-critical components Red Dye Penetrant Test is to be carried out as per ASTM E 1417 /ASTM E 165 guidelines.   
e) Ultrasonic test (UT) is to be carried out in accordance with ASTM B 594 (Al-Alloy), AMS 2631(Titanium), AMS 2630/2632 (all Metals except Titanium)   
f) DPT report is to be generated as per format. (Ref. forms & formats for DP template)

# 2.1.5. Dimensional Inspection:

a) Dimension Inspection Acceptance plan with QCP shall be generated by the manufacturer after placement of Supply Order as per Approved Drawings for Critical Dimensions, GD & T, complex geometry in Dimension Inspection Acceptance Plan table (Ref. Section: 7.1.2 for DI Template) and approval of the same shall be from QA Agency before DI inspection.   
b) If critical dimensions not mentioned in Drawings, designer shall submit the critical parameters in tabular form.   
c) Visual and Dimensional Inspection of Final machined component will be carried out as per the approved Drawings at main vendor / sub- vendor premises for acceptance of item. If required, dimensional inspection will be repeated post surface coating on critical mating and assembly components, which shall be mentioned in Dimension Inspection Acceptance plan or QA matrix.   
d) The dimensional inspection is to be carried out only with calibrated measuring instruments. Appropriate and accurate measuring instrument (having least count 1/10 of tolerance value) shall be used for measuring the dimensions. Appropriate Templates (validated), gauges, profile meters are to use.   
(e) CMM inspection reports are to be generated by vendor for all critical dimensions.   
f) Vendor has to ensure compliance to drawing requirements and generate Dimension Inspection report as per Format Ref. Section: 7.1.2 for DI Template)   
g) After ensuring all requirements as per drawing, vendor shall raise inspection request to R&QA-RCI   
h) R&QA-RCI shall ensure all critical dimensions) rep will re-verify 5-10% of these critical dimensions on sample basis.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

i) Overwriting, found satisfactory, ensured through CNC programming & Machining etc. are not acceptable in DI reports.   
j) All manufactured parts shall be laser engraved before coating as mentioned in the drawings, if not feasible viz. fasteners and small parts traceability to be maintained from manufacturing till consumption appropriately.

# 2.1.6. Surface Coating & Painting details with Testing

Following surface protection coating / Painting / anodizing / plating etc. are to be carried out on the store / components of store:

<table><tr><td>Process</td><td>Referred Specification / Standard (as per QAP)</td><td>Raw Material</td><td>Application (Component Details)</td></tr><tr><td>Chromatisation</td><td>RCI/R&amp;QA/Coating/01</td><td>AA 6082 T6</td><td>Front Plate, Top Plate, Rear Plate, LH Plate, RH Plate, Bottom Plate BOB Top Plate, BBP Top Plate - PSU Top Plate-1,PSU Top Plate-2 PSU LEG, ETH Top Plate, TX Gain BT Plate, TX Gain TP Plate, RX Gain BT Plate, RX Gain TP Plate, FEED THRU HOLDER &amp; Test Coupons</td></tr><tr><td>Powder Coat</td><td>Annexure-D</td><td>AA 6082 T6</td><td>Front Plate, Top Plate, Rear Plate, LH Plate, RH Plate, Bottom Plate &amp; Test Coupons</td></tr></table>

a) Plating finished components and test coupons shall be carried out in NADCAP (preferably) NABL Accredited/ approved Facility. Test coupons are to be evaluated for various test parameters as mentioned below.

Visual Inspection   
Coating Thickness   
Slat Spray Test   
Adhesion test   
Electrical Resistance Test

b) The Visual Inspection of the components is to be carried out as per the details mentioned in the approved drawings. If required, dimensional inspection will be repeated post surface coating on critical mating and assembly components, refer clause 2.1.5   
c) Tests of powder coat coupons are to be carried out as per Quality requirements specified in the referred specification.

# 2.1.7. Special Process (HEAT TREATMENT, WELDING, BRAZING, PLATING ETC.)

---Nil---

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.1.8. Brought Out Items

List of bought out items as per R&QA Approved BoM Ref. Doc No. (LW/DRDL/LRSAM/DLC-MU/SYS/DOC/MECH/MDI-BOM Date: 31st Jan-2025) is given below. Acceptance criteria of all Brought out Items will be CoC based.

Table 25: Brought Out Component

<table><tr><td>S.No.</td><td>Component Name</td><td>Qty/U 
nit Nos</td><td>Material/ 
Equiv.</td><td>Standard</td><td>Property 
Class</td><td>Source</td></tr><tr><td>1.</td><td>M3X8L Philips Pan Head Screw</td><td>36</td><td rowspan="29">SS</td><td rowspan="29">DIN- 
7985A, 
DIN- 
965A, 
DIN- 
127B, 
DIN- 
125A, 
DIN-933, 
DIN-315, 
DIN-934, 
DIN- 
8140.</td><td rowspan="29">A2</td><td rowspan="29">LPS 
Bossard</td></tr><tr><td>2.</td><td>M4X16L Philips CSK Head Screw</td><td>6</td></tr><tr><td>3.</td><td>M3X10L Philips CSK Head Screw</td><td>52</td></tr><tr><td>4.</td><td>M4X6L Philips Pan Head Screw</td><td>12</td></tr><tr><td>5.</td><td>M3X25L Philips Pan Head Screw</td><td>8</td></tr><tr><td>6.</td><td>M3X18L Philips Pan Head Screw</td><td>4</td></tr><tr><td>7.</td><td>M4X35L Philips Pan Head Screw</td><td>12</td></tr><tr><td>8.</td><td>M4X8L Philips Pan Head Screw</td><td>24</td></tr><tr><td>9.</td><td>M2X6L Philips CSK Head Screw</td><td>20</td></tr><tr><td>10.</td><td>M2X4L Philips Pan Head Screw</td><td>10</td></tr><tr><td>11.</td><td>M2.5X4L Philips Pan Head Screw</td><td>8</td></tr><tr><td>12.</td><td>M3X6L Philips CSK Head Screw</td><td>3</td></tr><tr><td>13.</td><td>M2.5X6L Philips Pan Head Screw</td><td>8</td></tr><tr><td>14.</td><td>M3 Spring Washer</td><td>36</td></tr><tr><td>15.</td><td>M3 Plain Washer</td><td>48</td></tr><tr><td>16.</td><td>M4 Plain Washer</td><td>36</td></tr><tr><td>17.</td><td>M4 Spring Washer</td><td>24</td></tr><tr><td>18.</td><td>M2 Plain Washer</td><td>10</td></tr><tr><td>19.</td><td>M6X40L Hex Head Screw</td><td>1</td></tr><tr><td>20.</td><td>M6 Wing Nut</td><td>1</td></tr><tr><td>21.</td><td>M6 Nut</td><td>1</td></tr><tr><td>22.</td><td>M6 Plain Washer</td><td>1</td></tr><tr><td>23.</td><td>M3x0.5-2D Insert</td><td>72</td></tr><tr><td>24.</td><td>M2.5x0.45-1D Insert</td><td>12</td></tr><tr><td>25.</td><td>M3x0.5-1D Insert</td><td>23</td></tr><tr><td>26.</td><td>M4x0.7-1D Insert</td><td>36</td></tr><tr><td>27.</td><td>M3x0.5-1.5 Insert</td><td>12</td></tr><tr><td>28.</td><td>M2x0.4-2D Insert</td><td>20</td></tr><tr><td>29.</td><td>M2x0.4-1D insert</td><td>10</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

a) Bought out Item clearance shall be issued by R&QA Mech for all the bought-out Airborne Stores based on the necessary technical information as per the prescribed format (Form 40) submitted by the applicant.   
b) All hardware items shall be procured as per IS/DIN/BN/MIL standard or equivalent standard as mentioned in the BoM. If any change with respect to approved BOM, Designer note to be made available prior to procurement of Items and BOM /MDI to be amended accordingly.   
c) COC's along with test certificates are to be provided for all the bought out items and COC's shall contain all relevant information with respect to material, component specification as per design requirement approved by MDI-BOM.   
d) Wherever applicable, life of perishable items (O-rings, gaskets, grease etc.) are to be ensured before installation. QA Matrix for Bought out item is placed at chapter 5   
e) Si. No. along with part no. shall be engraved / added for all bought out items.

# 2.1.9. Standard Parts (Helicoil, inserts, gaskets):

List of Std. Parts items as per R&QA Mech Approved BoM Ref. Doc No. (LW/DRDL/LRSAM/DLC-MU/SYS/DOC/MECH/MDI-BOM Date: 31st Jan-2025) is given below. Acceptance criteria of all Brought out items will be CoC based.

<table><tr><td>SI. No</td><td>Component Name</td><td>Part/Drg No</td><td>Source</td></tr><tr><td>1.</td><td>Helicoil Inserts</td><td>M3x0.5-2D Insert</td><td>Amit Inc</td></tr><tr><td>2.</td><td>Helicoil Inserts</td><td>M2.5x0.45-1D Insert</td><td>Amit Inc</td></tr><tr><td>3.</td><td>Helicoil Inserts</td><td>M3x0.5-1D Insert</td><td>Amit Inc</td></tr><tr><td>4.</td><td>Helicoil Inserts</td><td>M4x0.7-1D Insert</td><td>Amit Inc</td></tr><tr><td>5.</td><td>Helicoil Inserts</td><td>M3x0.5-1.5 Insert</td><td>Amit Inc</td></tr><tr><td>6.</td><td>Helicoil Inserts</td><td>M2x0.4-2D Insert</td><td>Amit Inc</td></tr><tr><td>7.</td><td>Helicoil Inserts</td><td>M2x0.4-1D Insert</td><td>Amit Inc</td></tr><tr><td>8.</td><td>Loctite/Thread Locker</td><td>Loctite 242</td><td>Loctite</td></tr><tr><td>9.</td><td>Adhesive</td><td>Conductive Adhesive</td><td>SSD Polymers</td></tr><tr><td>10.</td><td>Emi Divider Edge</td><td>0097097202</td><td>Laird
Technologies/Equiv.</td></tr><tr><td>11.</td><td>Thermal Grease</td><td>TC3-10G/Equiv.</td><td>Chip Quik Inc./Equiv.</td></tr><tr><td>12.</td><td>Thermal Interface Material</td><td>TG-A4500/Equiv.</td><td>T-Global Tech</td></tr><tr><td>13.</td><td>Handle</td><td>B4-50-203-15</td><td>Southco</td></tr><tr><td>14.</td><td>Slides</td><td>LFS46-0450</td><td>Rollon</td></tr><tr><td>15.</td><td>J1-power connector gasket Dwg</td><td>LWS-DLC-MU-GAS-01</td><td>SSD Polymers/Equiv.</td></tr><tr><td>16.</td><td>J2-I/O connector gasket Dwg</td><td>LWS-DLC-MU-GAS-02</td><td>SSD Polymers/Equiv.</td></tr><tr><td>17.</td><td>J3-Ethernet connector gasket Dwg</td><td>LWS-DLC-MU-GAS-03</td><td>SSD Polymers/Equiv.</td></tr><tr><td>18.</td><td>J4-USB connector gasket Dwg</td><td>LWS-DLC-MU-GAS-04</td><td>SSD Polymers/Equiv.</td></tr><tr><td>19.</td><td>Dia 3mm Round gasket Dwg</td><td>LWS-DLC-MU-GAS-05</td><td>SSD Polymers/Equiv.</td></tr><tr><td>20.</td><td>SQ. 3mm Gasket Dwg</td><td>LWS-DLC-MU-GAS-06</td><td>SSD Polymers/Equiv.</td></tr><tr><td>21.</td><td>SQ. 2mm Gasket Dwg</td><td>LWS-DLC-MU-GAS-07</td><td>SSD Polymers/Equiv.</td></tr><tr><td>22.</td><td>Dia 1mm Round gasket Dwg</td><td>LWS-DLC-MU-GAS-08</td><td>SSD Polymers/Equiv.</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

a) All standard /AGS Parts shall be procured as per specification/standard approved by R&QA RCI Mech in the BoM document. From registered / approved vendors only.   
b) All Gaskets / Rubber items after acceptance shall be packed in heat sealed foil lined paper packing & chalk powder with relevant marking outside the packing. The sealed packets are to be stored in places where the packets are not directly exposed to sunlight. The marking shall include store reference number, quantity, life of expiry, etc.   
All hardware items shall be procured as per IS/DIN/BN/MiL standard or equivalent standard as mentioned in the BoM and shall be accepted based on release note or CoC's along with test reports of the OEM.   
c) If required, these shall be accepted based on sample test results. On requirement basis, sample test plan will be made.

# 2.1.10. Fasteners (Qualifying Fasteners). Brought out

List of fasteners and applicable Batch Qualification Test (BQT) for acceptance of fasteners are listed below

<table><tr><td>SI No</td><td>Fastener details</td><td>Applicable BQT</td><td>Supplier</td></tr><tr><td>1.</td><td>M3X8L Philips Pan Head Screw</td><td>5 out of 400</td><td rowspan="22">LPS Bossard</td></tr><tr><td>2.</td><td>M4X16L Philips CSK Head Screw</td><td>5 out of 100</td></tr><tr><td>3.</td><td>M3X10L Philips CSK Head Screw</td><td>5 out of 100</td></tr><tr><td>4.</td><td>M4X6L Philips Pan Head Screw</td><td>5 out of 300</td></tr><tr><td>5.</td><td>M3X25L Philips Pan Head Screw</td><td>5 out of 100</td></tr><tr><td>6.</td><td>M3X18L Philips Pan Head Screw</td><td>5 out of 100</td></tr><tr><td>7.</td><td>M4X35L Philips Pan Head Screw</td><td>5 out of 100</td></tr><tr><td>8.</td><td>M4X8L Philips Pan Head Screw</td><td>5 out of 200</td></tr><tr><td>9.</td><td>M2X6L Philips CSK Head Screw</td><td>5 out of 200</td></tr><tr><td>10.</td><td>M2X4L Philips Pan Head Screw</td><td>5 out of 600</td></tr><tr><td>11.</td><td>M2.5X4L Philips Pan Head Screw</td><td>5 out of 200</td></tr><tr><td>12.</td><td>M3X6L Philips CSK Head Screw</td><td>5 out of 300</td></tr><tr><td>13.</td><td>M2.5X6L Philips Pan Head Screw</td><td>5 out of 200</td></tr><tr><td>14.</td><td>M3 Spring Washer</td><td>5 out of 200</td></tr><tr><td>15.</td><td>M3 Plain Washer</td><td>5 out of 200</td></tr><tr><td>16.</td><td>M4 Plain Washer</td><td>5 out of 200</td></tr><tr><td>17.</td><td>M4 Spring Washer</td><td>5 out of 200</td></tr><tr><td>18.</td><td>M2 Plain Washer</td><td>5 out of 100</td></tr><tr><td>19.</td><td>M6X40L Hex Head Screw</td><td>5 out of 100</td></tr><tr><td>20.</td><td>M6 Wing Nut</td><td>5 out of 100</td></tr><tr><td>21.</td><td>M6 Nut</td><td>5 out of 100</td></tr><tr><td>22.</td><td>M6 Plain Washer</td><td>5 out of 100</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

a) Fasteners shall duly conform to the Aero grade requirements as per approved BOM for production of unit.   
b) The fasteners shall be qualified as per Applicable BQT and the QA Agencies shall be involved in all stages from Raw Material to Final Product acceptance. Stages shall be offered to QA agencies as per QA Matrix duly signed by all stake holders (viz, Firm, Designer / Project, R&QA, AQA)   
c) The vendor shall maintain all details for traceability of fasteners in COC and Test Release Certificate. Customer information (P.O No, date, name of the customer), Material details (Grade, Heat/melt no, Heat treatment batch no), fastener details (Nomenclature, Size, Class, Lot No), fastener property (Mechanical, metallurgy, surface treatment, de-carburisation, etc.) are to be included.   
d) Non-critical fasteners may be directly accepted by Authorized Release Note signatory (DGAQA approved) as per provision of delegation letter items and clearance report shall be submitted to R&QA -RCI for information.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.2. Electrical Component Manufacturing

# 2.2.1. Electrical Components

The DLC-MU unit consists of the following 5 types of PCB's.

Table 26: Unit Sub-blocks and PCB Types   

<table><tr><td>S. No.</td><td>Sub-Block</td><td>PCB Nomenclature</td><td>Thickness</td><td>Layers</td><td>Description</td></tr><tr><td>1</td><td>Base Band Processing Board</td><td>BBP Board</td><td>1.83mm (+/- 0.25 mm)</td><td>20</td><td>Rogers 4350B or equivalent (Top and Bottom) 
IT180ABS 106 RC75 – Remaining Inner layers</td></tr><tr><td>2</td><td>Input Output Break Out Board</td><td>IO-BOB</td><td>1.6mm (+/- 0.25 mm)</td><td>4</td><td>FR4 as per IPC-4101 for all layers</td></tr><tr><td>3</td><td>Power Supply Unit Board</td><td>PSU Board</td><td>1.6mm (+/- 0.25 mm)</td><td>6</td><td>FR4 as per IPC-4101 for all layers</td></tr><tr><td>4</td><td>DLC-MU Tx Gain Stage</td><td>Tx Gain Stage</td><td>0.5mm (+/- 0.25 mm)</td><td>2</td><td>Rogers 4350B or Equivalent (Top &amp; Bottom)</td></tr><tr><td>5</td><td>DLC-MU Rx Gain Stage</td><td>Rx Gain Stage</td><td>0.5mm (+/- 0.25 mm)</td><td>2</td><td>Rogers 4350B or Equivalent (Top &amp; Bottom)</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.2.2. Analysis of PCB

Analysis of PCB should be carried out for power, thermal and tolerance. For digital PCB, timing and Signal Integrity analysis also needs to be carried out.

If any observation during analysis, subsequently layout needs to be modified. The analysis reports needs to be submitted to the Engineering team/ internal QA review and fabrication clearance needs to be obtained

# 2.2.3. PCB Fabrication and Bare PCB Inspection

Each PCB must undergo fab process with applicable reports as illustrated below along-with BBT.

Proyen approved vendor will be used for the fabrication services with prior experience of delivering for defense systems.

# a) Visual Inspection:

Each PCB needs to be checked visually under Scope (10X zoom) and examined for printing quality, laminate quality, holes quality and mechanical dimensions. Each PCB needs to be examined as per 10.2.1 and filled for each parameter.

# b) Electrical Inspection:

Each PCB needs to be verified for parameters applicable as listed in table below and Bare Board Test (BBT) reports be verified. Continuity and isolation tests be conducted on each PCB. Each PCB needs to be examined as per 10.2.2 and filled for each parameter.

The process applicability for PCB Fabrication and reports is as follows:

Table 27: PCB Fabrication and Reports   

<table><tr><td>S. No.</td><td>PCB</td><td>Applicability</td><td>Reference Section/Template</td></tr><tr><td>1</td><td>BBP Board</td><td>Following Fabrication compliance reports are to be obtained from the fab houseCertificate of ComplianceOutgoing Report/ quality CertificateMicrosection inspection reportOutgoing report/ stackE-Test Report (FBT)Ionic contamination test reportSurface thickness measurement report</td><td>Section 7.1.3</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>S. No.</td><td>PCB</td><td>Applicability</td><td>Reference Section/Template</td></tr><tr><td></td><td></td><td>· Solderability of PTH report
· Thermal stress test report
· Impedance measurement report
· Cross section analysis PCB
· Transparency plots</td><td></td></tr><tr><td></td><td></td><td>The following quality parameters will be inspected by the QA Engineer and part of Bare PCB Inspection Report
· Conductor Quality checks
· Laminate Quality checks
· Drill hole quality checks
· Breaks, fractures
· Unintentional Copper visibility</td><td></td></tr><tr><td>2</td><td>BOB</td><td>The following quality parameters will be inspected by the QA Engineer and part of Bare PCB Inspection Report
· Conductor Quality checks
· Laminate Quality checks
· Drill hole quality checks
· Breaks, fractures
· Unintentional Copper visibility
· Group A &amp; Group B Certificate</td><td>Section 7.1.3</td></tr><tr><td>3</td><td>PSU Board</td><td>The following quality parameters will be inspected by the QA Engineer and part of Bare PCB Inspection Report
· Conductor Quality checks
· Laminate Quality checks
· Drill hole quality checks
· Breaks, fractures
· Unintentional Copper visibility
· Group A &amp; Group B Certificate</td><td>Section 7.1.3</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>S. No.</td><td>PCB</td><td>Applicability</td><td>Reference Section/Template</td></tr><tr><td>4</td><td>DLC-MU Tx Gain Stage</td><td>The following quality parameters will be inspected by the QA Engineer and part of Bare PCB Inspection Report
·Conductor Quality checks
·Laminate Quality checks
·Drill hole quality checks
·Breaks, fractures
·Unintentional Copper visibility</td><td>Section 7.1.3</td></tr><tr><td>5</td><td>DLC-MU Tx Gain Stage</td><td>The following quality parameters will be inspected by the QA Engineer and part of Bare PCB Inspection Report
·Conductor Quality checks
·Laminate Quality checks
·Drill hole quality checks
·Breaks, fractures
Unintentional Copper visibility</td><td>Section 7.1.3</td></tr><tr><td>7</td><td>Display Device System</td><td>Certificate of Conformance</td><td></td></tr></table>

Note: PCB stage approval from DR&QA, RCI is necessary before assembly.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.2.4. QA Plan for components

a) Components have to be sourced from OEM or authorized distributor according to the design requirements for the system   
b) COC is needed from OEM for all the components.   
c) Components for each batch of PCBs are to be procured in a single lot.   
d) In case of non-availability of any part number, equivalent can be procured with the consent of Designer and QA Rep.   
e) Any deviation for the above needs to be approved by the system designer at Lekha and RCI Rep.

# 2.2.5. BOM Inspection

Each of the components needs to be inspected using

a) Visual inspection.   
b) Part number verification (Short & Long) for active and passive components.   
c) COC verification for date code and lot code.   
d) Measurement for passive components (Value / Tolerance / Wattage)

BOM needs to be approved by DR&QA, RCI before assembly.

BOM Component Kit inspection report template is provided in Section 7.1.4

# 2.2.6. Pre-assembly baking of PCBs

All the boards are to be baked before assembly as per specification.

After baking, the assembly be completed within 8 Hrs. In case assembly could not be completed, PCBs can be stored in dry cabinets at room temperature and RH $< 5\%$ . Details of storage equipment and storage duration to be provided before assembly.

The PCB baking inspection report template is provided in Section 7.1.5.

# 2.2.7. Pre-assembly baking of Components

Moisture Sensitive Devices (MSDs) have to be baked as per J-STD-033 specifications depending upon the MSL, floor life and storage conditions.

The list of devices, applicable baking requirement derived from standard, and the corresponding report is to be obtained from the assembly house.

After baking, the assembly be completed within 8 Hrs. In case assembly could not be completed, components can be stored in dry cabinets at room temperature and RH $< 5\%$ . Details of storage equipment and storage duration to be provided before assembly.

The Component baking inspection report template is provided in Section 7.1.6.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.2.8. Assembly and Inspection facilities

a) Boards contain very high pitch, MSD and ESD sensitive components. Unwanted handling and movements of components and boards from place to place should be avoided. Hence, boards assembly including SMD and BGA A.O.I, X-ray inspection and rework if any, has to be done by the firm in-house. It should not be subcontracted. If due to any unavoidable reason, subcontracting has to be done, it has to be approved by RCI.   
b) The firm should have in-house facilities for

i. Preassembly baking and storage facilities for moisture sensitive devices.   
ii. BGA and SMD pick and place and reflow assembly.   
iii. SMD and BGA rework station   
iv. X-ray inspection   
v. Optical/ digital inspection up to 40X   
vi. Automatic Optical Inspection

# 2.2.9. Assembly of components on PCB

a) Components include fine pitch BGAs, QFNs, Powe rPad ICs, TVSOPs, SOTs and 0402 passive components.   
b) Assembly, Inspection and rework jobs should be done by IPC-610 certified inspectors and IPC-001 certified technicians.   
c) Before assembly solder material and process clearance needs to be obtained from internal QA.   
d) Profiling of each PCBs needs to be done and clearance to obtained from internal QA.

# 2.2.10. Post-Assembly Inspection of PCB

After assembly, the inspection should be done as per Aero space standard Class 3A inspection. The inspection to be done using for BBP Only

# a) Automated Optical Inspection (AOI)

I. AOI should be done for all the solder boards covering the following   
II. Part number checking if visible on the parts   
III. Polarity checking wherever applicable   
IV. Orientation of the component   
V. Proper placement on the pads   
VI. Any tilt or offset in the placement   
VII. Solder Joint quality   
VIII. Missing components

A golden reference board approved by internal QA should be used for AOI. AOI inspection reports have to be submitted.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# b) Optical/digital inspection for solder quality

Optical inspection (40X) is to be used for inspecting all components for solder quality. All different type of solder defects are listed in ANNEXURE.

# c) X-Ray inspection

BGA, QFN and Power Pad ICs need to be X-ray inspected. List is enclosed for each board.   
X-ray inspection report needs to be submitted to each board.   
X-ray images also need to be submitted to each board.

Internal inspection and rework summary needs to be submitted to each board when offering board for assembly inspection to QA agency.

d) Populated PCB Inspection

Poculated PCB Inspection report template is provided in Section 7.1.7.

e) Wiring Interconnect Diagram

Writing Diagram refers section 1.5.3.2.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/C03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 2.3. Hardware/Component Realization:

# 2.3.1. Dry Fit / Mock Assembly

Mock Assembly is to be carried out as per the approved MDI, BOM, Check List and Integration Process Document (Refer Applicable documents table for MDI, BOM & IPD documents ref. Nos.) in presence of QA/QC Agencies before final assembly of the system.

# 2.4. Assembly

The manufacturing of components/part/sub-assy shall be carried out as per the process laid down in to achieve the required dimensions with the tolerance and other parameters. The sub-contractor/ vendor shall ensure that the quality of the store must be achieved by using the appropriate tools, machine and manpower. IGQC of main contractor shall ensure the quality during process of manufacturing / assembly. The vendor shall provide the infrastructure facilities for the inspection of the components / sub systems. (Traceability while procuring sub-assemblies from indigenous or foreign sources, following guidelines shall be followed and adherence to regulatory norms as per IMAP shall be ensured.

a) Component cleared in FAR shall only be considered for assembly.   
b) Final Assembly is to be carried out as per the applicable drawing, and Integration Process Document (Refer Applicable documents table for MDI, BOM & IPD documents in presence of QA/QC Agencies.   
c) Only approved Jigs/Fixtures shall be utilized for assembly.   
d) All safety precautions are to be taken during assembly Project has to issue safety instructions in this regard.   
e) Only calibrated measuring instruments/torque wrenches and serviceable tools / equipment's shall be used during assembly.   
f) Integration report shall be generated in parallel to activities carried out and signature of all stakeholders shall be obtained.   
g) Any rework procedure at assembly stage shall have approval from R&QA- RCI.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3. Quality Assurance & Quality Control Requirements

# 3.1. Quality assurance Plan

The System will be built in accordance with R&QA RCI approved Standard of Preparation (SOP) which includes BoM & MDI. This is the referral and authorized document for identification of materials/items-parts/components/modules in the store. BOM and MDI also provides information on build standard, processes, finishing and functionality aspects. Quality Assurance Plan (QAP) and Flow Chart encompasses various quality verification activities, which need to be undertaken. The flow chart covers various stage inspections and type of QA checks which Main contractor QA and RDAQA needs to perform. All stages duly witnessed/Co-ordinated by QA of the Main Contractor /Designer/ R&QA shall be offered to RDAQA (GW&M) for stage clearances as per QA Matrix through Memo duly signed by Authorised R&QA Rep. For all Sub-assemblies/Sub-parts/ Modules an internal checklist shall be prepared and assigned to every manufactured unit. Inspection & verification process elaborated in grand flow chart & subsequent paragraphs based on the nature of work and activities undertaken at various stages and levels. The QA Process at various stages is displayed in flow chart (Ref. Flow charts) All QA related communication is to be routed through Main Contractors' QA department only.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.2. Quality Assurance Activities

The activities are primarily divided into 3 tiers,

a) Inspection at Manufacturing / Vendor Premises   
b) Quality-Control by the Main Designer/Contractor's QC department   
c) Quality Assurance by the Regulatory body along with executive supervisory checks over the QCD, Re-verification of Critical Stages and Audit

The Inspection and Quality Control at the Main Designer/Contractor's/manufacturer's premises shall comprise of the following:

a) Incoming goods inspection and Tractability establishment (Refer DGAQA Directive 06/2018) and traceability requirements.   
b) In-process inspection (Manufacturing processes, Assembly process, Acceptance Record Generation, Deviation management and Non-conformance recordings) Acceptance Tagging.   
c) Acceptance tests for sub-assemblies and Stage clearances as per applicable test schedule.   
c) Final integration, Conformance tests and acceptance tests.

The quality Assurance process shall comprise of the following:

Manufacturing Process Conformance to Design Quality   
Quality audit checks   
Spot Checks   
Stage Clearances

# 3.3. QA Agencies

The agencies associated in manufacture of system as under

<table><tr><td>a.</td><td>Ordering agency</td><td>RCI, DRDL</td></tr><tr><td>b.</td><td>Design agency</td><td>RCI, DRDL</td></tr><tr><td>c.</td><td>Production agency</td><td>As per P.O/S.O</td></tr><tr><td>d.</td><td>QA Authority</td><td>RCI, R&amp;QA</td></tr><tr><td>e.</td><td>Main Contractor QA</td><td>R&amp;QA, RCI.</td></tr><tr><td>f.</td><td>Control of Documents</td><td>R&amp;QA RCI/ PD Project. Controlled Copies shall be distributed as per Master document entries. The document shall be copied or distributed only with the concurrence of the PD Project.</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lelha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.4. Configuration Management:

a) The Configuration change and control management is responsibility of project & Design Certifying Agency / QA agency approved drawings only shall be issued to the firm. In case of drawings under approval, the Project shall issue the controlled drawings and ensure the same is available with all the stake holders. The Configuration change and control register to be maintained at project which is auditable as per AS 9100D.   
b) The configuration management will include the process by which the configuration is identified, change is managed, configuration status is accounted for, disseminated to all stakeholders and verification and audit of configuration change are conducted.   
c) LRUs Configuration process shall be performed as per configuration process. (Project configuration document no....)

# 3.5. Control Of Document/Drawings:

All documents/Drawings shall be identified with proper document no/issue no/rev no/latest date of issue for the control of documented information; the organization shall address the following activities, as applicable:

a) Distribution, access, retrieval, and use;   
b) Control of changes (e.g., version control);   
c) Prevention of the unintended use of obsolete documented information by removal or by application of suitable identification or controls if kept for any purpose.   
d) Any change in the approved document (Applicable Documents) during development stage shall be brought to the notice of R&QA -RCI.   
e} All QA related issues shall be approved by R&QA -RCL.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.6. Control Of Records:

A system of process [job / route] cards or other records are to be maintained by Project, R&QA-RCI/its Vendor for each item, so that:

a) Quality Assurance documentation is maintained through all stages of manufacture /repair and /or storage.   
b) The personnel responsible for each stage can be identified. These records are to be preserved by the firm for a minimum period of Ten Years /as per R&QA-RCI procedure.   
e) The system of recording will also ensure the identity of raw materials / or the component / manufacturer / Lot No. etc., so that full details can be traced at any stage of manufacture / overhaul / repair.   
d) All data, record sheets TDRS records/ Route cards/ Inspection report is to be uniquely numbered and will be maintained in soft and hard format by the manufacturer (Project/RCI, Vendor/Sub vendor) and will be retained as per the contract from the date of dispatch of the item.   
e) All the original reports (Ex. Test Reports, Dimension Inspection reports) shall be submitted to QA. Agencies for the final clearance and the copy of approved reports shall be submitted to R&QA - RCI for reference in soft / Hard copy.

# 3.7. Control of Design & Development:

Any change in design during production stage shall be brought to the notice of QA Agency with proper change request and there of recorded in (ECN) and duly approved from QA Agency. All the drawings undergone design change / modification for a particular component/assembly shall be properly maintained in respective project office or work center for AS 9100 Audit.

The proposed changes during manufacturing process by any stakeholder shall be documented/ recorded and initiated to main contractor QA Agency, and the traceability of all the change incorporated to be stored and maintained by the firms.

# Part No/Drawing No of Components:

a) All components shall be uniquely identified with Drawing no/part no.   
b) Part no. and Drg. No shall be as per drawing office procedure of Project.   
c) All modifications in any Drg./part no shall be uniquely identified and same has to be reflected on the component. Components produced against any drawing no/part no, shall be allotted s.l. no. in order.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.8. Sub-Contract / Outsourcing:

(a) All sub-contract/outsourcing activities will be governed as per guidelines stipulated in R&QA RCP for QA during outsourcing.   
b) The subcontract outsourcing procedure shall include acceptance of industry standard QA requirement such as AS 9102 (First Article Inspection) for vendor/sub-contractor.   
c) All sub-contractors are required to comply with quality standard specified in the document and established inspection and testing facilities/arrangements, so that firm's product complies with technical specification.   
d) All sub contracted items shall be accepted after necessary QC/QA check including all dimensions, weight and material test reports with reference to approved drawing and in-house inspection report.   
e) Traceability and identification of the product shall be established starting from raw-material stage to its packing and till specified item in the approved document is accepted.   
f) Main contractor outsourcing procedure / document shall also elaborate guidelines to assess, evaluate and control their subcontractor/vendor.   
g) Records regarding assessment of sub-contractor and its quality management system along with periodical audit, vendor rating, evaluation etc. is to be maintained and to be produced to the QC/OA agencies as and when sought.

# 3.9. Identification:

The material and component shall be identified with following details.

<table><tr><td>Material</td><td>Components</td></tr><tr><td>Material Grade &amp; Heat treatment condition</td><td>Manufacturer name</td></tr><tr><td>Heat no/Melt no/Cast No.</td><td>Part No./Drawing number</td></tr><tr><td>Heat treatment Batch No.</td><td>SI. No.</td></tr><tr><td>Material size and SI. No.</td><td>Mod status</td></tr><tr><td>Grain flow direction.</td><td>Material heat no/HT batch no</td></tr><tr><td></td><td>Lot No. (for fasteners)</td></tr><tr><td colspan="2">All test reports and process log sheets shall be uniquely numbered / identified.</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.10. Traceability:

Traceability of all records (Test reports and process log sheets) shall be maintained with respect to the material details, components, sub assembly & assembly components.

# 3.11. Identification

Component identification and assembly/sub-assembly components. All brought out components / raw materials shall be traceable with OEMs certificate of conformance/test certificate/component test report.

# 3.12. Material Acceptance:

Material Acceptance requirement will be as follow Process flow chart of the same is enclosed in Flow charts in chapter 4

<table><tr><td>Material Classification</td><td>Material Source</td><td>RMQAP</td><td>Clearance</td></tr><tr><td>NON-CRITICAL</td><td>Type Approved/Non-type approved/Bought out material</td><td>R&amp;QA RCI specification/RMQAP&#x27;s</td><td>R&amp;QA-RCI (Main Contractor QC)</td></tr></table>

# 3.13. Non-Conformances:

Any non-conformance/deviation/defect observed during any stage of inspection/verification from approved document and standard shall be recorded in the Form 53-A (Ref. forms & formats for form 53-A).

Disposition procedure flow chart of non-conforming product is attached in Flow chart clause in chapter 4

The non-conforming product shall be handed over to quarantine store for resolving the issue with respective OEM. Action as per R&QA RCI shall be followed for disposal of non conformance/deviation. # Waiver board and rework authorization board.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.14. Re-sampling and Testing

Re-sampling and testing shall be in accordance with AMS 2371, if any specimen of any product used in above tests fails to meet the specified requirements, disposition of the product may be based on the results of additional testing on double the number of the failed samples except otherwise specified in following clauses:

a) Except where retesting results in discard of non-conforming materials, failure of any retest specimen to meet the specified requirements shall be for rejection of the material represented and no additional tests shall be permitted.   
b) If segregation, laps, folds, cracks, pitted area, inclusions or voids are found in macrostructure examination, two adjacent slices, one adjacent to each face of original slice shall be cut and examined. The procedure may be repeated until it is assured that the defective area has been removed.   
c) During ultrasonic inspection of rolling stock suitable stage of manufacture if unacceptable defect is found, the area containing each indication shall be removed and examined. If adequate analysis can be made from observation of ultrasonic indications to identify cause of indication, no further investigation would be necessary. If the nature of extent of indication cannot be adequately analysed by examination, the removed portion shall be further sectioned for complete analysis. The product faces adjacent to indications shall be macro etched and examined. If the ultrasonic indications are determined to be isolated and caused by, or associated with segregation voids, or inclusion, the remainder of the affected slab may be used. However, if etching of the adjacent cut faces of the slab reveals additional evidence of segregation, voids or inclusions, further cutting, etching and examination shall be conducted until it is assured the defective have been removed.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.15. Defect Investigation: (FAB)

a) A Defect Investigation Committee (DIC) shall be constituted for each development project or as per main contractor's policy with members from Designer, QA, R&QA-RCI and User Services (wherever applicable). The main contractor QA shall be responsible for convening and coordinating DI meeting.   
b} DIC may co-opt expert members from external agencies if required.

# 3.16. Batch / Lot Acceptance:

The lot acceptance is subjected to clearance of Proto qualification by QA Agencies and dispatch clearance/Green card is issued by R&QA-RCI based on Release note by ARNS (Authorise Release Note Signatory).

# 3.17. MIS, Test Jigs and Fixtures:

All test fixtures, jigs, tools, gauges, instrument etc., required to undertake manufacturing/inspection along with calibration certificate shall be made available by the vendor. Gauges and Templates as per the requirements for the inspection of components must be fabricated by the vendor and validated by R&QA-RCI. Calibration of all the instruments and gauges shall be maintained by the vendor. Calibration shall be done by the Govt. approved agency/NABL accredited lab only.

During Development phase all required assembly fixtures are to be designed and fabricated by the vendor and shall be validated by R&QA-RCI

<table><tr><td>DLC-MJ Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/O03</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.18. Test Rigs:

Test rigs, which addresses a broad category of equipment which shall include mock-ups, rigs, jigs, fixtures, simulators, simulation software, software tools, standard test equipment, integration rigs, hardware-in-loop simulator (HILS) etc. used during the design and development phase of system.

# 3.19. Review And Acceptance Of Quality Assurance Plan:

Quality Assurance plan shall be reviewed by the main contractor and inspection agencies and Approval will be given by QA Agency/QAP Approval Authority, Approved quality plan shall be followed for realizing the units. Revision to reflect changes will be maintained as per the "Amendment Record Sheet" with approval of QA authority.

Any amendment to the QAP shall be proposed by Vendor, reviewed by R&QA and final approval shall be obtained from R&QA -RCI.

# 3.20. Implementation Feedback:

In case of any feedback received from any stage and from any stakeholders, the feedback will be discussed with all stakeholders and if found necessary it will be incorporated with prior approval.

# 3.21. Training & Awareness

# 3.21.1. Training Program:

Firm QA Manager is responsible to ensure that operators and firm QC reps. are certified and aware of the respective clauses of this QAP and standards /SOP/Guidelines /Instructions, and equipped with proper skills and knowledge to perform activities

# 3.21.2. Awareness & Communication:

All Communication shall be routed through respective Design QA departments only. All RDAQA (GW&M) Stages shall be offered through Memos only.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT T</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 3.22. Handling

Handling precautions including ESD shall be exercised during all stages of fabrication, inspection, testing and packing & delivery.

# 3.23. Storage

Completed unit will be covered with Anti-Static covers and stored in normal room temperature.

# 3.24. Packaging

Each unit must be put in Rugged packaging box. Guidelines mentioned in MIL-STD 1367 shall be followed for developing the packing box. M/s Lekha Wireless Solutions Pvt. Ltd will also make sure that the connector to be covered with caps.

# 3.25. Transportation

The equipment/stores ordered should be packed to withstand transportation hazards. Safety and handling instructions should be marked on all sides

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 4. Flow Charts

# 4.1. Flow Chart -Mechanical

![](images/76ce5853d40c887af4e756ab56bfb67f764c3de0df9060239657932786e4c44f.jpg)  
Figure 13: QA Process flow for Mechanical

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/48f17f6bfaeb0b7eb2ec97494635f66bf6c6478ce1f80ac8f652d854bb8e4359.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/70c2c6afe55c561d884fa9d2ebfb01e8c3cd74753e46f67ce2a866bf47bd42a4.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 4.2. Flow Chart -Electrical

![](images/954920155c0d18c0dcc7381ecab595f35f880568a68c7ec8dff18f1fff4d0cfe.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/5512f7fbfcad56042bd2089d5a51aff2933832118a10250f122906d6a272cdbe.jpg)  
Figure 14: QA PCB Process Flow

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 4.3. Process Flow chart - Unit level

The unit level process flow chart for the Data Link Transmitted and Monitoring Unit is presented in Figure below.

![](images/cdbc754f2254ae3acd0ad2d0ec0a646e5c5683f6a94dda9fba8634ec05bbf6c6.jpg)  
Figure 31: Process Flow for Unit Level

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Intentionally Left Blank Page

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

5. Quality Assurance Matrix

5.1. Mechanical QA Matrix

QA matrix for RAW material

<table><tr><td rowspan="2">Raw Material</td><td rowspan="2">Raw Material Stage / Activity</td><td rowspan="2">Characteristics of checks</td><td rowspan="2">Quantum of Check</td><td rowspan="2">Reference Standard/ Document</td><td rowspan="2">Format of Record</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td rowspan="4">AA6082 T6 Flat Bar/Plate/Sheet</td><td rowspan="4">RMI &amp; RMT</td><td>Raw Material Identification (Dimensional, Visual)</td><td>100%</td><td rowspan="4">RCI/DR&amp;QA/RMQAP/059.</td><td>Inspection Report/ Stenciling report</td><td>P</td><td rowspan="4">R</td><td rowspan="2">W</td></tr><tr><td>Ultrasonic Test</td><td>100%</td><td>UT Test Report</td><td>P</td></tr><tr><td>Chemical Analysis</td><td>02 Samples</td><td>Test Report from NABL accredited Lab</td><td>P</td><td>W</td></tr><tr><td>Tensile at Room temperature</td><td>3 Samples</td><td>Test Report from NABL accredited Lab</td><td>P</td><td>W</td></tr></table>

[\frac{C + O{S}_{1} \cdot  {h}_{2}}{2{S}_{1} \cdot  {S}_{2}}]

QA Matrix for Component Stage   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING. UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2">SI.
No.</td><td rowspan="2">Name of the Component &amp; Qty. per Set</td><td rowspan="2">Characteristics of checks</td><td rowspan="2">Quantum of Check</td><td rowspan="2">Reference Document</td><td rowspan="2">Format of Record</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td rowspan="12">1.</td><td rowspan="2">Components List: AA 6082 T6</td><td>Dimensional Inspection</td><td>100%</td><td></td><td>Inspection Report</td><td rowspan="2">P</td><td rowspan="2">R</td><td rowspan="2">W</td></tr><tr><td>DP</td><td>100%</td><td>QAP No: LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003 Dt: 31 Jan-2025</td><td>Test Report</td></tr><tr><td>1.Front Plate, Drg No. LW-DLC-MU-PD-01</td><td rowspan="9">Surface Coating Visual Examination After coating (ex. Chromation)</td><td rowspan="9">100%</td><td rowspan="9">QAP No: LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT, QT/003 Dt: 31 Jan-2025</td><td rowspan="9">Coating COC</td><td rowspan="9">P</td><td rowspan="9">R</td><td rowspan="9">W</td></tr><tr><td>2.Top Plate, Drg No. LW-DLC-MU-PD-02</td></tr><tr><td>3.Rear Plate, Drg No. LW-DLC-MU-PD-03</td></tr><tr><td>4.LH Plate, Drg No. LW-DLC-MU-PD-04</td></tr><tr><td>5.RH Plate, Drg No. LW-DLC-MU-PD-05</td></tr><tr><td>6.Bottom Plate, Drg No. LW-DLC-MU-PD-06</td></tr><tr><td>7.BOB Top Plate, Drg No. LW-DLC-MU-PD-07</td></tr><tr><td>8.BBP Top Plate, Drg No. LW-DLC-MU-PD-08</td></tr><tr><td>9.PSU Top Plate-1, Drg No. LW-DLC-MU-PD-09</td></tr><tr><td colspan="8">10.PSU Top Plate-2, Drg No. LW-DLC-</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="10">SI.
No.</td><td rowspan="2">Name of the Component &amp; Qty. per Set</td><td rowspan="10">Characteristics of checks</td><td rowspan="10">Quantum of Check</td><td rowspan="10">Reference Document</td><td rowspan="10">Format of Record</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td>MU-PD-10</td><td></td><td></td><td></td></tr><tr><td>11. PSU Leg, Drg No. LW-DLC-MU-PD-11</td><td></td><td></td><td></td></tr><tr><td>12. ETH Top Cover, Drg No. LW-DLC-MU-PD-12</td><td></td><td></td><td></td></tr><tr><td>13. Tx Gain BT Plate, Drg No. LW-DLC-MU-PD-13</td><td></td><td></td><td></td></tr><tr><td>14. Tx Gain TP, Drg No. LW-DLC-MU-PD-14</td><td></td><td></td><td></td></tr><tr><td>15. Rx Gain BT Plate, Drg No. LW-DLC-MU-PD-15</td><td></td><td></td><td></td></tr><tr><td>16. Rx Gain TP, Drg No. LW-DLC-MU-PD-16</td><td></td><td></td><td></td></tr><tr><td>17. Feed Thru Holder, Drg No. LW-DLC-MU-PD-17</td><td></td><td></td><td></td></tr><tr><td rowspan="4">2</td><td rowspan="4">Tests after Coating @ Coupon Level</td><td>Salt Spray Test</td><td>01 Samples</td><td rowspan="4">RCI/R&amp;QA/Coating/01</td><td>Test Report from NABL accredit Lab</td><td>P</td><td>R</td><td>V</td></tr><tr><td>Electric Resistance Test</td><td>01 Samples</td><td>Test Report from NABL accredit Lab</td><td>P</td><td>R</td><td>V</td></tr><tr><td>Adhesion Test</td><td>01 Samples</td><td>Test Report from NABL accredit Lab</td><td>P</td><td>R</td><td>V</td></tr><tr><td>Coating Thickness</td><td>01 Samples</td><td>Test Report from NABL accredit Lab</td><td>P</td><td>R</td><td>V</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2">SI.
No.</td><td rowspan="2">Name of the Component &amp; Qty. per Set</td><td rowspan="2">Characteristics of checks</td><td rowspan="2">Quantum of Check</td><td rowspan="2">Reference Document</td><td rowspan="2">Format of Record</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td rowspan="6">3</td><td>1. Front Plate, Drg No. LW-DLC-MU-PD-01</td><td rowspan="6">Surface Coating Visual Examination After coating (ex. Powder Coat)</td><td rowspan="6">100%</td><td rowspan="6">Annexure-E</td><td rowspan="6">Powder Coat Report</td><td rowspan="6">P</td><td rowspan="6">R</td><td rowspan="6">V</td></tr><tr><td>2. Top Plate, Drg No. LWLW-DLC-MU-PD-02</td></tr><tr><td>3. Rear Plate, Drg No. LW-DLC-MU-PD-03</td></tr><tr><td>4.LH Plate, Drg No. LW-DLC-MU-PD-04</td></tr><tr><td>5.RH Plate, Drg No. LW-DLC-MU-PD-05</td></tr><tr><td>6. Bottom Plate, Drg No. LW-DLC-MU-PD-06</td></tr></table>

![](images/61e6ba2e51d9c3e7188323d93ce02e7e38e4159fcf9f37d5e26cac8520b2d45d.jpg)

QA Matrix for Bought Out Items:   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2">SI.
No.</td><td rowspan="2">Description.</td><td rowspan="2">Drawing No / Standard.</td><td rowspan="2">Qty.</td><td rowspan="2">Characteristics of check.</td><td rowspan="2">Check details</td><td rowspan="2">Quantum of check</td><td rowspan="2">Format of record</td><td rowspan="2">Reference Document</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td>1.</td><td>Fasteners List.
1. M3X8L Philips Pan Head Screw
2. M4X16L Philips CSK Head Screw
3. M3X10L Philips CSK Head Screw
4. M4X6L Philips Pan Head Screw
5. M3X25L Philips Pan Head Screw
6. M3X18L Philips Pan Head Screw
7. M4X35L Philips Pan Head Screw
8. M4X8L Philips Pan Head Screw
9. M2X6L Philips CSK Head Screw
10. M2X4L Philips Pan Head Screw
11. M2.5X4L Philips Pan Head Screw
12. M3X6L Philips CSK Head Screw</td><td>1. DIN-7985A
2. DIN-965A
3. DIN-965A
4. DIN-7985A
5. DIN-7985A
6. DIN-7985A
7. DIN-7985A
8. DIN-7985A
9. DIN-965A
10. DIN-7985A
11. DIN-7985A
12. DIN-965A
13. DIN-7985A
14. DIN-127B
15. DIN-125A
16. DIN-125A
17. DIN-127B
18. DIN-125A
19. DIN-933
20. DIN-315
21. DIN-934</td><td>As per BOM</td><td>Visual Inspection and As Per COC &amp; Test Reports</td><td>As Per COC &amp; Test Reports</td><td>Sample</td><td>Clearance Report</td><td>MDI &amp; BOM Doc. No. LW/DRDL/LR SAM/DLC-MU/SYS/DOC/MECH/MDI-BOM</td><td>P</td><td>R</td><td>V</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2">Sl.
No.</td><td rowspan="2">Description.</td><td rowspan="2">Drawing No / Standard.</td><td rowspan="2">Qty.</td><td rowspan="2">Characteristi
cs of check.</td><td rowspan="2">Check
details</td><td rowspan="2">Quantum
of check</td><td rowspan="2">Format of
record</td><td rowspan="2">Reference
Document</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td></td><td>13. M2.5X6L Philips Pan
Head Screw
14. M3 Spring Washer
15. M3 Plain Washer
16. M4 Plain Washer
17. M4 Spring Washer
18. M2 Plain Washer
19. M6X40L Hex Head
Screw
20. M6 Wing Nut
21. M6 Nut
22. M6 Plain Washer
23. M3x0.5-2D Insert
24. M2.5x0.45-1D Insert
25. M3x0.5-1D Insert
26. M4x0.7-1D Insert
27. M3x0.5-1.5 Insert
28. M2x0.4-2D Insert
29. M2x0.4-1D Insert</td><td>22. DIN-125A
23. DIN-8140
24. DIN-8140
25. DIN-8140
26. DIN-8140
27. DIN-8140
28. DIN-8140
29. DIN-8140</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

![](images/3dd5981c6aa5b594f0a2d219ce651d12fd576509cec3e33254c978d5cc3cdf0b.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2">Sl.
No.</td><td rowspan="2">Description.</td><td rowspan="2">Drawing No / Standard.</td><td rowspan="2">Qty.</td><td rowspan="2">Characteristics of check.</td><td rowspan="2">Check details</td><td rowspan="2">Quantum of check</td><td rowspan="2">Format of record</td><td rowspan="2">Reference Document</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td>2.</td><td>Gaskets
1. J1- D38999/20WE6PN
Drg No: LWS-DLC-MU-GAS-01
2. J2-D38999/20WD35SN
Drg No: LWS-DLC-MU-GAS-02
3. J3-RJFTV21G
Drg No: LWS-DLC-MU-GAS-03
4. J4-USBFTV21G
Drg No: LWS-DLC-MU-GAS-04
5. DIA 3MM ROUND
Drg No: LWS-DLC-MU-GAS-05
6. SQ 3MM Drg No: LWS-DLC-MU-GAS-06
7. SQ 2MM Drg No: LWS-DLC-MU-GAS-07
8. DIA 1MM ROUND Drg No: LWS-DLC-MU-GAS-08</td><td>MIL-G-83528</td><td>As per BOM</td><td>Visual Inspection and As Per COC</td><td>As Per COC</td><td>100%</td><td></td><td>MDI &amp; BOM Doc. No. LW/DRDL/LR SAM/DLC-MU/SYS/DOC /MECH/MDI-BOM</td><td>P</td><td>R</td><td>V</td></tr></table>

![](images/fed44a062ee8a54c3a3ab29ddddb9d6495189cf834b1811b04ca24e4607854cd.jpg)

QA Matrix for Assembly (Integration):   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2">SI.
No.</td><td rowspan="2">Description</td><td rowspan="2">Drawing No/
Standard.</td><td rowspan="2">Qty.</td><td rowspan="2">Characteristics
of check.</td><td rowspan="2">Check
details</td><td rowspan="2">Quantum
of check</td><td rowspan="2">Format
of record</td><td rowspan="2">Reference
Document</td><td colspan="3">Agency</td></tr><tr><td>Firm</td><td>PROJECT</td><td>R&amp;QA</td></tr><tr><td>1.</td><td>Sub Assembly:
1. Sub Assembly 1-Front
Plate
2. Sub Assembly 2-Top
Plate
3. Sub Assembly 3-Rear
Plate
4. Sub Assembly 4-LH
Plate
5. Sub Assembly 5-RH
Plate
6. Sub Assembly 6-Bottom Plate
7. Sub Assembly 6-Bottom Plate Next Sub
Assembly 6.1 - BOB
Assembly
8. Sub Assembly 6-Bottom Plate Next Sub
Assembly 6.2- BBP
Assembly
9. Sub Assembly 6-Bottom Plate Next Sub</td><td>1. LWS-DLC-MU-ASSY-01
2. LWS-DLC-MU-ASSY-02
3. LWS-DLC-MU-ASSY-03
4. LWS-DLC-MU-ASSY-04
5. LWS-DLC-MU-ASSY-05
6. LWS-DLC-MU-ASSY-06
7. LWS-DLC-MU-ASSY-07
8. LWS-DLC-MU-ASSY-08
9. LWS-DLC-MU-ASSY-09
10. LWS-DLC-MU-ASSY-10
11. LWS-DLC-MU-ASSY-11
12. LWS-DLC-MU-ASSY-12</td><td>As per
Drawing.</td><td>As per IPD</td><td>Visual</td><td>100%</td><td>Assembly
Check
List</td><td>IPD,
Checklist,
MDI &amp; 
BOM.</td><td>P</td><td>R</td><td>W</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td colspan="2">Assembly 6.3 - PSU Assembly10. Sub Assembly 6-Bottom Plate Next SubAssembly 6.4 -ETHERNET Assembly11. Sub Assembly 6-Bottom Plate Next SubAssembly 6.5 - TX GainStage Assembly.12. Sub Assembly 6-Bottom Plate Next SubAssembly 6.6 - RX GainStage Assembly13. Sub Assembly 6-Bottom Plate Next SubAssembly 6.7 - FeedThru Filter Assembly</td><td>13. LWS-DLC-MU-ASSY-13</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2.</td><td>Final Assembly</td><td>LWS-DLC-MUGA-01</td><td>As per Drawing.</td><td>As per IPD</td><td>Visual</td><td>100%</td><td>AssemblyCheckList</td><td>P</td><td>R</td><td>W</td><td></td></tr></table>

![](images/79ef116874eb0fbf0a83025168cd07171ece5cee0ea73d5df5dceedbc8d5d0fd.jpg)

IR - Inspection Report,   
V - Verify,   
W - Witness,   
R-Review,   
P-Perform,

5.2. Electrical QA Matrix   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

Table 28: Electrical QA matrix   

<table><tr><td>S.
No.</td><td>Stage
Description</td><td>Quality checks</td><td>Types of Checks</td><td>Sample Size</td><td>Reference Documents</td><td>Format of Records</td><td>Lekha</td><td>Project/ Designer</td><td>R&amp;QA
(RCI)</td></tr><tr><td rowspan="5">1</td><td rowspan="5">Bare PCB</td><td>a. PCB Test reports as applicable if multi-layer and hybrid</td><td>PCB Test Reports</td><td>100%</td><td>Bare PCB Inspection Report</td><td>TC</td><td>P</td><td>R</td><td>V</td></tr><tr><td>b. Physical checks/warp/bend</td><td>Test reports and inspection</td><td>100%</td><td rowspan="4">1. Bill of Material
2. Master Drawing Index Refer: LW/DRDL/LRSAM/DLC-MU/SYS/DOC/ELE/MDI-BOM Refer Section 7.1.3</td><td>IR</td><td>P</td><td>R</td><td>W</td></tr><tr><td>c. Dimensional verification</td><td>Test reports and inspection</td><td>100%</td><td>IR</td><td>P</td><td>R</td><td>V</td></tr><tr><td>d. Electrical inspection</td><td>Test reports and inspection</td><td>100%</td><td>IR</td><td>P</td><td>R</td><td>V</td></tr><tr><td>e. BBT</td><td>Isolation Checks</td><td>One Per Batch</td><td>IR</td><td>P</td><td>R</td><td>R</td></tr><tr><td>2</td><td>Component Kit inspection</td><td>IG, Kit inspection</td><td>CoC, item verification, BOM MDI and quantity checks</td><td>100%</td><td>Kit Inspection Report Refer Section:7.1.4</td><td>IR</td><td>P</td><td>R</td><td>W</td></tr><tr><td rowspan="2">3</td><td rowspan="2">PCB Assembly</td><td>a. Alignment of components</td><td rowspan="2">Inspection report 1. Visual Inspection 2. AOI for BBP 3. X-Ray for BGA</td><td rowspan="2">100%</td><td rowspan="2">Populated PCB inspection report Refer Section:7.1.5 &amp;7.1.6 &amp; E-MDI</td><td>IR</td><td>P</td><td>R</td><td>W</td></tr><tr><td>b. Polarity or orientation of components</td><td>IR</td><td>P</td><td>R</td><td>W</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="2"></td><td rowspan="2"></td><td>c. Soldering Defects</td><td rowspan="2">4.Cold check and isolation check report Test report</td><td rowspan="2"></td><td rowspan="2">2.Inspection check report Refer Section:7.1.8</td><td>IR</td><td>P</td><td>R</td><td>W</td></tr><tr><td>d. Missing Components</td><td>IR</td><td>P</td><td>R</td><td>W</td></tr><tr><td>4</td><td>Unit Assembly (Mock Integration)</td><td>Workmanship Fasteners</td><td>Functional Test</td><td>100%</td><td>IPD</td><td>IR</td><td>P</td><td>R</td><td>NA</td></tr><tr><td>5</td><td>IR Checks</td><td>1.Isolation check</td><td>Functional Test</td><td>100%</td><td>Isolation Report Refer Section:7.2.1</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>6</td><td>Function test</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>Function checks Report, QAP Doc, Refer Section:7.2.2</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>7</td><td>LRU/Unit Level Burn-in</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>Burn-In Test Report QAP Doc, Refer Section:7.3.1</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td rowspan="2">8</td><td rowspan="2">Potting</td><td>a. Potting Material</td><td>1.Potting material</td><td rowspan="2">100%</td><td rowspan="2">QAP Doc Refer Section:7.1.11</td><td>IR</td><td>P</td><td>R</td><td>V</td></tr><tr><td>b. Potting of PCB</td><td>2. COC</td><td>IR</td><td>P</td><td>R</td><td>W</td></tr><tr><td rowspan="3">9</td><td rowspan="3">Conformal coating</td><td>a. Coating Material</td><td rowspan="3">1. Visual 2. COC</td><td rowspan="3">100%</td><td rowspan="3">QAP Doc Refer Section :7.1.11</td><td></td><td>P</td><td>R</td><td>R</td></tr><tr><td>b. Uniformity of Coating</td><td></td><td>P</td><td>R</td><td>W</td></tr><tr><td>c. Finish</td><td></td><td>P</td><td>R</td><td>W</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td rowspan="5">10</td><td rowspan="5">Unit Assembly</td><td>a. Unit configuration</td><td>Validate configurations</td><td>100%</td><td>As per IPD Check List</td><td>IR</td><td>P</td><td>W/R</td><td>W</td></tr><tr><td>b. DLC-MU BBP Assembled board functional clearance</td><td>Board Level Functional Checks</td><td>100%</td><td>BBP Assembled board functional Test Report Report Refer Section: 7.1.10</td><td>IR</td><td>P</td><td>V</td><td>W</td></tr><tr><td>c. DLC-MU BOB Assembled board functional clearance</td><td>Board Level Functional Checks</td><td>100%</td><td>BOB Assembled board functional Test Report Report Refer Section: 7.1.10</td><td>IR</td><td>P</td><td>V</td><td>W</td></tr><tr><td>d. DLC-MU PSU Assembled board functional clearance</td><td>Board Level Functional Checks</td><td>100%</td><td>PSU Assembled board functional Test Report Report Refer Section: 7.1.10</td><td>IR</td><td>P</td><td>V</td><td>W</td></tr><tr><td>e. DLC-MU Tx Gain Stage Assembled board functional clearance</td><td>Board Level Functional Checks</td><td>100%</td><td>Tx Gain Stage Assembled board functional Test Report Report Refer Section: 7.1.10</td><td>IR</td><td>P</td><td>V</td><td>W</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>(%)</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%007</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%007</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%007</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%007</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%007</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%007</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%007</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%007</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%008</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%008</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%008</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%009</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%009</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%00T</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%011</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%01</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%010</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%01</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%010</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%01</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010
%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%009</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%01
%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%007</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%01</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%007</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%01</td><td>%010
%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>v</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>v</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>v</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%007</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>v</td><td>%010</td><td>%01</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%007</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%007</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%00T</td><td>%007</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>v</td><td>%00T</td><td>%007</td><td>%00T</td><td>%007</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%007</td></tr><tr><td>M</td><td>M</td><td>d</td><td>v</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%01</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%01</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%01</td><td>%00T</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td>%008</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%10</td><td>%00T</td><td>%008</td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T
%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%00T</td><td>%00T</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%007</td><td>%007</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%007</td><td>%007</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%007</td><td>%007</td><td></td><td></td></tr><tr><td>M</td><td>M</td><td>d</td><td>V</td><td>%010</td><td>%010</td><td>%007</td><td>%007</td><td></td><td></td></tr></table>

<table><tr><td>L'ENVIENANCE DE SELECTION DE SPÉCIALE DE L'ENVIENCE DE SELECTION DE SPÉCIALE DE L'ENVIENCE DE SELECTION DE SPÉCIALE DE L'ENVIENCE DE SELECTION DE SPÉCIALE DE L'ENVIENCE DE SELECTION DE SPÉCIALE DE L'ENVIENCE DE SELECTION DE SPÉCIALE DE L'ENVIENCE DE SELECTION DE SPÉCIALE DE L'ENVIENCE DE SELECTIONDE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIAL DE SPÉCIALE DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIAL DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉСA DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCELA DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE-spCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW DE SPÁCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SPÉCW OF SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SP ÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SP ÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DELSPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCIALE DE SÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SÉCIALE DE SÉCIALE DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIAL DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIALE DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAII DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAIA DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAA DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIA I DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIA1 DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIAI DE SPÉCW DE SÉCIA</td><td colspan="4"></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>15</td><td>Qualification Test (QT)</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QT Test Report QAP Doc,</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>a</td><td>EMI/EMC</td><td>CE102, CS101, CS114, CS115, CS116, RE102, RS103, HESD</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>b</td><td>High Temperature (Operational)</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>c</td><td>Low Temperature (Operational)</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>d</td><td>Vibration</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>e</td><td>Humidity</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>f</td><td>Bump</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>g</td><td>Acceleration</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>h</td><td>Altitude</td><td>Functional Checks</td><td>Functional Test</td><td>100%</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>W</td><td>W</td></tr><tr><td>i</td><td>Mould Growth</td><td>Visual Inspection</td><td>Visual Inspection</td><td>On Sample</td><td>QAP Doc</td><td>ATL</td><td>P</td><td>R</td><td>R</td></tr></table>

<table><tr><td>M</td><td>M</td><td>d</td><td></td><td></td><td>%00T</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="11"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="2"></td><td colspan="4"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr><tr><td colspan="6"></td><td colspan="5"></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6. Electrical Testing on System after Assembly

# 6.1. Test Flow

Table 29: Test Specifications   

<table><tr><td>S. No.</td><td>Test Set</td><td>Section Reference</td></tr><tr><td>1.</td><td>Functional Tests</td><td>Section 6.2</td></tr><tr><td>2.</td><td>Burn-in Test</td><td>Section 6.3</td></tr><tr><td>3.</td><td>ESS Tests</td><td>Section 6.3</td></tr><tr><td>4.</td><td>AT Tests</td><td>Section 6.4</td></tr><tr><td>5.</td><td>EMI/ EMC Tests</td><td>Section 6.6</td></tr><tr><td>6.</td><td>QT Tests</td><td>Section 6.5</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.2. Detailed Functional Test

Table 30: Details Functional Test Specification   

<table><tr><td>S. No</td><td>Functional test</td><td>Parameters Tested</td><td>Test Procedure</td></tr><tr><td>1</td><td>System Function Readiness and RF Initialization.</td><td>Functional Verification for System function readiness and RF initialization</td><td>Section: 6.8.1</td></tr><tr><td>2</td><td>Ethernet Test</td><td>Functional Verification for Ethernet Interface</td><td>Section: 6.8.2</td></tr><tr><td>3</td><td colspan="3">Transmitter</td></tr><tr><td>3.1</td><td>Transmission Power Test</td><td>Current measurement w.r.t 3 different voltages, RF Transmission power, with 3 different frequency</td><td>Section: 6.8.3.1</td></tr><tr><td>4</td><td colspan="3">Receiver</td></tr><tr><td>4.1</td><td>Receiver Sensitivity Test</td><td>Current measurement w.r.t 3 different voltages, Sensitivity, RSSI with 3 different frequency</td><td>Section: 6.8.4.1</td></tr><tr><td>5</td><td>Dynamic range Power Test -Design parameter evaluation (Bench test only)</td><td>DLC unit should decode for received signal strength between -35dBm to -105dBm Power level</td><td>Section: 6.8.5</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.3. Burn-IN and ESS Test Specifications

ESS test Specification is given in the Table below, Item Category: Items under Shelter & Controlled

Table 31: List of ESS Test Specification

<table><tr><td>S. No</td><td>Test</td><td>Test Condition</td><td>Test Procedure</td></tr><tr><td>1</td><td>Burn-In</td><td>+55°C±2°C for 48 hours in powered ON condition, Test Shall be conducted at LRU Level.</td><td>Section: 6.9</td></tr><tr><td>2</td><td colspan="3">ESS</td></tr><tr><td>a)</td><td>Pre-Random Vibration (RV1)</td><td>Duration: 5 min/axis
5 - 20 Hz : (6dB per octave) desirable
20 - 50Hz : 0.02 g² /Hz, then rolling down to 0.001 g² /Hz at 500 Hz Three axes. 15 minutes cumulative</td><td>Section: 6.11.1</td></tr><tr><td>b)</td><td>Thermal Cycling</td><td>a) -20°C ± 2°C for 1 hour
b) -20°C to +55°C at 10°C/min
c) +55°C ± 2°C for 1 Hour
d) +55°C to +70°C at 10°C/Min
e) 70°C ± 2°C for 1 hour.
f) 70°C to -20°C at 10°C/min
Total Cycle 6
PREET at ambient INSET as per Figure 17
POET at ambient
Note:
1. Last three cycles should be failure free
2. In case failure is observed during pre-defect free cycles the defect is to be rectified and test continued until three defect free cycles have been carried out.
3. Incase failure is observed during defect free cycles, detailed failure investigation including process review and design review is to be carried out to establish the cause of failure prior to commencement of production. Thereafter, the test is to be repeated from beginning</td><td>Section: 6.11.2</td></tr><tr><td>c)</td><td>Post Random Vibration (RV2)</td><td>Duration: 5 min/axis
5 - 20 Hz : (6dB per octave) desirable
20 - 50Hz : 0.02 g² /Hz, then rolling down to 0.001 g² /Hz at 500 Hz Three axes. 15 minutes cumulative</td><td>Section: 6.11.3</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.3.1. ESS Test Flow Chart Following is the ESS Test Flow Chart

![](images/efb1b7b60a0e4d8897c5900472339e644bf189216bd2f8b42fde46265da24db6.jpg)  
Figure 15: ESS Test Flow Chart

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.4. Acceptance Test Specifications

AT test Specification for is given in below Table 32,

# Item Category: Items Under Shelter & Controlled

Table 32: AT Test Specification

<table><tr><td>S. No.</td><td>Test</td><td>Test Condition</td><td>Test Procedure</td></tr><tr><td>1.</td><td>Bump
(Only transportation axis)
PREET &amp; POET</td><td>• No. of Bumps: 400 bump
• Peak Acceleration: 25g
• Pulse Duration: 6 msec
• Bump Rate: 1-2 Bumps/sec
• Unit will be tested under packaged condition</td><td>Section:6.12.5</td></tr><tr><td>2.</td><td>Humidity/Damp Heat Test</td><td>45°C, RH 95% for 8 hours
INSET (@ 7 1⁄2 Hrs.)</td><td>Section: 6.12.1</td></tr></table>

Table 33:AT Test Matrix   

<table><tr><td>S. No.</td><td>Test Group</td><td>Test</td><td>PREET</td><td>INSET</td><td>POET</td><td>Parameter monitored/ Procedure Section</td></tr><tr><td rowspan="2">1</td><td rowspan="2">AT</td><td>Bump</td><td>A</td><td>NA</td><td>A</td><td>Section: 6.12.5</td></tr><tr><td>Humidity/Damp</td><td>A</td><td>A</td><td>A</td><td>Section: 6.12.1</td></tr></table>

A Applicable

NA Not Applicable

PREET PRE-Environmental Testing

INSET In Situ Environmental Testing

POET POST Environmental Testing

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.4.1. AT Flow Chart

Following is the AT Flow Chart.

![](images/2c98253deacafd267400a1b65ee3c74e07d4a92191f50e58119c82ec97d37b0c.jpg)  
Figure 16: Flow Chart for AT Test

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Intentionally Left Blank Page

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.5. Qualification Test Specifications and Test Matrix

QT test Specification is given in below Table 34.

Item Category: Items Under Shelter & Controlled

Table 34: Environmental Specification for QT

<table><tr><td>SI.
No.</td><td>Environment Test</td><td>Test Condition</td><td>Test Procedure</td></tr><tr><td>1</td><td>High Temperature
1. Test will be done at constant temperature as per method 2 of Procedure II (Page501.4-3)
2. PREET &amp; POET at ambient
3. INSET As per MIL STD 810F, Method 501.4
4. INSET at 13th Hr applicable only for operational test
5. ±3°C tolerance is provided to cater for the controller variations.
However, set temperature should be above the mean / specified value at all points of time during testing.</td><td>Operation
(SHELtered Controlled)
+55°C ±3°C for 8 hrs.
+70°C ±3°C for 6 hrs.
+55°C ±3°C for 8 hrs.</td><td>Section:6.12.2</td></tr><tr><td>2</td><td>Low Temperature
Test will be done at constant temperature as per method 2 of Procedure II (Page502.4-3)
2. PREET &amp; POET at ambient
3. INSET at 13th Hr applicable only for operational test
4. ±3°C tolerance is provided to cater for the controller variations. However, set temperature should be below the mean / specified value at all points of time during testing.</td><td>Operation
(Controlled Sheltered)
-10°C±3°C for 8 hrs.
0°C±3°C for 6 hrs.
-10°C±3°C for 8 hrs.</td><td>Section:6.12.3</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>SI.
No.</td><td>Environment Test</td><td>Test Condition</td><td>Test Procedure</td></tr><tr><td>3</td><td>Vibration
(Along all three axes)
PREET, INSET &amp; POET</td><td>1. As per MIL STD 810F, Method 514.5 - composite wheeled trailer vibration exposure, Figure 26
2. Duration: 3 hrs cumulative 3. For packages not mounted inside Canister: 5 - 20 Hz (6db per oct) desirable 20 - 50Hz: 0.02 g2 /Hz, then rolling down to 0.001g2 /Hz at 500 Hz. 40min. per axis</td><td>Section:6.12.8</td></tr><tr><td>4</td><td>Bump
(Only transportation axis)
PREET &amp; POET</td><td>1. No. of Bumps: 4000 bump
2. Peak Acceleration: 25g
3. Pulse Duration: 6 msec
4. Bump Rate: 1-2 Bumps/sec
5. Unit will be tested under packaged condition</td><td>Section:6.12.5</td></tr><tr><td>5</td><td>Acceleration
PREET, &amp; POET</td><td>1. X(Longitudinal) ±3g,
2. Y (Lateral) ±1.5 g,
3. Z(Vertical) ±2.5 g
1min/Axis</td><td>Section:6.12.6</td></tr><tr><td>6</td><td>Altitude
1. PREET at ambient
2. INSET during last ½hour
3. POET at ambient</td><td>(Controlled Sheltered)
1. Altitude 3.0 Km
2. Operational Temperature -10°C±3°C for 8 hrs.
0°C±3°C for 6 hrs. Functional -10°C±3°C for 8 hrs.</td><td>Section:6.12.7</td></tr><tr><td>7</td><td>Humidity/Damp Heat
1. PREET at ambient
2. INSET during last ½hour
3. POET at ambient</td><td>45°C (RH 95%) for 8 hours
INSET (@ 7½ Hrs.)</td><td>Section:6.12.1</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>SI.
No.</td><td>Environment Test</td><td>Test Condition</td><td>Test Procedure</td></tr><tr><td>8</td><td>Mould Growth /Fungus</td><td>Analysis according to MIL-HDBK-454B Guideline 4
1. Will be done by material declaration/analysis.
2. In case new material is used which are not tested, a test is required.
3. Examples of sample coupons are:
i) Conformal coated PCBs.
ii)Insulations iii) Rubber grommets iv) Rubber Components v) EMI gaskets vi) Plastics vii) Paper, Vinyl, Textile component/parts, if any</td><td>On Sample Test</td></tr></table>

Table 35: QT Test Matrix   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>S. No.</td><td>Test Group</td><td>Test</td><td>PREET</td><td>INSET</td><td>POET</td><td>Parameter monitored/ Procedure Section Reference</td></tr><tr><td>1.</td><td rowspan="8">QT</td><td>High Temperature-</td><td>A</td><td>A</td><td>A</td><td rowspan="8">Section: 6.12.1 to 6.12.8</td></tr><tr><td>2.</td><td>Low Temperature-</td><td>A</td><td>A</td><td>A</td></tr><tr><td>3.</td><td>Random Vibration</td><td>A</td><td>A</td><td>A</td></tr><tr><td>4.</td><td>Humidity/Damp</td><td>A</td><td>A</td><td>A</td></tr><tr><td>5.</td><td>Bump</td><td>A</td><td>NA</td><td>A</td></tr><tr><td>6.</td><td>Acceleration</td><td>A</td><td>NA</td><td>A</td></tr><tr><td>7.</td><td>Altitude</td><td>A</td><td>A</td><td>A</td></tr><tr><td>8.</td><td>Mould Growth</td><td colspan="3">Sample Test</td></tr></table>

A Applicable

NA Not Applicable

PREET PRE-Environmental Testing

INSET In Situ Environmental Testing

POET POST Environmental Testing

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/ed1d2872b44e28709e0c17abd101a065de520b19a5a0c38ae81f14b1ef000bfe.jpg)

![](images/7e64bd8a53f15089c4886105b4c2c9bd233631795b6e0ca910f4b4f948f84482.jpg)  
Figure 17: ESS Thermal Cycle Test Profile   
Figure 18: Composite wheeled vehicle road transportation Random Vibration Profile

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.5.1. QT Flow Chart

Following is the QT Test Flow Chart.

![](images/d65d2ab1582f041a20c21acfc759c52f33743890d182416502b4eab30a002aa4.jpg)  
Figure 19: Flow Chart for QT Test

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.6. EMI/ EMC Test Specifications

EMI/EMC test as per MIL-STD-461E for is given in below Table 36.

Item Category: Items under Shelter & Controlled

Table 36: List of EMI/EMC Tests   

<table><tr><td>SI. No.</td><td>Test Name</td><td>Description</td></tr><tr><td>1.</td><td>CE102</td><td>Conducted Emissions, Power Leads, 10 kHz to 10 MHz</td></tr><tr><td>2.</td><td>CS101</td><td>Conducted Susceptibility, Power Leads, 30 Hz to 150 kHz</td></tr><tr><td>3.</td><td>CS114</td><td>Conducted Susceptibility, Bulk Cable Injection, 10 kHz to 200 MHz</td></tr><tr><td>4.</td><td>CS115</td><td>Conducted Susceptibility, Bulk Cable Injection, Impulse Excitation</td></tr><tr><td>5.</td><td>CS116</td><td>Conducted Susceptibility, Damped Sinusoidal Transients, Cables and Power Leads, 10 kHz to 100 MHz</td></tr><tr><td>6.</td><td>RE102</td><td>Radiated Emissions, Electric Field, 2 MHz to 18 GHz</td></tr><tr><td>7.</td><td>RS103</td><td>Radiated Susceptibility, Electric Field, 2 MHz to 40 GHz</td></tr><tr><td>8.</td><td>HESD – Human Electrostatic Discharge</td><td>16 kV, HESD level – 3, (MIL-STD-1686C)</td></tr></table>

Note: Although electronic sub-systems are to be tested for human Electrostatic Discharge (HESD) test for its design and engineering verification, there is no ESD test recommendation in the MIL-STD-461E document. To verify ESD test survival ability, MIL-STD-1686C and IEC 61000-4-2 have been recommended.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.6.1. EMI/EMC Test Flow Chart

Following is the flow chart for EMI/EMC Tests.

![](images/e494532510e2be127916f787d7bdc1151169a340a0ff00a3c2f2fd776c0e3e41.jpg)  
Figure 20: Flow Chart for EMI/EMC

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.7. Pre-Requisites and Process checks

Table 37: Pre-Requisites and Process Check   

<table><tr><td>S. No.</td><td>Check or Test</td><td>Stage</td><td>Section Reference</td><td>Template Reference</td></tr><tr><td>1.</td><td>Mechanical material COC &amp; Report</td><td rowspan="3">Clearance for Assembly</td><td>Section: 7.1.1</td><td>LW/DLC-MU/PR/QA/001 &amp; 002</td></tr><tr><td>2.</td><td>Bare PCB Inspection</td><td>Section: 7.1.3</td><td>LW/DLC-MU/PR/QA/003</td></tr><tr><td>3.</td><td>Component Kit Inspection</td><td>Section: 7.1.4</td><td>LW/DLC-MU/PR/QA/004</td></tr><tr><td>4.</td><td>Baking Inspection</td><td rowspan="6">PCBA Clearance for Unit Assembly</td><td>Section: 7.1.5</td><td>LW/DLC-MU/PR/QA/005 &amp; 006</td></tr><tr><td>5.</td><td>Populated PCB Inspection</td><td>Section: 7.1.7</td><td>LW/DLC-MU/PR/QA/007</td></tr><tr><td>6.</td><td>Assembled Card cold checks</td><td>Section : 7.1.8</td><td>LW/DLC-MU/PR/QA/008 to 011</td></tr><tr><td>7.</td><td>Power Supply checks</td><td>Section: 7.1.9</td><td>LW/DLC-MU/PR/QA/012 to 015</td></tr><tr><td>8.</td><td>Potting and Conformal coating</td><td>Section: 7.1.11</td><td>LW/DLC-MU/PR/QA/017</td></tr><tr><td>9.</td><td>Isolation checks</td><td>Section: 7.2.1</td><td>LW/DLC-MU/PR/QA/018</td></tr><tr><td>10.</td><td>BBP Assembled board Function checks</td><td rowspan="6">Unit Assembly Clearance for Integration tests (FT, AT, QT)</td><td rowspan="5">Section: 7.1.10</td><td rowspan="5">LW/DLC-MU/PR/QA/016</td></tr><tr><td>11.</td><td>BOB Board Functional checks</td></tr><tr><td>12.</td><td>PSU Board Functional checks</td></tr><tr><td>13.</td><td>Tx Gain Stage Checks</td></tr><tr><td>14.</td><td>Rx Gain Stage Checks</td></tr><tr><td>15.</td><td>Mechanical Housing Clearance</td><td>Section: 7.1.2</td><td>LW/DLC-MU/PR/QA/002</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

6.7.1. BBP + BOB + PSU Assembled Board Functional Checks

Refer Section: 7.1.10

6.7.2. Tx Gain Stage Functional Checks

Refer Section: 7.1.10

6.7.3. Rx Gain Stage Functional Checks

Refer Section: 7.1.10

6.7.4. Initial/ Final Isolation Checks

Refer Section: 7.2.1

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.8. Unit Functional Test Procedures

The Data Link Transmitter (DLC-MU) unit shall be subject to the functional tests as per the functional test specifications.

# 6.8.1. System Functional Readiness and RF Initialization

<table><tr><td>Test Name</td><td colspan="4">System function readiness and RF Initialization</td></tr><tr><td>Test Case</td><td colspan="4">FTP-001</td></tr><tr><td>Test Description</td><td colspan="4">Functional Verification for System function readiness and RF initialization</td></tr><tr><td>Test Report Ref.</td><td colspan="4">FTR-001</td></tr><tr><td>Test Method</td><td colspan="4">Make the test setup as shown in Figure 21Power On the DLC boardOpen USB-UART debug port on PC with 115200 baud-rate.System boot-up ensures DDR, Flash and debug console (USB UART) are functional.Execute the following commands to verify the console, management port and RF initializationecho "Message to DEBUG CONSOLE" &gt; /dev/ttyPSO dmesg / grep AD936x</td></tr><tr><td>Pass Criteria</td><td colspan="4">Boot-up logs are seen on the USB-UART Debug port as soon as board is powered onCLA s omanment PortTransmitted message "Message to DEBUG CONSOLE" has to be received and displayed.root@localhost:~# echo "Message to DEBUG CONSOLE" &gt; /dev/ttyPSO Message to DEBUG CONSOLEroot@localhost:~#RF InitializationString ad936x is successfully initialized should be displayed.root@localhost:~# dmesg | grep AD936x[ 1.585263] ad9361 spi0.0: ad9361 Probe : AD936x Rev 2 successfully initialized[ 1.857643] ad9361 spi1.0: ad9361 Probe : AD936x Rev 2 successfully initializedroot@localhost:~#</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.8.2. Ethernet Test

<table><tr><td>Test Name</td><td colspan="4">Ethernet Test</td></tr><tr><td>Test Case No.</td><td colspan="4">FTP-002</td></tr><tr><td>Test Description</td><td colspan="4">Functional Verification for Ethernet Interface</td></tr><tr><td>Test Report Ref.</td><td colspan="4">FTR-001</td></tr><tr><td>Test Method</td><td colspan="4">Make the test setup as shown in Figure 21.
Power On the DLC board
Open the USB-UART debug port on PC with 115200 baud-rate.
To test ping to Google server or gateway (External access is required else, configure and do a ping to a peer device).
    dhclient eth0
    ping 8.8.8.8
To do peer to peer test, set the IP address of the board using the following command
    ifconfig eth0 'IP Address'
    Check the IP of the system using the following command.
    ifconfig
    Ping to peer device using the following command
        o ping "Peer device IP Address"</td></tr><tr><td>Pass Criteria</td><td colspan="4">IP address should be obtained when connected to a network and ping test should be successful.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.8.3. Transmitter FTP

# 6.8.3.1. Transmission Power Test

![](images/5679e9d253aa8ffa46f50f2a12774eb05466ed7a3d80f8180aa2ced1c3e06def.jpg)  
Figure 21: Transmitter Test Setup

Table 38: Transmitter Test Setup Description   

<table><tr><td>SI. No</td><td>Legend</td><td>Description</td></tr><tr><td>1.</td><td>T1</td><td>DLC Unit</td></tr><tr><td>2.</td><td>T2</td><td>Stabilized AC Mains Power Supply with 220-240V AC voltage</td></tr><tr><td>3.</td><td>T3</td><td>Test Laptop for Debug console access with RS 232 to USB driver support</td></tr><tr><td>4.</td><td>T4</td><td>Lekha Rx Tester, Capable of receiving and validating the Tx data signals sent from DLC unit</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Test Name</td><td colspan="4">Transmission Power Test</td></tr><tr><td>Test Case No.</td><td colspan="4">FTP-003</td></tr><tr><td>Test Description</td><td colspan="4">Functional verification Transmission Power Test</td></tr><tr><td>Test Report Ref.</td><td colspan="4">FTR-002</td></tr><tr><td>Test Method</td><td colspan="4">Make the test setup as shown in Figure 22.
Power ON both DLC Transmitter and Lekha Tx Tester units.
Execute the application by using the following command on serial emulator software (Minicom/Teraterm) at 115200 baud rates.
/DLCApp
Configure the RF frequency of 2300MHz on DLC Transmitter unit and Lekha Tx Tester Unit.
To send at 4800bps rate, configure FEC 0 in config file on both units.
Set Spreading length to 127 in config file on both units.
Run the application.
Observe the Transmitter Test unit if the signal is detected. Note down RSSI.
To send at 9600bps rate, configure FEC 1 in config file on both units and run the application.
length 31 by configuring Spreading length to 31 in config file on both units.
Observe the Transmitter Test unit if the signal is detected. Note down RSSI.
Repeat the above test for frequency 2200 MHz and 2250 MHz with same default configurations.</td></tr><tr><td>Pass/Fail Criteria</td><td colspan="4">Link Should get established between the DLC transmitter Unit and Lekha Tx Tester Unit.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.8.4. Receiver FTP

# 6.8.4.1. Receiver Sensitivity test

![](images/c1244c5474efbb4ee828ee62510f710a61de5b8d411c4dfbc32a901d44ee3a74.jpg)  
Figure 22: Receiver test setup

Table 39: Receiver Test Setup Description   

<table><tr><td>SI. No</td><td>Legend</td><td>Description</td></tr><tr><td>1.</td><td>T1</td><td>DLC Unit</td></tr><tr><td>2.</td><td>T2</td><td>Stabilized AC Mains Power Supply with 220-240V AC voltage</td></tr><tr><td>3.</td><td>T3</td><td>Test Laptop for Debug console access with RS 232 to USB driver support</td></tr><tr><td>4.</td><td>T4</td><td>Lekha Tx Tester</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Test Name</td><td colspan="4">Receiver Sensitivity Test</td></tr><tr><td>Test Case No.</td><td colspan="4">FTP-004</td></tr><tr><td>Test Description</td><td colspan="4">Verification Receive Sensitivity.</td></tr><tr><td>Test Report Ref.</td><td colspan="4">FTR-003</td></tr><tr><td>Test Method</td><td colspan="4">Make the test setup as shown in Figure 24.
Power ON both DLC Unit and Lekha Rx Tester units.
Execute the application by using the following command on serial emulator software (Minicom/Teraterm) at 115200 baud rate.
/DLCApp
Configure the RF frequency of 1435MHz on DLC unit and Lekha Rx Tester Unit.
To receive at 9600ps rate, configure FEC OFF in config file on both units.
Set Spreading length to 1023 in config file on both units.
Run the application.
Observe the note down RSSI on DLC unit after decoding of signal.
To receive at 9600bps rate, configure FEC ON in config file on both units.
Set Spreading length to 511 in config file on both units.
Run the application.
Observe the note down RSSI on DLC unit after decoding of signal.
Repeat observe test for Random frequency inside 1435 to 1535MHz and check for decode of signal at DLC unit.</td></tr><tr><td>Pass/Fail Criteria</td><td colspan="4">DLC unit to decode signal for all frequency between 1435MHz to 1535MHz.
PER limit 1 out of 50.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.8.5. Dynamic range Power Test -Design parameter evaluation (Bench test only)

<table><tr><td>Test Name</td><td colspan="4">Dynamic range Power Test -Design parameter evaluation (Bench test only)</td></tr><tr><td>Test Case No.</td><td colspan="4">FTP-005</td></tr><tr><td>Test Description</td><td colspan="4">Verification of Power dynamic range of operation.</td></tr><tr><td>Test Report Ref.</td><td colspan="4">FTR-004</td></tr><tr><td>Test Method</td><td colspan="4">Make the test setup as shown in Figure 22.
Power ON both DLC Unit and Lekha Rx Tester units.
Execute the application by using the following command on serial emulator software (Minicom/Teraterm) at 115200 baud rate.
./DLCApp (reference name)
Configure the RF frequency of 1485MHz on DLC unit and Lekha Tx Tester Unit.
To receive at 9600ps rate, configure FEC ON in config file on both units.
Set Spreading length to 1023 in config file on both units.
Run the application.
Note down RSSI on DLC unit after decoding of signal.
Vary the Variable attenuation in step of 20dB until -105dB is reached.
Repeat procedure for every RSSI.</td></tr><tr><td>Pass/Fail Criteria</td><td colspan="4">DLC unit should decode for received signal strength between -35dBm to -105dBm Power level</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.9. Unit Level Burn-In Test Procedure

![](images/687417ecf12186872c8f448ca8d77239a4613f7113cf3c269174524d6cde55eb.jpg)  
Figure 23: Burn IN Test Setup

Table 40: Burn IN Test Setup Description   

<table><tr><td>Sl. No</td><td>Legend</td><td>Description</td></tr><tr><td>1</td><td>T1</td><td>DLC Unit</td></tr><tr><td>2</td><td>T2</td><td>Stabilized AC Mains Power Supply with 220-240V AC voltage</td></tr><tr><td>3</td><td>T3</td><td>Test Laptop for Debug console access with RS 232 to USB driver support</td></tr><tr><td>4</td><td>T4</td><td>Lekha Tx Unit</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Test Procedure</td><td colspan="4">ETP-001</td></tr><tr><td>Test Profile</td><td colspan="4">Burn in test at temperature of +55°C for 48 hours in powered ON condition at LRU Lavel.</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement:
• Sensitivity Test
• PER Test:
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">• Connect the unit as per the test setup Figure 23 and Power ON.
• Set the RF ports in Loopback receiver mode.
• Assembled boards shall be subjected to Burn-In for 168 hours in 'Power ON' condition.
• Suitable Mounting or open housing may be used for proper holding of assembled boards.
• PREET, INSET (Every 6 hours) and POET shall be carried out.
• Carry out PREET performance test. This consists of performance checks as per test condition mentioned and record the readings in the template in TDR-001
• Introduce the Unit Under Tested (UUT) into the chamber at ambient condition
• UUT shall be subjected to the temperature defined above. Carry out INSET performance tests every 6 hours. This consists of performance checks as per the test condition mentioned in template TDR-001
• After 168 hours allow the unit to recover to ambient temperature
• Carry out POET as performance tests as per the test conditions mentioned in the Template TDR-001</td></tr><tr><td rowspan="4">Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.10. ESS Test Procedure for AT/QT

# 6.10.1. Parameters to be checked during Burn-IN, ESS and ENV.

<table><tr><td>S. No</td><td>Test/Parameter Name</td><td>Test Description</td></tr><tr><td>1.</td><td>Current Measurement</td><td>Current should be (0.05 ±0.03A)</td></tr><tr><td>2.</td><td>Sensitivity Measurement</td><td>-105dBm±3dB</td></tr><tr><td>3.</td><td>PER Test</td><td>PER &lt; 1 out of 50 should be seen on console</td></tr></table>

# 6.10.2. Verification Unit Parameter during Burn-IN/ESS/AT/QT

<table><tr><td>Test Name</td><td colspan="4">Verification of Unit functionality during ESS Test</td></tr><tr><td>Test Case No.</td><td colspan="4">ETP-002</td></tr><tr><td>Test Description</td><td colspan="4">Verification of Unit functionality during ESS Test</td></tr><tr><td>Test Method</td><td colspan="4">Make the test setup as shown in Figure 24Power ON both DLC Unit and Lekha Tester units.Configure the RF frequency of 1435MHz on DLC unit and Lekha Rx Tester Unit.To receive at 9600ps rate, configure FEC OFF in config file on both units.Set Spreading length to 1023 in config file on both unitsRUN the application.Observe the note down RSSI on DLC unit after decoding of signal.Make sure to set attenuation such that you receive around -60dBm at DLC unitCHECK for PER on the console.</td></tr><tr><td>Pass/Fail Criteria</td><td colspan="4">Current drawn should be (0.05 ±0.03A).Sensitivity: -105dBm±3dBPER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td rowspan="4">Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.11. ESS/QT/AT Test Set UP

ESS/AT/QT test Setup is shown below

![](images/3c5fada999e8a647f0e3e3afca583cd66a0f294478789779fc4afe27a120784c.jpg)  
Figure 24: ESS/QT/AT Test Setup

Table 41:ESS Test Setup Description   

<table><tr><td>Sl. No</td><td>Legend</td><td>Description</td></tr><tr><td>1</td><td>T1</td><td>DLC Unit</td></tr><tr><td>2</td><td>T2</td><td>Stabilized AC Mains Power Supply with 220-240V AC voltage</td></tr><tr><td>3</td><td>T3</td><td>Test Laptop for Debug console access with RS 232 to USB driver support</td></tr><tr><td>4</td><td>T4</td><td>Lekha Tx Tester</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.11.1. Pre-Random Vibration (ESS)

<table><tr><td>Test Procedure</td><td>ETP-003</td></tr><tr><td>Test Details</td><td>Duration: 5 min/axis
5 - 20 Hz : (6db per octave) desirable
20 - 50Hz : 0.02 g2 /Hz, then rolling down to 0.001g2 /Hz
at 500 Hz Three axes. 15 minutes cumulative</td></tr><tr><td>Test Parameters Covered</td><td>• Current Measurement:
• Sensitivity Test
• PER Test:
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td>• Connect the unit as per the test setup illustrated in Figure 24 and Power ON.
• Unit under test (UUT) will need to be suitably set-up on the Vibration Shaker.
• Carry out PREET performance test. This consists of performance checks as per test conditions mentioned and record the readings in the template in TDR-002.
• Run the above-mentioned test profile. Carry out the INSET and tabulate the results in TDR-002.
• After completion of the test, take POET and tabulate the results in TDR-002.</td></tr><tr><td>Pass / Fail Criteria</td><td>• Current drawn should be (0.05 ±0.03A).
• Sensitivity: -105dBm±3dB
• PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr></table>

6.11.2. Thermal Cycling (ESS)   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Test Procedure</td><td colspan="4">ETP-004</td></tr><tr><td>Test Profile</td><td colspan="4">a) -20°C ± 2°C for 1 hourb) -20°C to +55°C at 10°C/minc) +55°C ± 2°C for 1 Hourd) +55°C to +70°C at 10°C/Mine) 70°C ± 2°C for 1 hour.f) 70°C to -20°C at 10°C/minTotal Cycle 6</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement• Sensitivity• PER TestRefer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">• Connect the unit as per the test setup illustrated in Figure 24 and Power ON.• Unit Under Test (UUT) will need to be suitably set-up in the temperature chamber.• Carry out PREET performance test. This consists of performance checks as per test conditions mentioned and recording the readings in the template in TDR-003.• Run the above-mentioned test profile. Carry out the INSET and tabulate the results in TDR-003.• After completion of the test, take POET and tabulate the results in TDR-003.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• Current drawn should be (0.05 ±0.03A).• Sensitivity: -105dBm±3dB• PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/79d0ecc8d6d073e6d93526289ff15c00d6eda8e1120daae1b76719e1f2e66c52.jpg)  
Figure 25: Thermal Cycling Test Profile

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DÀTÁ LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.11.3. Post - Random Vibration (ESS)

Repeat the random vibration test in accordance with section 6.11.1.

![](images/a2e088d45c3ba3632b00ab021f11659339f724bd43690e1af313d17eefb2596b.jpg)  
Figure 26: Composite wheeled vehicle road transportation Random Vibration Profile

<table><tr><td rowspan="4">Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12. Environmental Test Procedures

# 6.12.1. Humidity Test

<table><tr><td>Test Procedure</td><td colspan="4">ETP-005</td></tr><tr><td>Test Profile</td><td colspan="4">·45°C (RH 95%) for 8 hours
·RH &gt; 93% ± 5%
INSET - During the last 30mins of the test.</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">·Current Measurement
·Sensitivity
·PER Test
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">·Connect the unit as per the test setup illustrated in Figure 24 and Power ON.
·Unit under test (UUT) will need to be suitably set-up in the Humidity chamber.
·Carry out PREET performance test. This consists of performance checks as per test conditions mentioned and recording the readings in the template in TDR-004.
·Run the above-mentioned test profile. Carry out the INSET and tabulate the results in TDR-004.
·After completion of the test, take POET and tabulate the results in TDR-004.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">·Current drawn should be (0.05 ±0.03A).
·Sensitivity: -105dBm±3dB
·PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td rowspan="4">Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.2. High Temperature-Operational

<table><tr><td>Test Procedure</td><td colspan="4">ETP-006</td></tr><tr><td>Test Profile</td><td colspan="4">Operation
(Sheltered Controlled)
+55°C ±3°C for 8 hrs.
+70°C ±3°C for 6 hrs.
+55°C ±3°C for 8 hrs.
Performance checks during the 13thHours of operational cycle</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement
• Sensitivity
• PER Test
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">• Connect the unit as per the test setup illustrated in Figure 24 and Power ON.
• Unit Under Test (UUT) will need to be suitably set-up in the Temperature chamber.
• Carry out PREET performance test. This consists of performance checks as per test conditions mentioned and record the readings in the template in TDR-004.
• Run the above-mentioned test profile. Carry out the INSET and tabulate the results in TDR-004.
• After completion of the test, take POET and tabulate the results in TDR-004.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• Current drawn should be (0.05 ±0.03A).
• Sensitivity: -105dBm±3dB
• PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.3. Low Temperature - Operational

<table><tr><td>Test Procedure</td><td colspan="4">ETP-007</td></tr><tr><td>Test Profile</td><td colspan="4">(Controlled Sheltered)
-10°C±3°C for 8 hrs.
0°C±3°C for 6 hrs.
-10°C±3°C for 8 hrs.
Performance checks during 13thHours of operational cycle</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement
• Sensitivity
• PER Test
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">• Connect the unit as per the test setup illustrated in Figure 24 and Power ON.
• The unit under test (UUT) will need to be suitably set-up in the Temperature chamber.
• Carry out PREET performance test. This consists of performance checks as per test conditions mentioned and recording the readings in the template in TDR-004.
• Run the above-mentioned test profile. Carry out the INSET and tabulate the results in TDR-004.
• After completion of the test, take POET and tabulate the results in TDR-004.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• Current drawn should be (0.05 ±0.03A):
• Sensitivity: -105dBm±3dB
• PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.4. Mechanical Shock

<table><tr><td>Test Procedure</td><td>ETP-008</td></tr><tr><td colspan="2">Test Not Applicable</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/39637311c6aeed639d0addba4122b7f16620cb973d3975dc086260924e5dea7e.jpg)  
Figure 27: Shock Pulse Graphical Representation

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.5. Bump

<table><tr><td>Test Procedure</td><td colspan="4">ETP-009</td></tr><tr><td>Test Profile</td><td colspan="4">400±10 bumps for AT, 4000±10 bumps for QTPeak acceleration: 25gDuration: 6 mSecBump rate: 1-2 Bump/SecTest will be conducted on the unit in packed condition</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">Current MeasurementSensitivityPER TestRefer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">Connect the unit as per the test setup illustrated in Figure 24 and Power ON.Carry out PREET performance test. This consists of performance checks as per test conditions mentioned and record the readings in the template in TDR-005.Switch off the unit and remove all the connections.Place the unit in packaging Box.Unit under test (UUT) will need to be suitably set-up on the shock machineRUN the above-mentioned test profile.After completion of the test,thake out the unit from the packaging Box and visually examine the unit.Take POET and tabulate the results in TDR-005.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">Current drawn should be (0.05 ±0.03A).Sensitivity: -105dBm±3dBPER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.6. Acceleration

<table><tr><td>Test Procedure</td><td colspan="4">ETP-010</td></tr><tr><td>Test Profile</td><td colspan="4">1. X(Longitudinal) ±3g,
2. Y (Lateral) ±1.5 g,
3. Z(Vertical) ±2.5 g
1min/Axis</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement
• Sensitivity
• PER Test
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">• Connect the unit as per the test setup illustrated in Figure 24 and Power ON.
• Unit under test (UUT) will need to be suitably set-up on the shock machine.
• Carry out PREET performance test. This consists of performance checks as per test conditions mentioned and record the readings in the template in TDR-005.
• Run the above-mentioned test profile.
• After completion of the test, take POET and tabulate the results in TDR-005.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• Current drawn should be (0.05 ±0.03A).
• Sensitivity: -105dBm±3dB
• PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.7. Altitude

<table><tr><td>Test Procedure</td><td colspan="4">ETP-011</td></tr><tr><td>Test Profile</td><td colspan="4">1. Altitude 3.0 Km
2. Operational Temperature
-10°C±3°C for 8 hrs.
0°C±3°C for 6 hrs.
Functional
-10°C±3°C for 8 hrs</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement
• Sensitivity
• PER Test
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">• Connect the unit as per the test setup illustrated in Figure 24 and Power ON.
• Carry out PREET performance test. This consists of performance checks as per test condition mentioned and record the readings in the template in TDR-005.
• Unit under test (UUT) will need to be suitably set-up on the Altitude Chamber.
• Run the above-mentioned test profile.
• Take the INSET Reading last 1/2 hour. Record the reading in the template TDR-005
• After completion of the test, take POET and tabulate the results in TDR-005.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• Current drawn should be (0.05 ±0.03A).
• Sensitivity: -105dBm±3dB
• PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td rowspan="4">DLC-MU Park Mount
Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.8. Vibration

<table><tr><td>Test Procedure</td><td colspan="4">ETP-012</td></tr><tr><td>Test Profile</td><td colspan="4">1. As per MIL STD 810F, Method 514.5 - composite wheeled trailer vibration exposure, Figure 26
2. Duration: 3 hrs cumulative
3. For packages not mounted inside Canister: 5 - 20 Hz (6db per oct) desirable 20 - 50Hz : 0.02 g2 /Hz, then rolling down to 0.001g2 /Hz at 500 Hz. 40min. per axis</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement
• Sensitivity
• PER Test
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">• Connect the unit as per the test setup illustrated in Figure 24 and Power ON.
• Unit under test (UUT) will need to be suitably set-up on the Vibration Shaker.
• Carry out PREET performance test. This consists of performance checks as per test condition mentioned and record the readings in the template in TDR-006.
• Run the above-mentioned test profile. Carry out the INSET and tabulate the results in TDR-006.
• After completion of the test, take POET and tabulate the results in TDR-006.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• Current drawn should be (0.05 ±0.03A).
• Sensitivity: -105dBm±3dB
• PER Test: PER &lt; 1 out of 50 should be seen on console.</td></tr><tr><td rowspan="4">Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.12.9. Mould Growth Test

<table><tr><td>Test Procedure</td><td colspan="4">ETP-013</td></tr><tr><td rowspan="2">Test Profile</td><td colspan="4">·Within 15 minutes of spraying the equipment and the control strips shall be introduced into the chamber whose working space is maintained at a temperature of 30°C ± 1°C and a relative humidity of not less than 90%.
·If no mold growth is visible on any one of the control strips when the chamber door is opened for the first time after 7 days of starting the test, the test shall be considered void and shall be recommended.
·Provided that the mold growth on the control strips indicates that the exposed conditions are suitable and molds viable, the equipment shall be exposed in the chamber continuously for a total period of 28 days.
·The equipment shall be removed from the chamber after the 28 days of exposure and examined immediately under 10 power magnification.</td></tr><tr><td colspan="4">Duration: 28 days</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">·To determine the suitability of electronics and electrical equipment for use and/or storage in salt laden atmosphere. This test is intended mainly for evaluating the quality and uniformity of protective coatings.</td></tr><tr><td>Test Procedure</td><td colspan="4">·Test Samples will need to be suitably set-up in the Mould growth chamber.
·Run the above-mentioned test profile.
·After completion of the test, examine the unit visually for traces of mold growth.</td></tr><tr><td>Test Sample</td><td colspan="4">·50x50mm Coupon of Raw material.
·Cables/Wires
·EMI gaskets
·Fasteners
·Panel Connectors</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13. EMI/EMC Test Procedures

# 6.13.1. Conducted Emission Tests

# 6.13.1.1. CE102

<table><tr><td colspan="2">Test Name</td><td colspan="4">CE102</td></tr><tr><td colspan="2">Test Case No</td><td colspan="4">ETP-014</td></tr><tr><td colspan="2">Test Setup</td><td colspan="4">Refer Figure 29</td></tr><tr><td colspan="2">Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td colspan="2">Test Details</td><td colspan="4">This requirement is applicable from 10 kHz to 10 MHz for all power leads, including returns that obtain power from other sources not part of the EUT</td></tr><tr><td colspan="2">Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test: Refer Test Procedure Section:6.10.2</td></tr><tr><td colspan="2">Test Procedure</td><td colspan="4">UUT testing: Determine the conducted emissions from the UUT input power leads, including returns.
1. Conduct Pre-performance checks on the UUT.
2. Turn ON the UUT and allow sufficient time for stabilization.
3. Select an appropriate lead for testing as per Table 42 and clamp the current probe into position.
4. Scan the measurement receiver over the applicable frequency range, using the bandwidths and minimum measurement times specified in Table 43.
5. The equipment should be operated during this test and functionality should be monitored.
6. If the measured peaks are above the limit level, an ambient emission check shall be performed. This is to make sure there is no added interference from auxiliary equipment which may contribute to the higher levels along with the UUT emissions.
a. During testing, the ambient electromagnetic level measured with the UUT de-energized, and all auxiliary equipment turned on shall be at least 6 dB below the allowable specified limits when the tests are performed in a shielded enclosure.
b. Ambient conducted levels on power leads shall be measured with the leads disconnected from EUT and connected to a resistive load which draws the same current as the EUT.
c. If tests are performed in shielded enclosure and EUT is within the limits, ambient profile need not be recorded. Otherwise, it should be recorded.
7. Repeat Steps 2 to 5 for each power lead (Refer Table 42)</td></tr><tr><td colspan="2">DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td colspan="2">LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="3" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr><tr><td>Pass / Fail
Criteria</td><td colspan="5">The conducted emissions form power leads shall not exceed the limits as
Figure 28</td></tr></table>

Table 42: Power Lead for Test   
Table 43:Bandwidth and Measurement Time   

<table><tr><td>S/N</td><td>Power leads</td><td>Description</td></tr><tr><td>1</td><td>220-240 VAC</td><td>Live</td></tr><tr><td>2</td><td>Return</td><td>Neutral</td></tr><tr><td>3</td><td>Reference</td><td>Earth</td></tr></table>

<table><tr><td>Frequency Range</td><td>6 dB Bandwidth</td><td>Dwell Time</td><td>Minimum Measurement Time Analog Measurement Receiver</td></tr><tr><td>30 Hz - 1 kHz</td><td>10 Hz</td><td>0.15 sec</td><td>0.015 sec/Hz</td></tr><tr><td>1 kHz - 10 kHz</td><td>100 Hz</td><td>0.015 sec</td><td>0.15 sec/Hz</td></tr><tr><td>10 kHz - 150 kHz</td><td>1 kHz</td><td>0.015 sec</td><td>0.015 sec/Hz</td></tr><tr><td>150 kHz - 30 MHz</td><td>10 kHz</td><td>0.015 sec</td><td>1.5 sec/MHz</td></tr><tr><td>30 MHz - 1 GHz</td><td>100 kHz</td><td>0.015 sec</td><td>0.15 sec/MHz</td></tr><tr><td>Above 1 GHz</td><td>1 MHz</td><td>0.015 sec</td><td>15 sec/Hz</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/ca776a844a3de6f9b150bbe385c6134fb989658fe7c132f2312f9fb779d8db1b.jpg)  
Figure 28:CE102 limit (EUT power leads, AC and DC) for all applications.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/ed9bbb9ab944e5c991cdcdf3cb65ddd8d9e089ef72a2d3b3095af54bf9927ce0.jpg)  
Figure 29: CE102 Test Configuration

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13.2. Conducted Susceptibility Tests

# 6.13.2.1. CS101

<table><tr><td>Test Name</td><td colspan="4">CS101</td></tr><tr><td>Test Case No</td><td colspan="4">ETP-015</td></tr><tr><td>Test Setup</td><td colspan="4">Refer Figure 30</td></tr><tr><td>Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td>Test Details</td><td colspan="4">This requirement is applicable to equipment and subsystem AC and DC input power leads, not including returns. If the EUT is DC operated, this requirement is applicable over the frequency range of 30 Hz to 150 kHz. If the EUT is AC operated, this requirement is applicable starting from the second harmonic of the EUT power frequency and extending to 150 kHz</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test: Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">1. Conduct Pre-performance checks on the UUT.2. Turn ON the EUT and allow sufficient time for stabilization.3. CAUTION: Exercise care when performing this test since the "safety ground" of the oscilloscope is disconnected due to the isolation trans-former and a shock hazard may be present.4. Set the signal generator to the lowest test frequency. Increase the signal level until the required voltage or power level as per Figure 31 is reached on the power lead.5. While maintaining at least the required signal level, scan through the required frequency range at a rate no greater than specified in Table 45.6. Monitor the UUT for degradation of performance. Check the performance of UUT as per Section6.10.1. If susceptibility is noted, determine the threshold level as per Table 44 and verify that it is above the limit.7. Repeat steps 1 through 5 for each positive power lead. (Refer Table 42, S/N 1 and 2)</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• During and after the application of voltage levels, observe the EUT for any performance degradation such as uncommand operation, lock up or shut down. During and after the test the EUT setting shall be stable and cannot be unintentionally altered. Note any performance problems.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/bffde419f63722e2ccbe3680d305063e72ebbec51c0e1daf17489f34631aae5a.jpg)  
Figure 30: Signal injection, DC or single-phase AC

Following points need to be followed to determine threshold level wherever susceptibility is noted.

Table 44: THRESHOLDS OF SUSCEPTABILITY FOR EMI/EMC TESTS   

<table><tr><td>S. No</td><td colspan="4">Description</td></tr><tr><td>a)</td><td colspan="4">When a susceptibility condition is detected, reduce the interference signal until the EUT recovers.</td></tr><tr><td>b)</td><td colspan="4">Reduce the interference signal by an additional 6 dB.</td></tr><tr><td>c)</td><td colspan="4">Gradually increase the interference signal until the susceptibility condition reoccurs. The resulting level is the threshold of susceptibility.</td></tr><tr><td>d)</td><td colspan="4">Record this level, frequency range of occurrence, frequency and level of greatest susceptibility, and other test parameters, as applicable</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/12d3ad9109e3f3aaca491688c37c51f7ab6c0d16f8a694c7a5741f18f6ff92e3.jpg)  
Figure 31:CS101 voltage limit for all applications

Table 45: Susceptibility Scanning   

<table><tr><td>Frequency Range</td><td>Analog Scans Maximum Scan Rates</td><td>Stepped Scans Maximum Step Size</td></tr><tr><td>30 Hz - 1 MHz</td><td>0.0333f0/sec</td><td>0.05 f0</td></tr><tr><td>1 MHz - 30 MHz</td><td>0.00667 f0/sec</td><td>0.01 f0</td></tr><tr><td>30 MHz - 1 GHz</td><td>0.00333 f0/sec</td><td>0.005 f0</td></tr><tr><td>1 GHz - 8 GHz</td><td>0.000667 f0/sec</td><td>0.001 f0</td></tr><tr><td>8 GHz - 40 GHz</td><td>0.000333 f0/sec</td><td>0.0005 f0</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13.2.2. CS114

<table><tr><td>Test Name</td><td colspan="4">CS114</td></tr><tr><td>Test Case No</td><td colspan="4">ETP-016</td></tr><tr><td>Test Setup</td><td colspan="4">Refer Figure 33</td></tr><tr><td>Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td>Test Details</td><td colspan="4">Conducted Susceptibility, Bulk Cable, 10KHz to 200MHzThis requirement is applicable to all interconnecting cables (signal, control and data) and power cables.</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test:Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">1. EUT Testing: Perform the following procedures on each cable bundle inter-facing with each electrical connector on the EUT including complete power cables (high sides and returns). Also perform the procedures on power cables with the power returns and chassis grounds (green wires) excluded from the cable bundle.
2. Turn ON the measurement equipment and allow sufficient time for stabilization.
3. Calibrate the Test equipment as per Figure 37 and record forward power to establish the required current amplitude at frequency band 10KHz to 200MHz
4. Place the injection and monitor probes around a cable bundle interfacing with a EUT connector.
5. Locate the monitor probe 5cm from the connector. If the overall length of the connector and back-shell exceeds 5cm, position the monitor probe as close to the connector's back-shell as possible and the position noted.
6. Position the injection probe 5cm from the monitor probe.
7. Turn on the EUT and allow sufficient time for stabilization and perform functional check of the EUT.
8. Set the signal generator to 10 kHz with 1 kHz pulse modulation, 50% duty cycle.
9. Apply the forward power level to the injection probe while monitoring the induced current (i.e. pre calibrated level as per Curve#4 Figure 32</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td></td><td>10. Scan the required frequency range in accordance with Table 45 while maintaining the forward power level at the calibration level or the maximum current level for the applicable limit, whichever is less stringent.
11. Monitor the EUT for degradation of performance during testing. Check the performance of EUT as per Section 2.
12. Whenever susceptibility is noted, determine the threshold level as per Section 4 and verify that it is above the applicable requirement.
13. For EUTs with redundant cable for safety critical reasons such as multiple data buses, use simultaneous multi-cable injection techniques.
14. Conduct post-performance checks.</td></tr><tr><td>Pass / Fail Criteria</td><td>• During and after the application of RF signals to the EUT associated coupling, observe the EUT for any performance degradation such as uncommand operation, lock up or shut down. During and after the test the EUT setting shall be stable and cannot be unintentionally altered. Note any performance problem.</td></tr></table>

Table 46: CS114 Limit Curves   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td colspan="2">PLATFORMFREQ.RANGE</td><td>AIRCRAFT(EXTERNAL OR SAFETYCRITICAL)</td><td>AIRCRAFTINTERNAL</td><td>ALL SHIPS(ABOVE DECKS)ANDSUBMARINES(EXTERNAL)*</td><td>SHIPS(METALLIC)(BELOW DECKS)</td><td>SHIPS (NON-METALLIC)(BELOW DECKS)</td><td>SUBMARINES(INTERNAL)</td><td>GROUND</td><td>SPACE</td></tr><tr><td rowspan="3">10 kHz↓2 MHz</td><td>A</td><td>5</td><td>5</td><td>2</td><td>2</td><td>2</td><td>1</td><td>3</td><td>3</td></tr><tr><td>N</td><td>5</td><td>3</td><td>2</td><td>2</td><td>2</td><td>1</td><td>2</td><td>3</td></tr><tr><td>AF</td><td>5</td><td>3</td><td>-</td><td>-</td><td>-</td><td>-</td><td>2</td><td>3</td></tr><tr><td rowspan="3">2 MHz↓30 MHz</td><td>A</td><td>5</td><td>5</td><td>5</td><td>2</td><td>4</td><td>1</td><td>4</td><td>3</td></tr><tr><td>N</td><td>5</td><td>5</td><td>5</td><td>2</td><td>4</td><td>1</td><td>2</td><td>3</td></tr><tr><td>AF</td><td>5</td><td>3</td><td>-</td><td>-</td><td>-</td><td>-</td><td>2</td><td>3</td></tr><tr><td rowspan="3">30 MHz↓200 MHz</td><td>A</td><td>5</td><td>5</td><td>5</td><td>2</td><td>2</td><td>2</td><td>4</td><td>3</td></tr><tr><td>N</td><td>5</td><td>5</td><td>5</td><td>2</td><td>2</td><td>2</td><td>2</td><td>3</td></tr><tr><td>AF</td><td>5</td><td>3</td><td>-</td><td>-</td><td>-</td><td>-</td><td>2</td><td>3</td></tr></table>

KEY: A = Army

N = Navy

$\mathbf{AF} = \mathbf{Air}$ Force

* For equipment located external to the pressure hull of a submarine but within the superstructure, use

SHIPS (METALLIC) (BELOW DECKS)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/17bd4a6c6ea843f1a36801d228f157ef188bdefbdbe73ee5228b7e18d05cc888.jpg)  
Figure 32: CS114 calibration limit for all applications.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/b07509b78200d196ef0ccc45300a8c6098eb9473de4c63b3c6817905da1b9f3d.jpg)  
Figure 33: CS114 Test Setup

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13.2.3. CS115

<table><tr><td>Test Name</td><td colspan="4">CS115</td></tr><tr><td>Test Case No</td><td colspan="4">ETP-017</td></tr><tr><td>Test Setup</td><td colspan="4">Refer Figure 35</td></tr><tr><td>Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td>Test Details</td><td colspan="4">Conducted Susceptibility, Bulk Cable, impulse excitation</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test: Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">1. Conduct pre-performance checks on the UUT.
2. Turn ON the measurement equipment and allow sufficient time for stabilization.
3. Place the injection and monitor probes around a cable bundle interfacing with an EUT connector.
4. Locate the monitor 5cm from the connector. If the overall length of the connector and back-shell exceeds 5cm, position the monitor probe as close to the connector's back-shell as possible and the position noted.
5. Position the injection probe 5cm from the monitor probe.
6. Turn on the EUT and allow sufficient time for stabilization.
7. Adjust the pulse generator, as a minimum (i.e. pre calibrated signal having risen and fall times, pulse width and amplitude as specified in Figure 34 at a 30Hz rate for one minute).
8. Apply the test signal at the pulse repetition rate and for the duration specified in the requirement.
9. Monitor the EUT for degradation of performance during testing. Check the performance of EUT.
10. Whenever susceptibility is noted, determine the threshold level as per Table 44 and verify that it is above the limit.
11. Record the peak current induced in the cable as indicated on the oscilloscope.
12. Repeat Steps 7 through 11 on each cable bundle interfacing with each electrical connector on the EUT. For power cables, perform Steps 7 through 11 on complete power cables (high sides and returns) and on the power cables with the power returns and chassis grounds (green wires) excluded from the cable bundle.
13. Conduct post-performance checks on the UUT.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Pass/Fail Criteria

- During and after the application of impulse signal onto EUT associated cabling, observe the EUT for any performance degradation such as uncommand operation, lock up or shut down. During and after the test the EUT setting shall be stable and cannot be unintentionally altered. Note any performance problems.

![](images/d198f440b316628e39e1f55dd6effdf67ee83c24a4e3e6559be84f773ab82449.jpg)  
Figure 34: CS115 signal characteristics for all applications

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/4525bd1e5b32fde56f28273caa7e346ea76490cda58a5c91683d4081a5b3b889.jpg)  
Figure 35: CS115 Bulk cable injection Test Setup

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13.2.4. CS116

<table><tr><td>Test Name</td><td colspan="4">CS116</td></tr><tr><td>Test Case No</td><td colspan="4">ETP-018</td></tr><tr><td>Test Setup</td><td colspan="4">Refer Figure 38</td></tr><tr><td>Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td>Test Details</td><td colspan="4">Conducted Susceptibility, Damped Sinusoidal Transients, Cables and Power Leads (10 KHz to 100 MHz)</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test: Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">1. Conduct pre-performance checks on the UUT.
2. EUT testing: Perform the following procedures, using the EUT test setup on each cable bundle interfacing with each connector on the EUT including complete power cables. Also perform tests on each individual high side power lead (individual power returns and neutrals are not required to be tested).
3. Turn ON the measurement equipment and allow sufficient time for stabilization.
4. Place the injection and monitor probes around a cable bundle interfacing an EUT connector.
5. Locate the monitor probe 5cm from the connector. If the overall length of the connector and back-shell exceeds 5cm, position the monitor probe as close to the connector's back-shell as possible and the position noted.
6. Turn on the EUT and measurement equipment to allow sufficient time for stabilization.
7. Set the damp sine generator to 10 kHz.
8. Apply the signals to each cable of the EUT. Slowly increase the damped sine wave generator output level to provide the specified current but not exceeding the pre calibrated generator output level (as per Figure 36). Record the peak current obtained.
9. Monitor the EUT for degradation of performance during testing. Check the performance of EUT.
10. If susceptibility is noted, determine the threshold level as per Table 44 and verify that it is above the specified requirements.
11. Repeat Step 6 through 9 for the following frequencies as specified in the requirement.
12. - 100 kHz, 1 MHz, 10 MHz, 30 MHz and 100 MHz Figure 37Conduct post-performance checks.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Pass/Fail Criteria

- The EUT shall not exhibit any malfunction, degradation of performance, or deviation from specified indications, beyond the tolerances indicated in the individual equipment or subsystem specification, a maximum current as specified in Figure 37. The limit is applicable across the entire specified frequency range. As a minimum, compliance shall be demonstrated at the following frequencies: 0.01, 0.1, 1, 10, 30, and 100 MHz. If there are other frequencies known to be critical to the equipment installation, such as platform resonances, compliance shall also be demonstrated at those frequencies. The test signal repetition rate shall be no greater than one pulse per second and no less than one pulse every two seconds. The pulses shall be applied for a period of five minutes.

![](images/1c11162f773ed1d15ef615029e203cb35ed5f787c06fd528d659e6f7d1b5fb24.jpg)  
Figure 36: Typical CS116 damped sinusoidal waveform.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

Figure 37: CS116 limit for all applications.   
![](images/346ee49ddbbd11949170de7f893ac9795df344c3eafc6bd194c7e35610e3b6dd.jpg)  
NOTES:   
1. For Army and Navy procurements, $I_{MAX} = 10$ amperes   
2. For Air Force procurements, $I_{MAX} = 5$ amperes

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/b321130e369a1d4d53bf76f8d212526f20709db4095f27a2462a7596fbe59d4f.jpg)  
Figure 38: Typical set up for bulk cable injection of damped sinusoidal transients.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13.2.5. CS118

<table><tr><td>Test Name</td><td colspan="4">CS118</td></tr><tr><td>Test Case No</td><td colspan="4">ETP-019</td></tr><tr><td>Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td>Test Details</td><td colspan="4">Conducted Susceptibility, Personnel Borne Electrostatic Discharge.
Human Electrostatic Discharge, 16 kV, HESD level - 3, (MIL-STD-1686C)</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test:
Refer Test Procedure Section:6.10.2</td></tr><tr><td>Test Procedure</td><td colspan="4">1. Conduct pre-performance checks on the UUT.
2. The EUT shall be powered and operated during this test in a manner sufficient to verify its operation).
3. Set the ESD Model: Human ESD (150 pF charge capacitor and 330 Ω discharge resistor).
4. Apply five (5) positive discharges and five (5) negative discharges to each EUT test point
5. ESD Voltage level: 16 kV
6. No. of pulses: 3 each (positive polarity)
7. Apply the discharges using the following techniques:
  a. Discharge method: Contact discharge direct discharge
  b. Discharge points: Predetermined points (enclosure and operator accessible points).
8. For EUT during maintenance (off condition)
• ESD Model: Human ESD (150 pF charge capacitor and 330 Ω discharge resistor) ESD Voltage level: 2 kV No. of pulses: 3 each (positive polarity)
Discharge method: Contact discharge direct discharge: Predetermined points (enclosure and operator accessible points)
9. ESD test procedures for test setup and measurements guidelines, international standard IEC 61000-4-2 “Testing and Measurement Techniques – Electrostatic Discharge Immunity Test” will be followed.</td></tr><tr><td>Pass / Fail Criteria</td><td colspan="4">• The EUT shall not exhibit any malfunction, degradation of performance, or deviation from specified indications beyond the tolerances indicated in the individual equipment or subsystem specification, when subjected to the ESD Test</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13.3. Radiated Emission Tests

# 6.13.3.1. RE102

<table><tr><td>Test Name</td><td colspan="4">RE102</td></tr><tr><td>Test Case No</td><td colspan="4">ETP-020</td></tr><tr><td>Test Setup</td><td colspan="4">Refer Figure 40</td></tr><tr><td>Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td>Test Details</td><td colspan="4">Radiated Emissions, Electric Field (10KHz to 18GHz)</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test: Refer Test Procedure Section:6.10.2</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Test Procedure

1. Conduct pre-performance checks on the UUT.   
2. EUT Testing:   
3. Turn on the EUT and allow sufficient time for stabilization.   
4. Determine the radiated emissions from the EUT (i.e. Connector side) and its associated cabling.

a. Scan the measurement receiver for each applicable frequency range, using the bandwidths and minimum measurement times in Table 43   
b. Above $30\mathrm{MHz}$ , orient the antennas for both horizontally and vertically polarized fields.   
c. Take measurements for each antenna position.

5. If the measured peaks are above the limit level, ambient emission check shall be performed. This is to make sure there is no added interference from auxiliary equipment which may contribute to the higher levels along with the EUT emissions.

a. During testing, the ambient electromagnetic level measured with the EUT de-energized, and all auxiliary equipment turned on shall be at least 6 dB below the allowable specified limits when the tests are performed in a shielded enclosure.   
b. Ambient conducted levels on power leads shall be measured with the leads disconnected from EUT and connected to a resistive load which draws the same current as the EUT.   
c. If tests are performed in shielded enclosure and EUT is within the limits, ambient profile need not be recorded. Otherwise, it should be recorded.   
The equipment should be operated during this test and performance to be monitored.   
Conduct post-performance checks.

# Pass/Fail Criteria

- The electric field emissions from the EUT and its associated cabling shall not exceed the limits as per Figure 39.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/932518b7aafc12ca6aae2eb8425304bd130bc920ab4c5bc893b414c4094e2e19.jpg)  
Figure 39: RE102 limit all Ground applications.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/4fd06e1d655c3dc60ddfa83c9cda9026917a8189cb383954e240e4df8506bd7f.jpg)  
Figure 40: RE102 Basic test setup

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 6.13.4. Radiated Susceptibility Tests

# 6.13.4.1. RS103

<table><tr><td>Test Name</td><td colspan="4">RS103</td></tr><tr><td>Test Case No</td><td colspan="4">ETP-021</td></tr><tr><td>Test Setup</td><td colspan="4">Refer Figure 41</td></tr><tr><td>Test Report Ref</td><td colspan="4">TDR-007</td></tr><tr><td>Test Details</td><td colspan="4">Radiated Susceptibility, Electric field (2MHz to 40 GHz) 40 V/m</td></tr><tr><td>Test Parameters Covered</td><td colspan="4">• Current Measurement, Sensitivity and PER Test: Refer Test Procedure Section:6.10.2</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Test Procedure

1. Conduct pre-performance checks on the UUT.   
2. Turn on the measurement equipment and EUT and allow sufficient time for stabilization.   
3. Assess the test area for potential RF hazards and take necessary precautionary steps to ensure safety of test personnel.   
4. EUT Testing.

# a) E-Field sensor procedure.

I. Set the signal source to 1 KHz pulse modulation, $50\%$ duty cycle, and using appropriate amplifier and transmit antenna, establish an electric field at the test start frequency. Gradually increase the electric field level until it reaches the applicable limit. Refer Table 47 for limits.   
II. Scan the required frequency ranges in accordance with the rates and durations specified in Table 45 Maintain field strength levels in accordance with the applicable limit. Monitor EUT performance for susceptibility effects and check the performance of EUT.

# b) Receive antenna procedure.

I. Remove the receive antenna and reposition the EUT.   
II. Set the signal source to 1 KHz pulse modulation, $50\%$ duty cycle. Using an appropriate amplifier and transmit antenna, establish an electric field at the test start frequency. Gradually increase the input power level until it corresponds to the applicable level (Refer Table 45).

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Test Procedure</td><td>III. Scan the required frequency range in accordance with the rates and durations specified in Table 45 while assuring the correct transmitting input power is adjusted in accordance with the calibration data collected. Constantly monitor the EUT for susceptibility conditions and check the performance of EUT. c) If susceptibility is noted, determine the threshold Table 44 level and verify that it is above the limit. d) Perform testing over the required frequency range with the transmit antenna vertically polarized. Repeat the testing above 30 MHz with the transmit antenna horizontally polarized. e) Conduct post-performance check as per Section 8 Conduct post-performance checks. f) Repeat Step 4 for each transmitter antenna position. g) Conduct post-performance checks.</td></tr><tr><td>Pass / Fail Criteria</td><td>During and after the application of Electric field, observe the EUT for any performance degradation such as uncommand operation, lock up or shut down. During and after the test the EUT setting shall be stable and cannot be unintentionally altered. Note any performance problems.</td></tr></table>

Table 47: RS103 Limit   

<table><tr><td>S. No</td><td>Test Name</td><td>Freq Range</td><td>Limit Level (Volt/Meter)</td></tr><tr><td>1</td><td>RS 103</td><td>10kHz to 40 GHz</td><td>50V/m</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

![](images/0b0079075de7a1b49c708dfc93843b1c58c14eaa7eb0a7ef170e13c447a375bb.jpg)  
Figure 41: RS103 Test Setup

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Intentionally Left Blank Page

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7. Test Templates

The Process templates are presented in the following pages for the process requirements of the project.

# 7.1. Process Templates

# 7.1.1. Mechanical Housing Inspection Report

<table><tr><td>Title</td><td colspan="4">MECHANICAL HOUSING INSPECTION REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/PR/QA/001</td><td>Sheet:01 of 02</td></tr><tr><td>Unit Name</td><td colspan="2"></td><td>S. No</td><td></td></tr><tr><td>Supplier Name</td><td colspan="2"></td><td>Supplier PO Number</td><td></td></tr><tr><td>Quantity for Inspection</td><td colspan="2"></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td colspan="4">Mechanical Housing FAB Report Verification</td></tr><tr><td colspan="2">Unit Description</td><td colspan="2"></td></tr><tr><td>S.
No.</td><td>Report</td><td>Description/Parameter</td><td>Available/ Not Available</td></tr><tr><td>1.</td><td>Raw Material Inspection Report</td><td>Raw material as per part list &amp; drawings</td><td></td></tr><tr><td>2.</td><td>Chemical Analysis Report</td><td>Chemical Composition</td><td></td></tr><tr><td>3.</td><td>Tensile test Report</td><td>Tensile properties of the material</td><td></td></tr><tr><td>4.</td><td>Ultrasonic test Report</td><td>Surface &amp; Internal defects</td><td></td></tr><tr><td>5.</td><td>Fabricated component dimensional inspection report</td><td>Check the fabricated components dimensions as per mechanical drawings</td><td></td></tr><tr><td>6.</td><td>DP Test Report</td><td>Surface Defect Cracks due to fabrication</td><td></td></tr><tr><td>7.</td><td>Surface treatment inspection Report (Chromation, passivation, Anodize)</td><td>Check the surface finish of the components visually&amp; review COC&#x27;s of surface acceptance criteria for plated components</td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="3">MECHANICAL HOUSING INSPECTION REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/001</td><td>Sheet:02 of 02</td></tr></table>

<table><tr><td colspan="4">MECHANICAL HOUSING INSPECTION</td></tr><tr><td>S. No.</td><td>Parameter</td><td>Acceptable Deviation Limit</td><td>Satisfactory YES/ NO</td></tr><tr><td rowspan="3">1</td><td>Raw Material</td><td></td><td></td></tr><tr><td>Material</td><td>Acceptable/Not Acceptable</td><td></td></tr><tr><td>Surface defect/Cracks</td><td>Acceptable/Not Acceptable</td><td></td></tr><tr><td rowspan="2">2</td><td>Machining</td><td>Acceptable/Not Acceptable</td><td></td></tr><tr><td>Fabricated Part as per drawing (tolerance, Burrs)</td><td>Acceptable/Not Acceptable</td><td></td></tr><tr><td rowspan="2">3</td><td>Surface Treatment</td><td>Acceptable/Not Acceptable</td><td></td></tr><tr><td>Chromation/Powder coat as per standard given in drawing</td><td>Acceptable/Not Acceptable</td><td></td></tr></table>

<table><tr><td>Observations</td><td colspan="2"></td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

7.1.2. Mechanical Housing Unit Dimension Inspection Report   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="5">MECHANICAL HOUSING UNIT DIMENSION INSPECTION REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/PR/QA/002</td><td>Date:</td><td>Sheet:01 of 02</td></tr><tr><td>Unit Name</td><td colspan="2"></td><td colspan="2">S. No</td><td></td></tr><tr><td>Supplier Name</td><td colspan="2"></td><td colspan="2">Supplier PO Number</td><td></td></tr><tr><td>Quantity for Inspection</td><td colspan="2"></td><td colspan="2">Work Centre</td><td>DOFI, RCI</td></tr><tr><td>Drawing Reference</td><td colspan="5"></td></tr></table>

Deviation for uncontrolled dimension conform specification: IS 2102-1993 as per medium.

<table><tr><td>SI.No</td><td>Actual dimension(mm)</td><td colspan="7">Measured Dimension (mm)</td><td>Remarks</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="10"></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="4">MECHANICAL HOUSING UNIT DIMENSION INSPECTION REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/002</td><td>Date:</td><td>Sheet: 02 of 02</td></tr></table>

<table><tr><td>SI.No</td><td>Actual dimension (mm)</td><td colspan="7">Measured Dimension (mm)</td><td>Remarks</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td colspan="2"></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Observations</td><td colspan="2"></td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

7.1.3. Bare PCB Inspection Report   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="4">BARE PCB INSPECTION REPORT</td></tr><tr><td>Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/003</td><td colspan="2">Date:</td><td>Sheet:01 of 02</td></tr><tr><td>PCB Name</td><td></td><td>S. No</td><td colspan="2"></td></tr><tr><td>Supplier Name</td><td></td><td>Supplier PO Number</td><td colspan="2"></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td>Work Centre</td><td colspan="2">DOFI, RCI</td></tr></table>

<table><tr><td colspan="4">PCB FAB Report Verification (Applicable to BBP)</td></tr><tr><td colspan="2">PCB Description</td><td colspan="2"></td></tr><tr><td>S. No.</td><td>Report</td><td>Observations if any</td><td>Available Not Available</td></tr><tr><td>1.</td><td>Certificate of Compliance</td><td></td><td></td></tr><tr><td>2.</td><td>Outgoing Report/ quality Certificate</td><td></td><td></td></tr><tr><td>3.</td><td>Microsection inspection report</td><td></td><td></td></tr><tr><td>4.</td><td>Outgoing report/ stack</td><td></td><td></td></tr><tr><td>5.</td><td>E-Test Report (FBT)</td><td></td><td></td></tr><tr><td>6.</td><td>Ionic contamination test report</td><td></td><td></td></tr><tr><td>7.</td><td>Surface thickness measurement report</td><td></td><td></td></tr><tr><td>8.</td><td>Solderability of PTH report</td><td></td><td></td></tr><tr><td>9.</td><td>Thermal stress test report</td><td></td><td></td></tr><tr><td>10.</td><td>Impedance measurement report</td><td></td><td></td></tr><tr><td>11.</td><td>Cross section analysis PCB</td><td></td><td></td></tr><tr><td>12.</td><td>Transparency plots</td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="4">BARE PCB INSPECTION REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/003</td><td>Date:</td><td>Sheet:02 of 02</td></tr></table>

<table><tr><td colspan="6">PCB INSPECTION</td></tr><tr><td colspan="2">BBP □</td><td>BOB □</td><td>PSU □</td><td colspan="2">Tx/Rx Gain Stage □</td></tr><tr><td>S.
No.</td><td colspan="2">Parameter</td><td colspan="2">Acceptable Deviation Limit/Criteria</td><td>Acceptable
YES/ NO</td></tr><tr><td rowspan="6">1</td><td colspan="2">Conductor Quality</td><td colspan="2"></td><td></td></tr><tr><td colspan="2">Blisters/ Measles</td><td colspan="2">Nil</td><td></td></tr><tr><td colspan="2">Wrinkles</td><td colspan="2">Nil</td><td></td></tr><tr><td colspan="2">Separation of Conductor from Base laminate</td><td colspan="2">Nil</td><td></td></tr><tr><td colspan="2">Scratches, dents, nicks, pin holes, voids in any combination</td><td colspan="2">Reduction in cross sections by &lt;10%</td><td></td></tr><tr><td colspan="2">Foreign particles, grease or dirt</td><td colspan="2">Nil</td><td></td></tr><tr><td rowspan="2">2</td><td colspan="2">Laminate Quality</td><td colspan="2"></td><td></td></tr><tr><td colspan="2">Good appearance and without de-lamination/ cracks</td><td colspan="2">No delamination &amp; cracks</td><td></td></tr><tr><td rowspan="5">3</td><td colspan="2">Drill Hole Quality. Drill holes shall be free from</td><td colspan="2"></td><td></td></tr><tr><td colspan="2">Chipping</td><td colspan="2">No chipping</td><td></td></tr><tr><td colspan="2">Torn cladding</td><td colspan="2">No Torn cladding</td><td></td></tr><tr><td colspan="2">Burrs</td><td colspan="2">No Burrs</td><td></td></tr><tr><td colspan="2">Base material exposure around the holes</td><td colspan="2">Nil</td><td></td></tr><tr><td>4</td><td colspan="2">Breaks, especially around corners</td><td colspan="2">Nil</td><td></td></tr><tr><td>5</td><td colspan="2">Copper visibility</td><td colspan="2">No Copper visibility randomly on traces/ No features acceptable</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.1.4. Component Kit Inspection Report

<table><tr><td>Title</td><td colspan="5">COMPONENT KIT INSPECTION REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="3">LW/DLC-MU/PR/QA/004</td><td>Sheet:01 of 01</td></tr><tr><td>PCB Name</td><td colspan="3"></td><td>S. No</td><td></td></tr><tr><td>Supply Order No. to Assembly</td><td colspan="3"></td><td>Work Centre</td><td>DOFI, RCI</td></tr><tr><td>No. of Boards Kitted:</td><td colspan="3"></td><td colspan="2">Date:</td></tr><tr><td>BBP □</td><td colspan="2">BOB □</td><td colspan="2">PSU □</td><td>Tx/Rx Gain Stage □</td></tr></table>

<table><tr><td>S. No.</td><td>Inspection detail</td><td>Detail/ Description/ Observation</td></tr><tr><td>1</td><td>Kit quantity readiness for corresponding quantity and excess for any process tolerance</td><td></td></tr><tr><td>2</td><td>Identification number (BOM S. No.) of components for which COC&#x27;s available</td><td></td></tr><tr><td>3</td><td>Identification number (BOM S. No.) of components for which test reports available</td><td></td></tr><tr><td>4</td><td>Identification number (BOM S. No.) of components for which Neither COC nor test reports available</td><td></td></tr></table>

<table><tr><td>Component Kit Cleared for Assembly</td><td colspan="3">YES/ NO</td></tr><tr><td colspan="2">Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td colspan="2"></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.1.5. PCB Baking Inspection Report

<table><tr><td>Title</td><td colspan="4">PCB BAKING INSPECTION REPORT</td></tr><tr><td>Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/005</td><td colspan="2">Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td colspan="2"></td><td>S. No</td><td></td></tr><tr><td>Supplier/ Assembly House Name</td><td colspan="2"></td><td>Supplier PO Number</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td colspan="2"></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>S. No.</td><td>Parameter</td><td>Specification</td><td>QC Observation</td></tr><tr><td>1</td><td>Supplier/ Assembly house Baking Report</td><td>Report verification</td><td>Available/ Not Available</td></tr><tr><td>2</td><td>Temperature and duration of baking</td><td>As per baking specification</td><td></td></tr><tr><td>3</td><td>Discoloration of PCB laminate</td><td>Nil</td><td></td></tr><tr><td>4</td><td>Pad/ Pattern damage/ lifting</td><td>Nil</td><td></td></tr></table>

<table><tr><td>Clearance status</td><td colspan="2">Cleared /Not cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.1.6. Component Baking Inspection Report

<table><tr><td>Title</td><td colspan="4">COMPONENT BAKING INSPECTION REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/006</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td colspan="2"></td><td>Kit for S. No (s)</td><td></td></tr><tr><td rowspan="2">Supplier/ Assembly House Name</td><td rowspan="2" colspan="2"></td><td>Supplier PO Number</td><td></td></tr><tr><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>S. No.</td><td>Parameter</td><td>Specification</td><td>QC Observation</td></tr><tr><td>1</td><td>Supplier/ Assembly house Baking Report</td><td>Report verification</td><td>Available/ Not Available</td></tr><tr><td>2</td><td>Temperature and duration of baking</td><td>As per baking specification</td><td></td></tr><tr><td>3</td><td>Component Pad/ Pattern damage</td><td>Nill</td><td></td></tr><tr><td>4</td><td>Other defects, if any</td><td>Nill</td><td></td></tr></table>

<table><tr><td>Clearance status</td><td colspan="2">Cleared /Not cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

7.1.7. Populated PCB Inspection Report   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="4">POPULATED PCB INSPECTION REPORT</td></tr><tr><td>Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/PR/QA/007</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td></td><td colspan="2">S. No</td><td></td></tr><tr><td>Supplier/ Assembly House Name</td><td></td><td colspan="2">Supplier PO Number</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td colspan="2">Work Centre</td><td>DOFI, RCI</td></tr><tr><td>BBP □</td><td>BOB □</td><td colspan="2">PSU □</td><td>Tx/Rx Gain Stage □</td></tr></table>

<table><tr><td rowspan="2">S.
No.</td><td rowspan="2">Parameters</td><td rowspan="2">Acceptable Deviation Limits</td><td colspan="2">Satisfactory</td></tr><tr><td>Yes</td><td>No</td></tr><tr><td>1</td><td>Vendor&#x27;s QC reports</td><td>Available and satisfactory</td><td></td><td></td></tr><tr><td>2</td><td>X Ray inspection reports if PCB contains BGAs</td><td>Available and satisfactory</td><td></td><td></td></tr><tr><td>3</td><td>Part Number, Placement &amp; polarity as per layouts and BOM</td><td>Satisfactory</td><td></td><td></td></tr><tr><td>4</td><td>Component Assembly faults in optical scope inspection</td><td>Satisfactory</td><td></td><td></td></tr><tr><td>5</td><td>Enclosed foreign particles</td><td>Nil</td><td></td><td></td></tr><tr><td>6</td><td>Cracks</td><td>Nil</td><td></td><td></td></tr><tr><td>7</td><td>Residue of masking material</td><td>Nil</td><td></td><td></td></tr><tr><td>8</td><td>Discoloration</td><td>Nil</td><td></td><td></td></tr><tr><td>9</td><td>Pin holes and soft spots</td><td>Nil</td><td></td><td></td></tr><tr><td>10</td><td>Any discrepancy or failure in Verification of sub vendor QC reports</td><td>Nil</td><td></td><td></td></tr><tr><td>11</td><td>Other stackable connector placement not rugged fastened</td><td>Available and satisfactory</td><td></td><td></td></tr></table>

<table><tr><td>Clearance status</td><td colspan="2">Cleared /Not cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.1.8. Assembled Card Cold Checks

<table><tr><td>Title</td><td colspan="6">ASSEMBLED CARD COLD CHECKS</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/008</td><td colspan="3">Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td colspan="3">DLC-MU BBP (Antares)</td><td>S. No</td><td colspan="2"></td></tr><tr><td>PCB Quantity for Inspection</td><td colspan="3"></td><td colspan="2">Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>S. No</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Resistance Value (Ω)</td><td>Observed Value - OL (OK / NOT OK)</td></tr><tr><td>1</td><td>Reg_DC_VIN</td><td>J19.1</td><td>GND</td><td>J19.2</td><td>&gt;10KΩ</td><td></td></tr><tr><td>2</td><td>DC_VIN</td><td>C451.1</td><td>GND</td><td>C451.2</td><td>&gt;10KΩ</td><td></td></tr><tr><td>3</td><td>VCC_1V0</td><td>C161.1</td><td>GND</td><td>C451.2</td><td>&gt;20Ω</td><td></td></tr><tr><td>4</td><td>VCC_3V3</td><td>C201.1</td><td>GND</td><td>C451.2</td><td>&gt;1KΩ</td><td></td></tr><tr><td>5</td><td>VCC_1V2</td><td>C167.1</td><td>GND</td><td>C451.2</td><td>&gt;1KΩ</td><td></td></tr><tr><td>6</td><td>VCC1_1P8</td><td>C151.1</td><td>GND</td><td>C451.2</td><td>&gt;400Ω</td><td></td></tr><tr><td>7</td><td>VCC_1P35</td><td>C188.1</td><td>GND</td><td>C451.2</td><td>&gt;1KΩ</td><td></td></tr><tr><td>8</td><td>5V_OUT</td><td>C197.1</td><td>GND</td><td>C451.2</td><td>&gt;1KΩ</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="3">ASSEMBLED CARD COLD CHECKS</td></tr><tr><td>Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/009</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td>BOB</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>Sl.
No.</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Resistance Value (Ω)</td><td>Observed Value (OK / NOT OK)</td></tr><tr><td>1</td><td>VCC_5V</td><td>C21.1</td><td>GND</td><td>C21.2</td><td>&gt;1KΩ</td><td></td></tr><tr><td>2</td><td>VCC3V3</td><td>C23.1</td><td>GND</td><td>C21.2</td><td>&gt;1KΩ</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="5">ASSEMBLED CARD COLD CHECKS</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/010</td><td colspan="2">Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td colspan="3">PSU</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td colspan="3"></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>SI.
No.</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Resistance Value (Ω)</td><td>Observed Value (OK / NOT OK)</td></tr><tr><td>1</td><td>VCC_12V</td><td>C94.1</td><td>GND</td><td>C94.2</td><td>&gt;1KΩ</td><td></td></tr><tr><td>2</td><td>VCC_5V</td><td>C102.1</td><td>GND</td><td>C102.2</td><td>&gt;1KΩ</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="5">ASSEMBLED CARD COLD CHECKS</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/011</td><td colspan="2">Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td colspan="3">Tx Gain Stage</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td colspan="3"></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>Sl. No.</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Resistance Value (Ω)</td><td>Observed Value (Ok / Not Ok)</td></tr><tr><td>1</td><td>+5V</td><td>TP6</td><td>GND</td><td>TP5</td><td>&gt;10k</td><td></td></tr></table>

<table><tr><td>PCB Name</td><td>Rx Gain Stage</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>Sl. No.</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Resistance Value (Ω)</td><td>Observed Value (Ok / Not Ok)</td></tr><tr><td>1</td><td>+5V</td><td>TP2</td><td>GND</td><td>TP1</td><td>&gt;10k</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.1.9. Power Supply Checks

<table><tr><td>Title</td><td colspan="5">POWER SUPPLY CHECKS</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/012</td><td colspan="2">Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td colspan="3">DLC-MU BBP (Antares)</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td colspan="3"></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>S.No</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Value (V)</td><td>Observed Value - OL (OK / NOT OK)</td></tr><tr><td>1</td><td>Reg_DC_VIN</td><td>J19.1</td><td>GND</td><td>J19.2</td><td>12V +/- 1V</td><td></td></tr><tr><td>2</td><td>DC_VIN</td><td>C451.1</td><td>GND</td><td>C451.2</td><td>12V +/- 1V</td><td></td></tr><tr><td>3</td><td>VCC_1V0</td><td>C161.1</td><td>GND</td><td>C451.2</td><td>1V +/- 0.2V</td><td></td></tr><tr><td>4</td><td>VCC_3V3</td><td>C201.1</td><td>GND</td><td>C451.2</td><td>3.3V +/- 0.2V</td><td></td></tr><tr><td>5</td><td>VCC_1V2</td><td>C167.1</td><td>GND</td><td>C451.2</td><td>1.2V +/- 0.2V</td><td></td></tr><tr><td>6</td><td>VCC1_1P8</td><td>C151.1</td><td>GND</td><td>C451.2</td><td>1.8V +/- 0.2V</td><td></td></tr><tr><td>7</td><td>VCC_1P35</td><td>C188.1</td><td>GND</td><td>C451.2</td><td>1.35V +/- 0.2V</td><td></td></tr><tr><td>8</td><td>5V_OUT</td><td>C197.1</td><td>GND</td><td>C451.2</td><td>5V +/- 0.2V</td><td></td></tr><tr><td>9</td><td>1P3SUPPLY_A_AD1</td><td>R379</td><td>GND</td><td>C451.2</td><td>1.35 +/- 0.2V</td><td></td></tr><tr><td>10</td><td>1P3SUPPLY_A_AD2</td><td>R287</td><td>GND</td><td>C451.2</td><td>1.35 +/- 0.2V</td><td></td></tr><tr><td>11</td><td>PHY_DVDDL_1V2</td><td>FB11</td><td>GND</td><td>C451.2</td><td>1.2V +/- 0.2V</td><td></td></tr><tr><td>12</td><td>PHY_AVDDL_PLL_1V2</td><td>FB4</td><td>GND</td><td>C451.2</td><td>1.2V +/- 0.2V</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="3">POWER SUPPLY CHECKS</td></tr><tr><td>Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/013</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td>BOB</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>Sl.
No.</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Value (V)</td><td>Observed Value (OK / NOT OK)</td></tr><tr><td>1</td><td>VCC_5V</td><td>C21.1</td><td>GND</td><td>C21.2</td><td>5V +/- 0.2V</td><td></td></tr><tr><td>2</td><td>VCC3V3</td><td>C23.1</td><td>GND</td><td>C21.2</td><td>3.3V +/- 0.2V</td><td></td></tr></table>

<table><tr><td>Title</td><td colspan="3">POWER SUPPLY CHECKS</td></tr><tr><td>Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/PR/QA/014</td><td>Date:</td></tr><tr><td>PCB Name</td><td>PSU</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>Sl.
No.</td><td>Power Rail</td><td>Probe Point</td><td>Check with Rail</td><td>Probe Point</td><td>Expected Value (V)</td><td>Observed Value (OK / NOT OK)</td></tr><tr><td>1</td><td>VCC_12V</td><td>C94.1</td><td>GND</td><td>C94.2</td><td>12V +/- 1V</td><td></td></tr><tr><td>2</td><td>VCC_5V</td><td>C102.1</td><td>GND</td><td>C102.2</td><td>5V +/- 0.2V</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td>.</td><td>.</td><td>.</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="3">POWER SUPPLY CHECKS</td></tr><tr><td>Template/ Sheet No.</td><td>LW/DLC-MU/PR/QA/015</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td>Tx Gain Stage</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>Sl. No.</td><td>Power Rail</td><td>Probe Point</td><td>Ground Reference Point</td><td>Expected Value +/- Tolerance (V)</td><td>Observation</td></tr><tr><td>1.</td><td>+5V</td><td>TP6</td><td>TP5</td><td>5±0.5V</td><td></td></tr></table>

<table><tr><td>PCB Name</td><td>Rx Gain Stage</td><td>S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td>Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>SI. No.</td><td>Power Rail</td><td>Probe Point</td><td>Ground Reference Point</td><td>Expected Value +/- Tolerance (V)</td><td>Observation</td></tr><tr><td>1.</td><td>+5V</td><td>TP2</td><td>TP1</td><td>5±0.5V</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

7.1.10. Board Level Functional Checks   

<table><tr><td>Project</td><td>DLC-MU</td><td colspan="2">Work Centre</td><td colspan="2">DOFI</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="4">LW/DLC-MU/PR/QA/016</td></tr><tr><td colspan="2">Manufacturer</td><td>Lekha Wireless</td><td colspan="2">Unit Name</td><td>DLC-MU</td></tr><tr><td>Date</td><td></td><td>BBP SL No</td><td colspan="3"></td></tr><tr><td>PSU SL No</td><td></td><td>BOB SL No</td><td colspan="3"></td></tr></table>

<table><tr><td>Test No.</td><td>Parameter</td><td>Required Message</td><td>Observation</td><td>Remarks (Pass/Fail)</td></tr><tr><td>1.</td><td>Power ON, Current Drawn</td><td>230V, 0.05±0.03A</td><td></td><td></td></tr><tr><td>2.</td><td>UART 0 console access</td><td>Test Message String &quot;DEBUG CONSOLE&quot; should be received on the debug console.</td><td></td><td></td></tr><tr><td>3.</td><td>AD9364 Initialization</td><td>Initialization Successful</td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td>.</td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Project</td><td>DLC-MU</td><td>Work Centre</td><td>DOFI</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/PR/QA/016</td></tr></table>

<table><tr><td colspan="3">LW Tx Gain Stage</td><td colspan="3">SL No:</td></tr><tr><td rowspan="2">S. No.</td><td rowspan="2">Parameter/Specification/Frequency</td><td rowspan="2">I/P POWER @ RxIN (dBm)Tx</td><td>Tx Out (dBm)(-25dBm ±3dBm)</td><td>Gain (dB)(30dB ±3dBm)</td><td rowspan="2">Result Pass/ Fail</td></tr><tr><td>Tx</td><td>Tx</td></tr><tr><td>1.</td><td>2.20GHz</td><td>-55</td><td></td><td></td><td></td></tr><tr><td>2.</td><td>2.30GHz</td><td>-55</td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="3">LW Rx Gain Stage</td><td colspan="3">SL No:</td></tr><tr><td rowspan="2">S. No.</td><td rowspan="2">Parameter/Specification/Frequency</td><td rowspan="2">I/P POWER @Rx IN (dBm)Rx</td><td>Rx Out (dBm)(-25dBm ±3dBm)</td><td>Gain (dB)(30dB ±3dBm)</td><td rowspan="2">Result Pass/ Fail</td></tr><tr><td>Rx</td><td>Rx</td></tr><tr><td>1.</td><td>1.435GHz</td><td>-55</td><td></td><td></td><td></td></tr><tr><td>2.</td><td>1.535GHz</td><td>-55</td><td></td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

7.1.11. Potting and Conformal Coating Inspection Report   

<table><tr><td>Title</td><td colspan="4">POTTING AND CONFORMAL COATING INSPECTION REPORT</td></tr><tr><td>Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/PR/QA/017</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>PCB Name</td><td></td><td colspan="2">S. No</td><td></td></tr><tr><td>PCB Quantity for Inspection</td><td></td><td colspan="2">Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>S. No.</td><td>Process</td><td>Material</td><td>Expiry Date</td></tr><tr><td>1</td><td>Potting</td><td></td><td></td></tr><tr><td>2</td><td>Conformal Coating</td><td></td><td></td></tr></table>

<table><tr><td>S. No.</td><td>Process</td><td>Checklist</td><td>Acceptable/Not Acceptable</td></tr><tr><td>1</td><td>Potting</td><td>Vendor/ Supplier CoC</td><td></td></tr><tr><td rowspan="7">2</td><td rowspan="7">Conformal Coating</td><td>Masking as per drawing</td><td></td></tr><tr><td>Good and uniform Curing quality</td><td></td></tr><tr><td>No Contamination present</td><td></td></tr><tr><td>Good adhesion</td><td></td></tr><tr><td>No air bubbles</td><td></td></tr><tr><td>No pin holes</td><td></td></tr><tr><td>Uniform coating thickness</td><td></td></tr></table>

<table><tr><td>Observations</td><td colspan="2"></td></tr><tr><td>Clearance status</td><td colspan="2">Cleared /Not cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA, RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.2. FTR Templates

7.2.1. Initial/Final Isolation Checks   

<table><tr><td>Title</td><td colspan="4">ISOLATION &amp; CONTINUITY CHECKS</td></tr><tr><td>Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/PR/QA/018</td><td>Date:</td><td></td></tr><tr><td>Unit Name</td><td colspan="2"></td><td>S. No</td><td></td></tr><tr><td rowspan="2">Test Instance</td><td colspan="2">☐ Initial</td><td>Work Centre</td><td>DOFI, RCI</td></tr><tr><td>☐ Final</td><td colspan="3">Others Specify:</td></tr></table>

<table><tr><td>Test Instrument</td><td>Make/Model</td><td>Sl. No</td><td>Cal. Due Date</td></tr><tr><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Sl. No.</td><td>Pin No.</td><td>Signal Name</td><td>Reference</td><td>Continuity w.r.t Chassis</td><td>Expected Isolation Resistance w.r.t Chassis GND</td><td>Continuity YES/NO</td><td>Observed Isolation Value</td></tr><tr><td colspan="4">Connector Reference</td><td colspan="4">J1 (PWR)</td></tr><tr><td colspan="4">Connector Body w.r.t Chassis</td><td>YES</td><td>Short</td><td></td><td></td></tr><tr><td>1</td><td>1</td><td>240V AC</td><td>J1.3</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>2</td><td>1</td><td>240V AC</td><td>J1.5</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>.3</td><td>1</td><td>240V AC</td><td>J1.2</td><td>YES (&lt;10E)</td><td>&lt;10E Ohms</td><td></td><td></td></tr><tr><td>4</td><td>2</td><td>240V AC</td><td>J1.3</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>5</td><td>3</td><td>240V Return</td><td>J1.1</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>6</td><td>3</td><td>240V Return</td><td>J1.5</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>7</td><td>3</td><td>240V Return</td><td>J1.4</td><td>YES (&lt;10E)</td><td>&lt;10E Ohms</td><td></td><td></td></tr><tr><td>8</td><td>4</td><td>240V Return</td><td>J1.1</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>9</td><td>5</td><td>Reference</td><td>J1.1</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>10</td><td>5</td><td>Reference</td><td>J1.3</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>11</td><td>5</td><td>Reference</td><td>J1.6</td><td>YES (&lt;10E)</td><td>&lt;10E Ohms</td><td></td><td></td></tr><tr><td colspan="4">Connector Reference</td><td colspan="4">J2 (IO Connector)</td></tr><tr><td colspan="4">Connector Body w.r.t Chassis</td><td>YES</td><td>Short</td><td></td><td></td></tr><tr><td>1</td><td>1</td><td>UARTO_TX</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>2</td><td>2</td><td>UARTO_RX</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>3</td><td>3</td><td>Signal Ground</td><td>Chassis GND</td><td>YES (&lt;10E)</td><td>&lt;10 Ohms</td><td></td><td></td></tr><tr><td>4</td><td>6</td><td>RS422_TX1+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>SI. No.</td><td>Pin No.</td><td>Signal Name</td><td>Reference</td><td>Continuity w.r.t Chassis</td><td>Expected Isolation Resistance w.r.t Chassis GND</td><td>Continuity YES/NO</td><td>Observed Isolation Value</td></tr><tr><td>5</td><td>7</td><td>RS422_TX1-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>6</td><td>8</td><td>RS422_RX1+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>7</td><td>9</td><td>RS422_RX1-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>8</td><td>10</td><td>RS422_TX2+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>9</td><td>11</td><td>RS422_TX2-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>10</td><td>12</td><td>RS422_RX2+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>11</td><td>13</td><td>RS422_RX2-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>12</td><td>14</td><td>RS422_TX3+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>13</td><td>15</td><td>RS422_TX3-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>14</td><td>16</td><td>RS422_RX3+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>15</td><td>17</td><td>RS422_RX3-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>16</td><td>18</td><td>RS422_TX4+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>17</td><td>19</td><td>RS422_TX4-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>18</td><td>20</td><td>RS422_RX4+</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>19</td><td>21</td><td>RS422_RX4-</td><td>J2.3</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>20</td><td>22</td><td>GND</td><td>J2.3</td><td>YES (&lt;10E)</td><td>&lt;10 Ohms</td><td></td><td></td></tr><tr><td colspan="4">Connector Reference</td><td colspan="4">J4 (USB)</td></tr><tr><td colspan="4">Connector Body w.r.t Chassis</td><td>YES</td><td>Short</td><td></td><td></td></tr><tr><td>1</td><td>1</td><td>VBUS_USBx</td><td>Chassis GND</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>2</td><td>2</td><td>USB Data Nx</td><td>Chassis GND</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>3</td><td>3</td><td>USB Data Px</td><td>Chassis GND</td><td>NO (&gt;1K)</td><td>&gt;1K Ohms</td><td></td><td></td></tr><tr><td>4</td><td>4</td><td>Ground signal</td><td>Chassis GND</td><td>YES (&lt;10E)</td><td>&lt;10 Ohms</td><td></td><td></td></tr><tr><td>5</td><td>5</td><td>SHLD</td><td>Chassis GND</td><td>YES (&lt;10E)</td><td>&lt;10 Ohms</td><td></td><td></td></tr><tr><td colspan="4">Connector Reference</td><td colspan="4">J3 (Circular LAN)</td></tr><tr><td colspan="4">Connector Body w.r.t Chassis</td><td>YES</td><td>Short</td><td></td><td></td></tr><tr><td>1</td><td>1</td><td>ETH1_RX1_P</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>2</td><td>2</td><td>ETH1_RX1_N</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>3</td><td>3</td><td>ETH1_RX2_P</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>4</td><td>4</td><td>ETH1_RX2_N</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Sl. No.</td><td>Pin No.</td><td>Signal Name</td><td>Reference</td><td>Continuity w.r.t Chassis</td><td>Expected Isolation Resistance w.r.t Chassis GND</td><td>Continuity YES/NO</td><td>Observed Isolation Value</td></tr><tr><td>5</td><td>5</td><td>ETH1_MX3_P</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>6</td><td>6</td><td>ETH1_MX3_N</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>7</td><td>7</td><td>ETH1_MX4_P</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>8</td><td>8</td><td>ETH1_MX4_N</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td colspan="4">Connector Reference</td><td colspan="4">J5 (SMA Connector Tx)</td></tr><tr><td colspan="4">Connector Body w.r.t Chassis</td><td>YES</td><td>Short</td><td></td><td></td></tr><tr><td>1</td><td>1</td><td>Contact Pin</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>2</td><td>2</td><td>Connector GND</td><td>Chassis GND</td><td>YES (&lt;10E)</td><td>&lt;10 Ohms</td><td></td><td></td></tr><tr><td colspan="4">Connector</td><td colspan="4">J6 (SMA Connector Rx)</td></tr><tr><td colspan="4">Connector Body w.r.t Chassis</td><td>YES</td><td>Short</td><td></td><td></td></tr><tr><td>1</td><td>1</td><td>Contact Pin</td><td>Chassis GND</td><td>NO (&gt;10K)</td><td>&gt;10K Ohms</td><td></td><td></td></tr><tr><td>2</td><td>2</td><td>Connector GND</td><td>Chassis GND</td><td>YES (&lt;10E)</td><td>&lt;10 Ohms</td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.2.2. Unit Functional Test (Initial/ Final)

7.2.2.1. System Function Readiness and RF Initialization, Ethernet Test   

<table><tr><td>Title</td><td colspan="3">System Function Readiness and RF Initialization, Ethernet Test</td></tr><tr><td>Test Report No.</td><td>FTR-001</td><td>Date</td><td></td></tr><tr><td>Unit S/N</td><td></td><td>Work Centre</td><td></td></tr><tr><td>Model Name</td><td colspan="3"></td></tr></table>

<table><tr><td>S.
No</td><td>Parameters</td><td>Test
Procedure</td><td>Expected Result</td><td>Observed</td><td>Remarks</td></tr><tr><td>1.</td><td>Functional Verification for System function readiness and RF initialization</td><td>FTP-001</td><td>Boot-up logs are seen on the USB-UART Debug port as soon as board is powered on.
Console Management Port Transmitted message “Message to DEBUG CONSOLE” has to be received and displayed.
RF Initialization
String ad936x is successfully initialized should be displayed.</td><td></td><td></td></tr><tr><td>2.</td><td>Ethernet Test</td><td>FTP-002</td><td>IP address should be obtained when connected to a network and ping test should be successful</td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

7.2.2.2. Transmission Power Test   

<table><tr><td>Title</td><td colspan="3">Transmission Power Test</td></tr><tr><td>Test Report No.</td><td>FTR-002</td><td>Date</td><td></td></tr><tr><td>Unit S/N</td><td></td><td>Work Centre</td><td></td></tr><tr><td>Model Name</td><td></td><td>Test Procedure reference</td><td>FTP-003</td></tr></table>

<table><tr><td>Frequency</td><td>Voltage (VAC)</td><td>Current (0.05 ±0.03A)</td><td>Tx power expected in dBm</td><td>Observed Tx Power in dBm</td><td>Tx Packet</td><td>Rx Packet</td><td>Missed /Error Packets</td><td>Limit for PER</td><td>Pass/ Fail</td></tr><tr><td rowspan="2">2200MHz</td><td>220V</td><td></td><td>1±1dBm</td><td></td><td rowspan="6">Min. 3000</td><td></td><td></td><td rowspan="6">1 in 50</td><td></td></tr><tr><td>220V</td><td></td><td>1±1dBm</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">2250MHz</td><td>230V</td><td></td><td>1±1dBm</td><td></td><td></td><td></td><td></td></tr><tr><td>230V</td><td></td><td>1±1dBm</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">2300MHz</td><td>240V</td><td></td><td>1±1dBm</td><td></td><td></td><td></td><td></td></tr><tr><td>240V</td><td></td><td>1±1dBm</td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

7.2.2.3. Receiver Sensitivity Test   

<table><tr><td rowspan="4">DLC-MU Park Mount
Lekha</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="3">Receiver Sensitivity Test</td></tr><tr><td>Test Report No.</td><td>FTR-003</td><td>Date</td><td></td></tr><tr><td>Unit S/N</td><td></td><td>Work Centre</td><td></td></tr><tr><td>Model Name</td><td></td><td>Test Procedure reference</td><td>FTP-004</td></tr></table>

<table><tr><td>Frequency</td><td>Voltage (VAC)</td><td>Current (0.05 ±0.03A)</td><td>Sensitivity</td><td>Tx Packet</td><td>Rx Packet</td><td>Missed /Error Packets</td><td>RSSI</td><td>Limit for PER</td><td>Pass/Fail</td></tr><tr><td rowspan="2">1435MHz</td><td>220V</td><td></td><td>-105dBm±3dB</td><td rowspan="6">Min. 3000</td><td></td><td></td><td></td><td rowspan="6">1 in 50</td><td></td></tr><tr><td>220V</td><td></td><td>-105dBm±3dB</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">1485MHz</td><td>230V</td><td></td><td>-105dBm±3dB</td><td></td><td></td><td></td><td></td></tr><tr><td>230V</td><td></td><td>-105dBm±3dB</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">1535MHz</td><td>240V</td><td></td><td>-105dBm±3dB</td><td></td><td></td><td></td><td></td></tr><tr><td>240V</td><td></td><td>-105dBm±3dB</td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

CONFIDENTIAL & IP INTERNAL PAGE 205 of 249

<table><tr><td></td><td></td><td></td></tr><tr><td>DRYING</td><td>(DRYING)</td><td>DRYING</td></tr></table>

<table><tr><td></td><td rowspan="6">OSU T</td><td></td><td></td><td></td><td rowspan="6">e-</td><td>w-</td><td rowspan="6">z-</td></tr><tr><td></td><td></td><td></td><td></td><td>w-</td></tr><tr><td></td><td></td><td></td><td></td><td>w-</td></tr><tr><td></td><td></td><td></td><td></td><td>w-</td></tr><tr><td></td><td></td><td></td><td></td><td>w-</td></tr><tr><td></td><td></td><td></td><td></td><td>w-</td></tr><tr><td>Ie-</td><td>e-</td><td>ISSP</td><td>e-</td><td>e-</td><td>e-</td><td>e-</td><td>e-</td></tr></table>

<table><tr><td>S00-d⊥</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>N/S</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td>(√)</td><td></td><td></td><td></td></tr></table>

(Anon)   

<table><tr><td rowspan="2" colspan="2">Who owns the property?</td><td>Geng</td><td>Dece</td><td rowspan="2"></td></tr><tr><td>00</td><td>Rey</td></tr><tr><td>£00/£100</td><td>ON</td><td>00</td><td>A</td><td></td></tr></table>

7.3. Test Reports for Burn-in Test, ESS and ENTEST - AT/QT   

<table><tr><td rowspan="4">LIPC-MIL Park Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

7.3.1. Burn-in Test   
Tx Frequency: 1435MHz, Sensitivity: -105dBm±3dB   

<table><tr><td>Title</td><td colspan="4">BURN-IN TEST</td></tr><tr><td>Test Report No.</td><td colspan="2">TDR-001</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>Unit S. No.</td><td colspan="2"></td><td>Work Centre</td><td>DOFI, RCI</td></tr><tr><td colspan="2">Test Setup Reference</td><td></td><td>Test Procedure Ref</td><td>ETP-001</td></tr><tr><td>Test Condition</td><td colspan="4">Burn in test at temperature of +55°C for 48 hours in powered ON condition</td></tr></table>

<table><tr><td colspan="10">Tx Frequency: 1435MHz, Sensitivity: -105dBm±3dB</td></tr><tr><td>Test Case</td><td>Date/ Time</td><td>Voltage (Vac)</td><td>Current (0.05 ±0.03A)</td><td>Tx Packets</td><td>Rx Packets</td><td>RSSI</td><td>PER</td><td>Spec Value</td><td>Pass/Fail</td></tr><tr><td>PREET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td rowspan="12">1 in 50 Packets</td><td></td></tr><tr><td>INSET-1</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-2</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-3</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-4</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-5</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-6</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-7</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-8</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET-9</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>INSET- 10</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>POET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr></table>

CONFIDENTIAL & IP INTERNAL   

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td>.</td><td></td></tr><tr><td></td><td></td><td></td></tr><tr><td>DRYING</td><td>(100)</td><td>(100)</td></tr></table>

<table><tr><td></td><td rowspan="9">Depehns</td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E0d</td><td>Z</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E3N</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E3d</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E0d</td><td>A</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E3N</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E3d</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E0d</td><td>X</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E3N</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0E2</td><td></td><td>⊥E3d</td><td></td></tr><tr><td>1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="11"></td></tr></table>

__________   
1sE⊥nou!nueq!wopuey 2.E∠   

<table><tr><td>☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐</td><td colspan="2">☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐  ☑</td><td colspan="2">☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   □</td></tr><tr><td>☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐</td><td colspan="2">☐   0   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐
☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☻</td><td colspan="2">☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐
☐   0   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☐   ☻</td></tr></table>

<table><tr><td colspan="2" rowspan="2">ПИЗОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОDA</td><td>БЕTZ</td><td>ДОП</td><td>ДОП</td></tr><tr><td>00</td><td>СЕТ</td><td>СЕТ</td></tr><tr><td>БЕTZ</td><td>ON</td><td>00</td><td>СЕТ</td><td>СЕТ</td></tr><tr><td colspan="5">ПИЗОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДO</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT :</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>.00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>.00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

7.3.3. Temperature Cycle Test   
Tx Frequency: 1435MHz, Sensitivity: -105dBm±3dB   

<table><tr><td>Title</td><td colspan="6">TEMPERATURE CYCLE TEST</td><td></td></tr><tr><td>Test Report No.</td><td colspan="2">TDR-003</td><td>Date:</td><td>Test Setup Reference</td><td></td><td>Sheet:01 of 02</td><td></td></tr><tr><td>Unit S. No.</td><td colspan="2"></td><td>Work Centre</td><td>DOFI, RCI</td><td colspan="2">Test Procedure Ref</td><td>ETP-003</td></tr><tr><td colspan="2">TEST instances</td><td colspan="2">ESS □</td><td>QT □</td><td colspan="3">AT □</td></tr></table>

<table><tr><td colspan="11">Tx Frequency: 1435MHz, Sensitivity: -105dBm±3dB</td></tr><tr><td colspan="2">Test Case</td><td>Date/ Time</td><td>Voltage (Vac)</td><td>Current (0.05 ±0.03A)</td><td>Tx Packets</td><td>Rx Packets</td><td>RSSI</td><td>PER</td><td>Spec Value</td><td>Pass/Fail</td></tr><tr><td rowspan="2">Cy-1</td><td>-20°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td rowspan="12">1 in 50 Packets</td><td></td></tr><tr><td>55°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">Cy-2</td><td>-20°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>55°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">Cy-3</td><td>-20°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>55°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">Cy-4</td><td>-20°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>55°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">Cy-5</td><td>-20°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>55°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">Cy-6</td><td>-20°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>55°C</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

CONFIDENTIAL & IP INTERNAL

<table><tr><td></td><td></td><td></td></tr><tr><td>DRYER/ROY</td><td>(ROY)</td><td>(ROY)</td></tr></table>

BpWpSOT:AAHnssA'zHNSEeT:AouanbEeX   

<table><tr><td></td><td rowspan="3">Depehns
0000</td><td></td><td></td><td>0000 €</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>0000 €</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>0000 €</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td colspan="2">☐   ☐</td><td colspan="2">☐   ☐</td><td>☐   ☐</td><td>☐   ☐</td></tr><tr><td colspan="2">☐   ☐</td><td colspan="2">☐   ☐</td><td>☐   ☐</td><td>☐   ☐</td></tr><tr><td colspan="2">☐   ☐</td><td colspan="2">☐   ☐</td><td>☐   ☐</td><td>☐   ☐</td></tr><tr><td>HInn</td><td>HInn</td><td>HInn</td><td>HInn</td><td>HInn</td><td>HInn</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>HInn</td><td>HInn</td><td>HInn</td><td>HInn</td><td>HInn</td><td>HInn</td></tr></table>

$\geq  4$ ,即 $\angle {BAC} = {90}^{ \circ  }$ 时,   

<table><tr><td rowspan="2" colspan="2">ПИЗОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОDA</td><td>БОЗТ</td><td>ДОТ</td><td rowspan="3">БОЗТ</td></tr><tr><td>00</td><td>ДОТ</td></tr><tr><td>БОЗТ</td><td>БОЗТ</td><td>00</td><td>ДОТ</td></tr><tr><td colspan="4">ПИЗОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДОДO</td><td>ДОТ</td></tr></table>

7.3.5. Mechanical Shock, Bump, Acceleration Test   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="4">Mechanical Shock, Bump and Acceleration Test Report</td></tr><tr><td>Test Report No.</td><td>TDR-005</td><td colspan="2">Date:</td><td>Sheet:01 of 01</td></tr><tr><td>Unit S. No.</td><td colspan="2"></td><td>Work Centre</td><td>DOFI, RCI</td></tr><tr><td>Test Setup Reference</td><td colspan="2"></td><td>Test Procedure Ref</td><td>TP-014</td></tr><tr><td>Acceleration ☐</td><td colspan="3">Bump ☐</td><td></td></tr><tr><td colspan="3">AT ☐</td><td colspan="2">QT ☐</td></tr></table>

Tx Frequency: 1435MHz, Sensitivity: -105dBm±3dB   

<table><tr><td>Test Case</td><td>Date/ Time</td><td>Voltage (Vac)</td><td>Current (0.05 ±0.03A)</td><td>Tx Packets</td><td>Rx Packets</td><td>RSSI</td><td>PER</td><td>Spec Value</td><td>Pass/Fail</td></tr><tr><td>PREET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td rowspan="3">1 in 50 Packets</td><td></td></tr><tr><td>INSET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>POET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td></td><td></td><td></td></tr><tr><td>DRYER/ROY</td><td>(ROY)</td><td>(ROY)</td></tr></table>

<table><tr><td></td><td rowspan="9">SPECKS
DECR.
OS
T</td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥E0d</td><td rowspan="3">Z</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥ESNI</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥ERd</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥OeD</td><td rowspan="3">A</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥ESNI</td></tr><tr><td></td><td></td><td>.</td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥ERd</td></tr><tr><td></td><td></td><td>.</td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥OeD</td><td rowspan="3">X</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥ESNI</td></tr><tr><td></td><td></td><td></td><td></td><td>000E &#x27;U&#x27;W</td><td></td><td>A0EZ</td><td></td><td>⊥ERd</td></tr><tr><td>SPECKS
DECR
OS
T</td><td></td><td></td><td>ISSR</td><td>RX PRN</td><td></td><td>(∀E0&#x27;0&#x27;0&#x27;0&#x27;0&#x27;0)</td><td></td><td></td><td>⊥E0d
⊥ESNI
⊥ERd</td><td></td></tr></table>

BpEwpsOt:AnIiIiIeAs'ZHINSEI:AouenbEeX1   
A   

<table><tr><td colspan="2">☐          Μeνηρησίαηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηη</td><td colspan="2">☐          Μeνηρησίαηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηη</td><td>☐          Μeνηρησίηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηηη</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>££££ £</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>££ £££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>£££££</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££ ££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££ ±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££±£±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td></td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££×£±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td>££££±</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>££££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td>£££±</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>££££</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±££±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£ ±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£+£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£-£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£=£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£—£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£×£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>££±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td>£±£±</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td rowspan="2">&lt;|im_start|&gt;assistant</td><td>&lt;|im_start|&gt;assistant</td><td></td><td>2022</td><td></td><td></td></tr><tr><td>00</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>00</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

7.3.7. EMI/EMC Tests   

<table><tr><td rowspan="4">LIPC-MIL Park Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="5">EMI/ EMC TEST REPORT</td></tr><tr><td>Test Report No.</td><td colspan="2">TDR-007</td><td colspan="2">Date:</td><td>Sheet:01 of 01</td></tr><tr><td>Unit S. No.</td><td colspan="2"></td><td>Work Centre</td><td colspan="2">DOFI, RCI</td></tr><tr><td>Test Setup</td><td colspan="2">As per MIL 461E Standard</td><td colspan="2">Test Procedure Ref</td><td></td></tr><tr><td>CS101</td><td>CS114</td><td>CS115</td><td colspan="2">CS116</td><td>RS103</td></tr><tr><td>CE102</td><td>RE102</td><td>HESD</td><td colspan="2"></td><td></td></tr></table>

Tx Frequency: 1435MHz, Sensitivity: -105dBm±3dB   

<table><tr><td colspan="10">Tx Frequency: 1435MHz, Sensitivity: -105dBm±3dB</td></tr><tr><td>Test Case</td><td>Date/ Time</td><td>Voltage (Vac)</td><td>Current (0.05 ±0.03A)</td><td>Tx Packets</td><td>Rx Packets</td><td>RSSI</td><td>PER</td><td>Spec Value</td><td>Pass/Fail</td></tr><tr><td>PREET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td rowspan="3">1 in 50 Packets</td><td></td></tr><tr><td>INSET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr><tr><td>POET</td><td></td><td>230V</td><td></td><td>Min. 3000</td><td></td><td></td><td></td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

ed xueig 77 111eouuuaui   

<table><tr><td>VII AII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII NII OII</td><td></td><td></td></tr><tr><td>00</td><td>Rey</td><td></td></tr><tr><td>00</td><td>Rey</td><td></td></tr><tr><td>00</td><td>Rey</td><td></td></tr><tr><td>00</td><td>Rey</td><td></td></tr><tr><td>00</td><td>Rey</td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.4. Stage Clearance and Conformance Reports

# 7.4.1. Stage 1 - Raw Material and clearance to Assembly

<table><tr><td>Title</td><td colspan="4">RAW MATERIAL AND CLEARANCE TO ASSEMBLY REPORT</td></tr><tr><td>Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/TST/QA/001</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>Work Centre</td><td colspan="4">DOFI, RCI</td></tr><tr><td>BBP □</td><td>BOB □</td><td colspan="2">PSU □</td><td>Tx/Rx Gain Stage □</td></tr></table>

<table><tr><td colspan="5">Stage Clearance - Raw Material and Clearance to Assembly Report</td></tr><tr><td>S.
No.</td><td>Sub-Assembly</td><td>Report Reference</td><td colspan="2">Clearance Status</td></tr><tr><td>1</td><td>Bare-PCB Inspection Report</td><td>LW/DLC-MU/PR/QA/003</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>2</td><td>Component Kit Inspection Report</td><td>LW/DLC-MU/PR/QA/004</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>3</td><td>Mechanical Housing Inspection Report</td><td>LW/DLC-MU/PR/QA/001</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr></table>

<table><tr><td>Observations</td><td colspan="2"></td></tr><tr><td>Raw Material Stage Clearance</td><td>☐ Cleared</td><td>☐ Not – Cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.4.2. Stage 2 - PCBA clearance Report

<table><tr><td>Title</td><td colspan="5">PCBA CLEARANCE REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/TST/QA/002</td><td>Date:</td><td>Sheet: 01 of 01</td></tr><tr><td>Work Centre</td><td colspan="5">DOFI, RCI</td></tr><tr><td colspan="2">BBP □</td><td>IO BOB □</td><td colspan="2">PSU □</td><td>Tx/Rx Gain Stage □</td></tr></table>

<table><tr><td colspan="5">Stage Clearance - PCBA Clearance Report</td></tr><tr><td>S.
No.</td><td>Sub-Assembly</td><td>Report Reference</td><td colspan="2">Clearance Status</td></tr><tr><td>1.</td><td>Baking Inspection Report
(Applicable for BBP)</td><td>LW/DLC-MU/PR/QA/005</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>2.</td><td>Populated PCB Inspection Report</td><td>LW/DLC-MU/PR/QA/007</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>3.</td><td>Assembly Card Cold Checks</td><td>LW/DLC-MU/PR/QA/008 to 011</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>4.</td><td>Power Supply Checks</td><td>LW/DLC-MU/PR/QA/012 to 015</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>5.</td><td>Potting and Conformal coating</td><td>LW/DLC-MU/PR/QA/016</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr></table>

<table><tr><td>Observations</td><td colspan="3"></td></tr><tr><td colspan="2">PCBA Stage Clearance</td><td>□ Cleared</td><td>□ Not – Cleared</td></tr><tr><td colspan="2">Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td colspan="2"></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

7.4.3. Stage 3 - Unit Configuration and Assembly Clearance Report   

<table><tr><td>Title</td><td colspan="4">UNIT CONFIGURATION AND ASSEMBLY CLEARANCE REPORT</td></tr><tr><td>Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/TST/QA/003</td><td>Date:</td><td>Sheet: 01 of 02</td></tr><tr><td>Unit S. No.</td><td></td><td colspan="2">Work Centre</td><td>DOFI, RCI</td></tr></table>

<table><tr><td>S. No.</td><td>Configuration Description</td><td>Detail</td></tr><tr><td>1</td><td>FPGA PL Version Number</td><td></td></tr><tr><td>2</td><td>Revision and time stamp of PL Release Version</td><td></td></tr><tr><td>3</td><td>BSP Version</td><td></td></tr><tr><td>4</td><td>Application Revision number</td><td></td></tr><tr><td>5</td><td>Dimensions: 
Length=482.6 mm ±2.0mm 
Depth=350 mm ±2.0mm 
Height=88.00 mm ±0.2mm</td><td></td></tr><tr><td>6</td><td>Weight ≤10Kg</td><td></td></tr></table>

<table><tr><td>Observations</td><td colspan="2"></td></tr><tr><td>Assembly Stage Clearance</td><td>☐ Cleared</td><td>☐ Not – Cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Title</td><td colspan="4">UNIT CONFIGURATION AND ASSEMBLY CLEARANCE REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td>LW/DLC-MU/TST/QA/003</td><td>Date:</td><td>Sheet: 02 of 02</td></tr></table>

<table><tr><td colspan="5">Stage Clearance – Assembly Clearance Report</td></tr><tr><td>S.
No.</td><td>Sub-Assembly</td><td>Report Reference</td><td colspan="2">Clearance Status</td></tr><tr><td>1</td><td>BBP Assembled Board Functional Clearance</td><td>FTR Section: 7.1.10</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>2</td><td>BOB Board Functional Clearance</td><td>FTR Section: 7.1.10</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>3</td><td>PSU Board Functional Clearance</td><td>FTR Section: 7.1.10</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>4</td><td>Tx/Rx Gain Stage Unit Functional Clearance</td><td>FTR Section: 7.1.10</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>5</td><td>Isolation Checks</td><td>Section:7.2.1</td><td>□ Cleared</td><td>□ Not – Cleared</td></tr></table>

<table><tr><td>Observations</td><td colspan="2"></td></tr><tr><td>Assembly Stage Clearance</td><td>☐ Cleared</td><td>☐ Not – Cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.4.4. Stage 4 - ATP Conformance Report [Final Conformance Report]

# 7.4.4.1. Certificate of Conformance - AT

<table><tr><td>Title</td><td colspan="6">AT CONFORMANCE REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/TST/QA/004</td><td colspan="2">Date:</td><td>Sheet: 01 of 02</td></tr><tr><td>Unit S. No.</td><td colspan="2"></td><td colspan="2">Work Centre</td><td colspan="2">DOFI, RCI</td></tr><tr><td>Date of Clearance</td><td colspan="6"></td></tr></table>

<table><tr><td>S. No.</td><td>Test</td><td>Reference</td><td>Clearance (Yes/ No)</td><td>Comments if any</td></tr><tr><td>1.</td><td>Burn-In</td><td>+55°C±2°C for 48 hours in powered ON condition at LRU Level</td><td></td><td></td></tr><tr><td>2.</td><td>Initial Functional &amp; Isolation Test</td><td>Section Ref: 7.2.1 &amp; 7.2.2 Report Ref No: LW/DLC-MU/PR/QA/018, FTR-001 to FTR-004</td><td></td><td></td></tr><tr><td>3.</td><td>Pre-Random Vibration (RV1)</td><td>Duration: 5 min/axis 5 - 20 Hz : (6dB per octave) desirable 20 - 50Hz : 0.02 g2 /Hz, then rolling down to 0.001 g2 /Hz</td><td></td><td></td></tr><tr><td>4.</td><td>Thermal Cycling</td><td>a) -20°C ± 2°C for 1 hourb) -20°C to +55°C at 10°C/minc) +55°C ± 2°C for 1 Hourd) +55°C to +70°C at 10°C/Mine) 70°C ± 2°C for 1 hour.f) 70°C to -20°C at 10°C/minTotal Cycle 6</td><td></td><td></td></tr><tr><td>5.</td><td>Post-Random Vibration (RV2)</td><td>Duration: 5 min/axis 5 - 20 Hz : (6dB per octave) desirable 20 - 50Hz : 0.02 g2 /Hz, then rolling down to 0.001 g2 /Hz</td><td></td><td></td></tr><tr><td>6.</td><td>Bump (Only transportation axis)</td><td>1. No. of Bumps: 400 bump2. Peak Acceleration: 25g3. Pulse Duration: 6 msec4. Bump Rate: 1-2 Bumps/sec5. Unit will be tested under packaged condition</td><td></td><td></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

<table><tr><td>S. No.</td><td>Test</td><td>Reference</td><td>Clearance (Yes/ No)</td><td>Comments if any</td></tr><tr><td>7.</td><td>Humidity Test Heat</td><td>45°C (RH 95%) for 8 hours 
INSET (@ 7 1⁄2 Hrs.)</td><td></td><td></td></tr><tr><td>8.</td><td>Final Functional &amp; Isolation Test</td><td>Section Ref: 7.2.1 &amp; 7.2.2 
Report Ref No: LW/DLC-MU/PR/QA/018, FTR-001 to FTR-004</td><td></td><td></td></tr></table>

<table><tr><td>AT Clearance</td><td>☐ Cleared</td><td>☐ Not - Cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 7.4.4.2. Certificate of Conformance - QT

<table><tr><td>Title</td><td colspan="6">QT CONFORMANCE REPORT</td></tr><tr><td colspan="2">Template/ Sheet No.</td><td colspan="2">LW/DLC-MU/TST/QA/013</td><td colspan="2">Date:</td><td>Sheet: 01 of 02</td></tr><tr><td>Unit S. No.</td><td colspan="2"></td><td colspan="2">Work Centre</td><td colspan="2">DOFI, RCI</td></tr><tr><td>Date of Clearance</td><td colspan="6"></td></tr></table>

<table><tr><td>S.
No.</td><td>Test</td><td>Reference</td><td>Clearance
(Yes/ No)</td><td>Comments
if any</td></tr><tr><td>1</td><td>Burn-In</td><td>+55°C±2°C for 48 hours in powered ON condition at LRU Level</td><td></td><td></td></tr><tr><td>2</td><td>Initial Functional &amp; Isolation Test</td><td>Section Ref: 7.2.1 &amp; 7.2.2
Report Ref No: LW/DLC-MU/PR/QA/018, FTR-001 to FTR-004</td><td></td><td></td></tr><tr><td colspan="5">Environmental Stress Screening (ESS) Tests</td></tr><tr><td>3</td><td>Pre-Random Vibration
(RV1)</td><td>Duration: 5 min/axis
5 - 20 Hz : (6db per octave) desirable
20 - 50Hz : 0.02 g2 /Hz, then rolling down to 0.001g2 /Hz
at 500 Hz Three axes. 15 minutes cumulative</td><td></td><td></td></tr><tr><td>4</td><td>Thermal Cycling</td><td>g) -20°C ± 2°C for 1 hour
h) -20°C to +55°C at 10°C/min
i) +55°C ± 2°C for 1 Hour
j) +55°C to +70°C at 10°C/Min
k) 70°C ± 2°C for 1 hour.
l) 70°C to -20°C at 10°C/min
Total Cycle 6</td><td></td><td></td></tr><tr><td>5</td><td>Post-Random Vibration
(RV2)</td><td>Duration: 5 min/axis
5 - 20 Hz : (6db per octave) desirable
20 - 50Hz : 0.02 g2 /Hz, then rolling down to 0.001g2 /Hz
at 500 Hz Three axes. 15 minutes cumulative</td><td></td><td></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

<table><tr><td>S.
No.</td><td>Test</td><td>Reference</td><td>Clearance
(Yes/ No)</td><td>Comments
if any</td></tr><tr><td colspan="5">QT Testing</td></tr><tr><td>6</td><td>EMI/EMC Test</td><td>CE102, CS101, CS114, CS115, CS116, RS103, RE102, HESD</td><td></td><td></td></tr><tr><td>7</td><td>High Temperature
The test will be done at constant
temperature as per
method 2 of
Procedure II (Page 501.4-3)</td><td>Operation
(Sheltered Controlled)
+55°C ±3°C for 8 hrs.
+70°C ±3°C for 6 hrs.
+55°C ±3°C for 8 hrs.</td><td></td><td></td></tr><tr><td>8</td><td>Low Temperature
Test will be done at
constant temperature as
per method 2 of Procedure
II (Page 502.4-3)</td><td>Operation
(Controlled Sheltered)
-10°C±3°C for 8 hrs.
0°C±3°C for 6 hrs.
-10°C±3°C for 8 hrs.</td><td></td><td></td></tr><tr><td>9</td><td>Random Vibration
(Along all three axes)
1. PREET, INSET &amp; POET</td><td>1. As per MIL STD 810F, Method 514.5
- composite wheeled trailer vibration
exposure, Figure 26
2. Duration: 3 hrs cumulative
3. For packages not mounted inside
Canister: 5 - 20 Hz (6db per oct)
desirable 20 - 50Hz: 0.02 g2 /Hz, then
rolling down to 0.001g2 /Hz at 500 Hz.
40min. per axis</td><td></td><td></td></tr><tr><td>10</td><td>Bump
(Only transportation axis)</td><td>1. No. of Bumps: 4000 bump
2. Peak Acceleration: 25g
3. Pulse Duration: 6 msec
4. Bump Rate: 1-2 Bumps/sec
5. Unit will be tested under packaged
condition</td><td></td><td></td></tr><tr><td>11</td><td>Acceleration</td><td>1. X(Longitudinal) ±3g,
2. Y (Lateral) ±1.5 g,
3. Z (Vertical) ±2.5 g
1min/Axis</td><td></td><td></td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

<table><tr><td>S.
No.</td><td>Test</td><td>Reference</td><td>Clearance
(Yes/ No)</td><td>Comments
if any</td></tr><tr><td>12</td><td>Altitude
1. PREET at ambient
2. INSET during last ½hour
3. POET at ambient</td><td>1. Altitude 3.0 Km
2. Operational Temperature
-10°C±3°C for 8 hrs.
0°C±3°C for 6 hrs.
Functional
-10°C±3°C for 8 hrs</td><td></td><td></td></tr><tr><td>13</td><td>Humidity Test Heat</td><td>45°C (RH 95%) for 8 hours
INSET (@ 7½ Hrs.)</td><td></td><td></td></tr><tr><td>14</td><td>Mould Growth /Fungus</td><td>Analysis according to MIL- HDBK-454B
Guideline 4
1. Will be done by material
declaration/analysis.
2. In case new material is used which
are not tested, a test is required.
3. Examples of sample coupons are:
i) Conformal coated PCBs. ii)Insulations
iii)Rubber grommets iv)Rubber
Components v) EMI gaskets vi)Plastics
vii)Paper, Vinyl, Textile
component/parts, if any</td><td></td><td></td></tr><tr><td>15</td><td>Final Functional &amp;
Isolation Test</td><td>Section Ref: 7.2.1 &amp; 7.2.2
Report Ref No: LW/DLC-
MU/PR/QA/018, FTR-001 to FTR-004</td><td></td><td></td></tr></table>

<table><tr><td>QT Clearance</td><td>□ Cleared</td><td>□ Not - Cleared</td></tr><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 8. Annexures

# Annexure-A: Quality Control Plan (QCP)

Application: For ensuring seamless, appropriate, precise manufacturing & inspection of components following listed below details needs to be followed & QCP must be submitted to QA agency for review & Approval before manufacturing with respect to Approved Drawings only (BTS case).

Note: Refer Instructions to prepare QCP.

# PLANS:-

1. Manufacturing Control Plan: It consists of two tables. 1 List of Operations & Detailed Process Plan (Refer IPD Document No: LW/DRDL/LRSAM/DLC-MU/SYS/DOC/IPD/004)

List of Operations: Contains list of various stages of operations for the component (Refer IPD Document No: LW/DRDL/LRSAM/DLC-MU/SYS/DOC/IPD/004).

Detailed Process Plan: process plan for components to ensure mfg. procedures to be followed from End Use R/m Material cut size to its final inspection. (Refer IPD Document No: LW/DRDL/LRSAM/DLC-MU/SYS/DOC/IPD/004).

2. Dimension Inspection Acceptance Plan: To meet specific criteria and procedures for inspecting the dimensions of a component. (Refer Section: 7.1.2).

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Annexus-B: QA Plan for RAW Materials

Table 48: QA Plan for RAW Material   

<table><tr><td>Material</td><td>R&amp;QA(M) Document Number</td><td>List of Tests applicable for Present Application</td><td>Remarks</td></tr><tr><td>AA6082</td><td rowspan="4">RCI/DR&amp;QA/RMQAP/059.</td><td>1. Raw Material Identification (Visual &amp; Dimensional Inspection)</td><td></td></tr><tr><td>T6</td><td>2. Ultrasonic Test</td><td></td></tr><tr><td>Flat</td><td>3. Chemical Analysis</td><td></td></tr><tr><td>Bar/Plate/Sheet</td><td>4. Tensile Test</td><td></td></tr></table>

# Note:

1. All the tests mentioned in R&QA QAP need not be conducted.   
2. Only tests mentioned in column 3 in the above Table, will be conducted. The qualification values of the tests will be governed by the corresponding R&QA QAP document.   
3. The approved QA matrix provided in this document governs the number of samples and inspection/witnessing activities.   
4. The sampling plan for tensile and hardness testing must be submitted by the supplier before the preparation of the test samples. After approval of the sampling plan, the supplier has to start the testing activity.   
5. The failed samples need to be quarantined and submitted to DR&QA, RCI. Further testing activities will be started after failed samples are submitted to DR&QA.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Annexure-C: List of DLC-MU Drawings

Table 49: List of Part component drawings of DLC-MU   

<table><tr><td>S. No.</td><td>Drawing No./Standard</td><td>Description</td><td>Material Type</td><td>Qty/Unit</td></tr><tr><td>1.</td><td>LWS-DLC-MU-PD-01</td><td>Front Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>2.</td><td>LWS-DLC-MU-PD-02</td><td>Top Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>3.</td><td>LWS-DLC-MU-PD-03</td><td>Rear Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>4.</td><td>LWS-DLC-MU-PD-04</td><td>LH Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>5.</td><td>LWS-DLC-MU-PD-05</td><td>RH Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>6.</td><td>LWS-DLC-MU-PD-06</td><td>Bottom Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>7.</td><td>LWS-DLC-MU-PD-07</td><td>BOB Top Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>8.</td><td>LWS-DLC-MU-PD-08</td><td>BBP Top Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>9.</td><td>LWS-DLC-MU-PD-09</td><td>PSU Top Plate-1</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>10.</td><td>LWS-DLC-MU-PD-10</td><td>PSU Top Plate-2</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>11.</td><td>LWS-DLC-MU-PD-11</td><td>PSU Leg</td><td>AA 6082 T6</td><td>4 No.</td></tr><tr><td>12.</td><td>LWS-DLC-MU-PD-12</td><td>ETH Top Cover</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>13.</td><td>LWS-DLC-MU-PD-13</td><td>TX Gain BT Plate</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>14.</td><td>LWS-DLC-MU-PD-14</td><td>TX Gain TP</td><td>AA 6082 T6</td><td>1 No.</td></tr><tr><td>15.</td><td>LWS-DLC-MU-PD-15</td><td>RX Gain BT Plate</td><td>AA 6082 T6</td><td>1 no.</td></tr><tr><td>16.</td><td>LWS-DLC-MU-PD-16</td><td>RX Gain TP</td><td>AA 6082 T6</td><td>1 no.</td></tr><tr><td>17.</td><td>LWS-DLC-MU-PD-17</td><td>Feed Thru Holder</td><td>AA 6082 T6</td><td>1 no.</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td colspan="1">Jan 2025</td></tr></table>

# Annexure-D: QA Plan for Powder Coating

The process contains two stages, the first is cleaning and Yellow Chromate Conversion of the components and the second stage is powder coating of the components.

# 1. Process:

A. Steps involved in Powder Coating.

Water Rinsing: Rinse the components in water for 2 minutes   
- Preheating: Pre-heating the components in oven for moisture removal for 10 -15 minutes   
- Powder Spraying: Spraying the Olive Green (RAL 6003) Powder Coating with electronic spray gun.   
Heating: Heating in Oven for 1 to 1.5 hours

# 2 Qualification Test:

Chromate Conversion and powder coating shall be carried out as per the above process on two aluminum alloy 6082 T6 sheet/plate coupons of size $75 \times 250 \, \text{mm}$ . The same shall be subjected to the following tests.

2.1 Visual Inspection: The coating shall be uniform in appearance and color. The coating shall be continuous, free from breaks, scratches and other damage.   
2.2 Dry Film Thickness Test: The coating shall be adherent and non-powdery.

# 3 Acceptance Test:

The process qualified as per procedure given in Para 2 shall be used for chromating and powder coating of the components. For each batch of components the details of the components (item description, quantity & identification numbers) and all the process parameters shall be recorded. Two representative coupons as per Para 2.0 shall be chromated and powder coated along with each batch of components. For batch acceptance, one of the representative coupons should meet the test requirements mentioned in Para 2.1 to 2.2. All the components shall be subjected to visual inspection and should meet the requirements mentioned in Para 2.1.

# 4 Reports:

The firm shall furnish with each batch of Chromatisation, a report stating that the parts have been processed, tested and conform to the specified requirements. And should mention the details of the powders being used for coating (i.e. Lot & Batch No.)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Annexure-E: Copy of Specifications

# Specifications and Scope of Work for Data link Controller and Monitoring unit with Rack Mount Ruggedized Display

# Scope of Work:

The Vendor has to develop a Controller and Monitoring Unit along with Rugged display as per the specs given below with the following arrangement:

1. The Data link controller and Monitoring unit will be as per the specifications given below.   
2. Up gradation of storage, log access, ICD application to be taken up.   
3. For display, it will be a ruggedized 12" display unit.   
4. Vendor has to design the tray and the slide mechanism for the display to house it in a 19" Rack when not in use.   
5. When in use, it will be opened and overlap with the frontal portion of the rack unit.   
6. ICD enhancements and validation will be part of the work.   
7. The slide arrangement, display, foldable tray and mounting all need to be designed and fabricated by the vendor for Rugged display unit.

# 1. Technical specifications of Data Link Controller:

The Data-link Controller with Display is host of Ground Data-link system which provides an interface with Radar & FCS. The controller to be realized in 2U 19" rack mount cabinet. The system translates information on network, implement protocol conversion, ensure seamless data flow, monitor health & implement switchover algorithm for hot standby between main & Redundant Data-link system. The 19" 2U rack mount foldable 12" Display provides network traffic & health of data-link system

The system should be designed using embedded processor with GB Ethernet with auto switch over logic of hot standby redundancy. It should provide secondary storage for logging network traffic useful during post flight analysis. It should also facilitate internal data generation during data-link maintenance operation.

![](images/3a8d5a7695eb2788c471e9c7b5dc2d2abc40a4402297fdc43af4379507f54a90.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 1. Data Link Controller:

<table><tr><td colspan="2">Base Module:</td></tr><tr><td>Processing Unit</td><td>Xilinx Zynq SOC7045-XC 7Z045 - 2FG900I or higher</td></tr><tr><td>Clock</td><td>40MHz TCXO</td></tr><tr><td>Non-Volatile Memory</td><td>NOR flash, 256MB or more</td></tr><tr><td>SDRAM</td><td>DDR3L, 8Gb</td></tr><tr><td>SD CARD</td><td>Internal access only
PUSH-PUSH R/A SMD (For Debug and development purposes)</td></tr><tr><td>eMMC</td><td>16GB NAND Flash (For deployment purposes)</td></tr><tr><td>EEPROM - Memory</td><td>8Kb or more</td></tr><tr><td colspan="2">RF Module:</td></tr><tr><td>Transceiver</td><td>AD9361 /AD9364</td></tr><tr><td colspan="2">Peripherals:</td></tr><tr><td>GB Ethernet</td><td>2 ports</td></tr><tr><td>USB to UART Bridge</td><td>1 UARTs at RS232 Level</td></tr><tr><td>USB interface</td><td>ULPI Interface (USB 2.0)</td></tr><tr><td>USB Expansion</td><td>Use external ruggedized hub for any larger display monitor via USB</td></tr><tr><td>GPS</td><td>UART interface</td></tr><tr><td>RS422 Ports</td><td>4 No&#x27;s</td></tr></table>

# 2. Crypto Module:

- Implementation AES algorithm for Data packets.   
- Packet conversion to Data Block for synchronization with AES.

# 3. Auto switchover Algorithm:

- Auto Switchover Algorithm for implementation of hot standby redundancy.   
Development of algorithm based on quality & health of main & redundant data link units.   
Algorithm should implement PER of Data Link Monitoring System.   
- Monitor & Provide Data-link system vitals.   
- Switch over time should be less than 0.5 sec (Switch over time should be programmable)

# II. Technical Specifications of monitoring Unit:

- The Data link monitoring unit should have an L-Band Receiver module whose code and frequency is programmable, in order to monitor the health of Ground Transmitter and update the health parameters like RSSI, Track etc., to Data link controller. It should also verify the health of S-Band Ground Receiver module. For this the module should have One S-Band Transmitter whose code and Frequency are programmable.

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Trans-receiver unit</td><td>Consists of One S-Band transmitter and a L-Band receiver</td></tr><tr><td>I.(a) Transmitter</td><td></td></tr><tr><td></td><td>Frequency: S-band (programmable in steps of 1KHz)</td></tr><tr><td></td><td>Transmission rate: 4800 bps without FEC or 9600 with FEC</td></tr><tr><td></td><td>Spreading code length:127 or 31 programmable</td></tr><tr><td></td><td>Signal Bandwidth (with RRC): less than 1MHz @127 code length 4800 data rate Or less than 2MHz @127 code length 9600 Transmission rate(FEC ON) Signal Bandwidth @31 bit code 4800 data rate less than 0.25 MHz Signal Bandwidth @31 bit code 4800 data rate(9600bps Transmission rate) less than 0.5 MHz</td></tr><tr><td></td><td>No of transmitters: 1 No of RF ports: 1</td></tr><tr><td></td><td>Input/output data Interface: Ethernet</td></tr><tr><td></td><td>Modulation: BPSK</td></tr><tr><td></td><td>Output: 1 dBm +/- 1 dB</td></tr><tr><td></td><td>RF Connector: SMA connector for RF output</td></tr><tr><td></td><td>Data interface: Ethernet</td></tr><tr><td>I.(b) Receiver</td><td>Frequency: L-band (programmable in steps of 1 MHz)</td></tr><tr><td></td><td>No of Rx antenna ports: 1</td></tr><tr><td>RF Bandwidth: 100 MHz</td><td>No of receivers: 1 and can operate at a different frequency Each Antenna input is passed through limiter, BPF and LNA and fed to Receiver..</td></tr><tr><td></td><td>CDMA decoder: band width Efficient Spread Spectrum</td></tr><tr><td></td><td>Data Rate: 9600 without FEC, 4800 bps with FEC (1/2 rate convolution coding)</td></tr><tr><td></td><td>Error Correction de Coding: Viterbi soft</td></tr><tr><td></td><td>Signal Bandwidth: 15±1 MHz @9600bps data rate 1023 code length, 7.5±1 MHz @ 9600 bps data rate 511 code length</td></tr><tr><td></td><td>Decoder: Decode single user data from 6 user CDMA data</td></tr><tr><td></td><td>Sensitivity: -105 dBm for given 6-user CDMA signal @ PER of 1 in 50 Packets without FEC</td></tr><tr><td></td><td>Dynamic Range: 70 dB or Higher</td></tr><tr><td></td><td>PN Code:511/1023, programmable to other code lengths</td></tr><tr><td></td><td>Modulation: BPSK</td></tr><tr><td></td><td>PER: 1 in 50 Packets at Sensitivity level</td></tr><tr><td></td><td>Acquisition/Reacquisition Time: &lt; 10 ms</td></tr></table>

![](images/c2b0bf0608044cb911310f508acf1b7571cde0adbbfb1177af7d37d994ee657a.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# III. External Display with Processor:

Ruggedized external mountable 12" display with USB control. It comes with an external attachment to base unit. It is USB based display & rugged connector. Vendor should provide drivers & develop software to display system parameters on display. Vendor should provide Rack mount on 19" Rack.

# 4. Display Specifications

<table><tr><td rowspan="9">System</td><td>CPU</td><td>Intel®Celeron®J6412quadcore</td></tr><tr><td>Frequency</td><td>2.0GHz</td></tr><tr><td>L2Cache</td><td>1.5 MB</td></tr><tr><td>Memory</td><td>1xSDRAMDDR43200MHz(max 32G)</td></tr><tr><td>Storage</td><td>1x2 5°SATAbay(optional;requiresab框架协议installation)1xM 2slot:Mkeyforstorage(SATAonly,2242&amp;2280)</td></tr><tr><td>Network(LAN)</td><td>2x10/100/1000/2500MbpsEthemet(IntelI225-LM)</td></tr><tr><td>I/O</td><td>2xSenalports:1xRS-232,1xRS-232/422/485(AdjustablethroughBIOS)2xUSB2.0,2xUSB3.11xTypeC(USBonly)1xHDM11.41xTPM2.0</td></tr><tr><td>Expansion</td><td>1xM 22230E-keyforwardwirelesscard</td></tr><tr><td>WatchdogTimer</td><td>255timerlevels,setupbysoftware</td></tr></table>

<table><tr><td rowspan="2">PhysicalCharacteristics</td><td>Dimensions</td><td colspan="3">317x246 x52 7 mm(12.5x 9.7x 2.07in)</td></tr><tr><td>Weight</td><td colspan="4">3.16 kg(8 14lb)</td></tr><tr><td>OSSupport</td><td>OSSupport</td><td colspan="3">Microsoft*Windows10(64-bit), Linux,Android</td></tr><tr><td rowspan="2">PowerConsumption</td><td>InputVoltage</td><td colspan="3">12~30Vcc</td></tr><tr><td>PowerConsumption</td><td colspan="4">36 5W(Burn-inless8.1inWindows10,64-bit)</td></tr><tr><td rowspan="8">LCD</td><td>DisplayType</td><td colspan="3">12*TFTLCD(LED backlight)</td></tr><tr><td>Resolution</td><td colspan="4">1024x768</td></tr><tr><td></td><td colspan="4"></td></tr><tr><td></td><td colspan="4"></td></tr><tr><td>ViewingAngle</td><td colspan="4">85(left),85(right),89(up),89(down)</td></tr><tr><td>Luminance(cd/m2)</td><td colspan="4">500</td></tr><tr><td>ContrastRatio</td><td colspan="4">1000</td></tr><tr><td>BacklightLifetime</td><td colspan="4">30,000hr(min.)</td></tr><tr><td rowspan="4">Touchscreen</td><td>TouchType</td><td>FLO5-wiresistventouch</td><td colspan="2">ProjectedCapacitiveMulti-touch</td></tr><tr><td>LightTransmission</td><td>80±5%at550nmwavelength</td><td colspan="2">88±2%</td></tr><tr><td>Controller</td><td>USBInterface</td><td colspan="2">USBInterface</td></tr><tr><td>Durability (Touches)</td><td>Greaterthan35milliontouchesinoneolocationwithoutfailure</td><td colspan="2">Coverglass&gt;7H</td></tr><tr><td rowspan="8">Environment</td><td>OperatingTemperature</td><td colspan="3">-10~50°C(14~122°F)</td></tr><tr><td>StorageTemperature</td><td colspan="4">-20~60°C(-4~140°F)</td></tr><tr><td>RelativeHumidity</td><td colspan="4">10~95%@40°C(non-condensing)</td></tr><tr><td>Shock</td><td colspan="4">Operating10Gpokacoloration(11modulation),followIEC60068 2 27</td></tr><tr><td>Vibration</td><td colspan="4">OperatingRandomVibrationTest5-500Hz,2Gms@withSSD,followIEC60068-2-64</td></tr><tr><td>EMC</td><td colspan="4">CE,FCCClass8,BSMI,UKCA,VCCI</td></tr><tr><td>Safety</td><td colspan="4">CB,CCC,BSMI,UL,UKCA</td></tr><tr><td>FrontPanelProtection</td><td colspan="4">IP66compliant</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 5. Power supply:

AC input: 220-240V, 50 Hz supply.

# 6. Connectors:

<table><tr><td>Peripheral functionality</td><td>JTAG, SDCARD (internal to the unit)</td></tr><tr><td>Power connector</td><td>Circular ruggedized connector - 38999 series</td></tr><tr><td>Peripheral connector</td><td>4xRS422 ports and debug console port on Circular connector</td></tr><tr><td>USB</td><td>Ruggedized connector on panel.</td></tr><tr><td>Power supply</td><td>6-pin connector</td></tr><tr><td>Cables</td><td>2 meter cables with mating connector</td></tr><tr><td>RF connectors</td><td>1 No SMA(F) for Tx RF output
1 No SMA(F) for Rx RF input</td></tr><tr><td>Monitor and control</td><td>Ruggedized Circular connector, RJ45 or customer defined</td></tr><tr><td>Grounding</td><td>Ground stud</td></tr></table>

# 7. SOFTWARE/ICD IMPLEMENTATION

<table><tr><td>Software</td><td>Linux OS. Vendor to provide C/C++ code for ICD and external display.
C/C++ Code &amp; Vivado prj/EDK files to be provided. Software for local storage of data &amp;health parameters must be provided</td></tr><tr><td>ICD Software</td><td>As per RCI ICD Document</td></tr><tr><td>Software Documents</td><td>Docs to be submitted for RCI IV&amp;V.
Software clearance by vendor.</td></tr></table>

Note: The ICD will be given to L1 vendor

# 8. Control & Monitor Signals:

Code selection : loadable PN code by Software   
- FEC Selection : FEC on/off by software selection   
Frequency selection L-Band/S-Band synchronizer by software   
TM Signals 2-Buffered RSSI Signals, 2-Buffered PLL Health, 2-buffered decoder Health, 1 Buffered encoder Health

(Note: Control & Monitor Software to be implemented as per RCI ICD)

Monitor Firmware: the unit should update correlator measurement and health data such as correlation values, measured CNR, Measured Doppler Drift, slue rate, software version on TM Rs422 port.   
RS-422 Protocol: 112.5 baud, 8-bit, 1 stop bit, No parity & GB Ethernet (Note: ICD to be implemented by vendor)

![](images/14fc6acbb876525575c7ca92535ae3966189ba96e209d2fabde9e30a828e779c.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 9. Controller Interfaces:

GB Ethernet : 2 Nos RS422 : 4 Nos

# 10. Mechanical:

<table><tr><td>Material</td><td>Aluminum Alloy 6082-T6/ HE 30 Material Grade</td></tr><tr><td>Dimensions (excluding display)</td><td>2U, 19&quot; Rack Mount unit with sliders &amp; handles.</td></tr><tr><td>EMI/EMC</td><td>Shielding &amp; Gaskets</td></tr><tr><td>Weight</td><td>Approx. 10 Kgs</td></tr><tr><td>Finish</td><td>Yellow chromate- Total unit
External surfaces - powder coat olive green
RAL6003 Engraving of legends, logos and connector markings.</td></tr><tr><td>Adopter kit</td><td>Attachment kit for 12&quot; rugged display</td></tr><tr><td colspan="2">Display unit:</td></tr><tr><td>Dimension</td><td>12&quot; Rugged Display</td></tr><tr><td>Mount</td><td>Tray</td></tr></table>

# 11.QA/QC:

As per Project/RCI QA/QC policy   
RCIR&QA,DSQA involved.   
IV&V to be compelled as per DSQA, RCI requirements.

12. Tentative EN-TEST Requirements: ( These environmental tests mentioned are tentative LRSAM/KUSHA En-test specifications will be given to L1 vendor)

Data-link Controller and Monitoring Basic Unit (1 QT & 2 AT)

# QT:

Cold checks   
Power checks/ Initial Functional Tests   
ESS(Pre Random vibration/10-Thermal cycle/Post Random vibration)   
EMI/EMC Test (CE102/CS101/CS114/CS115/CS116/CS118/RE102/RS103)   
* QT Tests: ESS/ Random Vibration / LT / HT/ Humidity/ Fungus or Mould growth / Altitude /Mechanical Shock /Acceleration /Bump / Drop and Topping.

![](images/eafbfa6345277316561ec4ae590d386f2d347bed7d74c864e541ea0f1e0b6150.jpg)

![](images/c3afba318e888b326f5a6f4b340a273efdf22b61d63a8c89f1d6b1b18ce612af.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# AT:

Cold checks   
Power checks Initial Functional tests   
* ESS Test (Pre Random vibration / 6 Thermal cycle / Post Random vibration)   
Random Vibration   
* Shock   
Bump   
Damp Heat test   
- Operating cycles

# 12" Rugged Display (3 No's)

Acceptance based on FTP, OEM Test reports & COC only. No en-tests will be done for display unit

# 13. Acceptance Criteria:

1. Acceptance of Data-Link Controller and Monitoring Unit (1 QT & 2 AT) based on FTP followed by AT/QT tests by vendor   
2. Acceptance of Rugged 12" Display is based on FTP & OEM COCs.   
3. Vendor has to be prepare QAP, QTP and ATP and test report documents in concurrence with user rep, RCI. All the documents must be prepared as per R&QA/RCI format.

The goods will be accepted only after full functional testing. Following tests will be carried out:

1. ICD verification (GB Ethernet /RS422)   
2. Uplink / downlink Frequency testing. The RF signal of both uplink/ downlink and for all spot frequencies we are observed on spectrum analyzer.   
3. PN codes, FEC selection test   
4. Dynamic range, sensitivity & PER measurement.   
5. FTP, Burn-in-test, ESS, AT&QT test as per Kusha/LRSAM test level plan.   
6. Acceptance of Data Link Ground Health Monitoring unit(I QT & 2 AT) based on FTP followed by En test (AT and QT)

# 14. List of Deliverables:

Data link controller and monitoring Unit(2 AT & 1 QT) with rugged Display (3Nos)   
Data-link Controller and Monitoring unit with FTP & AT reports   
Rugged 12" Display with COC   
RF Cables: Assorted   
Data Cables: assorted

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# 15. Terms and Conditions:

1. Mil-Grade/ Industry Grade Components to be used wherever applicable.   
2. Software to be written as per RCI ICD   
3. RCI ICD will be given to LI Vendor.   
4. Above specifications are tentative and they may be fine turned if necessary during TEC.   
5. PCBs should be Gp-A/Gp-B certification if applicable.   
6. Data link parameters are confidential & will be shared to L1 vendor after NDA document is signed.   
7. 12" Rugged Display will be cleared by verifying OEM tests reports & production of COCs   
8. Cable Loom to be provided by vendor for external connectivity.   
9. Internal cabling to be done by low loss semi-rigid RF cables.   
10. Proper title & label to be printed. RCI logo to be printed. Model no to be given as per RCI standard plan and it must be there on all deliverables.   
11. The firm should produce necessary documents and reports in prescribed format.   
12. AT and QT to be done by Vendor. QA/QC by R&QA/RCI, IV & V by DSQA /RCI at every stage of development.   
13. The acceptance of stores is based on FTP tests & AT/QT in the presence of RCI rep   
14. Warranty: |Year

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Annexure-I

The order of precedence of different category of test is given below

![](images/77a41f5b4b1a9ce3d685e46c4edc08e520e4895e6d3cbf8997e43c247acfaf40.jpg)

![](images/1bb5fc2f7c6baf53d56941c0b95acab830ab0e60550b5e0fee9b361fbe91c10e.jpg)  
AT:

![](images/577c225aedbbbafe05464328f8ee1eb3f51e13572bdc8dccb70bc5ada8fe6bbd.jpg)  
QT:

# EMI/EMC Tests:

1. CE 102 6. RE101   
2.CS101 7.RE102   
3.CS114 8.RS101   
4.CS116 9.RS103   
5. CS118

NOTE: The En-test requirements are tentative. The detailed En-test requirements will be given at the time of S.O Placement

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

# Annexure-F: Specifications Mapping and Notes

Table 50: Specification Mapping   

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td>Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td colspan="4">I. Technical specifications of Data Link Controller:</td></tr><tr><td colspan="3">The Data-link Controller with Display is host of Ground Data-link system which provides an interface with Radar &amp; FCS. The controller to be realized in 2U 19&quot; rack mount cabinet. The system translates information on network, implements protocol conversion, ensures seamless data flow, monitors health &amp; implement switchover algorithm for hot standby between main &amp; Redundant Data-link system. The 19&quot; 2U rack mount foldable 12&quot; Display provides network traffic &amp; health of data-link system. The system should be designed using an embedded processor with GB Ethernet with auto switch over logic of hot standby redundancy. It should provide secondary storage for logging network traffic, which is useful during post flight analysis. It should</td><td>Noted</td></tr><tr><td colspan="4">1. Data Link Controller Board</td></tr><tr><td colspan="4">Base Module</td></tr><tr><td>Processing Unit</td><td colspan="2">Xilinx Zynq SoC7045 - XC 7Z045</td><td>Implemented BBP system</td></tr><tr><td>Clock</td><td colspan="2">40MHz TCXO</td><td>Implemented BBP system</td></tr><tr><td>Non-Volatile Memory</td><td colspan="2">NOR flash, 256MB</td><td>Implemented BBP system</td></tr><tr><td>SDRAM</td><td colspan="2">DDR3L, 8GB</td><td>Implemented BBP system</td></tr><tr><td>SD CARD</td><td colspan="2">Internal access only
PUSH-PUSH R/A SMD</td><td>Implemented BBP system</td></tr><tr><td>eMMC</td><td colspan="2">16Gb NAND Flash
(For deployment purposes)</td><td>Implemented BBP system</td></tr><tr><td>EEPROM- Memory</td><td colspan="2">8Kb</td><td>Part of Non-volatile memory on BBP system</td></tr><tr><td colspan="4">RF Module</td></tr><tr><td>Transceiver</td><td colspan="2">AD9361 / AD9364</td><td>Implemented AD9364 on BBP system</td></tr><tr><td colspan="4">Peripherals</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td colspan="2">Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td colspan="2">Gb Ethernet</td><td>2 Ports</td><td colspan="2">By using a ruggedized ethernet switch expander, for Future expansion</td></tr><tr><td colspan="2">USB to UART Bridge</td><td>UARTs at RS232 Level.</td><td colspan="2">Implemented on BBP system and brought out on panel connector</td></tr><tr><td colspan="2">USB interface</td><td>ULPI Interface (USB 2.0)</td><td colspan="2">Implemented on BBP system and brought out on panel connector</td></tr><tr><td colspan="2">USB Expansion</td><td>Use an external ruggedized hub for any larger display monitor via USB.</td><td colspan="2">External USB Supported.</td></tr><tr><td colspan="2">GPS</td><td>UART Interface</td><td colspan="2">Implemented on BBP system and brought out on panel</td></tr><tr><td colspan="2">RS422 Ports</td><td>4 No's</td><td colspan="2">Implemented on BOB card and brought out on panel connector</td></tr><tr><td colspan="5">2. Crypto Module</td></tr><tr><td colspan="3">Implementation of AES Algorithm for Data packets</td><td colspan="4" rowspan="2">Implemented as part of Software ICD system-Design Parameters</td></tr><tr><td colspan="4">Packet Conversion to Data Block for synchronization with AES</td></tr><tr><td colspan="5">3. Auto Swithover Algorithm</td></tr><tr><td colspan="3">Auto Swithover Algorithm for implementation of hot standby redundancy</td><td colspan="4">Implemented as part of Software ICD system, Tests during Rack integration</td></tr><tr><td colspan="3">Development of algorithm based on quality &amp; health of main &amp; redundant data link units</td><td colspan="4">Implemented as part of Software ICD system, Tests during Rack integration</td></tr><tr><td colspan="3">The algorithm should implement PER of Data Link Monitoring System.</td><td colspan="4">Implemented as part of Software ICD system, Tests during Rack integration</td></tr><tr><td colspan="3">Monitor &amp; Provide Data-link systems vitals</td><td colspan="4">Implemented as part of Software ICD system, Tests during Rack integration</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td colspan="2">Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td colspan="3">Switch overtime should be less than 0.5 sec (Switch over time should be programmable)</td><td colspan="2">Implemented as part of Software ICD system, Tests during Rack integration</td></tr><tr><td colspan="5">II. Technical Specifications of Monitoring Unit</td></tr><tr><td>Trans-receiver unit</td><td colspan="2">Consists of One S-Band transmitter and an L-Band receiver</td><td colspan="2">Hardware Design parameter Implemented Tx Gain Stage &amp; Rx Gain Stage.</td></tr><tr><td rowspan="7">1.(a) Transmitter</td><td colspan="2">Frequency: S-band (programmable in steps of 1KHz)</td><td colspan="2">Design parameter As per user requirement</td></tr><tr><td colspan="2">Transmission rate: 4800 bps without FEC or 9600 with FEC</td><td colspan="4">Design parameter As per user requirement &amp; verification trough FTP</td></tr><tr><td colspan="2">Spreading code length: 127 or 31 programmable</td><td colspan="4">Design parameter As per user requirement &amp; verification trough FTP</td></tr><tr><td colspan="2">Signal Bandwidth (with RRC): less than 1MHz @127 code length 4800 data rate. 
Or less than 2MHz @127 code length 9600 Transmission rate 
(FEC ON) 
Signal Bandwidth @31-bit code 4800 data rate less than 0.25 MHz</td><td colspan="4">Design parameter As per user requirement and verification by FTP</td></tr><tr><td colspan="2">No of transmitters: 1 
No of RF ports: 1</td><td colspan="4">Design parameter Implemented (Tx port on Front Pannel)</td></tr><tr><td colspan="2">Input/output data Interface: Ethernet</td><td colspan="4">Design parameter As per user requirement (Ethernet Connector on Front Panel)</td></tr><tr><td colspan="2">Modulation: BPSK</td><td colspan="4">Design parameter As per user requirement</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td colspan="2">Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td rowspan="3"></td><td colspan="2">Output: 1 dBm +/- 1 dB</td><td colspan="2">Design parameter
As per user requirement &amp; verification by FTP</td></tr><tr><td colspan="2">RF Connector: SMA connector for RF output</td><td colspan="2">Design parameter
As per user requirement
(Tx Connector on Front Panel)</td></tr><tr><td colspan="2">Data interface: Ethernet</td><td colspan="2">Design parameter
TX Out Connector</td></tr><tr><td rowspan="2">1.(b) Receiver</td><td colspan="2">Frequency: L-band (programmable in steps of 1 MHz)</td><td colspan="2">Design parameter
As per user requirement</td></tr><tr><td colspan="2">No of Rx antenna ports: 1</td><td colspan="2">Design parameter
As per user requirement
(Rx Connector on Front Panel)</td></tr><tr><td>RF Bandwidth: 100 MHz</td><td colspan="2">No of receivers: 1 and can operate at a different frequency
Each Antenna input is passed through limiter, BPF and LNA and fed to Receiver.</td><td colspan="2">Design parameter
As per user requirement implemented</td></tr><tr><td colspan="3">CDMA decoder: band width Efficient Spread Spectrum</td><td colspan="4">Software Design parameter
As per user requirement</td></tr><tr><td colspan="3">Data Rate: 9600 without FEC, 4800 bps with FEC (1/2 rate convolution coding)</td><td colspan="4">Design parameter
As per user requirement &amp; verification by FTP</td></tr><tr><td colspan="3">Error Correction de Coding: Viterbi soft</td><td colspan="4">Design parameter
As per user requirement</td></tr><tr><td colspan="3">Signal Bandwidth: 15+1 MHz @9600bps data rate 1023 code length, 7.5+1 MHz 9600 bps data rate 511 code length</td><td colspan="4">Design parameter
As per user requirement &amp; verification by FTP</td></tr><tr><td colspan="3">Decoder: Decode single user data from 6 user CDMA data</td><td colspan="4">Design parameter
As per user requirement</td></tr><tr><td colspan="3">Sensitivity: -105 dBm for given 6-user CDMA signal @PER of 1 in 50 Packets without FEC</td><td colspan="4">Design parameter
As per user requirement &amp; verification by FTP</td></tr><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td colspan="2" rowspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td>Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td colspan="3">Dynamic Range: 70 dB or Higher</td><td>Design parameterAs per user requirement</td></tr><tr><td colspan="3">PN Code :511/1023, programmable to other code lengths</td><td>Design parameterAs per user requirement</td></tr><tr><td colspan="3">Modulation: BPSK</td><td>Design parameterAs per user requirement</td></tr><tr><td colspan="3">PER: 1 in 50 Packets at Sensitivity level</td><td>Design parameterAs per user requirement &amp; verification by FTP</td></tr><tr><td colspan="3">Acquisition/Reacquisition Time:&lt; 10 ms</td><td>Design parameterAs per user requirement</td></tr><tr><td colspan="4">III. External Display with Processor</td></tr><tr><td colspan="3">Ruggedized external mountable 12&quot; display with USB control. It comes with an external attachment to the base unit. It is a USB based display &amp; rugged connector. Vendors should provide drivers &amp; develop software to display system parameters on display. Vendor should provide Rack mount Kit for mounting on 19&quot; Rack.</td><td>Design parameterAs per user requirement.Acceptance based on OEM Test Report &amp; COC Only</td></tr><tr><td colspan="4">4. Display Specifications:</td></tr><tr><td rowspan="6">System</td><td>CPU</td><td>Intel CeleronJ6412quadcore</td><td>Intel® Core™ i7-10810U vPro™ Processor which is higher end</td></tr><tr><td>Frequency</td><td>2.0GHz</td><td>1.1 GHz up to 4.9 GHz which is better provided</td></tr><tr><td>L2 Cache</td><td>1.5 MB</td><td>6MB cache is provide which is better</td></tr><tr><td>Memory</td><td>1xSDRAMDDR43200MHz (max 32G)</td><td>Design parameterAs per user requirement</td></tr><tr><td>Storage</td><td>1x2.5&quot; SATA bay (optional, requires a bracket module for installation) 1xM 2slot M key for storage (SATA only 224282280)</td><td>Design parameterAs per user requirement512GB OPAL NVMe SSD (1TB optional)</td></tr><tr><td>Network (LAN)</td><td>2x10/100/1000/2500MbpsEthe met (Intel1225-LM)</td><td>1 Port available</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td>Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td rowspan="3"></td><td>I/O</td><td>2xSerialports: 1xRS-232,1xRS-232/422/485(Adjustable through BIOS)2xUSB2.0,2xUSB3.11xTypeC (USB only)1Xhd</td><td>USB Ports are provided with can use with external USB to Serial adaptor for Serial ports &amp; USB Hub</td></tr><tr><td>Expansion</td><td>1xM22230E-key for wireless card</td><td>Smart Card Reader, NFC, Fingerprint Reader</td></tr><tr><td>Watchdog Timer</td><td>255 timer levels, setup by software</td><td>Higher end Display provided</td></tr><tr><td rowspan="2">Physical Characteristics</td><td>Dimensions</td><td>317x246 x52.7 mm (12.5x 9.7x 2.07 in)</td><td>Higher end Display provided</td></tr><tr><td>Weight</td><td>3.16 kg(8.14lb)</td><td>Better less weight 1.527Kg Design parameter As per user requirement</td></tr><tr><td>OS Support</td><td>OS Support</td><td>Microsoft Windows10(64-bit), Linux, Android</td><td>Supported for windows/Linux/android</td></tr><tr><td rowspan="2">Power Consumption</td><td>Input Voltage</td><td>12-30VDC</td><td>230AC input voltage with Adapter 12-30VDC Provided</td></tr><tr><td>Power Consumption</td><td>36.5W (Windows10,64-bit)</td><td>Design parameter As per user requirement 36.5W or better wattage provided</td></tr><tr><td rowspan="4">LCD</td><td>Display Type</td><td>12&quot;TFTLCD (LED backlight)</td><td>Design parameter As per user requirement</td></tr><tr><td>Resolution</td><td>1024x768</td><td>2160 x 1440 (QHD) LCD is provided</td></tr><tr><td>Viewing Angle</td><td>85(left),85(right),89(up), 89(down)</td><td>Design parameter As per user requirement</td></tr><tr><td>Luminance(c d/m2)</td><td>500</td><td>Better luminance provided1.200cd/m2</td></tr></table>

![](images/10f8c5feab58b29542937f568d02409f5fecb5393cd88752170350d2fdba4e49.jpg)

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td>Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td rowspan="2"></td><td>Contrast Ratio</td><td>1000</td><td>Design parameter
As per user requirement</td></tr><tr><td>Backlight Lifetime</td><td>30,000hr(min.)</td><td>Design parameter
As per user requirement</td></tr><tr><td rowspan="4">Touch Screen</td><td>Touch Type</td><td>ELO5-wire resistive touch; Projected Capacitive Mulli-touch</td><td>10 finger capacitive multi-touchscreen with digitizer is provided.</td></tr><tr><td>Light Transmission</td><td>80±5% at 550nm wavelength; 88±2%</td><td>Better Light Transmission is provided</td></tr><tr><td>Controller</td><td>USB interface</td><td>Provided</td></tr><tr><td>Durability (Touches)</td><td>Greaterthan35million touches in one location without failure: Cover glass&gt;7H</td><td>Design parameter
As per user requirement</td></tr><tr><td rowspan="8">Environment</td><td>Operating Temperature</td><td>-10~50°C(14~122°F)</td><td>MIL-STD 810G, -29 °C to 60 °C qualified</td></tr><tr><td>Storage Temperature</td><td>-20~60°C(-4~140°F)</td><td>MIL-STD 810G qualified</td></tr><tr><td>Relative Humidity</td><td>10~95%@40°C(non-condensing)</td><td>MIL-STD 810G qualified</td></tr><tr><td>Shock</td><td>Operating 10Gpeak acceleration (11ms duration), following EC60068-2-27</td><td>MIL-STD 810G qualified</td></tr><tr><td>Vibration</td><td>Operating Random Vibration Test5-500Hz, 2Gms@withSSD-follow IEC60068-2-64</td><td>MIL-STD 810G qualified</td></tr><tr><td>EMC</td><td>CE, FCC Class B, BSMI, UKCA, VCCI</td><td>MIL-STD 461E qualified</td></tr><tr><td>Safety</td><td>CB, CCC, BSMI, UL, UKCA</td><td>Complied</td></tr><tr><td>Front Panel Protection</td><td>IP66 compliant</td><td>Complied</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td>Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td colspan="4">5. POWER SUPPLY</td></tr><tr><td colspan="3">AC Input: 220-240 V, 50 Hz Supply</td><td>Design parameterAs per user requirement &amp; verification by FTP</td></tr><tr><td colspan="4">6. Connectors</td></tr><tr><td colspan="2">Peripheral functionality</td><td>JTAG, SDCARD (Internal to the unit)</td><td>Hardware Design parameterAvailable in BBP Boar</td></tr><tr><td colspan="2">Power Connector</td><td>Circular ruggedized connector - 38999 series</td><td>6 Pin Power Supply Connector Provided</td></tr><tr><td colspan="2">Peripheral Connector</td><td>4xRS422 ports and Debug console ports on Circular connector</td><td>Design parameterAs per user requirement</td></tr><tr><td colspan="2">USB</td><td>Ruggedized connector on panel. (Customer defined)</td><td>Complied</td></tr><tr><td colspan="2">Power Supply</td><td>6-pin Connector</td><td>6 Pin Power Supply Connector Provided.</td></tr><tr><td colspan="2">Cables</td><td>2-meter cables with mating connector</td><td>will provided</td></tr><tr><td colspan="2">RF connectors</td><td>1 No SMA(F) for Tx RF output1 No SMA(F) for Rx RF input</td><td>Complied</td></tr><tr><td colspan="2">Monitor and control</td><td>Ruggedized Circular connector, RJ45 or customer defined</td><td>Complied</td></tr><tr><td colspan="2">Grounding</td><td>Ground stud</td><td>Complied</td></tr><tr><td colspan="4">SOFTWARE/ICD IMPLEMENTATION</td></tr><tr><td colspan="2">Software</td><td>Linux OS. Vendor to provide C/C++ Code for ICD and external display.C/C++ Code &amp; Vivado Prj/EDK files to be provided. Software for local storage of data &amp; health parameters must be provided.</td><td>Software Design parameterAs per user requirement</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td>Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td colspan="2">ICD Software</td><td>As per RCI ICD Document</td><td>Software Design parameterAs per user requirement</td></tr><tr><td colspan="2">Software Documents</td><td>Docs to be submitted for RCI I V&amp; V.Software clearance by Vendor.</td><td>Software Design parameterAs per user requirement</td></tr><tr><td colspan="4">7. Control &amp; Monitor Signals</td></tr><tr><td colspan="2">Code selection</td><td>loadable PN code by Software</td><td>Software Design parameterAs per user requirement</td></tr><tr><td colspan="2">FEC Selection</td><td>FEC on/off by software selection</td><td>Complied</td></tr><tr><td colspan="2">Frequency selection</td><td>L-Band/S-Band synchronizer by software</td><td>Complied</td></tr><tr><td colspan="2">TM Signals</td><td>2-Buffered RSSI Signals, 2-Buffered PLL Health, 2-buffered decoder Health, 1 Buffered encoder Health</td><td>Complied/Reserved for future purpose</td></tr><tr><td colspan="2">Monitor Firmware</td><td>The unit should update correlator measurement and health data such as correlation values, measured CNR, Measured Doppler Drift, slue rate, software version on TM Rs422 port.</td><td>Software Design parameterAs per user requirement</td></tr><tr><td colspan="2">RS-422 Protocol</td><td>115.2 baud, 8-bit, 1 stop bit, No parity &amp; GB Ethernet</td><td>Design parameterAs per user requirement</td></tr><tr><td colspan="4">8. CONTROLLER INTERFACES</td></tr><tr><td colspan="2">Controller Interfaces</td><td>GB Ethernet: 2 NosRS422: 4 Nos</td><td>Design parameterAs per user requirement</td></tr><tr><td colspan="4">9. MECHANICAL</td></tr><tr><td colspan="2">Material</td><td>Aluminum Alloy 6082-T6/ HE 30 Material Grade</td><td>Design parameterAs per user requirement</td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>Spec. Line#</td><td>PO Line item</td><td>Parameter Description</td><td>Specification Mapping Notes in discussion with User Requirement</td></tr><tr><td colspan="2">Dimensions (excluding display)</td><td>2U, 19&quot; Rack mount unit with sliders &amp; handles.</td><td>Design parameter
As per user requirement</td></tr><tr><td colspan="2">EMI/EMC</td><td>Shielding &amp; Gaskets</td><td>Design parameter
As per user requirement</td></tr><tr><td colspan="2">Weight</td><td>Approx. 10 Kgs</td><td>Design parameter
As per user requirement</td></tr><tr><td colspan="2">Finish</td><td>Yellow chromate - Total unit
External surfaces - powder coat olive green RAL6003 Engraving of legends, logos and connector markings.</td><td>Design parameter
As per user requirement</td></tr><tr><td colspan="2">Adopter Kit</td><td>Attachment kit for 12&quot; rugged display</td><td>Design parameter
As per user requirement</td></tr></table>

[\left\{  {1,2,3,4}\right\}  \text{以}]

$\left( {0 < x}\right) t + x < p - 1 < 1.$

$\frac{a - b}{a + b} = \frac{c - d}{c + d}$

Annexure-G: Failure Analysis Proforma   

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>S. No.</td><td>Item/ Description</td><td>Detail/ Notes</td></tr><tr><td>1</td><td>Name of the Project</td><td></td></tr><tr><td>2</td><td>Failure Reported By</td><td></td></tr><tr><td>3</td><td>Date</td><td></td></tr><tr><td>4</td><td>Sub System</td><td></td></tr><tr><td>4.1</td><td>Drawing No. &amp; Description</td><td></td></tr><tr><td>4.2</td><td>Operating Time</td><td></td></tr><tr><td>4.3</td><td>Module</td><td></td></tr><tr><td>4.4</td><td>Assembly</td><td></td></tr><tr><td>4.5</td><td>Sub-Assembly</td><td></td></tr><tr><td>5</td><td>Failure Observed During</td><td></td></tr><tr><td>5.1</td><td>Pre-Screen Test</td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

<table><tr><td>5.2</td><td>Environmental Test</td><td></td></tr><tr><td>5.3</td><td>Post Screen Test</td><td></td></tr><tr><td>6</td><td>Description of Failure</td><td></td></tr><tr><td>7</td><td>Analysis/ Cause of Failure</td><td>☐ Incorrect Operation☐ Incorrect Handling☐ Improper Design☐ Incorrect Manufacturing☐ Others</td></tr><tr><td>8</td><td>Follow up/ Corrective Action for Defect Rectification</td><td></td></tr><tr><td>9</td><td>Remarks/ Review of Corrective or preventive action taken</td><td></td></tr></table>

<table><tr><td>Lekha Wireless</td><td>RCI (DOFI)</td><td>DR&amp;QA/ RCI</td></tr><tr><td></td><td></td><td></td></tr></table>

<table><tr><td>DLC-MU Rack Mount</td><td colspan="4">DATA LINK CONTROLLER AND MONITORING UNIT QAP &amp; AT, QT DOCUMENT</td></tr><tr><td rowspan="3">Lekha</td><td>Ver.</td><td>00</td><td>Doc. No</td><td>LW/DRDL/LRSAM/DLC-MU/SYS/DOC/QAP &amp; AT,QT/003</td></tr><tr><td>Rev.</td><td>00</td><td rowspan="2" colspan="2">Under IP License or Specific NDA Only</td></tr><tr><td>Date.</td><td>Jan 2025</td></tr></table>

--- END OF DOCUMENT ---